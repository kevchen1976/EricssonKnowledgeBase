#!/usr/bin/env bash
set -euo pipefail

PDF_ROOT=""
AGENT_ROOT=""
PREP_ROOT=""
PYTHON_BIN=""
VERSION="$(date +%Y%m%d%H%M%S)"
ALLOW_FALLBACK=false
START_SERVICES=false
SKIP_PREVIEW=false
YES=false

usage() {
  cat <<'USAGE'
Usage:
  build_new_database.sh --pdf-root PATH --agent-root PATH --prep-root PATH [options]

Required:
  --pdf-root PATH       Directory containing source Ericsson PDFs
  --agent-root PATH     Installed Ericsson Agent directory
  --prep-root PATH      Installed Ericsson Preparation directory

Options:
  --python PATH         Python interpreter; auto-detected when omitted
  --version TOKEN       OpenSearch backing-index token
  --allow-fallback      Allow PyMuPDF when Docling fails
  --skip-preview        Skip offline parent/child preview
  --start-services      Start Ericsson KB and Agent after validation
  --yes                 Required before deleting prepared data and rebuilding
  -h, --help            Show help
USAGE
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --pdf-root) PDF_ROOT=${2:?missing value}; shift 2 ;;
    --agent-root) AGENT_ROOT=${2:?missing value}; shift 2 ;;
    --prep-root) PREP_ROOT=${2:?missing value}; shift 2 ;;
    --python) PYTHON_BIN=${2:?missing value}; shift 2 ;;
    --version) VERSION=${2:?missing value}; shift 2 ;;
    --allow-fallback) ALLOW_FALLBACK=true; shift ;;
    --skip-preview) SKIP_PREVIEW=true; shift ;;
    --start-services) START_SERVICES=true; shift ;;
    --yes) YES=true; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
done

[ -n "$PDF_ROOT" ] && [ -n "$AGENT_ROOT" ] && [ -n "$PREP_ROOT" ] || { usage >&2; exit 2; }
PDF_ROOT=$(realpath "$PDF_ROOT")
AGENT_ROOT=$(realpath "$AGENT_ROOT")
PREP_ROOT=$(realpath "$PREP_ROOT")
[ -d "$PDF_ROOT" ] || { echo "PDF directory not found: $PDF_ROOT" >&2; exit 3; }
PDF_COUNT=$(find "$PDF_ROOT" -maxdepth 1 -type f -iname '*.pdf' -print | wc -l | tr -d '[:space:]')
[ "${PDF_COUNT:-0}" -gt 0 ] || { echo "No PDF files found directly under: $PDF_ROOT" >&2; exit 3; }
[ -f "$AGENT_ROOT/ingest_ericsson.py" ] || { echo "Invalid Agent root: $AGENT_ROOT" >&2; exit 3; }
[ -d "$PREP_ROOT/ericsson_kb" ] || { echo "Invalid Preparation root: $PREP_ROOT" >&2; exit 3; }
[ "$YES" = true ] || { echo "Refusing destructive clean build without --yes." >&2; exit 2; }

if [ -z "$PYTHON_BIN" ]; then
  ROOT=$(dirname "$AGENT_ROOT")
  if [ -x "$ROOT/.venv/bin/python" ]; then
    PYTHON_BIN="$ROOT/.venv/bin/python"
  elif [ -x "$AGENT_ROOT/.venv/bin/python" ]; then
    PYTHON_BIN="$AGENT_ROOT/.venv/bin/python"
  else
    PYTHON_BIN=$(command -v python3 || command -v python)
  fi
fi
[ -x "$PYTHON_BIN" ] || { echo "Python not executable: $PYTHON_BIN" >&2; exit 3; }

PREPARED_ROOT="$AGENT_ROOT/data/prepared"
LOG_ROOT="$AGENT_ROOT/logs"
mkdir -p "$LOG_ROOT"

printf '%s\n' \
  "PDF root      : $PDF_ROOT" \
  "Preparation   : $PREP_ROOT" \
  "Agent         : $AGENT_ROOT" \
  "Python        : $PYTHON_BIN" \
  "PDF documents : $PDF_COUNT" \
  "Index version : $VERSION"

cd "$AGENT_ROOT"
./startup_all_service.sh stop-agent >/dev/null 2>&1 || true
./startup_all_service.sh stop-kb >/dev/null 2>&1 || true

rm -rf "$PREPARED_ROOT"
mkdir -p "$PREPARED_ROOT/markdown"

PREP_ARGS=("$PDF_ROOT" --output-dir "$PREPARED_ROOT" --overwrite)
if [ "$ALLOW_FALLBACK" != true ]; then
  PREP_ARGS+=(--no-fallback)
fi

echo "[1/7] Preparing Markdown, images and filesystem manifests"
(
  cd "$PREP_ROOT"
  PYTHONPATH="$PREP_ROOT${PYTHONPATH:+:$PYTHONPATH}" \
    "$PYTHON_BIN" -m ericsson_kb "${PREP_ARGS[@]}"
) 2>&1 | tee "$LOG_ROOT/preparation_${VERSION}.log"

echo "[2/7] Validating prepared data"
cd "$AGENT_ROOT"
PYTHONPATH="$AGENT_ROOT${PYTHONPATH:+:$PYTHONPATH}" \
  "$PYTHON_BIN" scripts/validate_prepared_data.py data/prepared \
  --output "$LOG_ROOT/prepared_validation_${VERSION}.json"

echo "[3/7] Running strict embedding token preflight"
PYTHONPATH="$AGENT_ROOT${PYTHONPATH:+:$PYTHONPATH}" \
  "$PYTHON_BIN" scripts/check_embedding_lengths.py \
  --prepared-root data/prepared \
  --output "$LOG_ROOT/embedding_length_preflight_${VERSION}.json"

if [ "$SKIP_PREVIEW" != true ]; then
  echo "[4/7] Building and validating offline parent/child preview"
  rm -rf data/prepared/ingestion-preview
  PYTHONPATH="$AGENT_ROOT${PYTHONPATH:+:$PYTHONPATH}" \
    "$PYTHON_BIN" ingest_ericsson.py \
    --prepared-root data/prepared \
    --mode dry-run \
    --skip-embeddings \
    --preview-dir data/prepared/ingestion-preview
  PYTHONPATH="$AGENT_ROOT${PYTHONPATH:+:$PYTHONPATH}" \
    "$PYTHON_BIN" scripts/verify_parent_child_storage.py \
    --preview-dir data/prepared/ingestion-preview \
    --output "$LOG_ROOT/parent_child_preview_${VERSION}.json"
  rm -rf data/prepared/ingestion-preview
else
  echo "[4/7] Offline preview skipped"
fi

echo "[5/7] Checking shared OpenSearch"
PYTHONPATH="$AGENT_ROOT${PYTHONPATH:+:$PYTHONPATH}" \
  "$PYTHON_BIN" scripts/check_opensearch.py

echo "[6/7] Ingesting new parent/child indexes and switching aliases"
PYTHONPATH="$AGENT_ROOT${PYTHONPATH:+:$PYTHONPATH}" \
  "$PYTHON_BIN" ingest_ericsson.py \
  --prepared-root data/prepared \
  --mode rebuild \
  --version "$VERSION" \
  --delete-old \
  2>&1 | tee "$LOG_ROOT/ingestion_${VERSION}.log"

echo "[7/7] Validating live parent/child storage"
PYTHONPATH="$AGENT_ROOT${PYTHONPATH:+:$PYTHONPATH}" \
  "$PYTHON_BIN" scripts/verify_parent_child_storage.py \
  --live \
  --sample-size 200 \
  --output "$LOG_ROOT/parent_child_live_${VERSION}.json"

if [ "$START_SERVICES" = true ]; then
  ./startup_all_service.sh kb
  ./startup_all_service.sh agent
  ./startup_all_service.sh status
fi

echo "Clean Ericsson database build completed: $VERSION"
