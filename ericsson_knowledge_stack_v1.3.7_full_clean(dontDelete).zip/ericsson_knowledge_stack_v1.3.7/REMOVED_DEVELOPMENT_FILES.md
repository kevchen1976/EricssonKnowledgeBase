# Files intentionally omitted from the production-clean bundle

## Agent

- unit-test directory and patch-specific tests;
- patch notes and validation snapshots;
- old package verification scripts;
- one-time legacy manifest-index cleanup utility;
- streaming, numbered-boundary, image and Ollama patch diagnostics;
- duplicate `ericsson_preparation` implementation and its wrappers;
- Docling/development requirements files;
- sample prepared data, SQLite audit records and prior logs.

Operational safety scripts retained:

```text
check_embedding_lengths.py
check_opensearch.py
check_redis.py
cleanup_rebuild_version.py
export_service_settings.py
validate_prepared_data.py
verify_parent_child_storage.py
```

## Preparation

- unit tests and regression fixtures;
- patch notes and validation snapshots;
- old-corpus repair/normalization utilities;
- extraction-only and manifest-only wrappers;
- examples and patch-era shell wrappers.

The complete production preparation implementation remains in `ericsson_kb/`.
