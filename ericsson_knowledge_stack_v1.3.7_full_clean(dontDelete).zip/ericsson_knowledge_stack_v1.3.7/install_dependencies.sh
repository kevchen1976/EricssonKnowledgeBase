#!/usr/bin/env bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
PYTHON_BIN=""
INSTALL_ROOT="$HOME/RANKB_Local_Ericsson"
WITH_GRAPH=false
UPGRADE_PIP=false

usage() {
  cat <<'USAGE'
Usage:
  install_dependencies.sh [options]

Options:
  --python PATH       Python interpreter to use
  --root PATH         Installation root used for auto-detection
  --with-graph        Also install optional Neo4j client dependency
  --upgrade-pip       Upgrade pip/setuptools/wheel first
  -h, --help          Show help

The script installs dependencies only. It does not modify source, data,
OpenSearch, Redis, Ollama, or service processes.
USAGE
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --python) PYTHON_BIN=${2:?missing value}; shift 2 ;;
    --root) INSTALL_ROOT=${2:?missing value}; shift 2 ;;
    --with-graph) WITH_GRAPH=true; shift ;;
    --upgrade-pip) UPGRADE_PIP=true; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
done

INSTALL_ROOT=$(realpath -m "$INSTALL_ROOT")
if [ -z "$PYTHON_BIN" ]; then
  if [ -x "$INSTALL_ROOT/.venv/bin/python" ]; then
    PYTHON_BIN="$INSTALL_ROOT/.venv/bin/python"
  elif command -v python3 >/dev/null 2>&1; then
    PYTHON_BIN=$(command -v python3)
  elif command -v python >/dev/null 2>&1; then
    PYTHON_BIN=$(command -v python)
  fi
fi
[ -n "$PYTHON_BIN" ] && [ -x "$PYTHON_BIN" ] || {
  echo "Python interpreter not found. Use --python PATH." >&2
  exit 3
}

AGENT_REQ="$HERE/ericsson_ran_knowledge_agent_v1.3.7/requirements.txt"
PREP_REQ="$HERE/ericsson_kb_preparation_v1.1.2/requirements.txt"
GRAPH_REQ="$HERE/ericsson_ran_knowledge_agent_v1.3.7/requirements-graph.txt"

printf '%s\n' \
  "Python: $PYTHON_BIN" \
  "Agent requirements: $AGENT_REQ" \
  "Preparation requirements: $PREP_REQ"

if [ "$UPGRADE_PIP" = true ]; then
  "$PYTHON_BIN" -m pip install --upgrade pip setuptools wheel
fi

"$PYTHON_BIN" -m pip install -r "$AGENT_REQ"
"$PYTHON_BIN" -m pip install -r "$PREP_REQ"

if [ "$WITH_GRAPH" = true ]; then
  "$PYTHON_BIN" -m pip install -r "$GRAPH_REQ"
fi

"$PYTHON_BIN" -m pip check

echo "Ericsson Agent and Preparation dependencies installed successfully."
