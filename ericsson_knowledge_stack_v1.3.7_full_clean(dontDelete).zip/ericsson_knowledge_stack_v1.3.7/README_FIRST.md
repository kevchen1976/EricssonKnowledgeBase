# Ericsson Knowledge Stack 1.3.7

This is a complete, production-clean source replacement containing:

```text
ericsson_ran_knowledge_agent_v1.3.7/
ericsson_kb_preparation_v1.1.2/
```

It includes the Ericsson PDF preparation code and the full standalone Agent/KB
source. It intentionally does **not** include proprietary Ericsson PDFs,
prepared corpus data, embedding/reranker model weights, OpenSearch data,
credentials, logs, SQLite audit records, or Python virtual environments.

## Included behavior

- Docling-native reading order and extracted `*_images/` folders.
- Malformed-heading repair and canonical numbered-outline Markdown.
- Front matter/footer removal after useful metadata capture.
- Filesystem JSONL manifests, matching the Nokia storage model.
- OpenSearch parent + vector-child indexes only.
- Strict embedding input-length preflight and pre-encode guard.
- Numbered Ericsson headings as authoritative parent boundaries.
- BM25 + vector recall, RRF, optional reranker, and full-parent evidence.
- Evidence image serving/rendering from `data/prepared/markdown/*_images/`.
- Redis memory, query rewrite, SQLite audit, and detailed RAG logs.
- Nokia-compatible SSE/WebSocket answer streaming.
- Explicit Ollama `num_ctx=32000`, native timing trace, and client trace.
- Optional Neo4j scaffold, disabled by default.

## 1. Verify the downloaded bundle

```bash
chmod +x verify_bundle.sh install_dependencies.sh install_replace.sh build_new_database.sh
./verify_bundle.sh
```

## 2. Replace the existing source trees safely

The recommended installation keeps your current Agent directory name so
existing launch commands continue to work. It preserves:

- `config/services.env` when present;
- the existing `models/` directory;
- an in-project `.venv` when present;
- all replaced files in a timestamped backup.

For a brand-new prepared corpus:

```bash
./install_replace.sh \
  --root "$HOME/RANKB_Local_Ericsson" \
  --agent-target "$HOME/RANKB_Local_Ericsson/ericsson_ran_knowledge_agent_v1.2.2" \
  --prep-target "$HOME/RANKB_Local_Ericsson/ericsson_kb_preparation" \
  --fresh-data \
  --yes
```

The previous source/data is moved under:

```text
$HOME/RANKB_Local_Ericsson/full_stack_backups/<timestamp>/
```

The installer does not delete or modify OpenSearch. A successful database
rebuild later switches the Ericsson aliases atomically and then removes old
Ericsson parent/child backing indexes when `--delete-old` is used.

Review the clean `config/settings.json` plus your preserved
`config/services.env` before building. If older custom values existed only in
`settings.json`, retrieve them from the timestamped backup and move valid
deployment overrides into `config/services.env`.

## 3. Install dependencies into the existing shared virtual environment

```bash
./install_dependencies.sh \
  --python "$HOME/RANKB_Local_Ericsson/.venv/bin/python"
```

Add `--with-graph` only when the optional Neo4j API will be enabled.

## 4. Build a brand-new prepared corpus and Ericsson OpenSearch generation

```bash
./build_new_database.sh \
  --pdf-root /path/to/ericsson_pdfs \
  --agent-root "$HOME/RANKB_Local_Ericsson/ericsson_ran_knowledge_agent_v1.2.2" \
  --prep-root "$HOME/RANKB_Local_Ericsson/ericsson_kb_preparation" \
  --python "$HOME/RANKB_Local_Ericsson/.venv/bin/python" \
  --version 20260907clean01 \
  --start-services \
  --yes
```

The build command performs:

```text
clean data/prepared
 -> Docling Markdown and image extraction
 -> heading repair and canonicalization
 -> per-document and combined manifests
 -> filesystem routing manifests and feature catalog
 -> prepared-data validation
 -> strict embedding-length preflight
 -> offline parent/child preview validation
 -> shared OpenSearch connectivity check
 -> new Ericsson parent/child index rebuild
 -> atomic alias switch
 -> old Ericsson parent/child backing-index cleanup
 -> live parent/child validation
 -> optional KB and Agent startup
```

By default, Docling failure aborts the build. Add `--allow-fallback` only when
PyMuPDF fallback is deliberately acceptable. Add `--skip-preview` only after
the corpus/process is already well established.

## 5. Validate service readiness

```bash
curl -s http://localhost:8102/ready | python -m json.tool
curl -s http://localhost:8100/ready | python -m json.tool
```

Then open:

```text
http://localhost:8100/
```

The Agent directory name may remain `v1.2.2`; the internal package version is
`1.3.7`.

## Manual copy alternative

You may copy the two source directories manually. Preserve the existing
`models/` directory and live `config/services.env`, but do not carry old
`data/prepared/` into a clean build. Then follow
`ericsson_ran_knowledge_agent_v1.3.7/docs/BUILD_NEW_DATABASE.md`.
