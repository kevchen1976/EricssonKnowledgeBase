#!/usr/bin/env bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
ROOT="$HOME/RANKB_Local_Ericsson"
AGENT_TARGET=""
PREP_TARGET=""
PRESERVE_DATA=false
YES=false

usage() {
  cat <<USAGE
Usage:
  $0 [options]

Options:
  --root PATH          Installation root (default: $ROOT)
  --agent-target PATH  Existing/new Agent directory
  --prep-target PATH   Existing/new Preparation directory
  --fresh-data         Install with an empty Agent data directory (default)
  --preserve-data      Preserve the existing Agent data directory
  --yes                Required confirmation
  -h, --help           Show this help

The installer always preserves an existing models directory, config/services.env,
and an in-project .venv. It moves the old source trees into a timestamped backup.
USAGE
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --root) ROOT=${2:?missing value}; shift 2 ;;
    --agent-target) AGENT_TARGET=${2:?missing value}; shift 2 ;;
    --prep-target) PREP_TARGET=${2:?missing value}; shift 2 ;;
    --fresh-data) PRESERVE_DATA=false; shift ;;
    --preserve-data) PRESERVE_DATA=true; shift ;;
    --yes) YES=true; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
done

ROOT=$(realpath -m "$ROOT")
mkdir -p "$ROOT"

if [ -z "$AGENT_TARGET" ]; then
  if [ -d "$ROOT/ericsson_ran_knowledge_agent_v1.2.2" ]; then
    AGENT_TARGET="$ROOT/ericsson_ran_knowledge_agent_v1.2.2"
  else
    existing=$(find "$ROOT" -maxdepth 1 -mindepth 1 -type d -name 'ericsson_ran_knowledge_agent_v*' | sort | tail -1 || true)
    AGENT_TARGET=${existing:-"$ROOT/ericsson_ran_knowledge_agent_v1.3.7"}
  fi
fi
if [ -z "$PREP_TARGET" ]; then
  if [ -d "$ROOT/ericsson_kb_preparation" ]; then
    PREP_TARGET="$ROOT/ericsson_kb_preparation"
  else
    PREP_TARGET="$ROOT/ericsson_kb_preparation_v1.1.2"
  fi
fi
AGENT_TARGET=$(realpath -m "$AGENT_TARGET")
PREP_TARGET=$(realpath -m "$PREP_TARGET")

AGENT_SOURCE="$HERE/ericsson_ran_knowledge_agent_v1.3.7"
PREP_SOURCE="$HERE/ericsson_kb_preparation_v1.1.2"
[ -d "$AGENT_SOURCE" ] || { echo "Missing source: $AGENT_SOURCE" >&2; exit 3; }
[ -d "$PREP_SOURCE" ] || { echo "Missing source: $PREP_SOURCE" >&2; exit 3; }

printf '%s\n' "Install root : $ROOT" "Agent target : $AGENT_TARGET" "Prep target  : $PREP_TARGET" "Preserve data: $PRESERVE_DATA"
if [ "$YES" != true ]; then
  echo "Refusing to modify files without --yes." >&2
  exit 2
fi

STAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_ROOT="$ROOT/full_stack_backups/$STAMP"
mkdir -p "$BACKUP_ROOT"

# Stop only tracked Ericsson services. Shared Nokia/OpenSearch/Redis are untouched.
if [ -x "$AGENT_TARGET/startup_all_service.sh" ]; then
  "$AGENT_TARGET/startup_all_service.sh" stop-agent >/dev/null 2>&1 || true
  "$AGENT_TARGET/startup_all_service.sh" stop-kb >/dev/null 2>&1 || true
  "$AGENT_TARGET/startup_all_service.sh" stop-graph >/dev/null 2>&1 || true
fi

install_tree() {
  local source=$1
  local target=$2
  local label=$3
  local backup="$BACKUP_ROOT/$label"

  if [ -e "$target" ]; then
    mv "$target" "$backup"
  fi
  mkdir -p "$(dirname "$target")"
  cp -a "$source" "$target"

  if [ -d "$backup/.venv" ]; then
    rm -rf "$target/.venv"
    mv "$backup/.venv" "$target/.venv"
  fi
}

install_tree "$AGENT_SOURCE" "$AGENT_TARGET" agent_previous

# Restore deployment settings and local model weights without duplicating them.
if [ -f "$BACKUP_ROOT/agent_previous/config/services.env" ]; then
  cp -a "$BACKUP_ROOT/agent_previous/config/services.env" "$AGENT_TARGET/config/services.env"
fi
if [ -d "$BACKUP_ROOT/agent_previous/models" ]; then
  rm -rf "$AGENT_TARGET/models"
  mv "$BACKUP_ROOT/agent_previous/models" "$AGENT_TARGET/models"
fi
if [ "$PRESERVE_DATA" = true ] && [ -d "$BACKUP_ROOT/agent_previous/data" ]; then
  rm -rf "$AGENT_TARGET/data"
  mv "$BACKUP_ROOT/agent_previous/data" "$AGENT_TARGET/data"
else
  rm -rf "$AGENT_TARGET/data"
  mkdir -p "$AGENT_TARGET/data/prepared/markdown"
  cat > "$AGENT_TARGET/data/README.md" <<'DATAEOF'
# Runtime data

Populate `data/prepared/` with the Ericsson KB Preparation package, then run ingestion.
The SQLite audit database is created at runtime.
DATAEOF
  touch "$AGENT_TARGET/data/prepared/.gitkeep"
fi

# Keep prior logs only in the backup for a fresh, unambiguous runtime.
rm -rf "$AGENT_TARGET/logs" "$AGENT_TARGET/run"
mkdir -p "$AGENT_TARGET/logs" "$AGENT_TARGET/run"
touch "$AGENT_TARGET/logs/.gitkeep" "$AGENT_TARGET/run/.gitkeep"

install_tree "$PREP_SOURCE" "$PREP_TARGET" preparation_previous

chmod +x "$AGENT_TARGET/startup_all_service.sh" "$PREP_TARGET/prepare_ericsson.py"
find "$AGENT_TARGET/scripts" -type f -name '*.py' -exec chmod +x {} +

PYTHON=""
if [ -x "$ROOT/.venv/bin/python" ]; then
  PYTHON="$ROOT/.venv/bin/python"
elif [ -x "$AGENT_TARGET/.venv/bin/python" ]; then
  PYTHON="$AGENT_TARGET/.venv/bin/python"
elif command -v python3 >/dev/null 2>&1; then
  PYTHON=$(command -v python3)
fi

if [ -n "$PYTHON" ]; then
  "$PYTHON" -m compileall -q "$AGENT_TARGET/agent_core" "$AGENT_TARGET/agent_service" \
    "$AGENT_TARGET/kb_api" "$AGENT_TARGET/ingestion" "$PREP_TARGET/ericsson_kb"
fi
bash -n "$AGENT_TARGET/startup_all_service.sh"

cat > "$ROOT/ERICSSON_STACK_INSTALLED.txt" <<INFO
Installed: $(date -Iseconds)
Agent source version: 1.3.7
Preparation source version: 1.1.2
Agent target: $AGENT_TARGET
Preparation target: $PREP_TARGET
Backup: $BACKUP_ROOT
Data preserved: $PRESERVE_DATA
INFO

echo "Installation complete."
echo "Backup: $BACKUP_ROOT"
echo "Next: install requirements, then run build_new_database.sh for a clean database."
