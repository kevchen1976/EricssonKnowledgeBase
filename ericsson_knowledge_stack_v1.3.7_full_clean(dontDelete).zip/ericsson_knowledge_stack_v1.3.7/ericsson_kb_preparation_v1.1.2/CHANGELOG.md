# Changelog

## 1.1.2

- Canonical numbered-outline Markdown.
- Front matter and browser/footer chrome removed after metadata capture.
- Unnumbered visual subheads retained inside numbered semantic sections.

## 1.1.1

- Preserves Docling traversal order instead of sorting raw PDF Y coordinates.

## 1.1.0

- Repairs malformed glossary and implausibly long headings without dropping text.
