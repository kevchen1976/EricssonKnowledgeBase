from __future__ import annotations

"""Conservative post-processing for Docling-generated Markdown headings.

Docling occasionally labels glossary rows or an entire paragraph as a section
heading.  The resulting heading can be hundreds of tokens long and is then
repeated in every child embedding prefix.  This module repairs those structural
errors without deleting or truncating source text.

The repair is intentionally conservative:

* Genuine numbered headings are retained, including headings nested to four or
  more numeric levels.
* Unnumbered headings are retained outside glossary-like sections.
* Within glossary/abbreviation sections, unnumbered headings are demoted to
  ordinary body text until the next non-descendant numbered heading.
* Any heading that is implausibly long is demoted to body text anywhere in the
  document.
* Markdown fenced code blocks are never modified.

The operation is idempotent.  Running it again on repaired Markdown produces no
additional changes.
"""

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

HEADING_RE = re.compile(r"^(?P<marks>#{1,6})[ \t]+(?P<title>.+?)[ \t]*$")
PAGE_MARKER_LINE_RE = re.compile(r"^\s*<!--\s*page:\s*(\d+)\s*-->\s*$", re.I)
FENCE_RE = re.compile(r"^\s*(?P<fence>`{3,}|~{3,})")
NUMBERED_HEADING_RE = re.compile(
    r"^(?P<number>\d+(?:\.\d+){0,8})(?:[.)])?[ \t]+(?P<title>\S.*)$"
)

# Ericsson documents use several variants for glossary-style sections.
GLOSSARY_SECTION_RE = re.compile(
    r"\b(?:"
    r"concepts?\s+and\s+abbreviations?|"
    r"abbreviations?(?:\s+and\s+acronyms?)?|"
    r"acronyms?(?:\s+and\s+abbreviations?)?|"
    r"terms?\s+and\s+definitions?|"
    r"definitions?(?:\s+and\s+abbreviations?)?|"
    r"glossary|terminology"
    r")\b",
    re.I,
)

HEADING_REPAIR_SCHEMA_VERSION = "1.0"
HEADING_REPAIR_VERSION = "1.1.0"
DEFAULT_MAX_HEADING_CHARS = 240
DEFAULT_MAX_HEADING_WORDS = 36
DEFAULT_REPORT_PREVIEW_CHARS = 500


@dataclass(frozen=True)
class HeadingRepairConfig:
    max_heading_chars: int = DEFAULT_MAX_HEADING_CHARS
    max_heading_words: int = DEFAULT_MAX_HEADING_WORDS
    report_preview_chars: int = DEFAULT_REPORT_PREVIEW_CHARS

    def __post_init__(self) -> None:
        if self.max_heading_chars < 40:
            raise ValueError("max_heading_chars must be at least 40")
        if self.max_heading_words < 8:
            raise ValueError("max_heading_words must be at least 8")
        if self.report_preview_chars < 80:
            raise ValueError("report_preview_chars must be at least 80")


@dataclass(frozen=True)
class HeadingRepair:
    line_number: int
    page_number: int
    reason: str
    original_level: int
    original_heading: str
    replacement_text: str
    original_char_count: int
    original_word_count: int
    original_sha256: str

    def to_dict(self, preview_chars: int = DEFAULT_REPORT_PREVIEW_CHARS) -> Dict[str, object]:
        def preview(value: str) -> str:
            value = value.replace("\n", " ").strip()
            if len(value) <= preview_chars:
                return value
            return value[: max(0, preview_chars - 18)].rstrip() + " ...[truncated]"

        data = asdict(self)
        data["original_heading"] = preview(self.original_heading)
        data["replacement_text"] = preview(self.replacement_text)
        return data


@dataclass
class HeadingRepairResult:
    markdown: str
    repairs: List[HeadingRepair] = field(default_factory=list)
    source_name: str = ""
    original_sha256: str = ""
    repaired_sha256: str = ""
    config: HeadingRepairConfig = field(default_factory=HeadingRepairConfig)

    @property
    def changed(self) -> bool:
        return self.original_sha256 != self.repaired_sha256

    def to_report_dict(self) -> Dict[str, object]:
        reason_counts: Dict[str, int] = {}
        for repair in self.repairs:
            reason_counts[repair.reason] = reason_counts.get(repair.reason, 0) + 1
        return {
            "source": self.source_name,
            "changed": self.changed,
            "repair_count": len(self.repairs),
            "reason_counts": reason_counts,
            "original_sha256": self.original_sha256,
            "repaired_sha256": self.repaired_sha256,
            "repairs": [
                repair.to_dict(self.config.report_preview_chars)
                for repair in self.repairs
            ],
        }


@dataclass(frozen=True)
class _GlossaryContext:
    level: int
    number: Optional[Tuple[int, ...]]
    heading: str


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _word_count(text: str) -> int:
    return len(re.findall(r"\S+", text or ""))


def _number_tuple(title: str) -> Optional[Tuple[int, ...]]:
    match = NUMBERED_HEADING_RE.match(title.strip())
    if not match:
        return None
    return tuple(int(part) for part in match.group("number").split("."))


def _is_descendant(number: Tuple[int, ...], root: Tuple[int, ...]) -> bool:
    return len(number) > len(root) and number[: len(root)] == root


def _is_glossary_section(title: str) -> bool:
    return bool(GLOSSARY_SECTION_RE.search(title or ""))


def _is_implausibly_long(title: str, config: HeadingRepairConfig) -> bool:
    return (
        len(title) > config.max_heading_chars
        or _word_count(title) > config.max_heading_words
    )


def _replacement_for_heading(title: str) -> str:
    # Keep every source character; only remove Markdown heading semantics.
    return title.strip()


def _make_repair(
    *,
    line_number: int,
    page_number: int,
    reason: str,
    level: int,
    title: str,
) -> HeadingRepair:
    replacement = _replacement_for_heading(title)
    return HeadingRepair(
        line_number=line_number,
        page_number=page_number,
        reason=reason,
        original_level=level,
        original_heading=title,
        replacement_text=replacement,
        original_char_count=len(title),
        original_word_count=_word_count(title),
        original_sha256=_sha256_text(title),
    )


def repair_markdown_headings(
    markdown: str,
    *,
    source_name: str = "",
    config: Optional[HeadingRepairConfig] = None,
) -> HeadingRepairResult:
    """Repair malformed headings while preserving all source content.

    The returned Markdown is normalized only for newline consistency.  No text
    is discarded and no body text is truncated.
    """

    config = config or HeadingRepairConfig()
    original = (markdown or "").replace("\r\n", "\n").replace("\r", "\n")
    lines = original.splitlines(keepends=True)
    repaired_lines: List[str] = []
    repairs: List[HeadingRepair] = []

    page_number = 1
    glossary: Optional[_GlossaryContext] = None
    active_fence: Optional[str] = None

    for line_number, raw_line in enumerate(lines, 1):
        # Keep the original newline sequence after replacing only heading syntax.
        newline = "\n" if raw_line.endswith("\n") else ""
        line = raw_line[:-1] if newline else raw_line
        stripped = line.strip()

        page_match = PAGE_MARKER_LINE_RE.match(stripped)
        if page_match:
            page_number = int(page_match.group(1))
            repaired_lines.append(raw_line)
            continue

        fence_match = FENCE_RE.match(line)
        if fence_match:
            fence = fence_match.group("fence")
            fence_char = fence[0]
            if active_fence is None:
                active_fence = fence_char
            elif active_fence == fence_char:
                active_fence = None
            repaired_lines.append(raw_line)
            continue

        if active_fence is not None:
            repaired_lines.append(raw_line)
            continue

        match = HEADING_RE.match(line)
        if not match:
            repaired_lines.append(raw_line)
            continue

        marks = match.group("marks")
        title = match.group("title").strip()
        level = len(marks)
        number = _number_tuple(title)

        # A non-descendant numbered heading closes the glossary section.  A
        # descendant numbered heading (for example 1.3.1) is retained as a real
        # structural subsection.
        if glossary is not None and number is not None:
            if glossary.number is None:
                glossary = None
            elif number != glossary.number and not _is_descendant(number, glossary.number):
                glossary = None

        reason: Optional[str] = None
        if _is_implausibly_long(title, config):
            reason = "implausibly_long_heading"
        elif glossary is not None and number is None:
            reason = "glossary_entry_heading"

        if reason:
            repair = _make_repair(
                line_number=line_number,
                page_number=page_number,
                reason=reason,
                level=level,
                title=title,
            )
            repairs.append(repair)
            repaired_lines.append(repair.replacement_text + newline)
            continue

        repaired_lines.append(raw_line)

        if _is_glossary_section(title):
            glossary = _GlossaryContext(
                level=level,
                number=number,
                heading=title,
            )

    repaired = "".join(repaired_lines)

    return HeadingRepairResult(
        markdown=repaired,
        repairs=repairs,
        source_name=source_name,
        original_sha256=_sha256_text(original),
        repaired_sha256=_sha256_text(repaired),
        config=config,
    )


def _atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.heading-repair.tmp")
    temp.write_text(text, encoding="utf-8")
    temp.replace(path)


def _backup_path(path: Path, backup_dir: Path, original_sha256: str) -> Path:
    digest = original_sha256[:12]
    return backup_dir / f"{path.stem}.{digest}.before-heading-repair{path.suffix}"


def repair_markdown_file(
    path: Path,
    *,
    backup_dir: Optional[Path] = None,
    write: bool = True,
    config: Optional[HeadingRepairConfig] = None,
) -> Tuple[HeadingRepairResult, Optional[Path]]:
    """Repair a Markdown file atomically and optionally retain one backup.

    The backup filename includes a digest of the original content, so repeated
    runs are idempotent and do not create an unbounded series of copies.
    """

    path = Path(path)
    original = path.read_text(encoding="utf-8")
    result = repair_markdown_headings(
        original,
        source_name=path.name,
        config=config,
    )
    backup_path: Optional[Path] = None

    if result.changed and write:
        if backup_dir is not None:
            backup_dir = Path(backup_dir)
            backup_dir.mkdir(parents=True, exist_ok=True)
            backup_path = _backup_path(path, backup_dir, result.original_sha256)
            if not backup_path.exists():
                shutil.copy2(path, backup_path)
        _atomic_write_text(path, result.markdown)

    return result, backup_path


def build_heading_repair_report(
    results: Sequence[HeadingRepairResult],
    *,
    backup_paths: Optional[Dict[str, Path]] = None,
) -> Dict[str, object]:
    backup_paths = backup_paths or {}
    documents = []
    reason_counts: Dict[str, int] = {}
    total_repairs = 0
    changed_documents = 0

    for result in results:
        item = result.to_report_dict()
        backup = backup_paths.get(result.source_name)
        if backup is not None:
            item["backup"] = str(backup)
        documents.append(item)
        total_repairs += len(result.repairs)
        if result.changed:
            changed_documents += 1
        for repair in result.repairs:
            reason_counts[repair.reason] = reason_counts.get(repair.reason, 0) + 1

    return {
        "schema_version": HEADING_REPAIR_SCHEMA_VERSION,
        "repair_version": HEADING_REPAIR_VERSION,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "documents_scanned": len(results),
        "documents_changed": changed_documents,
        "heading_repairs": total_repairs,
        "reason_counts": reason_counts,
        "content_dropped": False,
        "documents": documents,
    }


def write_heading_repair_report(
    path: Path,
    results: Sequence[HeadingRepairResult],
    *,
    backup_paths: Optional[Dict[str, Path]] = None,
) -> Path:
    payload = build_heading_repair_report(results, backup_paths=backup_paths)
    _atomic_write_text(
        Path(path),
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
    )
    return Path(path)
