"""Ericsson documentation preparation pipeline."""

from .canonical_markdown import (
    CANONICAL_MARKDOWN_VERSION,
    canonical_metadata,
    canonicalize_markdown,
    canonicalize_markdown_file,
)
from .heading_repair import (
    HEADING_REPAIR_VERSION,
    HeadingRepairConfig,
    repair_markdown_file,
    repair_markdown_headings,
)
from .ids import (
    find_feature_ids,
    find_package_ids,
    normalize_feature_id,
    normalize_package_id,
)

__version__ = "1.1.2"

__all__ = [
    "CANONICAL_MARKDOWN_VERSION",
    "HEADING_REPAIR_VERSION",
    "HeadingRepairConfig",
    "canonical_metadata",
    "canonicalize_markdown",
    "canonicalize_markdown_file",
    "find_feature_ids",
    "find_package_ids",
    "normalize_feature_id",
    "normalize_package_id",
    "repair_markdown_file",
    "repair_markdown_headings",
]
