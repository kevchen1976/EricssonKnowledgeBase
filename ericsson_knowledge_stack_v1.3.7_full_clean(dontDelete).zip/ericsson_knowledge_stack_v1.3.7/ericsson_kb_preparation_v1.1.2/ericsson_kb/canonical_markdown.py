from __future__ import annotations

"""Canonicalize Ericsson CPI Markdown around numbered document outlines.

The extractor can label visual subheads (for example ``Summary`` or
``Additional Information``) with the same Markdown heading level as real
numbered sections.  It can also emit browser/document chrome before the first
real section and footer chrome after the content.  This module converts that
layout-oriented Markdown into a deterministic RAG representation:

* numbered outline headings (``1``, ``3.1``, ``4.2.3``...) are the only
  structural Markdown headings when a numbered outline is present;
* unnumbered visual headings inside such documents are demoted to bold body
  labels so their text stays with the surrounding numbered parent;
* front matter before the first numbered heading is removed from RAG content;
* strict Ericsson/browser footer chrome is removed;
* page markers are retained so page_start/page_end evidence remains correct;
* compact metadata recovered from removed front matter is retained in a
  machine-readable HTML comment that the section parser ignores.

For documents without a numbered outline, the function leaves heading
structure unchanged apart from strict footer-chrome removal.  The operation is
idempotent.
"""

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
from typing import Dict, List, Optional, Tuple

from .ids import find_feature_ids, find_package_ids
from .markdown import normalize_markdown

CANONICAL_MARKDOWN_VERSION = "1.1.2"
CANONICAL_SCHEMA_VERSION = "1.0"

PAGE_MARKER_RE = re.compile(r"^\s*<!--\s*page:\s*(\d+)\s*-->\s*$", re.I)
HEADING_RE = re.compile(r"^(?P<marks>#{1,6})[ \t]+(?P<title>.+?)[ \t]*$")
NUMBERED_TITLE_RE = re.compile(
    r"^(?P<number>\d+(?:\.\d+){0,8})(?:[.)])?[ \t]+(?P<title>\S.*)$"
)
CANONICAL_META_RE = re.compile(
    r"^\s*<!--\s*ericsson-canonical-meta:\s*(\{.*\})\s*-->\s*$",
    re.I,
)

# Strict chrome only. These expressions intentionally do not match general
# prose containing the words "legal", "Ericsson CPI", or dates.
STRICT_CHROME_RES = (
    re.compile(r"^\s*(?:#{1,6}\s+)?Legal\s*\|\s*©\s*Ericsson\s+AB\b.*$", re.I),
    re.compile(r"^\s*Ericsson\s+CPI\s*\d+\s*/\s*\d+\s*$", re.I),
    re.compile(r"^\s*about:blank\s+\d+\s*/\s*\d+\s*$", re.I),
    re.compile(
        r"^\s*\d{1,2}/\d{1,2}/\d{2,4},\s*\d{1,2}:\d{2}\s*(?:AM|PM)\s*\S.*$",
        re.I,
    ),
)

FRONT_MATTER_SKIP_TITLES = {
    "contents",
    "table of contents",
}
DOCUMENT_FAMILY_RE = re.compile(
    r"^(?:feature description|commercial product description|solution guideline)\b",
    re.I,
)


@dataclass(frozen=True)
class CanonicalChange:
    line_number: int
    page_number: int
    action: str
    original: str
    replacement: str = ""


@dataclass
class CanonicalizationResult:
    markdown: str
    source_name: str = ""
    numbered_outline: bool = False
    first_numbered_heading: str = ""
    metadata: Dict[str, object] = field(default_factory=dict)
    changes: List[CanonicalChange] = field(default_factory=list)
    original_sha256: str = ""
    canonical_sha256: str = ""

    @property
    def changed(self) -> bool:
        return self.original_sha256 != self.canonical_sha256

    def to_dict(self) -> Dict[str, object]:
        counts: Dict[str, int] = {}
        for change in self.changes:
            counts[change.action] = counts.get(change.action, 0) + 1
        return {
            "source_name": self.source_name,
            "version": CANONICAL_MARKDOWN_VERSION,
            "schema_version": CANONICAL_SCHEMA_VERSION,
            "numbered_outline": self.numbered_outline,
            "first_numbered_heading": self.first_numbered_heading,
            "changed": self.changed,
            "original_sha256": self.original_sha256,
            "canonical_sha256": self.canonical_sha256,
            "metadata": self.metadata,
            "change_counts": counts,
            "changes": [asdict(x) for x in self.changes],
        }


def _sha256(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8")).hexdigest()


def _is_chrome(line: str) -> bool:
    return any(rx.match(line or "") for rx in STRICT_CHROME_RES)


def _numbered_heading(line: str) -> Optional[Tuple[str, str, int]]:
    hm = HEADING_RE.match(line or "")
    if not hm:
        return None
    title = hm.group("title").strip()
    nm = NUMBERED_TITLE_RE.match(title)
    if not nm:
        return None
    number = nm.group("number")
    clean_title = nm.group("title").strip()
    level = min(6, 1 + number.count("."))
    return number, clean_title, level


def _existing_meta(lines: List[str]) -> Dict[str, object]:
    for line in lines[:40]:
        m = CANONICAL_META_RE.match(line)
        if not m:
            continue
        try:
            value = json.loads(m.group(1))
            return value if isinstance(value, dict) else {}
        except Exception:
            return {}
    return {}


def _candidate_document_title(preamble_lines: List[str], source_name: str) -> str:
    candidates: List[str] = []
    for raw in preamble_lines:
        hm = HEADING_RE.match(raw.strip())
        if not hm:
            continue
        title = re.sub(r"\s+", " ", hm.group("title")).strip()
        if not title or title.lower() in FRONT_MATTER_SKIP_TITLES:
            continue
        if DOCUMENT_FAMILY_RE.match(title):
            continue
        if _is_chrome(title):
            continue
        if len(title) <= 180:
            candidates.append(title)
    if candidates:
        return candidates[-1]
    stem = Path(source_name).stem if source_name else ""
    stem = re.sub(r"\s*\(\d+\)\s*$", "", stem).strip()
    return stem


def _front_matter_metadata(preamble: str, source_name: str, existing: Dict[str, object]) -> Dict[str, object]:
    metadata = dict(existing)
    lines = preamble.splitlines()
    title = _candidate_document_title(lines, source_name)
    if title:
        metadata.setdefault("title", title)
    feature_ids = find_feature_ids(preamble)
    package_ids = find_package_ids(preamble)
    if feature_ids:
        metadata["front_matter_feature_ids"] = feature_ids
    if package_ids:
        metadata["front_matter_package_ids"] = package_ids
    metadata["canonical_version"] = CANONICAL_MARKDOWN_VERSION
    return metadata


def _meta_comment(metadata: Dict[str, object]) -> str:
    if not metadata:
        return ""
    payload = json.dumps(metadata, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return f"<!-- ericsson-canonical-meta: {payload} -->"


def canonical_metadata(markdown: str) -> Dict[str, object]:
    """Return metadata written by :func:`canonicalize_markdown`."""
    for line in (markdown or "").splitlines()[:40]:
        m = CANONICAL_META_RE.match(line)
        if m:
            try:
                value = json.loads(m.group(1))
                return value if isinstance(value, dict) else {}
            except Exception:
                return {}
    return {}


def canonicalize_markdown(markdown: str, *, source_name: str = "") -> CanonicalizationResult:
    original = (markdown or "").replace("\r\n", "\n").replace("\r", "\n")
    raw_lines = original.splitlines()
    existing_meta = _existing_meta(raw_lines)

    numbered_positions: List[int] = []
    for idx, line in enumerate(raw_lines):
        if _numbered_heading(line.strip()):
            numbered_positions.append(idx)

    # A single numbered heading can be a list-like false positive. Requiring at
    # least two gives us a document-outline signal while still supporting small
    # two-section CPI documents.
    numbered_outline = len(numbered_positions) >= 2
    changes: List[CanonicalChange] = []

    if not numbered_outline:
        out: List[str] = []
        page = 1
        for lineno, line in enumerate(raw_lines, 1):
            pm = PAGE_MARKER_RE.match(line)
            if pm:
                page = int(pm.group(1))
                out.append(line)
                continue
            if _is_chrome(line):
                changes.append(CanonicalChange(lineno, page, "remove_footer_chrome", line))
                continue
            out.append(line)
        canonical = normalize_markdown("\n".join(out))
        return CanonicalizationResult(
            markdown=canonical,
            source_name=source_name,
            numbered_outline=False,
            metadata=existing_meta,
            changes=changes,
            original_sha256=_sha256(original),
            canonical_sha256=_sha256(canonical),
        )

    first_idx = numbered_positions[0]
    first_info = _numbered_heading(raw_lines[first_idx].strip())
    assert first_info is not None
    first_number, first_title, _ = first_info
    first_heading = f"{first_number} {first_title}"

    preamble_lines = raw_lines[:first_idx]
    preamble = "\n".join(preamble_lines)
    metadata = _front_matter_metadata(preamble, source_name, existing_meta)

    # Retain the last page marker before the first numbered section. This keeps
    # evidence page accounting correct while removing all front-matter content.
    leading_page_marker = ""
    leading_page = 1
    for line in preamble_lines:
        pm = PAGE_MARKER_RE.match(line)
        if pm:
            leading_page_marker = f"<!-- page: {int(pm.group(1))} -->"
            leading_page = int(pm.group(1))

    out: List[str] = []
    if leading_page_marker:
        out.append(leading_page_marker)
    meta_line = _meta_comment(metadata)
    if meta_line:
        out.append(meta_line)

    page = leading_page
    for lineno, line in enumerate(raw_lines[first_idx:], first_idx + 1):
        stripped = line.strip()
        pm = PAGE_MARKER_RE.match(stripped)
        if pm:
            page = int(pm.group(1))
            # Avoid duplicate page marker when first section is on the same page
            # as the retained preamble marker.
            marker = f"<!-- page: {page} -->"
            if not out or out[-1] != marker:
                out.append(marker)
            continue

        if CANONICAL_META_RE.match(stripped):
            # Existing metadata comment is emitted once at the top.
            continue

        if _is_chrome(stripped):
            changes.append(CanonicalChange(lineno, page, "remove_footer_chrome", line))
            continue

        numbered = _numbered_heading(stripped)
        if numbered:
            number, title, level = numbered
            replacement = f"{'#' * level} {number} {title}"
            if replacement != stripped:
                changes.append(CanonicalChange(lineno, page, "normalize_numbered_heading", line, replacement))
            out.append(replacement)
            continue

        hm = HEADING_RE.match(stripped)
        if hm:
            title = hm.group("title").strip()
            replacement = f"**{title}**"
            changes.append(CanonicalChange(lineno, page, "demote_unnumbered_heading", line, replacement))
            out.append(replacement)
            continue

        out.append(line)

    # Report front matter as one logical removal instead of one change per line.
    removed_preamble = [x for x in preamble_lines if x.strip() and not PAGE_MARKER_RE.match(x.strip()) and not CANONICAL_META_RE.match(x.strip())]
    if removed_preamble:
        changes.insert(
            0,
            CanonicalChange(
                line_number=1,
                page_number=leading_page,
                action="remove_front_matter",
                original="\n".join(removed_preamble)[:2000],
                replacement=meta_line,
            ),
        )

    canonical = normalize_markdown("\n".join(out))
    return CanonicalizationResult(
        markdown=canonical,
        source_name=source_name,
        numbered_outline=True,
        first_numbered_heading=first_heading,
        metadata=metadata,
        changes=changes,
        original_sha256=_sha256(original),
        canonical_sha256=_sha256(canonical),
    )


def _backup_path(path: Path, backup_dir: Path, digest: str) -> Path:
    return backup_dir / f"{path.stem}.{digest[:12]}.before-canonicalization{path.suffix}"


def canonicalize_markdown_file(
    path: Path,
    *,
    backup_dir: Optional[Path] = None,
    write: bool = True,
) -> Tuple[CanonicalizationResult, Optional[Path]]:
    original = path.read_text(encoding="utf-8")
    result = canonicalize_markdown(original, source_name=path.name)
    backup: Optional[Path] = None
    if write and result.changed:
        if backup_dir is not None:
            backup_dir.mkdir(parents=True, exist_ok=True)
            backup = _backup_path(path, backup_dir, result.original_sha256)
            if not backup.exists():
                backup.write_text(original, encoding="utf-8")
        temp = path.with_name(f".{path.name}.canonical.tmp")
        temp.write_text(result.markdown, encoding="utf-8")
        temp.replace(path)
    return result, backup


def write_canonicalization_report(
    path: Path,
    results: List[CanonicalizationResult],
    *,
    backup_paths: Optional[Dict[str, Path]] = None,
) -> Path:
    backup_paths = backup_paths or {}
    changed = [r for r in results if r.changed]
    payload = {
        "schema_version": CANONICAL_SCHEMA_VERSION,
        "canonical_version": CANONICAL_MARKDOWN_VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "documents_scanned": len(results),
        "documents_changed": len(changed),
        "numbered_outline_documents": sum(r.numbered_outline for r in results),
        "front_matter_removed": sum(any(c.action == "remove_front_matter" for c in r.changes) for r in results),
        "unnumbered_headings_demoted": sum(sum(c.action == "demote_unnumbered_heading" for c in r.changes) for r in results),
        "footer_chrome_removed": sum(sum(c.action == "remove_footer_chrome" for c in r.changes) for r in results),
        "content_policy": {
            "numbered_headings_are_structural": True,
            "unnumbered_headings_become_body_labels": True,
            "page_markers_retained": True,
            "front_matter_removed_from_rag_content": True,
            "metadata_comment_retained": True,
        },
        "documents": [],
    }
    for result in results:
        item = result.to_dict()
        backup = backup_paths.get(result.source_name)
        item["backup"] = str(backup) if backup else ""
        payload["documents"].append(item)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return path
