from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import List, Sequence

from .analyze import analyze_markdown
from .canonical_markdown import (
    CanonicalizationResult,
    canonicalize_markdown_file,
    write_canonicalization_report,
)
from .extract_docling import extract_pdf
from .heading_repair import (
    HeadingRepairResult,
    repair_markdown_file,
    repair_markdown_headings,
    write_heading_repair_report,
)
from .manifest import manifest_records, write_jsonl, write_sidecar
from .models import DocumentAnalysis
from .routing import build_routing

log = logging.getLogger(__name__)


def iter_pdfs(input_path: Path) -> List[Path]:
    if input_path.is_file() and input_path.suffix.lower() == ".pdf":
        return [input_path]
    return sorted(input_path.glob("*.pdf")) if input_path.is_dir() else []


def feature_catalog_rows(analyses: Sequence[DocumentAnalysis]) -> List[dict]:
    catalog: List[dict] = []
    for analysis in analyses:
        if analysis.feature_variants:
            for variant in analysis.feature_variants:
                catalog.append({
                    "feature_id": variant.feature_id,
                    "feature_title": variant.feature_name,
                    "access_type": variant.access_type,
                    "package_id": variant.package_id,
                    "package_title": variant.package_name,
                    "node_type": variant.node_type,
                    "source": analysis.markdown_path.name,
                })
        elif analysis.owner_feature_id:
            catalog.append({
                "feature_id": analysis.owner_feature_id,
                "feature_title": analysis.feature_title or analysis.title,
                "access_type": ", ".join(analysis.access_types),
                "package_id": analysis.primary_package_id,
                "package_title": ", ".join(analysis.package_names),
                "node_type": ", ".join(analysis.node_types),
                "source": analysis.markdown_path.name,
            })
    return catalog


def write_feature_catalog(analyses: Sequence[DocumentAnalysis], output_dir: Path) -> Path:
    path = output_dir / "ericsson_feature_catalog.json"
    path.write_text(
        json.dumps(feature_catalog_rows(analyses), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return path


def rebuild_manifests_from_markdown(
    markdown_files: Sequence[Path],
    output_dir: Path,
    *,
    overwrite_routing: bool = True,
) -> dict:
    """Rebuild all manifest outputs from a set of prepared Markdown files."""

    analyses: List[DocumentAnalysis] = []
    all_records = []
    canonical_results: List[CanonicalizationResult] = []
    canonical_backups: dict[str, Path] = {}
    canonical_backup_dir = output_dir / "canonicalization-backups"
    for md_path in sorted(markdown_files):
        canonical_result, canonical_backup = canonicalize_markdown_file(
            md_path,
            backup_dir=canonical_backup_dir,
            write=True,
        )
        canonical_results.append(canonical_result)
        if canonical_backup is not None:
            canonical_backups[md_path.name] = canonical_backup
        analysis = analyze_markdown(md_path)
        analyses.append(analysis)
        write_sidecar(analysis)
        records = manifest_records(analysis)
        all_records.extend(records)
        write_jsonl(
            output_dir / "manifests" / f"{md_path.stem}.manifest.jsonl",
            records,
        )

    combined = output_dir / "combined_manifest.jsonl"
    write_jsonl(combined, all_records)
    index = build_routing(combined, output_dir, overwrite=overwrite_routing)
    write_feature_catalog(analyses, output_dir)
    canonical_report = write_canonicalization_report(
        output_dir / "canonicalization_report.json",
        canonical_results,
        backup_paths=canonical_backups,
    )
    return {
        "documents": len(analyses),
        "records": len(all_records),
        "manifest_index": index,
        "canonicalization": {
            "documents_changed": sum(r.changed for r in canonical_results),
            "report": str(canonical_report),
        },
    }


def run_pipeline(
    input_path: Path,
    output_dir: Path,
    backend: str | None = None,
    overwrite: bool = False,
    allow_fallback: bool = True,
) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    markdown_dir = output_dir / "markdown"
    markdown_dir.mkdir(exist_ok=True)
    analyses: List[DocumentAnalysis] = []
    all_records = []
    repair_results: List[HeadingRepairResult] = []
    backup_paths: dict[str, Path] = {}
    backup_dir = output_dir / "heading-repair-backups"
    canonical_results: List[CanonicalizationResult] = []
    canonical_backup_paths: dict[str, Path] = {}
    canonical_backup_dir = output_dir / "canonicalization-backups"

    for pdf in iter_pdfs(input_path):
        md_path = markdown_dir / f"{pdf.stem}.md"
        if md_path.exists() and not overwrite:
            log.info("Reusing markdown: %s", md_path)
            repair_result, backup = repair_markdown_file(
                md_path,
                backup_dir=backup_dir,
                write=True,
            )
            page_count = 0
            if repair_result.repairs:
                log.warning(
                    "Repaired %d malformed heading(s) in reused Markdown %s",
                    len(repair_result.repairs),
                    md_path.name,
                )
            if backup is not None:
                backup_paths[md_path.name] = backup
            canonical_result, canonical_backup = canonicalize_markdown_file(
                md_path,
                backup_dir=canonical_backup_dir,
                write=True,
            )
            if canonical_backup is not None:
                canonical_backup_paths[md_path.name] = canonical_backup
        else:
            extraction = extract_pdf(
                pdf,
                output_dir,
                backend=backend,
                allow_fallback=allow_fallback,
            )
            md_path.write_text(extraction.markdown, encoding="utf-8")
            page_count = extraction.page_count
            log.info("Extracted %s with %s", pdf.name, extraction.engine)
            repair_result = extraction.heading_repair or repair_markdown_headings(
                extraction.markdown,
                source_name=md_path.name,
            )
            repair_result.source_name = md_path.name
            canonical_result = extraction.canonicalization
            if canonical_result is None:
                canonical_result, canonical_backup = canonicalize_markdown_file(
                    md_path,
                    backup_dir=canonical_backup_dir,
                    write=True,
                )
                if canonical_backup is not None:
                    canonical_backup_paths[md_path.name] = canonical_backup
            canonical_result.source_name = md_path.name

        repair_results.append(repair_result)
        canonical_results.append(canonical_result)

        analysis = analyze_markdown(md_path, source_pdf=pdf, page_count=page_count)
        analyses.append(analysis)
        write_sidecar(analysis)
        records = manifest_records(analysis)
        all_records.extend(records)
        write_jsonl(output_dir / "manifests" / f"{pdf.stem}.manifest.jsonl", records)

    combined = output_dir / "combined_manifest.jsonl"
    write_jsonl(combined, all_records)
    index = build_routing(combined, output_dir, overwrite=overwrite)
    write_feature_catalog(analyses, output_dir)

    report_path = write_heading_repair_report(
        output_dir / "heading_repair_report.json",
        repair_results,
        backup_paths=backup_paths,
    )
    total_repairs = sum(len(result.repairs) for result in repair_results)
    repaired_documents = sum(bool(result.repairs) for result in repair_results)
    canonical_report_path = write_canonicalization_report(
        output_dir / "canonicalization_report.json",
        canonical_results,
        backup_paths=canonical_backup_paths,
    )

    return {
        "documents": len(analyses),
        "records": len(all_records),
        "manifest_index": index,
        "heading_repair": {
            "documents_repaired": repaired_documents,
            "repairs": total_repairs,
            "content_dropped": False,
            "report": str(report_path),
        },
        "canonicalization": {
            "documents_changed": sum(r.changed for r in canonical_results),
            "numbered_outline_documents": sum(r.numbered_outline for r in canonical_results),
            "report": str(canonical_report_path),
        },
    }
