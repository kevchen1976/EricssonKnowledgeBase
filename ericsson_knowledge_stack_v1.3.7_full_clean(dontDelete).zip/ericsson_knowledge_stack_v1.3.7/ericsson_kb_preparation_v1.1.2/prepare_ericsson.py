#!/usr/bin/env python3
"""Convenience entry point for Ericsson PDF preparation."""
from ericsson_kb.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
