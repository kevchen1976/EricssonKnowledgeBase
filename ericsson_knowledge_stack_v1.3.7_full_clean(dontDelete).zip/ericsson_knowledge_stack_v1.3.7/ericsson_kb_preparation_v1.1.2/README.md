# Ericsson KB Preparation 1.1.2

Converts Ericsson CPI PDFs into canonical Markdown, extracted evidence images,
metadata, manifests and filesystem routing indexes for Ericsson RAN Knowledge
Agent 1.3.7.

## Pipeline

```text
PDF
 -> Docling layout extraction
 -> Docling-native reading order
 -> page markers and image folders
 -> malformed-heading repair
 -> front-matter/footer removal
 -> numbered-outline canonicalization
 -> document analysis
 -> per-document manifests
 -> combined_manifest.jsonl
 -> routing-manifest
 -> feature catalog
```

For documents with a numbered outline, only numbered headings remain structural
Markdown headings. Visual labels such as `Summary`, `Additional Information`,
`Feature Dependencies` and `Network Requirements` remain body labels inside the
numbered section. Page markers are retained for evidence page ranges.

## Install

```bash
source ~/RANKB_Local_Ericsson/.venv/bin/activate
python -m pip install -r requirements.txt
```

An editable install is optional:

```bash
python -m pip install -e .
```

## Clean preparation

```bash
python -m ericsson_kb /path/to/ericsson_pdfs \
  --output-dir /path/to/agent/data/prepared \
  --overwrite \
  --no-fallback
```

Use `--no-fallback` for a controlled production build. Remove it only when
PyMuPDF fallback is deliberately accepted. Add `--verbose` for extraction logs.

## Output

```text
prepared/
├── markdown/
│   ├── Document.md
│   └── Document_images/
├── manifests/
├── combined_manifest.jsonl
├── routing-manifest/
│   ├── by-feature-id/
│   ├── by-mentioned-feature-id/
│   ├── by-package-id/
│   └── by-topic/
├── ericsson_feature_catalog.json
├── heading_repair_report.json
└── canonicalization_report.json
```

This production distribution intentionally omits old-corpus migration scripts,
patch notes, examples and unit tests. The core preparation implementation is
fully contained in `ericsson_kb/`.
