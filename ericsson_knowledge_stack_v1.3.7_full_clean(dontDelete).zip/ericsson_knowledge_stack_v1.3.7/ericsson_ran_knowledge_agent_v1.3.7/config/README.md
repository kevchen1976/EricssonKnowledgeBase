# Configuration

`settings.json` contains safe defaults. Copy `services.env.example` to
`services.env` for deployment-specific values and credentials.

`services.env` is intentionally ignored by source control and is loaded without
overriding variables already exported by the process.

OpenSearch is shared physically with Nokia but Ericsson uses separate parent
and child aliases. Manifest routing is filesystem-based and has no OpenSearch
manifest index.
