# Local models

Model weights are intentionally not included.

Expected defaults:

```text
models/bge-large-en-v1.5
models/ms-marco-MiniLM-L-12-v2
```

The embedding model must produce 1024-dimensional vectors for the default
OpenSearch mapping. Use the same embedding model at ingestion and query time.
