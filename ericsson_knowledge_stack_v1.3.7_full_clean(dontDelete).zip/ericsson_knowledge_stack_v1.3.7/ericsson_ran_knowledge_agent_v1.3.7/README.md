# Ericsson RAN Knowledge Agent 1.3.7

Production-ready Ericsson documentation knowledge agent aligned with the Nokia agent contract.

## What is included

- Ericsson-only parent/child OpenSearch ingestion.
- Filesystem JSONL manifests for feature, package and topic routing.
- Section-aware parent chunks and vectorized child windows.
- Strict BGE embedding-length preflight and pre-encode guard.
- BM25 + vector recall, RRF fusion and optional reranking.
- Full-parent evidence expansion and citation metadata.
- Evidence image serving and rendering from `data/prepared/markdown/*_images/`.
- Redis conversation memory and LLM query rewriting.
- SQLite query/answer audit records.
- Nokia-compatible WebSocket and SSE streaming.
- Native Ollama daemon timing trace plus separate client request/response logging.
- Optional Neo4j scaffold, disabled by default.

PDF extraction and manifest generation live in the separate sibling package
`ericsson_kb_preparation_v1.1.2`.

## Runtime architecture

```text
Browser / API client
       |
       v
Ericsson Agent :8100
       |
       +--> Redis session memory
       +--> Ollama query rewrite / answer synthesis
       +--> SQLite audit
       |
       v
Ericsson KB :8102
       |
       +--> filesystem routing manifests
       +--> OpenSearch child index (BM25 + vector)
       +--> RRF / optional reranker
       +--> OpenSearch parent index (full evidence)
       +--> prepared evidence images
```

OpenSearch stores only:

- `ericsson-ran-kb-children`
- `ericsson-ran-kb-parents`

Manifests remain on the filesystem, matching the Nokia implementation.

## Required prepared-data layout

```text
data/prepared/
├── markdown/
│   ├── Document.md
│   └── Document_images/
│       └── page_003_image_001.png
├── manifests/
├── combined_manifest.jsonl
├── routing-manifest/
│   ├── by-feature-id/
│   ├── by-mentioned-feature-id/
│   ├── by-package-id/
│   └── by-topic/
├── ericsson_feature_catalog.json
├── heading_repair_report.json
└── canonicalization_report.json
```

## Install Python dependencies

The existing shared virtual environment can be reused:

```bash
source ~/RANKB_Local_Ericsson/.venv/bin/activate
python -m pip install -r requirements.txt
```

Optional Neo4j support:

```bash
python -m pip install -r requirements-graph.txt
```

Embedding and reranker model files are not included. Put them at the paths in
`config/settings.json`, normally:

```text
models/bge-large-en-v1.5
models/ms-marco-MiniLM-L-12-v2
```

## Configure

```bash
cp config/services.env.example config/services.env
nano config/services.env
```

Important defaults:

```dotenv
OPENSEARCH_CHILD_ALIAS=ericsson-ran-kb-children
OPENSEARCH_PARENT_ALIAS=ericsson-ran-kb-parents
OLLAMA_CONTEXT_TOKENS=32000
REDIS_KEY_PREFIX=ericsson:session:
USE_RERANKER=false
GRAPH_ENABLED=false
```

Configuration precedence is:

```text
process environment
  > config/services.env
  > config/settings.json
  > built-in defaults
```

## Build a new database

Use the bundle-level `build_new_database.sh`, or follow
`docs/BUILD_NEW_DATABASE.md`.

The minimum direct sequence is:

```bash
# Preparation is run from the sibling preparation package.
cd ../ericsson_kb_preparation_v1.1.2
python -m ericsson_kb /path/to/ericsson_pdfs \
  --output-dir ../ericsson_ran_knowledge_agent_v1.3.7/data/prepared \
  --overwrite \
  --no-fallback

cd ../ericsson_ran_knowledge_agent_v1.3.7
python scripts/validate_prepared_data.py data/prepared
python scripts/check_embedding_lengths.py --prepared-root data/prepared
python scripts/check_opensearch.py
python ingest_ericsson.py \
  --prepared-root data/prepared \
  --mode rebuild \
  --version 20260907clean01 \
  --delete-old
python scripts/verify_parent_child_storage.py --live --sample-size 200
```

## Start and stop services

```bash
./startup_all_service.sh start
./startup_all_service.sh status
./startup_all_service.sh stop
```

Individual controls:

```bash
./startup_all_service.sh kb
./startup_all_service.sh agent
./startup_all_service.sh graph
./startup_all_service.sh stop-kb
./startup_all_service.sh stop-agent
./startup_all_service.sh stop-graph
./startup_all_service.sh ollama-start
./startup_all_service.sh ollama-stop
./startup_all_service.sh ollama-status
./startup_all_service.sh ollama-log-status
./startup_all_service.sh redis-check
```

The launcher never starts or stops shared OpenSearch, Redis or Nokia services.
It reuses an existing Ollama daemon. If none is running and
`OLLAMA_START_ENABLED=true`, it starts and tracks its own `ollama serve` process.

## API endpoints

Agent:

```text
POST   /query
POST   /query/stream       SSE
WS     /ws/stream          Nokia-compatible stream events
DELETE /session/{id}
GET    /health
GET    /ready
GET    /capabilities
GET    /kb-assets/...      evidence images
```

KB:

```text
POST /kb/search
GET  /kb/search
POST /kb/feature/{feature_id}/retrieve
POST /kb/package/{package_id}/retrieve
GET  /health
GET  /ready
GET  /kb/debug/index-info
GET  /kb/debug/parent-child-status
GET  /kb-assets/...
```

Streaming events are `workflow`, `chunk`, `done`, `error` and `ping`.
The final `done` event carries the validated answer, citations and full-parent
evidence.

## Logs

```text
logs/ericsson-agent.log    process stdout/stderr for Agent launcher
logs/ericsson-kb.log       process stdout/stderr for KB launcher
logs/ericsson_agent.log    workflow, memory, rewrite and audit summaries
logs/chunks.log            manifest, BM25, vector, RRF, reranker and final evidence
logs/ollama.log            native Ollama daemon timing/token-rate trace
logs/ollama-client.log     Ericsson Ollama HTTP request/response trace
```

Enable bounded Ollama payload logging with:

```dotenv
OLLAMA_VERBOSE=1
OLLAMA_LOG_PROMPT_MAX_CHARS=12000
OLLAMA_LOG_RESPONSE_MAX_CHARS=12000
```

## Production scripts retained

```text
scripts/check_embedding_lengths.py
scripts/check_opensearch.py
scripts/check_redis.py
scripts/cleanup_rebuild_version.py
scripts/export_service_settings.py
scripts/validate_prepared_data.py
scripts/verify_parent_child_storage.py
```

Patch-only tests, migration utilities and duplicate document-preparation code
have been removed from this production distribution.
