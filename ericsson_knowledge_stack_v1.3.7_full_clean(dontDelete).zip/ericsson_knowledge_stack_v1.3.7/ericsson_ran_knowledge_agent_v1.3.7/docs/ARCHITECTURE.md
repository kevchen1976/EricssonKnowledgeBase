# Architecture

## Vendor-agent contract

Ericsson remains independently accessible through its own API and is suitable
for registration behind a future Nokia/Ericsson supervisor.

The public contract is:

```text
query -> vendor routing -> retrieval -> synthesis -> citations/evidence
```

## Storage

Filesystem:

- canonical Markdown and sibling image folders;
- per-document manifests;
- `combined_manifest.jsonl`;
- routing manifests by feature, mentioned feature, package and topic.

OpenSearch:

- child documents: BM25 fields and 1024-dimensional embedding vectors;
- parent documents: complete numbered semantic sections, not embedded.

The retrieval contract is `rank-children-then-mget-parents`.

## Parent boundaries

When a document has a numbered outline, only headings beginning with a section
number create parent boundaries. Unnumbered labels such as `Summary`,
`Additional Information`, `Feature Dependencies` and `Network Requirements`
remain within the numbered parent.

For documents without a numbered outline, normal Markdown headings remain the
fallback structure.

## Images

A parent contains only image paths referenced within that parent. The KB API
also reconstructs missing `image_paths` from stored Markdown links for older
indexes. Agent and KB services expose the prepared Markdown root at
`/kb-assets`, and the frontend renders evidence figures under the corresponding
full-parent evidence card.

## Supervisor readiness

Nokia and Ericsson now share the same conceptual layout:

```text
routing metadata = filesystem JSONL
RAG data         = child + parent OpenSearch indexes
answer stream    = workflow/chunk/done/error/ping
```

Vendor-specific identity rules and index names remain isolated.
