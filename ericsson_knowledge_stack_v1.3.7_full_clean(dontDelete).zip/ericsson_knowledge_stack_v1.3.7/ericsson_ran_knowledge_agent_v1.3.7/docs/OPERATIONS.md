# Operations

## Status and lifecycle

```bash
./startup_all_service.sh status
./startup_all_service.sh start
./startup_all_service.sh stop
./startup_all_service.sh restart --verbose
```

`restart --verbose` also enables verbose Ollama client payload logging for the
new process.

## OpenSearch diagnostics

```bash
python scripts/check_opensearch.py
python scripts/verify_parent_child_storage.py --live --sample-size 200
curl -s 'http://localhost:9200/_cat/aliases/ericsson-ran-kb-*?v'
```

## Redis diagnostics

```bash
./startup_all_service.sh redis-check
redis-cli --scan --pattern 'ericsson:session:*'
```

## Ollama diagnostics

```bash
./startup_all_service.sh ollama-status
./startup_all_service.sh ollama-log-status
tail -f logs/ollama.log
tail -f logs/ollama-client.log
ollama ps
```

Native token rates are written by Ollama to `logs/ollama.log` as
`prompt eval time` and `eval time` lines.

## RAG diagnostics

```bash
tail -f logs/chunks.log
grep -E '\[(MANIFEST|RAG)' logs/chunks.log | tail -100
```

Only the first five BM25, vector and reranker results are printed, with bounded
text previews.

## Evidence image diagnostics

For a known prepared image:

```bash
curl -I http://localhost:8100/kb-assets/Document_images/page_003_image_001.png
```

A `200` response confirms the browser can render it.
