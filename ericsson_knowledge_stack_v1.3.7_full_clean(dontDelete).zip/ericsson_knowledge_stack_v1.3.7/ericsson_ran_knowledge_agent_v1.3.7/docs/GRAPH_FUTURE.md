# Neo4j scaffold

Neo4j code remains present but is disabled by default while Ericsson relation
data is curated.

Use a separate logical database:

```dotenv
GRAPH_ENABLED=true
NEO4J_DATABASE=ericsson
```

Install graph dependencies with `requirements-graph.txt`. The parent/child
OpenSearch and filesystem manifest architecture does not depend on Neo4j.
