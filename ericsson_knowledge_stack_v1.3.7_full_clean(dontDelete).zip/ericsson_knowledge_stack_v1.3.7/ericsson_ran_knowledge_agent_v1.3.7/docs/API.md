# API

## Non-streaming query

```bash
curl -s -X POST http://localhost:8100/query \
  -H 'Content-Type: application/json' \
  -d '{
    "session_id": "ericsson-example",
    "query": "What are the dependencies of FAJ 121 0488?",
    "limit": 5,
    "include_evidence": true
  }'
```

## SSE streaming

```bash
curl -N -X POST http://localhost:8100/query/stream \
  -H 'Content-Type: application/json' \
  -d '{
    "session_id": "ericsson-stream-example",
    "query": "Explain FAJ 121 0488",
    "include_evidence": true
  }'
```

Events:

```text
workflow
chunk
chunk
...
done
```

## WebSocket streaming

Connect to:

```text
ws://localhost:8100/ws/stream
```

Send one JSON request with `query`, optional `session_id`, `limit`,
`include_evidence`, and optional `email`.

## Direct KB retrieval

```bash
curl -s -X POST \
  'http://localhost:8102/kb/feature/FAJ%20121%200488/retrieve' \
  -H 'Content-Type: application/json' \
  -d '{"query":"dependencies","limit":5,"include_related":true}'
```

KB results contain full parent sections, matched child metadata, filename,
page range, ranking scores, `image_paths` and browser-safe `image_urls`.
