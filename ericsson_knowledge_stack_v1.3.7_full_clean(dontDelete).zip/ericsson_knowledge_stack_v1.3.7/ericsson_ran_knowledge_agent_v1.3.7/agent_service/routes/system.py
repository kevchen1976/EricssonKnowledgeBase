"""Agent service health and capability endpoints."""
from __future__ import annotations

import httpx
from fastapi import APIRouter, Response, status

from agent_core.constants import PARENT_CHILD_CONTRACT, RETRIEVAL_SCHEMA

from ..state import get_state

router = APIRouter()


@router.get("/health")
def health() -> dict:
    state = get_state()
    settings = state.settings
    return {
        "status": "ok",
        "service": "ericsson-agent-api",
        "vendor": settings.vendor,
        "corpus_id": settings.corpus_id,
        "graph_enabled": settings.graph_enabled,
        "llm_enabled": settings.llm_enabled,
        "query_rewrite_enabled": settings.enable_llm_query_rewrite,
        "session_memory_enabled": settings.session_memory_enabled,
        "session_backend": state.sessions.backend,
        "redis_last_ping_ok": state.sessions.last_ping_ok,
    }


@router.get("/ready")
def ready(response: Response) -> dict:
    state = get_state()
    settings = state.settings

    kb_ready = False
    kb_detail = ""
    try:
        result = httpx.get(
            settings.kb_api_url.rstrip("/") + "/ready",
            timeout=min(settings.kb_timeout, 10),
        )
        kb_ready = result.status_code == 200 and bool(result.json().get("ready"))
        kb_detail = result.text[:1000]
    except Exception as exc:
        kb_detail = str(exc)

    redis_ready = True
    redis_detail = "disabled"
    if settings.session_memory_enabled:
        try:
            redis_ready = state.sessions.ping()
            redis_detail = "connected" if redis_ready else "PING returned false"
        except Exception as exc:
            redis_ready = False
            redis_detail = str(exc)

    overall_ready = kb_ready and redis_ready
    if not overall_ready:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    return {
        "ready": overall_ready,
        "kb_ready": kb_ready,
        "kb_detail": kb_detail,
        "session_memory_enabled": settings.session_memory_enabled,
        "redis_ready": redis_ready,
        "redis_detail": redis_detail,
    }


@router.get("/capabilities")
def capabilities() -> dict:
    state = get_state()
    settings = state.settings
    return {
        "vendor": settings.vendor,
        "corpus_id": settings.corpus_id,
        "api_contract": "standalone-vendor-agent-v1",
        "retrieval_schema": RETRIEVAL_SCHEMA,
        "identity_formats": ["FAJ 121 xxxx", "FAJ 801 xxxx"],
        "workflows": [
            "feature_lookup",
            "package_lookup",
            "knowledge_search",
            "graph_assisted_search",
        ],
        "streaming": {
            "websocket": "/ws/stream",
            "sse": "/query/stream",
            "browser_transport": "websocket",
            "events": ["workflow", "chunk", "done", "error", "ping"],
            "event_contract": "nokia-compatible",
        },
        "conversation": {
            "query_rewrite_enabled": settings.enable_llm_query_rewrite,
            "session_memory_enabled": settings.session_memory_enabled,
            "session_backend": state.sessions.backend,
            "redis_key_prefix": settings.redis_key_prefix,
            "session_ttl_seconds": settings.session_ttl_seconds,
            "max_session_history": settings.max_session_history,
            "history_answer_chars": settings.session_history_answer_chars,
            "stored_answer_chars": settings.session_stored_answer_chars,
        },
        "data_sources": {
            "opensearch": {
                "child_alias": settings.child_alias,
                "parent_alias": settings.parent_alias,
                "manifest_storage": "filesystem_jsonl",
                "chunk_alias": settings.child_alias,
                "retrieval_contract": PARENT_CHILD_CONTRACT,
                "require_parent_context": settings.require_parent_context,
                "verify_parent_content_hash": settings.verify_parent_content_hash,
                "embedding_input_mode": settings.embedding_input_mode,
                "embedding_max_input_tokens_override": settings.embedding_max_input_tokens,
                "embedding_token_guard": "strict-preflight-and-pre-encode",
            },
            "manifests": {
                "storage": "filesystem_jsonl",
                "combined_manifest": str(settings.combined_manifest),
                "feature_manifest_root": str(settings.feature_manifest_root),
                "package_manifest_root": str(settings.package_manifest_root),
                "topic_manifest_root": str(settings.topic_manifest_root),
            },
            "neo4j": {
                "enabled": settings.graph_enabled,
                "database": settings.neo4j_database,
            },
        },
    }
