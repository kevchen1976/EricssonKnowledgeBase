"""Ericsson synchronous and Nokia-compatible streaming query endpoints."""
from __future__ import annotations

import asyncio
import json
import time
from typing import Any, AsyncIterator, Callable, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse

from agent_core.contracts import QueryRequest, QueryResponse
from agent_core.logging_utils import (
    new_request_id,
    request_context,
    single_line,
    single_line_words,
)
from agent_core.streaming import stream_events

from ..auth import authorize
from ..sessions import Turn, format_history
from ..state import get_state

router = APIRouter()

StreamSink = Callable[[Dict[str, Any]], None]


def _resolved_session_id(requested: str | None, user_email: str | None) -> str | None:
    # Match Nokia's user-derived fallback when authentication identifies the
    # caller. Anonymous API callers must provide session_id explicitly; using a
    # shared "session_None" key would mix unrelated users.
    return requested or (f"session_{user_email}" if user_email else None)


def _execute_query(
    request: QueryRequest,
    user_email: str | None,
    *,
    event_sink: StreamSink | None = None,
) -> QueryResponse:
    """Run one request and preserve the existing audit/Redis lifecycle.

    Streaming callers install ``event_sink``. The workflow is still executed
    once, and the same completed QueryResponse is audited and stored in Redis
    as the normal POST /query path.
    """
    state = get_state()
    request_id = new_request_id()
    started = time.perf_counter()
    result: QueryResponse | None = None
    session_id = _resolved_session_id(request.session_id, user_email)

    with request_context(request_id):
        state.logger.info(
            "[QUERY START] session_id=%s user_email=%s limit=%s include_evidence=%s stream=%s query=%r",
            session_id or "",
            user_email or "",
            request.limit,
            request.include_evidence,
            event_sink is not None,
            request.query,
        )
        try:
            service_settings = getattr(state, "settings", None)
            max_history = int(getattr(service_settings, "max_session_history", 5))
            history_answer_chars = int(
                getattr(service_settings, "session_history_answer_chars", 2000)
            )
            stored_answer_chars = int(
                getattr(service_settings, "session_stored_answer_chars", 4000)
            )
            session_ttl = int(getattr(service_settings, "session_ttl_seconds", 3600))
            memory_enabled = bool(
                getattr(service_settings, "session_memory_enabled", True)
            )
            history = state.sessions.get(session_id)
            history_text = format_history(
                history,
                max_turns=max_history,
                answer_chars=history_answer_chars,
            )
            if not memory_enabled:
                state.logger.info("[MEMORY] Session memory is disabled")
            elif session_id is None:
                state.logger.info("[MEMORY] No session_id or authenticated user; request is stateless")
            elif history:
                state.logger.info(
                    "[MEMORY] Session=%s has %d stored exchange(s); using last %d history_chars=%d preview=%s",
                    session_id,
                    len(history),
                    min(len(history), max_history),
                    len(history_text),
                    single_line_words(history_text, max_words=50),
                )
            else:
                state.logger.info("[MEMORY] New or empty session=%s", session_id)

            with stream_events(event_sink):
                result = state.agent.run(
                    request.query,
                    limit=request.limit,
                    include_evidence=request.include_evidence,
                    history=history_text,
                )

            result.metadata["session_id"] = session_id
            result.metadata["prior_turn_count"] = len(history)
            result.metadata["history_chars"] = len(history_text)
            result.metadata["session_backend"] = getattr(state.sessions, "backend", "unknown")
            result.metadata["streaming"] = event_sink is not None

            elapsed_ms = int((time.perf_counter() - started) * 1000)
            citations_payload = [
                citation.model_dump(mode="json") for citation in result.citations
            ]

            response_payload = result.model_dump(mode="json")
            state.audit.record(
                request_id=request_id,
                query=request.query,
                workflow=result.workflow,
                source=result.source,
                latency_ms=elapsed_ms,
                success=True,
                session_id=session_id,
                user_email=user_email,
                tool_calls=[
                    {
                        "tool": "ericsson_knowledge_workflow",
                        "workflow": result.workflow,
                        "feature_ids": result.feature_ids,
                        "package_ids": result.package_ids,
                        "original_query": request.query,
                        "effective_query": result.metadata.get(
                            "effective_query", request.query
                        ),
                        "query_rewritten": bool(
                            result.metadata.get("query_rewritten")
                        ),
                    }
                ],
                tool_outputs=[
                    {
                        "source": result.source,
                        "citations": citations_payload,
                        "warnings": result.warnings,
                        "metadata": result.metadata,
                        "evidence": result.evidence,
                    }
                ],
                final_answer=result.answer,
                validation_ok=True,
                validation_errors=[],
                feature_ids=result.feature_ids,
                package_ids=result.package_ids,
                citation_count=len(result.citations),
                citations=citations_payload,
                warnings=result.warnings,
                response=response_payload,
            )

            if session_id and memory_enabled:
                history.append(
                    Turn.create(
                        request.query,
                        result.answer,
                        answer_chars=stored_answer_chars,
                    )
                )
                state.sessions.set(session_id, history)
                state.logger.info(
                    "[MEMORY] Stored current exchange session=%s retained_up_to=%d ttl_seconds=%d",
                    session_id,
                    max_history,
                    session_ttl,
                )

            state.logger.info(
                "[QUERY COMPLETE] workflow=%s source=%s latency_ms=%d features=%s packages=%s "
                "citations=%d warnings=%d answer_chars=%d rewritten=%s stream=%s answer_preview=%s",
                result.workflow,
                result.source,
                elapsed_ms,
                result.feature_ids,
                result.package_ids,
                len(result.citations),
                len(result.warnings),
                len(result.answer),
                bool(result.metadata.get("query_rewritten")),
                event_sink is not None,
                single_line(result.answer, max_chars=320),
            )
            return result
        except Exception as exc:
            elapsed_ms = int((time.perf_counter() - started) * 1000)
            state.audit.record(
                request_id=request_id,
                query=request.query,
                workflow=result.workflow if result else "",
                source="ericsson_agent",
                latency_ms=elapsed_ms,
                success=False,
                session_id=session_id,
                user_email=user_email,
                final_answer=result.answer if result else "",
                validation_ok=False,
                validation_errors=[str(exc)],
                feature_ids=result.feature_ids if result else [],
                package_ids=result.package_ids if result else [],
                citation_count=len(result.citations) if result else 0,
                citations=(
                    [
                        citation.model_dump(mode="json")
                        for citation in result.citations
                    ]
                    if result
                    else []
                ),
                warnings=result.warnings if result else [],
                error=str(exc),
                response=result.model_dump(mode="json") if result else {},
            )
            state.logger.exception(
                "[QUERY ERROR] latency_ms=%d stream=%s query=%r error=%s",
                elapsed_ms,
                event_sink is not None,
                request.query,
                single_line(exc, max_chars=500),
            )
            raise



async def iter_query_events(
    request: QueryRequest,
    user_email: str | None,
) -> AsyncIterator[Dict[str, Any]]:
    """Yield Nokia-style workflow/chunk/done events for one Ericsson request.

    The event types match Nokia: ``workflow``, ``chunk``, ``done``, and ``error``.
    Ericsson includes its completed QueryResponse inside the final ``done`` payload
    so the browser can render validated final text, citations, and evidence.
    """
    loop = asyncio.get_running_loop()
    queue: asyncio.Queue[Dict[str, Any]] = asyncio.Queue()
    streamed_chunks: list[str] = []

    def sink(event: Dict[str, Any]) -> None:
        loop.call_soon_threadsafe(queue.put_nowait, dict(event))

    def worker() -> None:
        # All workflow/chunk/result events are submitted through the same sink
        # from the same worker thread.  This preserves FIFO ordering.  The
        # previous implementation submitted workflow/chunk with
        # call_soon_threadsafe(), then put __result__ directly from the event
        # loop; under a fast completion the result sentinel could overtake the
        # workflow callback and the consumer would stop before yielding it.
        try:
            result = _execute_query(
                request,
                user_email,
                event_sink=sink,
            )
            sink(
                {
                    "type": "__result__",
                    "response": result.model_dump(mode="json"),
                }
            )
        except Exception as exc:
            sink(
                {
                    "type": "__error__",
                    "content": f"Ericsson agent query failed: {exc}",
                }
            )

    task = asyncio.create_task(asyncio.to_thread(worker))
    try:
        while True:
            event = await queue.get()
            event_type = str(event.get("type") or "")

            if event_type == "__result__":
                payload = event.get("response") if isinstance(event.get("response"), dict) else {}
                final_answer = str(payload.get("answer") or "")
                if not streamed_chunks and final_answer:
                    yield {"type": "chunk", "content": final_answer}

                # Keep Nokia's event types unchanged. The complete validated
                # answer is carried in done.response; Ericsson's browser uses it
                # to replace any provisional token stream if validation changed it.
                yield {
                    "type": "done",
                    "response": payload,
                }
                break

            if event_type == "__error__":
                yield {"type": "error", "content": str(event.get("content") or "Unknown error")}
                break

            if event_type == "chunk":
                streamed_chunks.append(str(event.get("content") or ""))
            yield event
    finally:
        # A disconnected HTTP/WebSocket client cannot cancel a blocking Ollama
        # request running in a worker thread. Let it finish so audit/session state
        # remains consistent, but avoid holding the response generator open.
        if task.done():
            try:
                task.result()
            except Exception:
                pass


@router.post("/query", response_model=QueryResponse)
def query_agent(
    request: QueryRequest,
    user_email: Optional[str] = Depends(authorize),
) -> QueryResponse:
    try:
        return _execute_query(request, user_email)
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Ericsson agent query failed: {exc}",
        ) from exc


@router.post("/query/stream")
async def query_agent_stream(
    request: QueryRequest,
    user_email: Optional[str] = Depends(authorize),
) -> StreamingResponse:
    """Server-Sent Events streaming endpoint matching Nokia's API shape."""

    async def generate() -> AsyncIterator[str]:
        async for event in iter_query_events(request, user_email):
            yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@router.delete("/session/{session_id}")
def clear_session(
    session_id: str,
    _user_email: Optional[str] = Depends(authorize),
) -> dict:
    state = get_state()
    try:
        existed = state.sessions.clear(session_id)
    except Exception as exc:
        state.logger.exception("[REDIS] Failed to clear session=%s", session_id)
        raise HTTPException(
            status_code=500,
            detail=f"Could not clear Ericsson session: {exc}",
        ) from exc
    return {"cleared": True, "existed": existed, "session_id": session_id}
