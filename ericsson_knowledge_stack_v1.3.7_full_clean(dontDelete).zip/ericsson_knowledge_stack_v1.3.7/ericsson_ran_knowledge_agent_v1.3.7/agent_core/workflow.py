"""End-to-end standalone Ericsson query workflow."""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Sequence

from .clients import GraphClient, KBClient, OllamaClient, ServiceClientError
from .contracts import QueryResponse
from .logging_utils import current_request_id, single_line, single_line_words
from .rewrite import looks_like_raw_alarm, rewrite_query_with_llm
from .routing import RouteDecision, route_query
from .settings import Settings
from .synthesis import build_citations, synthesize_answer
from .streaming import emit_stream_event
from .validation import validate_answer

logger = logging.getLogger("ericsson_agent")


def _hits(payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    for key in ("retrievalResults", "results", "hits"):
        value = payload.get(key)
        if isinstance(value, list):
            return [item for item in value if isinstance(item, dict)]
    return []


def _source(hit: Dict[str, Any]) -> Dict[str, Any]:
    value = hit.get("_source", hit)
    return value if isinstance(value, dict) else {}


def _merge_hits(groups: Iterable[Sequence[Dict[str, Any]]], limit: int) -> List[Dict[str, Any]]:
    by_key: Dict[str, Dict[str, Any]] = {}
    order: List[str] = []
    for group in groups:
        for hit in group:
            source = _source(hit)
            key = str(source.get("parent_id") or source.get("chunk_id") or hit.get("_id") or "")
            if not key:
                key = f"anonymous-{len(order)}"
            score = float(hit.get("_score") or 0.0)
            if key not in by_key:
                by_key[key] = hit
                order.append(key)
            elif score > float(by_key[key].get("_score") or 0.0):
                by_key[key] = hit
    values = [by_key[key] for key in order]
    values.sort(key=lambda item: float(item.get("_score") or 0.0), reverse=True)
    return values[:limit]


def _collect_ids(evidence: Sequence[Dict[str, Any]], route: RouteDecision) -> tuple[List[str], List[str]]:
    features = list(route.feature_ids)
    packages = list(route.package_ids)
    for hit in evidence:
        source = _source(hit)
        for key in ("feature_id", "primary_feature_id", "owner_feature_id"):
            value = str(source.get(key) or "")
            if value and value not in features:
                features.append(value)
        for value in source.get("feature_ids", []) if isinstance(source.get("feature_ids"), list) else []:
            if value and value not in features:
                features.append(str(value))
        for key in ("package_id", "primary_package_id"):
            value = str(source.get(key) or "")
            if value and value not in packages:
                packages.append(value)
        for value in source.get("package_ids", []) if isinstance(source.get("package_ids"), list) else []:
            if value and value not in packages:
                packages.append(str(value))
    return features, packages


def _log_evidence(evidence: Sequence[Dict[str, Any]]) -> None:
    shown = min(len(evidence), 5)
    logger.info("[AGENT FINAL_EVIDENCE] count=%d logged=%d", len(evidence), shown)
    for rank, hit in enumerate(evidence[:shown], 1):
        source = _source(hit)
        matched_children = source.get("matched_children") if isinstance(source.get("matched_children"), list) else []
        logger.info(
            "[AGENT EVIDENCE] rank=%d parent_id=%s score=%.8f matched_children=%d file=%s "
            "page=%s-%s section=%s snippet=%s",
            rank,
            source.get("parent_id") or hit.get("_id") or "",
            float(hit.get("_score") or 0.0),
            len(matched_children),
            single_line(source.get("filename"), max_chars=140),
            source.get("page_start") or "",
            source.get("page_end") or source.get("page_start") or "",
            single_line(source.get("heading_path") or source.get("heading"), max_chars=220),
            single_line_words(source.get("content"), max_words=50),
        )
    if len(evidence) > shown:
        logger.info("[AGENT EVIDENCE] omitted_candidates=%d", len(evidence) - shown)


@dataclass
class EricssonAgent:
    settings: Settings
    kb: KBClient | None = None
    graph: GraphClient | None = None
    ollama: OllamaClient | None = None

    def __post_init__(self) -> None:
        if self.kb is None:
            self.kb = KBClient(self.settings)
        if self.graph is None and self.settings.graph_enabled:
            self.graph = GraphClient(self.settings)
        if self.ollama is None and self.settings.llm_enabled:
            self.ollama = OllamaClient(self.settings)

    def run(
        self,
        query: str,
        *,
        limit: int | None = None,
        include_evidence: bool = False,
        history: str = "",
    ) -> QueryResponse:
        started = time.perf_counter()
        original_query = " ".join(str(query or "").split()).strip()
        effective_query = original_query
        history_text = str(history or "").strip()
        logger.info("[EXECUTE_WORKFLOW] Query: %r", original_query)
        logger.info("[EXECUTE_WORKFLOW] History length: %d chars", len(history_text))
        if history_text:
            logger.info(
                "[EXECUTE_WORKFLOW] History preview: %s",
                single_line_words(history_text, max_words=50),
            )
        else:
            logger.info("[EXECUTE_WORKFLOW] History is empty")

        if (
            self.settings.enable_llm_query_rewrite
            and self.ollama is not None
            and not looks_like_raw_alarm(original_query)
        ):
            effective_query = rewrite_query_with_llm(original_query, history_text, self.ollama)
            if effective_query != original_query:
                logger.info(
                    "[WORKFLOW] Using rewritten query=%r original_query=%r",
                    effective_query,
                    original_query,
                )
        else:
            logger.info(
                "[WORKFLOW] LLM query rewrite skipped enabled=%s llm_available=%s raw_alarm=%s",
                self.settings.enable_llm_query_rewrite,
                self.ollama is not None,
                looks_like_raw_alarm(original_query),
            )
        logger.info(
            "[WORKFLOW EFFECTIVE QUERY] original=%r effective=%r changed=%s",
            original_query,
            effective_query,
            effective_query != original_query,
        )

        requested_limit = self.settings.default_limit if limit is None else int(limit)
        actual_limit = min(max(1, requested_limit), self.settings.maximum_limit)
        route = route_query(effective_query, graph_enabled=self.settings.graph_enabled)
        warnings: List[str] = []
        hit_groups: List[List[Dict[str, Any]]] = []
        route_metadata: Dict[str, Any] = {
            "reason": route.reason,
            "original_query": original_query,
            "effective_query": effective_query,
            "rewritten_query": effective_query,
            "query_rewritten": effective_query != original_query,
            "history_chars": len(history_text),
            "query_rewrite_enabled": self.settings.enable_llm_query_rewrite,
        }

        logger.info(
            "[AGENT ROUTE] request_id=%s workflow=%s reason=%s feature_ids=%s package_ids=%s "
            "use_graph=%s requested_limit=%s actual_limit=%d query=%r",
            current_request_id(),
            route.workflow,
            route.reason,
            route.feature_ids,
            route.package_ids,
            route.use_graph,
            limit,
            actual_limit,
            effective_query,
        )

        assert self.kb is not None
        try:
            if route.workflow == "feature_lookup":
                manifests: List[Dict[str, Any]] = []
                per_feature_limit = max(2, actual_limit)
                for feature_id in route.feature_ids:
                    logger.info(
                        "[AGENT KB_CALL] operation=retrieve_feature feature_id=%s limit=%d include_related=true",
                        feature_id,
                        per_feature_limit,
                    )
                    payload = self.kb.retrieve_feature(
                        feature_id,
                        effective_query,
                        limit=per_feature_limit,
                        include_related=True,
                    )
                    payload_hits = _hits(payload)
                    hit_groups.append(payload_hits)
                    logger.info(
                        "[AGENT KB_RESULT] operation=retrieve_feature feature_id=%s parents=%d warnings=%d "
                        "fallback_type=%s",
                        feature_id,
                        len(payload_hits),
                        len(payload.get("warnings", []) or []),
                        payload.get("fallback_type") or "",
                    )
                    manifest = payload.get("manifest")
                    if isinstance(manifest, dict):
                        manifests.append(manifest)
                    warnings.extend(str(value) for value in payload.get("warnings", []) if value)
                route_metadata["manifests"] = manifests
            elif route.workflow == "package_lookup":
                manifests = []
                for package_id in route.package_ids:
                    logger.info(
                        "[AGENT KB_CALL] operation=retrieve_package package_id=%s limit=%d",
                        package_id,
                        max(2, actual_limit),
                    )
                    payload = self.kb.retrieve_package(package_id, effective_query, limit=max(2, actual_limit))
                    payload_hits = _hits(payload)
                    hit_groups.append(payload_hits)
                    logger.info(
                        "[AGENT KB_RESULT] operation=retrieve_package package_id=%s parents=%d warnings=%d "
                        "fallback_type=%s",
                        package_id,
                        len(payload_hits),
                        len(payload.get("warnings", []) or []),
                        payload.get("fallback_type") or "",
                    )
                    manifest = payload.get("manifest")
                    if isinstance(manifest, dict):
                        manifests.append(manifest)
                    warnings.extend(str(value) for value in payload.get("warnings", []) if value)
                route_metadata["manifests"] = manifests
            else:
                logger.info("[AGENT KB_CALL] operation=search limit=%d", actual_limit)
                payload = self.kb.search(effective_query, limit=actual_limit)
                payload_hits = _hits(payload)
                hit_groups.append(payload_hits)
                logger.info(
                    "[AGENT KB_RESULT] operation=search parents=%d warnings=%d fallback_type=%s",
                    len(payload_hits),
                    len(payload.get("warnings", []) or []),
                    payload.get("fallback_type") or "",
                )
                warnings.extend(str(value) for value in payload.get("warnings", []) if value)
        except ServiceClientError as exc:
            logger.warning("[AGENT KB_ERROR] error=%s", single_line(exc, max_chars=500))
            emit_stream_event({
                "type": "workflow",
                "workflow": route.workflow,
                "source": "ericsson_agent",
            })
            return QueryResponse(
                answer="The Ericsson knowledge-base service is unavailable, so I could not retrieve supporting documentation.",
                source="ericsson_agent",
                workflow=route.workflow,
                feature_ids=route.feature_ids,
                package_ids=route.package_ids,
                warnings=[str(exc)],
                metadata=route_metadata,
            )

        evidence = _merge_hits(hit_groups, actual_limit)
        logger.info(
            "[AGENT EVIDENCE_MERGE] input_groups=%d input_hits=%d selected_parents=%d limit=%d",
            len(hit_groups),
            sum(len(group) for group in hit_groups),
            len(evidence),
            actual_limit,
        )
        _log_evidence(evidence)

        graph_context: Dict[str, Any] | None = None
        if route.use_graph and self.graph is not None:
            try:
                logger.info("[AGENT GRAPH_CALL] feature_ids=%s package_ids=%s", route.feature_ids, route.package_ids)
                if route.feature_ids:
                    graph_context = self.graph.feature_context(route.feature_ids[0])
                elif route.package_ids:
                    graph_context = self.graph.package_context(route.package_ids[0])
                else:
                    graph_context = self.graph.search_context(effective_query, limit=min(20, actual_limit * 2))
                logger.info("[AGENT GRAPH_RESULT] available=%s", bool(graph_context))
            except ServiceClientError as exc:
                warnings.append(str(exc) + "; continued with OpenSearch evidence only.")
                logger.warning("[AGENT GRAPH_ERROR] error=%s", single_line(exc, max_chars=500))

        stream_source = "ericsson_kb_graph" if graph_context else "ericsson_kb"
        emit_stream_event({
            "type": "workflow",
            "workflow": route.workflow,
            "source": stream_source,
        })

        synthesis_started = time.perf_counter()
        logger.info(
            "[AGENT SYNTHESIS_START] evidence_count=%d graph_used=%s llm_enabled=%s",
            len(evidence),
            bool(graph_context),
            self.ollama is not None,
        )
        answer, synthesis_warnings = synthesize_answer(
            original_query,
            evidence,
            ollama=self.ollama,
            graph_context=graph_context,
            history=history_text,
            effective_query=effective_query,
        )
        synthesis_ms = int((time.perf_counter() - synthesis_started) * 1000)
        warnings.extend(synthesis_warnings)
        logger.info(
            "[AGENT SYNTHESIS_COMPLETE] elapsed_ms=%d answer_chars=%d warnings=%d preview=%s",
            synthesis_ms,
            len(answer),
            len(synthesis_warnings),
            single_line(answer, max_chars=320),
        )

        validation = validate_answer(
            answer,
            evidence,
            user_feature_ids=route.feature_ids,
            user_package_ids=route.package_ids,
        )
        warnings.extend(validation.warnings)
        logger.info(
            "[AGENT VALIDATION] unsupported_feature_ids=%s unsupported_package_ids=%s "
            "invalid_citations=%s missing_citations=%s warnings=%s",
            validation.unsupported_feature_ids,
            validation.unsupported_package_ids,
            validation.invalid_citations,
            validation.missing_citations,
            validation.warnings,
        )
        if (
            validation.unsupported_feature_ids
            or validation.unsupported_package_ids
            or validation.invalid_citations
            or validation.missing_citations
        ):
            # Do not return an LLM answer that introduced an unsupported Ericsson
            # identity or failed the evidence-marker contract. Fall back to
            # deterministic evidence rendering instead.
            logger.warning("[AGENT VALIDATION_FALLBACK] replacing LLM answer with evidence-only answer")
            answer, fallback_warnings = synthesize_answer(
                original_query,
                evidence,
                ollama=None,
                graph_context=graph_context,
                history=history_text,
                effective_query=effective_query,
            )
            warnings.extend(fallback_warnings)
            warnings.append(
                "LLM output was replaced with an evidence-only answer because it introduced unsupported Ericsson identities "
                "or used missing/invalid evidence markers."
            )
            validation = validate_answer(
                answer,
                evidence,
                user_feature_ids=route.feature_ids,
                user_package_ids=route.package_ids,
            )
            logger.info(
                "[AGENT FALLBACK_VALIDATION] unsupported_feature_ids=%s unsupported_package_ids=%s "
                "invalid_citations=%s missing_citations=%s",
                validation.unsupported_feature_ids,
                validation.unsupported_package_ids,
                validation.invalid_citations,
                validation.missing_citations,
            )
        feature_ids, package_ids = _collect_ids(evidence, route)
        citations = build_citations(evidence)
        route_metadata.update({
            "evidence_count": len(evidence),
            "graph_used": bool(graph_context),
            "direct_feature_lookup": route.workflow == "feature_lookup",
        })
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        logger.info(
            "[AGENT COMPLETE] workflow=%s elapsed_ms=%d evidence_count=%d citations=%d "
            "feature_ids=%s package_ids=%s warnings=%d",
            route.workflow,
            elapsed_ms,
            len(evidence),
            len(citations),
            feature_ids,
            package_ids,
            len(warnings),
        )
        return QueryResponse(
            answer=validation.answer,
            source="ericsson_kb_graph" if graph_context else "ericsson_kb",
            workflow=route.workflow,
            feature_ids=feature_ids,
            package_ids=package_ids,
            citations=citations,
            warnings=list(dict.fromkeys(warnings)),
            evidence=[_source(hit) | {"score": hit.get("_score")} for hit in evidence] if include_evidence else [],
            metadata=route_metadata,
        )
