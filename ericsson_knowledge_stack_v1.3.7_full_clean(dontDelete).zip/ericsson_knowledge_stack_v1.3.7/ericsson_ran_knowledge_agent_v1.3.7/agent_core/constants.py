"""Shared Ericsson service/package constants.

Keeping these values in one module prevents the Agent API, KB API, ingestion
reports, capability payloads, and tests from drifting onto different schema
versions during deployment.
"""

PACKAGE_VERSION = "1.3.7"
RETRIEVAL_SCHEMA = "ericsson-kb-1.2-parent-child"
PARENT_CHILD_CONTRACT = "rank-children-then-mget-parents"
PARENT_STORAGE_ROLE = "parent"
CHILD_STORAGE_ROLE = "child"
# Legacy compatibility only. v1.3.x Nokia-parity runtime does not create or
# query a manifest OpenSearch index, but older modules may still import this
# constant during mixed-patch upgrades.
MANIFEST_STORAGE_ROLE = "manifest"
