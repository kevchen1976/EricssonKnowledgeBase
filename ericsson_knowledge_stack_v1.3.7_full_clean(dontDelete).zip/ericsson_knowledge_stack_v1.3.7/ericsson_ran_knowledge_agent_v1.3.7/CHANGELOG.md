# Changelog

## 1.3.7 consolidated production distribution

- Canonical metadata comments are ignored by the ingestion parser, preventing a metadata-only `Document Overview` parent.

- Nokia-compatible WebSocket and SSE answer streaming.
- FastAPI 0.141 route introspection compatibility.
- Filesystem-only manifest routing, with OpenSearch parent and child indexes.
- Numbered Ericsson section headings are authoritative parent boundaries.
- Full-parent evidence image metadata recovery, asset serving and frontend rendering.
- Explicit 32K Ollama context on all LLM requests.
- Native Ollama timing trace and separate bounded client trace.
- Redis memory, query rewrite and SQLite audit parity with the Nokia agent.
- Strict embedding input-length preflight.
- Duplicate preparation implementation and patch/test artifacts removed.

## Preparation compatibility

Use Ericsson KB Preparation 1.1.2 or later. It fixes Docling reading order,
repairs malformed headings, removes front matter/footer chrome, canonicalizes
numbered outlines and generates filesystem routing manifests.
