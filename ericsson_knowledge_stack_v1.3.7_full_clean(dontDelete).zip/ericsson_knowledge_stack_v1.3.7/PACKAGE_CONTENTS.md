# Package contents

## Ericsson RAN Knowledge Agent 1.3.7

Runtime source for:

- Agent API and web frontend;
- KB API and filesystem manifest routing;
- parent/child OpenSearch ingestion;
- BM25/vector/RRF/reranker retrieval;
- Redis memory and query rewrite;
- SQLite audit and RAG/Ollama logs;
- SSE/WebSocket streaming;
- evidence image serving/rendering;
- optional Neo4j scaffold.

Production operational scripts retained:

```text
check_embedding_lengths.py
check_opensearch.py
check_redis.py
cleanup_rebuild_version.py
export_service_settings.py
validate_prepared_data.py
verify_parent_child_storage.py
```

## Ericsson KB Preparation 1.1.2

Runtime source for:

- PDF discovery and Docling extraction;
- page-aware Markdown and image folders;
- reading-order preservation;
- malformed-heading repair;
- front-matter/footer canonicalization;
- document analysis and Ericsson ID extraction;
- per-document/combined manifests;
- filesystem routing indexes and feature catalog.

## Bundle utilities

```text
verify_bundle.sh
install_dependencies.sh
install_replace.sh
build_new_database.sh
```
