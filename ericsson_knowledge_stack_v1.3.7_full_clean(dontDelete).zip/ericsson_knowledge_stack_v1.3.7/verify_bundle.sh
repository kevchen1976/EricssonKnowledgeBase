#!/usr/bin/env bash
set -euo pipefail
HERE=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
AGENT="$HERE/ericsson_ran_knowledge_agent_v1.3.7"
PREP="$HERE/ericsson_kb_preparation_v1.1.2"

if [ -n "${PYTHON:-}" ]; then
  if [ -x "$PYTHON" ]; then
    PYTHON_BIN=$PYTHON
  elif command -v "$PYTHON" >/dev/null 2>&1; then
    PYTHON_BIN=$(command -v "$PYTHON")
  else
    echo "Python not found: $PYTHON" >&2
    exit 3
  fi
elif [ -x "$HOME/RANKB_Local_Ericsson/.venv/bin/python" ]; then
  PYTHON_BIN="$HOME/RANKB_Local_Ericsson/.venv/bin/python"
elif command -v python3 >/dev/null 2>&1; then
  PYTHON_BIN=$(command -v python3)
else
  PYTHON_BIN=$(command -v python)
fi

[ -x "$PYTHON_BIN" ] || { echo "Python not executable: $PYTHON_BIN" >&2; exit 3; }

if [ -f "$HERE/SHA256SUMS" ]; then
  (cd "$HERE" && sha256sum -c SHA256SUMS)
fi
[ -f "$AGENT/agent_core/constants.py" ]
[ -f "$PREP/ericsson_kb/pipeline.py" ]
[ -f "$AGENT/static/index.html" ]
[ -f "$AGENT/config/services.env.example" ]
[ ! -d "$AGENT/tests" ]
[ ! -d "$AGENT/ericsson_preparation" ]
[ ! -d "$PREP/tests" ]

bash -n "$HERE/install_replace.sh"
bash -n "$HERE/install_dependencies.sh"
bash -n "$HERE/build_new_database.sh"
bash -n "$AGENT/startup_all_service.sh"

"$PYTHON_BIN" -m compileall -q \
  "$AGENT/agent_core" "$AGENT/agent_service" "$AGENT/kb_api" \
  "$AGENT/graph_api" "$AGENT/ingestion" "$PREP/ericsson_kb"

PYTHONPATH="$AGENT" "$PYTHON_BIN" - <<'PY'
from agent_core.constants import PACKAGE_VERSION
from agent_core.settings import get_settings
assert PACKAGE_VERSION == "1.3.7"
s = get_settings(reload=True)
assert s.child_alias == "ericsson-ran-kb-children"
assert s.parent_alias == "ericsson-ran-kb-parents"
assert s.ollama_context_tokens == 32000
assert not hasattr(s, "manifest_alias")
from agent_service.application import app
paths = set(app.openapi().get("paths", {}))
assert {"/query", "/query/stream", "/health", "/ready", "/capabilities"} <= paths
from agent_service.routes.websocket import router
assert "/ws/stream" in {getattr(r, "path", "") for r in router.routes}
from ingestion.markdown_parser import parse_markdown_sections
sample = """<!-- page: 1 -->
<!-- ericsson-canonical-meta: {\"title\": \"Example\"} -->
# 1 Overview

Body.
"""
sections = parse_markdown_sections(sample, include_preamble=True)
assert len(sections) == 1 and sections[0].heading_number == "1"
print("Agent source verification: PASS")
PY

PYTHONPATH="$PREP" "$PYTHON_BIN" - <<'PY'
import ericsson_kb
assert ericsson_kb.__version__ == "1.1.2"
print("Preparation source verification: PASS")
PY

echo "Bundle verification: PASS"
