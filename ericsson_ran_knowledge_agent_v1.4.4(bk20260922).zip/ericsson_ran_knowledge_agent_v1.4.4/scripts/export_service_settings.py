#!/usr/bin/env python3
"""Export resolved service settings as shell-safe assignments.

The launcher sources deployment environment variables first, then calls this
script so the Bash process and the Python services use the same resolved ports,
hosts, paths, and feature flags.
"""
from __future__ import annotations

import shlex
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agent_core.settings import get_settings


def _emit(name: str, value: object) -> None:
    print(f"{name}={shlex.quote(str(value))}")


def main() -> int:
    settings = get_settings(reload=True)
    _emit("SERVICE_BIND_HOST", settings.bind_host)
    _emit("AGENT_API_PORT", settings.agent_api_port)
    _emit("GRAPH_API_PORT", settings.graph_api_port)
    _emit("KB_API_PORT", settings.kb_api_port)
    _emit("AGENT_API_URL", settings.agent_api_url)
    _emit("GRAPH_API_URL", settings.graph_api_url)
    _emit("KB_API_URL", settings.kb_api_url)
    _emit("RESOLVED_LOGS_DIR", settings.logs_dir)
    _emit("GRAPH_ENABLED", "true" if settings.graph_enabled else "false")
    _emit("SESSION_MEMORY_ENABLED", "true" if settings.session_memory_enabled else "false")
    _emit("ENABLE_LLM_QUERY_REWRITE", "true" if settings.enable_llm_query_rewrite else "false")
    _emit("REDIS_URL", settings.redis_url)
    _emit("REDIS_HOST", settings.redis_host)
    _emit("REDIS_PORT", settings.redis_port)
    _emit("REDIS_DB", settings.redis_db)
    _emit("REDIS_SSL", "true" if settings.redis_ssl else "false")
    _emit("REDIS_KEY_PREFIX", settings.redis_key_prefix)
    _emit("SESSION_TTL", settings.session_ttl_seconds)
    _emit("MAX_HISTORY", settings.max_session_history)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
