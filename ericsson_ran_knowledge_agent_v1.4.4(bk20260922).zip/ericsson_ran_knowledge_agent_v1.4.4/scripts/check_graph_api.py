#!/usr/bin/env python3
"""Small Ericsson Graph API smoke test."""
from __future__ import annotations

import argparse
import json
import sys
import uuid

import httpx


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://localhost:8101")
    ap.add_argument("--feature", default="FAJ 121 5377")
    args = ap.parse_args()

    base = args.url.rstrip("/")
    request_id = f"graph-smoke-{uuid.uuid4()}"
    headers = {"X-Request-ID": request_id}
    print("REQUEST_ID", request_id)
    with httpx.Client(timeout=20) as client:
        ready = client.get(base + "/ready", headers=headers)
        print("READY", ready.status_code, "response_request_id=", ready.headers.get("X-Request-ID"), ready.text)
        if ready.status_code != 200:
            return 1

        response = client.get(
            base + "/tools/feature/counters",
            params={"feature": args.feature, "limit": 5},
            headers=headers,
        )
        print(
            "FEATURE_COUNTERS",
            response.status_code,
            "response_request_id=",
            response.headers.get("X-Request-ID"),
        )
        try:
            print(json.dumps(response.json(), indent=2, ensure_ascii=False)[:12000])
        except ValueError:
            print(response.text[:12000])
        return 0 if response.status_code == 200 else 2


if __name__ == "__main__":
    raise SystemExit(main())
