#!/usr/bin/env python3
"""Verify Ericsson parent/child storage offline or against live OpenSearch."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agent_core.settings import get_settings
from ingestion.opensearch_store import make_client, validate_index_configuration
from ingestion.storage_validation import validate_live_storage, validate_preview_storage


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--live", action="store_true", help="Validate the configured live Ericsson aliases")
    mode.add_argument("--preview-dir", type=Path, help="Directory containing parents.jsonl and children.jsonl")
    parser.add_argument("--sample-size", type=int, default=100, help="Maximum live child records to sample")
    parser.add_argument(
        "--require-embeddings",
        action="store_true",
        help="Require child vectors in an offline preview (use with --test-embedder or production preview)",
    )
    parser.add_argument("--output", type=Path, help="Optional JSON report path")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    settings = get_settings()
    validate_index_configuration(settings)
    if args.live:
        report = validate_live_storage(make_client(settings), settings, sample_size=args.sample_size)
    else:
        preview_dir = args.preview_dir or settings.prepared_root / "ingestion-preview"
        report = validate_preview_storage(preview_dir, require_embeddings=args.require_embeddings)

    payload = report.to_dict()
    rendered = json.dumps(payload, indent=2, ensure_ascii=False)
    print(rendered)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    return 0 if report.ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
