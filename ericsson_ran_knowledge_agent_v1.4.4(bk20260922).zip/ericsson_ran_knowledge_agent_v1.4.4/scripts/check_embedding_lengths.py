#!/usr/bin/env python3
"""Validate all final Ericsson child embedding inputs without touching OpenSearch."""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agent_core.settings import get_settings
from ingestion.embedding import EmbeddingInputLengthError
from ingestion.manifest_loader import ManifestStore
from ingestion.pipeline import make_embedder, preflight_embedding_inputs, settings_for_prepared_root
from ingestion.prepared_loader import load_prepared_documents


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Tokenize every final child embedding input with the production model tokenizer and "
            "fail if any input exceeds SentenceTransformer.max_seq_length. No OpenSearch request is made."
        )
    )
    parser.add_argument("--prepared-root", type=Path, default=Path("data/prepared"))
    parser.add_argument("--combined-manifest", type=Path)
    parser.add_argument("--output", type=Path)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    settings = settings_for_prepared_root(
        get_settings(reload=True),
        args.prepared_root,
        args.combined_manifest,
    )
    store = ManifestStore.load(settings.combined_manifest)
    documents = load_prepared_documents(settings, store)
    embedder = make_embedder(settings)

    try:
        report = preflight_embedding_inputs(documents, store, settings, embedder)
        payload = {
            "status": "passed",
            "prepared_root": str(settings.prepared_root),
            "markdown_documents": len(documents),
            "embedding_model": embedder.name,
            "embedding_dimension": embedder.dimension,
            **asdict(report),
            "opensearch_touched": False,
        }
        exit_code = 0
    except EmbeddingInputLengthError as exc:
        payload = {
            "status": "failed",
            "prepared_root": str(settings.prepared_root),
            "markdown_documents": len(documents),
            "embedding_model": embedder.name,
            "embedding_dimension": embedder.dimension,
            "model_max_tokens": exc.max_input_tokens,
            "over_limit_inputs": exc.total_violations,
            "violations": exc.violations,
            "opensearch_touched": False,
        }
        exit_code = 2

    rendered = json.dumps(payload, indent=2, ensure_ascii=False)
    print(rendered)
    if args.output:
        output = args.output.expanduser().resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(rendered + "\n", encoding="utf-8")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
