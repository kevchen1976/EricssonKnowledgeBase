#!/usr/bin/env python3
"""Safely remove an incomplete Ericsson rebuild generation.

The script is dry-run by default. It refuses to delete an index currently used
by any configured Ericsson alias.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agent_core.settings import get_settings
from ingestion.opensearch_store import (
    backing_names,
    make_client,
    remove_indices,
    validate_index_configuration,
)


def _alias_targets(client: Any, alias: str) -> list[str]:
    try:
        result = client.indices.get_alias(name=alias)
    except Exception as exc:
        status = getattr(exc, "status_code", None)
        if status == 404 or "404" in str(exc):
            return []
        raise
    return sorted(result.keys()) if isinstance(result, dict) else []


def main() -> int:
    parser = argparse.ArgumentParser(description="Delete an incomplete Ericsson rebuild version safely")
    parser.add_argument("--version", required=True, help="Backing-index version, for example 20260902b")
    parser.add_argument("--execute", action="store_true", help="Actually delete; default is preview only")
    args = parser.parse_args()

    settings = get_settings(reload=True)
    validate_index_configuration(settings)
    child, parent = backing_names(settings, args.version)
    targets = [parent, child]

    client = make_client(settings)
    aliases = [settings.parent_alias, settings.child_alias]
    alias_targets = {alias: _alias_targets(client, alias) for alias in aliases}
    live_indices = {index for values in alias_targets.values() for index in values}
    live_conflicts = sorted(set(targets) & live_indices)
    existing = [name for name in targets if client.indices.exists(index=name)]

    payload = {
        "version": args.version,
        "targets": targets,
        "existing_targets": existing,
        "configured_alias_targets": alias_targets,
        "live_conflicts": live_conflicts,
        "execute": bool(args.execute),
    }
    print(json.dumps(payload, indent=2))

    if live_conflicts:
        print(
            "Refusing deletion because at least one target is currently behind a live Ericsson alias. "
            "Create and switch to a newer generation first."
        )
        return 3
    if not args.execute:
        print("Dry run only. Add --execute after confirming the targets and no live conflicts.")
        return 0
    if not existing:
        print("No matching incomplete indexes exist; nothing to delete.")
        return 0

    removed = remove_indices(client, existing, settings)
    print(json.dumps({"removed": removed}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
