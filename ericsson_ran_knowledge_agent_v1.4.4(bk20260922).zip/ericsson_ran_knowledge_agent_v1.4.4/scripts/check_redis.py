#!/usr/bin/env python3
"""Check the shared Redis service using the Ericsson session configuration."""
from __future__ import annotations

import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agent_core.settings import get_settings
from agent_service.sessions import SessionStore


def main() -> int:
    settings = get_settings(reload=True)
    result = {
        "enabled": settings.session_memory_enabled,
        "backend": "redis" if settings.session_memory_enabled else "disabled",
        "host": settings.redis_host,
        "port": settings.redis_port,
        "db": settings.redis_db,
        "key_prefix": settings.redis_key_prefix,
        "session_ttl_seconds": settings.session_ttl_seconds,
        "max_session_history": settings.max_session_history,
        "connected": None,
        "error": "",
    }
    if not settings.session_memory_enabled:
        print(json.dumps(result, indent=2))
        return 0
    store = SessionStore(
        enabled=True,
        max_turns=settings.max_session_history,
        ttl_seconds=settings.session_ttl_seconds,
        stored_answer_chars=settings.session_stored_answer_chars,
        redis_url=settings.redis_url,
        redis_host=settings.redis_host,
        redis_port=settings.redis_port,
        redis_db=settings.redis_db,
        redis_password=settings.redis_password,
        redis_ssl=settings.redis_ssl,
        key_prefix=settings.redis_key_prefix,
        socket_timeout=settings.redis_socket_timeout,
        connect_timeout=settings.redis_connect_timeout,
    )
    try:
        result["connected"] = store.ping()
    except Exception as exc:
        result["connected"] = False
        result["error"] = str(exc)
    finally:
        store.close()
    print(json.dumps(result, indent=2))
    return 0 if result["connected"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
