// Ericsson-native V4 graph indexes used by the Agent Graph API.
// Run only against the dedicated Ericsson Neo4j database.
// The V4 graph builder/loader remains the authority for graph creation.

CREATE CONSTRAINT ericsson_feature_id_unique IF NOT EXISTS
FOR (n:Feature) REQUIRE n.id IS UNIQUE;

CREATE INDEX ericsson_feature_identity_norm IF NOT EXISTS
FOR (n:Feature) ON (n.feature_identity_norm);

CREATE INDEX ericsson_feature_name IF NOT EXISTS
FOR (n:Feature) ON (n.name);

CREATE CONSTRAINT ericsson_moattribute_id_unique IF NOT EXISTS
FOR (n:MOAttribute) REQUIRE n.id IS UNIQUE;

CREATE INDEX ericsson_moattribute_owner_name IF NOT EXISTS
FOR (n:MOAttribute) ON (n.mo_class, n.name);

CREATE CONSTRAINT ericsson_pmcounter_id_unique IF NOT EXISTS
FOR (n:PmCounter) REQUIRE n.id IS UNIQUE;

CREATE INDEX ericsson_pmcounter_name IF NOT EXISTS
FOR (n:PmCounter) ON (n.name);

CREATE CONSTRAINT ericsson_ebscounter_id_unique IF NOT EXISTS
FOR (n:EbsCounter) REQUIRE n.id IS UNIQUE;

CREATE INDEX ericsson_ebscounter_name IF NOT EXISTS
FOR (n:EbsCounter) ON (n.name);

CREATE CONSTRAINT ericsson_fmalarm_id_unique IF NOT EXISTS
FOR (n:FmAlarmType) REQUIRE n.id IS UNIQUE;

CREATE INDEX ericsson_fmalarm_specific_problem IF NOT EXISTS
FOR (n:FmAlarmType) ON (n.specific_problem);

CREATE INDEX ericsson_fmalarm_native_id IF NOT EXISTS
FOR (n:FmAlarmType) ON (n.fm_alarm_type_id);
