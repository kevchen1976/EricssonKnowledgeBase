#!/usr/bin/env python3
"""Compatibility guard for the retired pre-V4 manifest graph importer.

The Ericsson-native V4 graph is built from the MOM/CPI XML and Ericsson
spreadsheets, then enriched by the dedicated Feature overlay loaders. The old
Package/Document/Feature manifest importer used a different graph model and
must not be run against the V4 database.
"""
from __future__ import annotations


def main() -> int:
    raise SystemExit(
        "neo4j/import_staging.py is retired for Ericsson-native V4. "
        "Build/load the V4 native graph first, then run the Feature overlay "
        "loaders. See docs/GRAPH_FUTURE.md and docs/OPERATIONS.md."
    )


if __name__ == "__main__":
    raise SystemExit(main())
