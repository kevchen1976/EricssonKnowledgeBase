# Neo4j runtime support

This folder contains only runtime schema indexes for the Ericsson-native V4
Graph API.

The authoritative graph is built outside the agent package from the latest
MOM/CPI XML and Ericsson spreadsheets. Feature-to-Counter, Feature-to-
MOAttribute, and Feature-to-FmAlarmType overlays are loaded afterward.

`import_staging.py` is retained only as a safety guard. The old manifest-based
Package/Document graph importer is incompatible with V4 and will exit without
writing.
