"""Ericsson hybrid retrieval: rank child vectors, then fetch stored parents."""
from __future__ import annotations

import hashlib
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Sequence

from agent_core.constants import CHILD_STORAGE_ROLE, PARENT_CHILD_CONTRACT
from agent_core.ids import normalize_feature_id, normalize_package_id
from agent_core.logging_utils import single_line, single_line_words

from .state import KBState

_TRACE_RESULT_LIMIT = 5
_TRACE_SNIPPET_WORDS = 50


class ParentContextUnavailableError(RuntimeError):
    """Raised when selected child evidence cannot resolve its stored parent."""


def _sha256_text(text: str) -> str:
    return hashlib.sha256(str(text or "").encode("utf-8")).hexdigest()


@dataclass
class SearchOutcome:
    hits: List[Dict[str, Any]]
    mode: str
    warnings: List[str] = field(default_factory=list)


def _source(hit: Dict[str, Any]) -> Dict[str, Any]:
    value = hit.get("_source", {})
    return value if isinstance(value, dict) else {}


def _rag_logger(state: KBState):
    return getattr(state, "rag_logger", state.logger)


def _trace_child_hits(logger: Any, search_id: str, stage: str, hits: Sequence[Dict[str, Any]]) -> None:
    shown = min(len(hits), _TRACE_RESULT_LIMIT)
    logger.info("[RAG %s] search_id=%s candidates=%d logged=%d", stage, search_id, len(hits), shown)
    for rank, hit in enumerate(hits[:shown], 1):
        source = _source(hit)
        logger.info(
            "[RAG %s] search_id=%s rank=%d child_id=%s os_score=%.8f parent_id=%s "
            "file=%s page=%s-%s section=%s association=%s snippet=%s",
            stage,
            search_id,
            rank,
            source.get("chunk_id") or hit.get("_id") or "",
            float(hit.get("_score") or 0.0),
            source.get("parent_storage_id") or source.get("parent_id") or "",
            single_line(source.get("filename"), max_chars=140),
            source.get("page_start") or "",
            source.get("page_end") or source.get("page_start") or "",
            single_line(source.get("heading_path") or source.get("heading"), max_chars=220),
            source.get("feature_association") or "none",
            single_line_words(source.get("content"), max_words=_TRACE_SNIPPET_WORDS),
        )
    if len(hits) > shown:
        logger.info("[RAG %s] search_id=%s omitted_candidates=%d", stage, search_id, len(hits) - shown)


def _trace_rrf(
    logger: Any,
    search_id: str,
    fused: Sequence[Dict[str, Any]],
    text_hits: Sequence[Dict[str, Any]],
    vector_hits: Sequence[Dict[str, Any]],
) -> None:
    bm25 = {
        str(hit.get("_id") or ""): (rank, float(hit.get("_score") or 0.0))
        for rank, hit in enumerate(text_hits, 1)
        if hit.get("_id")
    }
    vector = {
        str(hit.get("_id") or ""): (rank, float(hit.get("_score") or 0.0))
        for rank, hit in enumerate(vector_hits, 1)
        if hit.get("_id")
    }
    shown = min(len(fused), _TRACE_RESULT_LIMIT)
    logger.info("[RAG RRF] search_id=%s candidates=%d logged=%d", search_id, len(fused), shown)
    for rank, hit in enumerate(fused[:shown], 1):
        doc_id = str(hit.get("_id") or "")
        source = _source(hit)
        bm25_rank, bm25_score = bm25.get(doc_id, (None, None))
        vector_rank, vector_score = vector.get(doc_id, (None, None))
        logger.info(
            "[RAG RRF] search_id=%s rank=%d child_id=%s rrf_score=%.8f "
            "bm25_rank=%s bm25_score=%s vector_rank=%s vector_score=%s parent_id=%s snippet=%s",
            search_id,
            rank,
            source.get("chunk_id") or doc_id,
            float(hit.get("_rrf_score") or 0.0),
            bm25_rank if bm25_rank is not None else "-",
            f"{bm25_score:.8f}" if bm25_score is not None else "-",
            vector_rank if vector_rank is not None else "-",
            f"{vector_score:.8f}" if vector_score is not None else "-",
            source.get("parent_storage_id") or source.get("parent_id") or "",
            single_line_words(source.get("content"), max_words=_TRACE_SNIPPET_WORDS),
        )
    if len(fused) > shown:
        logger.info("[RAG RRF] search_id=%s omitted_candidates=%d", search_id, len(fused) - shown)


def _trace_reranker(logger: Any, search_id: str, fused: Sequence[Dict[str, Any]]) -> None:
    ordered = sorted(
        fused,
        key=lambda hit: float(hit.get("_rerank_score") if hit.get("_rerank_score") is not None else float("-inf")),
        reverse=True,
    )
    shown = min(len(ordered), _TRACE_RESULT_LIMIT)
    logger.info("[RAG RERANKER] search_id=%s candidates=%d logged=%d", search_id, len(ordered), shown)
    for rank, hit in enumerate(ordered[:shown], 1):
        source = _source(hit)
        logger.info(
            "[RAG RERANKER] search_id=%s rank=%d child_id=%s rerank_score=%.8f "
            "rrf_score=%.8f parent_id=%s snippet=%s",
            search_id,
            rank,
            source.get("chunk_id") or hit.get("_id") or "",
            float(hit.get("_rerank_score") or 0.0),
            float(hit.get("_rrf_score") or 0.0),
            source.get("parent_storage_id") or source.get("parent_id") or "",
            single_line_words(source.get("content"), max_words=_TRACE_SNIPPET_WORDS),
        )
    if len(ordered) > shown:
        logger.info("[RAG RERANKER] search_id=%s omitted_candidates=%d", search_id, len(ordered) - shown)


def _trace_final_children(
    logger: Any,
    search_id: str,
    ranked: Sequence[Dict[str, Any]],
    selected: Sequence[Dict[str, Any]],
    state: KBState,
) -> None:
    shown = min(len(selected), _TRACE_RESULT_LIMIT)
    logger.info(
        "[RAG FINAL_CHILD_SELECTION] search_id=%s ranked_candidates=%d selected_children=%d logged=%d",
        search_id,
        len(ranked),
        len(selected),
        shown,
    )
    for rank, hit in enumerate(selected[:shown], 1):
        source = _source(hit)
        base_score = float(
            hit.get("_rerank_score")
            if hit.get("_rerank_score") is not None
            else hit.get("_rrf_score") or hit.get("_score") or 0.0
        )
        multiplier = _association_multiplier(source, state)
        priority = int(source.get("manifest_priority") or 0)
        priority_boost = priority * state.settings.manifest_priority_boost
        logger.info(
            "[RAG FINAL_CHILD] search_id=%s rank=%d child_id=%s final_score=%.8f base_score=%.8f "
            "association=%s association_multiplier=%.6f manifest_priority=%d priority_boost=%.8f "
            "parent_id=%s file=%s section=%s snippet=%s",
            search_id,
            rank,
            source.get("chunk_id") or hit.get("_id") or "",
            float(hit.get("_final_child_score") or 0.0),
            base_score,
            source.get("feature_association") or "none",
            multiplier,
            priority,
            priority_boost,
            source.get("parent_storage_id") or source.get("parent_id") or "",
            single_line(source.get("filename"), max_chars=140),
            single_line(source.get("heading_path") or source.get("heading"), max_chars=220),
            single_line_words(source.get("content"), max_words=_TRACE_SNIPPET_WORDS),
        )
    if len(selected) > shown:
        logger.info(
            "[RAG FINAL_CHILD] search_id=%s omitted_candidates=%d",
            search_id,
            len(selected) - shown,
        )


def _trace_final_parents(logger: Any, search_id: str, parents: Sequence[Dict[str, Any]]) -> None:
    shown = min(len(parents), _TRACE_RESULT_LIMIT)
    logger.info(
        "[RAG FINAL_PARENT_SELECTION] search_id=%s returned_parents=%d logged=%d",
        search_id,
        len(parents),
        shown,
    )
    for rank, hit in enumerate(parents[:shown], 1):
        source = _source(hit)
        matched_children = source.get("matched_children") if isinstance(source.get("matched_children"), list) else []
        logger.info(
            "[RAG FINAL_PARENT] search_id=%s rank=%d parent_id=%s parent_storage_id=%s score=%.8f "
            "matched_children=%d file=%s page=%s-%s section=%s snippet=%s",
            search_id,
            rank,
            source.get("parent_id") or hit.get("_id") or "",
            source.get("parent_storage_id") or hit.get("_id") or "",
            float(hit.get("_score") or 0.0),
            len(matched_children),
            single_line(source.get("filename"), max_chars=140),
            source.get("page_start") or "",
            source.get("page_end") or source.get("page_start") or "",
            single_line(source.get("heading_path") or source.get("heading"), max_chars=220),
            single_line_words(source.get("content"), max_words=_TRACE_SNIPPET_WORDS),
        )
    if len(parents) > shown:
        logger.info(
            "[RAG FINAL_PARENT] search_id=%s omitted_candidates=%d",
            search_id,
            len(parents) - shown,
        )


def _bool_filter(filters: Mapping[str, Any], state: KBState) -> Dict[str, Any]:
    settings = state.settings
    clauses: List[Dict[str, Any]] = [
        {"term": {"storage_role": CHILD_STORAGE_ROLE}},
        {"term": {"retrieval_contract": PARENT_CHILD_CONTRACT}},
    ]
    if settings.strict_vendor_filter:
        clauses.extend([
            {"term": {"vendor": settings.vendor}},
            {"term": {"corpus_id": settings.corpus_id}},
        ])

    filename = str(filters.get("filename") or "").strip()
    filenames = [str(value) for value in filters.get("filenames", []) if value]
    if filename:
        clauses.append({"term": {"filename": filename}})
    elif filenames:
        clauses.append({"terms": {"filename": filenames}})

    feature_id = normalize_feature_id(str(filters.get("feature_id") or ""))
    if feature_id:
        clauses.append({
            "bool": {
                "should": [
                    {"term": {"feature_id": feature_id}},
                    {"term": {"owner_feature_id": feature_id}},
                    {"term": {"feature_ids": feature_id}},
                    {"term": {"included_feature_ids": feature_id}},
                    {"term": {"mentioned_feature_ids": feature_id}},
                    {"term": {"related_feature_ids": feature_id}},
                ],
                "minimum_should_match": 1,
            }
        })

    package_id = normalize_package_id(str(filters.get("package_id") or ""))
    if package_id:
        clauses.append({
            "bool": {
                "should": [
                    {"term": {"package_id": package_id}},
                    {"term": {"primary_package_id": package_id}},
                    {"term": {"package_ids": package_id}},
                ],
                "minimum_should_match": 1,
            }
        })

    keyword_fields = {
        "doc_type": "doc_type",
        "doc_role": "doc_role",
        "section_type": "section_type",
        "feature_association": "feature_association",
        "access_type": "access_types",
    }
    for request_key, index_field in keyword_fields.items():
        value = str(filters.get(request_key) or "").strip()
        if value:
            clauses.append({"term": {index_field: value}})
    return {"bool": {"filter": clauses}} if clauses else {"match_all": {}}


def _text_query(query: str, filter_query: Dict[str, Any], state: KBState) -> Dict[str, Any]:
    settings = state.settings
    filter_clauses = filter_query.get("bool", {}).get("filter", []) if "bool" in filter_query else []
    return {
        "bool": {
            "filter": filter_clauses,
            "should": [
                {
                    "multi_match": {
                        "query": query,
                        "type": "best_fields",
                        "fields": [
                            f"content^{settings.bm25_content_boost}",
                            f"heading_path^{settings.bm25_heading_boost}",
                            f"heading^{settings.bm25_heading_boost}",
                            f"title^{settings.bm25_title_boost}",
                            "feature_title^3.0",
                            "topics^1.4",
                            "question_templates^1.2",
                        ],
                    }
                },
                {"match_phrase": {"content": {"query": query, "boost": 1.5}}},
            ],
            "minimum_should_match": 1,
        }
    }


def _rrf(
    text_hits: Sequence[Dict[str, Any]],
    vector_hits: Sequence[Dict[str, Any]],
    rank_constant: int,
) -> List[Dict[str, Any]]:
    scores: Dict[str, float] = {}
    originals: Dict[str, Dict[str, Any]] = {}
    for hits in (text_hits, vector_hits):
        for rank, hit in enumerate(hits, 1):
            doc_id = str(hit.get("_id") or "")
            if not doc_id:
                continue
            scores[doc_id] = scores.get(doc_id, 0.0) + 1.0 / (rank + rank_constant)
            current = originals.get(doc_id)
            if current is None or float(hit.get("_score") or 0.0) > float(current.get("_score") or 0.0):
                originals[doc_id] = hit
    output: List[Dict[str, Any]] = []
    for doc_id in sorted(scores, key=scores.get, reverse=True):
        hit = dict(originals[doc_id])
        hit["_rrf_score"] = scores[doc_id]
        output.append(hit)
    return output


def _association_multiplier(source: Dict[str, Any], state: KBState) -> float:
    step = state.settings.feature_association_boost
    association = str(source.get("feature_association") or "none")
    if association == "primary":
        return 1.0 + 2 * step
    if association == "included":
        return 1.0 + step
    if association == "related":
        return 1.0 + step / 2
    if association == "mentioned":
        return max(0.5, 1.0 - step)
    return 1.0


def _rank_children(hits: Sequence[Dict[str, Any]], state: KBState) -> List[Dict[str, Any]]:
    """Apply Ericsson association/manifest boosts before final child selection."""
    ranked: List[Dict[str, Any]] = []
    for hit in hits:
        source = _source(hit)
        base = float(
            hit.get("_rerank_score")
            if hit.get("_rerank_score") is not None
            else hit.get("_rrf_score") or hit.get("_score") or 0.0
        )
        priority = int(source.get("manifest_priority") or 0)
        score = base * _association_multiplier(source, state)
        score += priority * state.settings.manifest_priority_boost
        updated = dict(hit)
        updated["_final_child_score"] = score
        ranked.append(updated)
    ranked.sort(key=lambda value: float(value.get("_final_child_score") or 0.0), reverse=True)
    return ranked


def _parent_storage_ids(children: Sequence[Dict[str, Any]]) -> List[str]:
    values: List[str] = []
    seen: set[str] = set()
    for child in children:
        source = _source(child)
        storage_id = str(source.get("parent_storage_id") or source.get("parent_id") or "").strip()
        if storage_id and storage_id not in seen:
            seen.add(storage_id)
            values.append(storage_id)
    return values


def _fetch_parents(client: Any, alias: str, storage_ids: Sequence[str]) -> Dict[str, Dict[str, Any]]:
    if not storage_ids:
        return {}
    response = client.mget(index=alias, body={"ids": list(storage_ids)})
    parents: Dict[str, Dict[str, Any]] = {}
    for document in response.get("docs", []) if isinstance(response, dict) else []:
        if not document.get("found"):
            continue
        source = document.get("_source") or {}
        if isinstance(source, dict):
            parents[str(document.get("_id") or "")] = source
    return parents


def _expand_parents(
    selected_children: Sequence[Dict[str, Any]],
    parents: Mapping[str, Dict[str, Any]],
    warnings: List[str],
    *,
    require_parent_context: bool = True,
    verify_parent_content_hash: bool = True,
) -> List[Dict[str, Any]]:
    """Expand selected child hits to unique full parents in child-rank order.

    In the default strict mode, a missing or mismatched parent is a retrieval
    integrity failure. The optional child fallback exists only for controlled
    migration/diagnostic use.
    """
    output: List[Dict[str, Any]] = []
    by_storage_id: Dict[str, Dict[str, Any]] = {}
    warned_missing: set[str] = set()
    warned_hashes: set[str] = set()

    for rank, child_hit in enumerate(selected_children, 1):
        child_source = _source(child_hit)
        storage_id = str(child_source.get("parent_storage_id") or child_source.get("parent_id") or "").strip()
        logical_parent_id = str(child_source.get("parent_id") or storage_id)
        child_score = float(
            child_hit.get("_final_child_score")
            or child_hit.get("_rerank_score")
            or child_hit.get("_rrf_score")
            or child_hit.get("_score")
            or 0.0
        )
        matched_child = {
            "child_id": child_source.get("chunk_id") or child_hit.get("_id"),
            "rank": rank,
            "score": child_score,
            "content": str(child_source.get("content") or ""),
            "page_start": int(child_source.get("page_start") or 1),
            "page_end": int(child_source.get("page_end") or child_source.get("page_start") or 1),
            "heading_path": child_source.get("heading_path"),
            "section_type": child_source.get("section_type"),
        }

        parent_source = dict(parents.get(storage_id, {}))
        use_child_fallback = False
        if not parent_source:
            message = (
                f"Stored parent {storage_id or logical_parent_id} was unavailable for selected child "
                f"{matched_child['child_id']}."
            )
            if require_parent_context:
                raise ParentContextUnavailableError(message)
            use_child_fallback = True
            if storage_id not in warned_missing:
                warnings.append(message + " Child content was returned as fallback.")
                warned_missing.add(storage_id)

        if parent_source and verify_parent_content_hash:
            expected_hash = str(child_source.get("parent_content_sha256") or "").strip()
            parent_content = str(parent_source.get("content") or "")
            actual_hash = str(parent_source.get("content_sha256") or "").strip() or _sha256_text(parent_content)
            if not expected_hash:
                message = (
                    f"Selected child {matched_child['child_id']} has no expected parent-content hash for "
                    f"stored parent {storage_id or logical_parent_id}."
                )
                if require_parent_context:
                    raise ParentContextUnavailableError(message)
                use_child_fallback = True
                if storage_id not in warned_hashes:
                    warnings.append(message + " Child content was returned as fallback.")
                    warned_hashes.add(storage_id)
            elif actual_hash != expected_hash:
                message = (
                    f"Stored parent {storage_id or logical_parent_id} failed content-integrity validation for "
                    f"selected child {matched_child['child_id']}."
                )
                if require_parent_context:
                    raise ParentContextUnavailableError(message)
                use_child_fallback = True
                if storage_id not in warned_hashes:
                    warnings.append(message + " Child content was returned as fallback.")
                    warned_hashes.add(storage_id)

        if storage_id in by_storage_id and not use_child_fallback:
            by_storage_id[storage_id]["_source"]["matched_children"].append(matched_child)
            continue

        if use_child_fallback:
            parent_source = dict(child_source)
            parent_source["content"] = str(child_source.get("content") or "")
            parent_source["parent_id"] = logical_parent_id
            parent_source["parent_storage_id"] = storage_id
            # A fallback result is intentionally keyed per child so two missing
            # parents cannot collapse into one fabricated context record.
            result_key = f"fallback:{matched_child['child_id']}"
        else:
            result_key = storage_id

        parent_source.pop("embedding", None)
        parent_source.pop("embedding_text", None)
        parent_source.pop("parent_content", None)
        parent_source["parent_id"] = str(parent_source.get("parent_id") or logical_parent_id)
        parent_source["parent_storage_id"] = str(parent_source.get("parent_storage_id") or storage_id)
        parent_source["matched_children"] = [matched_child]
        result = {
            "_id": storage_id or logical_parent_id,
            "_score": child_score,
            "_rrf_score": child_hit.get("_rrf_score"),
            "_rerank_score": child_hit.get("_rerank_score"),
            "_source": parent_source,
        }
        by_storage_id[result_key] = result
        output.append(result)
    return output


class HybridSearchEngine:
    def __init__(self, state: KBState) -> None:
        self.state = state

    def search(self, query: str, *, limit: int, filters: Optional[Mapping[str, Any]] = None) -> SearchOutcome:
        """Select ``limit`` child hits, then fetch and deduplicate their parents.

        The number of returned parents can be smaller than ``limit`` when more
        than one selected child belongs to the same section. Contributing child
        evidence is retained under ``matched_children``.
        """
        started = time.perf_counter()
        search_id = uuid.uuid4().hex[:12]
        query = " ".join(str(query or "").split())
        if not query:
            raise ValueError("Search query cannot be empty")
        settings = self.state.settings
        limit = min(max(1, int(limit)), settings.maximum_limit)
        initial = max(limit * 10, settings.initial_candidate_count)
        filter_values = dict(filters or {})
        filter_query = _bool_filter(filter_values, self.state)
        client = self.state.client()
        warnings: List[str] = []
        rag_logger = _rag_logger(self.state)

        rag_logger.info(
            "[RAG START] search_id=%s query=%r limit=%d initial_candidates=%d child_alias=%s "
            "parent_alias=%s reranker_enabled=%s filters=%s",
            search_id,
            query,
            limit,
            initial,
            settings.child_alias,
            settings.parent_alias,
            settings.reranker_enabled,
            filter_values,
        )

        child_source_filter = {"excludes": ["embedding", "embedding_text", "parent_content"]}
        text_body = {
            "size": initial,
            "track_total_hits": False,
            "_source": child_source_filter,
            "query": _text_query(query, filter_query, self.state),
        }
        stage_started = time.perf_counter()
        text_response = client.search(index=settings.child_alias, body=text_body)
        text_hits = list((text_response.get("hits") or {}).get("hits") or [])
        bm25_ms = int((time.perf_counter() - stage_started) * 1000)
        rag_logger.info("[RAG BM25] search_id=%s elapsed_ms=%d", search_id, bm25_ms)
        _trace_child_hits(rag_logger, search_id, "BM25_RECALL", text_hits)

        vector_hits: List[Dict[str, Any]] = []
        vector_ok = False
        embedding_ms = 0
        vector_ms = 0
        try:
            stage_started = time.perf_counter()
            vector = self.state.embedder().encode([query])[0]
            embedding_ms = int((time.perf_counter() - stage_started) * 1000)
            rag_logger.info(
                "[RAG QUERY_EMBEDDING] search_id=%s elapsed_ms=%d dimension=%d",
                search_id,
                embedding_ms,
                len(vector),
            )
            knn_clause: Dict[str, Any] = {"vector": vector, "k": initial}
            if filter_query and "match_all" not in filter_query:
                knn_clause["filter"] = filter_query
            vector_body = {
                "size": initial,
                "track_total_hits": False,
                "_source": child_source_filter,
                "query": {"knn": {"embedding": knn_clause}},
            }
            stage_started = time.perf_counter()
            vector_response = client.search(index=settings.child_alias, body=vector_body)
            vector_ms = int((time.perf_counter() - stage_started) * 1000)
            vector_hits = list((vector_response.get("hits") or {}).get("hits") or [])
            vector_ok = True
            rag_logger.info("[RAG VECTOR] search_id=%s elapsed_ms=%d", search_id, vector_ms)
            _trace_child_hits(rag_logger, search_id, "VECTOR_RECALL", vector_hits)
        except Exception as exc:
            if not settings.allow_bm25_only:
                rag_logger.exception("[RAG VECTOR_ERROR] search_id=%s", search_id)
                raise
            warning = f"Vector retrieval was unavailable; BM25-only retrieval was used: {exc}"
            warnings.append(warning)
            rag_logger.warning("[RAG VECTOR_FALLBACK] search_id=%s error=%s", search_id, single_line(exc, max_chars=500))

        stage_started = time.perf_counter()
        fused = _rrf(text_hits, vector_hits, settings.rrf_rank_constant)
        rrf_ms = int((time.perf_counter() - stage_started) * 1000)
        rag_logger.info(
            "[RAG RRF_SUMMARY] search_id=%s elapsed_ms=%d rank_constant=%d",
            search_id,
            rrf_ms,
            settings.rrf_rank_constant,
        )
        _trace_rrf(rag_logger, search_id, fused, text_hits, vector_hits)

        reranker_ms = 0
        if settings.reranker_enabled and fused:
            try:
                stage_started = time.perf_counter()
                reranker = self.state.reranker()
                pairs = [[query, str(_source(hit).get("content") or "")] for hit in fused]
                scores = reranker.predict(pairs, convert_to_numpy=True, show_progress_bar=False)
                for hit, score in zip(fused, scores):
                    hit["_rerank_score"] = float(score)
                reranker_ms = int((time.perf_counter() - stage_started) * 1000)
                rag_logger.info(
                    "[RAG RERANKER_SUMMARY] search_id=%s elapsed_ms=%d candidates=%d",
                    search_id,
                    reranker_ms,
                    len(fused),
                )
                _trace_reranker(rag_logger, search_id, fused)
            except Exception as exc:
                warning = f"Reranking was unavailable; RRF order was retained: {exc}"
                warnings.append(warning)
                rag_logger.warning(
                    "[RAG RERANKER_FALLBACK] search_id=%s error=%s",
                    search_id,
                    single_line(exc, max_chars=500),
                )
        else:
            rag_logger.info(
                "[RAG RERANKER_DISABLED] search_id=%s enabled=%s fused_candidates=%d",
                search_id,
                settings.reranker_enabled,
                len(fused),
            )

        ranked_children = _rank_children(fused, self.state)
        selected_children = ranked_children[:limit]
        _trace_final_children(rag_logger, search_id, ranked_children, selected_children, self.state)

        parent_ids = _parent_storage_ids(selected_children)
        logged_parent_ids = parent_ids[:_TRACE_RESULT_LIMIT]
        rag_logger.info(
            "[RAG PARENT_MGET_REQUEST] search_id=%s parent_alias=%s requested=%d logged=%d ids=%s omitted=%d",
            search_id,
            settings.parent_alias,
            len(parent_ids),
            len(logged_parent_ids),
            logged_parent_ids,
            max(0, len(parent_ids) - len(logged_parent_ids)),
        )
        require_parent_context = bool(getattr(settings, "require_parent_context", True))
        verify_parent_content_hash = bool(getattr(settings, "verify_parent_content_hash", True))
        parent_ms = 0
        try:
            stage_started = time.perf_counter()
            parents = _fetch_parents(client, settings.parent_alias, parent_ids)
            parent_ms = int((time.perf_counter() - stage_started) * 1000)
            rag_logger.info(
                "[RAG PARENT_MGET_RESULT] search_id=%s elapsed_ms=%d requested=%d found=%d",
                search_id,
                parent_ms,
                len(parent_ids),
                len(parents),
            )
        except Exception as exc:
            if require_parent_context:
                rag_logger.exception("[RAG PARENT_MGET_ERROR] search_id=%s", search_id)
                raise ParentContextUnavailableError(
                    f"Parent-context lookup from {settings.parent_alias} failed: {exc}"
                ) from exc
            parents = {}
            warning = f"Parent-context lookup was unavailable; child fallback was used: {exc}"
            warnings.append(warning)
            rag_logger.warning(
                "[RAG PARENT_FALLBACK] search_id=%s error=%s",
                search_id,
                single_line(exc, max_chars=500),
            )

        missing_parent_ids = [parent_id for parent_id in parent_ids if parent_id not in parents]
        if missing_parent_ids:
            logged_missing_ids = missing_parent_ids[:_TRACE_RESULT_LIMIT]
            rag_logger.warning(
                "[RAG MISSING_PARENTS] search_id=%s count=%d logged=%d ids=%s omitted=%d strict=%s",
                search_id,
                len(missing_parent_ids),
                len(logged_missing_ids),
                logged_missing_ids,
                max(0, len(missing_parent_ids) - len(logged_missing_ids)),
                require_parent_context,
            )
        if missing_parent_ids and require_parent_context:
            preview = ", ".join(missing_parent_ids[:5])
            suffix = " ..." if len(missing_parent_ids) > 5 else ""
            raise ParentContextUnavailableError(
                f"{len(missing_parent_ids)} selected parent document(s) were missing from "
                f"{settings.parent_alias}: {preview}{suffix}"
            )

        parent_hits = _expand_parents(
            selected_children,
            parents,
            warnings,
            require_parent_context=require_parent_context,
            verify_parent_content_hash=verify_parent_content_hash,
        )
        _trace_final_parents(rag_logger, search_id, parent_hits)

        elapsed_ms = int((time.perf_counter() - started) * 1000)
        rag_logger.info(
            "[RAG COMPLETE] search_id=%s mode=%s elapsed_ms=%d bm25_ms=%d embedding_ms=%d "
            "vector_ms=%d rrf_ms=%d reranker_ms=%d parent_mget_ms=%d text_hits=%d vector_hits=%d "
            "fused=%d selected_children=%d returned_parents=%d warnings=%d",
            search_id,
            "hybrid_parent_child_search" if vector_ok else "bm25_parent_child_search",
            elapsed_ms,
            bm25_ms,
            embedding_ms,
            vector_ms,
            rrf_ms,
            reranker_ms,
            parent_ms,
            len(text_hits),
            len(vector_hits),
            len(fused),
            len(selected_children),
            len(parent_hits),
            len(warnings),
        )

        self.state.logger.info(
            "query=%r child_alias=%s parent_alias=%s text_hits=%d vector_hits=%d "
            "selected_children=%d returned_parents=%d filters=%s elapsed_ms=%d search_id=%s",
            query,
            settings.child_alias,
            settings.parent_alias,
            len(text_hits),
            len(vector_hits),
            len(selected_children),
            len(parent_hits),
            filter_values,
            elapsed_ms,
            search_id,
        )
        return SearchOutcome(
            hits=parent_hits,
            mode="hybrid_parent_child_search" if vector_ok else "bm25_parent_child_search",
            warnings=warnings,
        )
