"""FastAPI assembly for the standalone Ericsson Knowledge Base service."""
from __future__ import annotations

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from agent_core.constants import PACKAGE_VERSION
from agent_core.logging_utils import request_context
from fastapi.staticfiles import StaticFiles

from .routes import search, system
from .search import ParentContextUnavailableError
from .state import get_state

state = get_state()
app = FastAPI(
    title="Ericsson RAN Knowledge Base API",
    version=PACKAGE_VERSION,
    description="Ericsson-only Markdown/manifest retrieval over dedicated OpenSearch aliases.",
)

# Markdown and sibling image folders are served from the same root.  Links such
# as ``Document_images/page_004_image_001.png`` therefore resolve unchanged.
app.mount(
    "/" + state.settings.kb_asset_url_prefix.strip("/"),
    StaticFiles(directory=str(state.settings.markdown_root), check_dir=False),
    name="kb-assets",
)
app.include_router(search.router)
app.include_router(system.router)


@app.middleware("http")
async def bind_request_context(request: Request, call_next):
    """Correlate direct KB calls and Agent -> KB calls in the RAG trace log."""
    request_id = str(request.headers.get("X-Request-ID") or "").strip() or None
    with request_context(request_id):
        return await call_next(request)


@app.exception_handler(ParentContextUnavailableError)
async def parent_context_unavailable_handler(
    request: Request, exc: ParentContextUnavailableError
) -> JSONResponse:
    del request
    return JSONResponse(
        status_code=503,
        content={
            "detail": str(exc),
            "error_code": "PARENT_CONTEXT_UNAVAILABLE",
        },
    )
