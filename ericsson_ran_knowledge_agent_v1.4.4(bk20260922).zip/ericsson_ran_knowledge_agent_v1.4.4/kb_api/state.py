"""Lazy OpenSearch, embedding, reranker, settings, and logging state."""
from __future__ import annotations

import threading
from typing import Any, Optional

from agent_core.logging_utils import configure_file_logger
from agent_core.settings import Settings, get_settings
from ingestion.embedding import SentenceTransformerEmbedder
from ingestion.opensearch_store import make_client, validate_index_configuration


class KBState:
    def __init__(self, settings: Optional[Settings] = None) -> None:
        self.settings = settings or get_settings()
        # Fail closed before any query is issued if deployment variables point at
        # a Nokia or generic shared index namespace.
        validate_index_configuration(self.settings)
        self._client: Any = None
        self._embedder: Optional[SentenceTransformerEmbedder] = None
        self._reranker: Any = None
        self._lock = threading.RLock()
        self.logger = configure_file_logger(
            "ericsson_kb",
            self.settings.logs_dir / "ericsson_kb.log",
        )
        # Keep the Nokia-style detailed retrieval trace in a dedicated file.
        self.rag_logger = configure_file_logger(
            "ericsson_rag",
            self.settings.logs_dir / "chunks.log",
        )

    def client(self):
        with self._lock:
            if self._client is None:
                self._client = make_client(self.settings)
            return self._client

    def embedder(self) -> SentenceTransformerEmbedder:
        with self._lock:
            if self._embedder is None:
                self._embedder = SentenceTransformerEmbedder(
                    self.settings.embedding_model_path,
                    device=self.settings.embedding_device,
                    normalize=self.settings.embedding_normalize,
                    local_files_only=self.settings.local_files_only,
                    batch_size=self.settings.embedding_batch_size,
                    max_input_tokens=self.settings.embedding_max_input_tokens,
                )
            return self._embedder

    def reranker(self):
        if not self.settings.reranker_enabled:
            return None
        with self._lock:
            if self._reranker is None:
                from sentence_transformers import CrossEncoder

                path = self.settings.reranker_model_path
                if self.settings.local_files_only and not path.is_dir():
                    raise FileNotFoundError(f"Local reranker model directory not found: {path}")
                source = str(path) if path.exists() else str(path)
                try:
                    self._reranker = CrossEncoder(
                        source,
                        device=self.settings.reranker_device,
                        local_files_only=self.settings.local_files_only,
                    )
                except Exception:
                    if self.settings.reranker_device == "cpu":
                        raise
                    self._reranker = CrossEncoder(
                        source,
                        device="cpu",
                        local_files_only=self.settings.local_files_only,
                    )
            return self._reranker

    def opensearch_status(self) -> dict[str, Any]:
        try:
            client = self.client()
            info = client.info()
            child_exists = bool(client.indices.exists_alias(name=self.settings.child_alias))
            parent_exists = bool(client.indices.exists_alias(name=self.settings.parent_alias))
            return {
                "connected": True,
                "cluster_name": info.get("cluster_name", ""),
                "version": (info.get("version") or {}).get("number", ""),
                "child_alias_exists": child_exists,
                "parent_alias_exists": parent_exists,
                "chunk_alias_exists": child_exists,
            }
        except Exception as exc:
            return {"connected": False, "error": str(exc)}


_STATE: Optional[KBState] = None


def get_state(*, reload: bool = False) -> KBState:
    global _STATE
    if _STATE is None or reload:
        _STATE = KBState()
    return _STATE
