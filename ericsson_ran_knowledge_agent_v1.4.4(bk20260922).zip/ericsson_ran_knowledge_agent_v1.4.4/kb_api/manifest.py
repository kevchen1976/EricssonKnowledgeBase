"""Ericsson filesystem-manifest resolution and Markdown asset URL normalization.

Nokia parity: runtime routing reads prepared JSONL manifests from disk only.
OpenSearch stores searchable child/parent content, not manifest records.
"""
from __future__ import annotations

import json
import re
import time
import uuid
from pathlib import Path, PurePosixPath
from typing import Any, Dict, Iterable, List, Optional
from urllib.parse import quote, unquote, urlparse

from agent_core.ids import feature_key, normalize_feature_id, normalize_package_id, package_key
from agent_core.logging_utils import single_line, single_line_words

from .state import KBState

_IMAGE_RE = re.compile(r"!\[([^\]]*)\]\(([^)]+)\)")
_MANIFEST_LOG_RESULT_LIMIT = 5
_MANIFEST_LOG_SNIPPET_WORDS = 50

SAFE_MANIFEST_FIELDS = [
    "record_kind", "record_id", "feature_id", "primary_feature_id", "feature_ids",
    "included_feature_ids", "mentioned_feature_ids", "related_feature_ids",
    "owner_feature_id", "feature_title", "package_id", "primary_package_id",
    "package_ids", "package_names", "filename", "source_markdown", "source_pdf",
    "title", "doc_type", "document_subtype", "doc_role", "manifest_stage",
    "section_type", "section_heading", "heading_path", "page_start", "page_end",
    "access_types", "node_types", "licensing", "prerequisites",
    "restriction_status", "feature_association", "topics", "topic_aliases",
    "content_retrievable", "is_feature_owner", "route_by_feature",
    "route_by_package", "route_by_topic",
]


def _read_jsonl(path: Path) -> List[Dict[str, Any]]:
    records: List[Dict[str, Any]] = []
    if not path.exists():
        return records
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            line = line.strip()
            if not line:
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid manifest JSONL at {path}:{line_number}: {exc}") from exc
            if isinstance(value, dict):
                records.append(value)
    return records


def _document(record: Dict[str, Any]) -> bool:
    return str(record.get("record_kind") or record.get("manifest_stage") or "") == "document"


def _direct_feature(record: Dict[str, Any], feature_id: str) -> bool:
    if not _document(record):
        return False
    owner = normalize_feature_id(str(record.get("owner_feature_id") or record.get("feature_id") or ""))
    return bool(
        owner == feature_id
        and (
            bool(record.get("is_feature_owner"))
            or str(record.get("doc_role") or "") == "feature_document"
            or str(record.get("doc_type") or "") == "feature_description"
        )
    )


def _related_feature(record: Dict[str, Any], feature_id: str) -> bool:
    values: List[str] = []
    for key in ("feature_ids", "included_feature_ids", "mentioned_feature_ids", "related_feature_ids"):
        raw = record.get(key, [])
        if not isinstance(raw, list):
            raw = [raw] if raw else []
        values.extend(normalize_feature_id(str(value)) for value in raw)
    return feature_id in values


def _package_match(record: Dict[str, Any], package_id: str) -> bool:
    values: List[str] = []
    for key in ("package_id", "primary_package_id"):
        value = normalize_package_id(str(record.get(key) or ""))
        if value:
            values.append(value)
    raw = record.get("package_ids", [])
    if not isinstance(raw, list):
        raw = [raw] if raw else []
    values.extend(normalize_package_id(str(value)) for value in raw)
    return package_id in values


def public_manifest_record(record: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not record:
        return None
    return {key: record.get(key) for key in SAFE_MANIFEST_FIELDS if key in record}


def _manifest_logger(state: KBState):
    return getattr(state, "rag_logger", getattr(state, "logger", None))


def _manifest_record_preview(record: Dict[str, Any]) -> str:
    """Return a bounded human-readable preview for manifest trace logging."""
    for key in (
        "summary",
        "content",
        "description",
        "value",
        "text",
        "section_heading",
        "title",
        "feature_title",
        "filename",
    ):
        value = record.get(key)
        if value not in (None, "", [], {}):
            if isinstance(value, (dict, list)):
                value = json.dumps(value, ensure_ascii=False, default=str)
            return single_line_words(value, max_words=_MANIFEST_LOG_SNIPPET_WORDS)
    return ""


def _trace_manifest_records(
    logger: Any,
    *,
    lookup_id: str,
    lookup_kind: str,
    lookup_value: str,
    source: str,
    records: List[Dict[str, Any]],
) -> None:
    if logger is None:
        return
    shown = min(len(records), _MANIFEST_LOG_RESULT_LIMIT)
    logger.info(
        "[MANIFEST RESULTS] lookup_id=%s kind=%s value=%s source=%s candidates=%d logged=%d",
        lookup_id,
        lookup_kind,
        lookup_value,
        source,
        len(records),
        shown,
    )
    for rank, record in enumerate(records[:shown], 1):
        logger.info(
            "[MANIFEST RESULT] lookup_id=%s kind=%s value=%s source=%s rank=%d "
            "record_kind=%s record_id=%s file=%s doc_type=%s doc_role=%s association=%s "
            "page=%s-%s section=%s snippet=%s",
            lookup_id,
            lookup_kind,
            lookup_value,
            source,
            rank,
            record.get("record_kind") or record.get("manifest_stage") or "",
            single_line(record.get("record_id"), max_chars=180),
            single_line(record.get("filename") or record.get("source_markdown"), max_chars=160),
            record.get("doc_type") or "",
            record.get("doc_role") or "",
            record.get("feature_association") or "none",
            record.get("page_start") or "",
            record.get("page_end") or record.get("page_start") or "",
            single_line(record.get("heading_path") or record.get("section_heading"), max_chars=220),
            _manifest_record_preview(record),
        )
    if len(records) > shown:
        logger.info(
            "[MANIFEST RESULTS] lookup_id=%s kind=%s value=%s source=%s omitted_candidates=%d",
            lookup_id,
            lookup_kind,
            lookup_value,
            source,
            len(records) - shown,
        )


class ManifestRepository:
    def __init__(self, state: KBState) -> None:
        self.state = state
        self.settings = state.settings
        self.logger = _manifest_logger(state)

    def feature_records(self, value: str, *, _lookup_id: str | None = None) -> List[Dict[str, Any]]:
        lookup_id = _lookup_id or uuid.uuid4().hex
        started = time.perf_counter()
        feature_id = normalize_feature_id(value)
        if self.logger is not None:
            self.logger.info(
                "[MANIFEST SEARCH START] lookup_id=%s kind=feature requested=%s normalized=%s",
                lookup_id,
                single_line(value, max_chars=100),
                feature_id,
            )
        if not feature_id:
            if self.logger is not None:
                self.logger.info(
                    "[MANIFEST SEARCH COMPLETE] lookup_id=%s kind=feature source=none records=0 "
                    "elapsed_ms=%d reason=invalid_identity",
                    lookup_id,
                    int((time.perf_counter() - started) * 1000),
                )
            return []

        key = feature_key(feature_id)
        path = self.settings.feature_manifest_root / "FAJ121" / f"{key}.jsonl"
        mentioned_path = self.settings.mentioned_feature_manifest_root / "FAJ121" / f"{key}.jsonl"
        direct_records = _read_jsonl(path)
        mentioned_records = _read_jsonl(mentioned_path)
        if self.logger is not None:
            self.logger.info(
                "[MANIFEST FILE_SEARCH] lookup_id=%s kind=feature value=%s role=direct "
                "path=%s exists=%s records=%d",
                lookup_id,
                feature_id,
                path,
                path.is_file(),
                len(direct_records),
            )
            self.logger.info(
                "[MANIFEST FILE_SEARCH] lookup_id=%s kind=feature value=%s role=mentioned "
                "path=%s exists=%s records=%d",
                lookup_id,
                feature_id,
                mentioned_path,
                mentioned_path.is_file(),
                len(mentioned_records),
            )

        local_records = direct_records + mentioned_records
        if local_records:
            seen: set[str] = set()
            records: List[Dict[str, Any]] = []
            for record in local_records:
                identity = str(record.get("record_id") or json.dumps(record, sort_keys=True, default=str))
                if identity not in seen:
                    seen.add(identity)
                    records.append(record)
            _trace_manifest_records(
                self.logger,
                lookup_id=lookup_id,
                lookup_kind="feature",
                lookup_value=feature_id,
                source="local_jsonl",
                records=records,
            )
            if self.logger is not None:
                self.logger.info(
                    "[MANIFEST SEARCH COMPLETE] lookup_id=%s kind=feature value=%s source=local_jsonl "
                    "records=%d elapsed_ms=%d",
                    lookup_id,
                    feature_id,
                    len(records),
                    int((time.perf_counter() - started) * 1000),
                )
            return records

        if self.logger is not None:
            self.logger.info(
                "[MANIFEST SEARCH COMPLETE] lookup_id=%s kind=feature value=%s source=local_jsonl "
                "records=0 elapsed_ms=%d reason=no_local_records",
                lookup_id,
                feature_id,
                int((time.perf_counter() - started) * 1000),
            )
        return []

    def feature_bundle(self, value: str) -> Dict[str, Any]:
        lookup_id = uuid.uuid4().hex
        feature_id = normalize_feature_id(value)
        records = self.feature_records(value, _lookup_id=lookup_id)
        direct = [record for record in records if _direct_feature(record, feature_id)]
        related_docs = [
            record
            for record in records
            if _document(record)
            and not _direct_feature(record, feature_id)
            and _related_feature(record, feature_id)
        ]
        direct.sort(
            key=lambda record: (
                str(record.get("doc_type")) != "feature_description",
                str(record.get("filename") or ""),
            )
        )
        related_docs.sort(
            key=lambda record: (
                str(record.get("feature_association") or "") == "mentioned",
                str(record.get("doc_role") or "") == "general_document",
                str(record.get("filename") or ""),
            )
        )
        title = ""
        for record in direct + related_docs + records:
            candidate = str(record.get("feature_title") or "").strip()
            if candidate:
                title = candidate
                break
        primary = direct[0] if direct else None
        if self.logger is not None:
            self.logger.info(
                "[MANIFEST FEATURE_SELECTION] lookup_id=%s feature_id=%s records=%d "
                "direct_documents=%d related_documents=%d primary_file=%s title=%s",
                lookup_id,
                feature_id,
                len(records),
                len(direct),
                len(related_docs),
                single_line((primary or {}).get("filename"), max_chars=160),
                single_line(title, max_chars=160),
            )
        return {
            "feature_id": feature_id,
            "feature_title": title,
            "primary": primary,
            "direct_documents": direct,
            "related_documents": related_docs,
            "records": records,
        }

    def package_records(self, value: str, *, _lookup_id: str | None = None) -> List[Dict[str, Any]]:
        lookup_id = _lookup_id or uuid.uuid4().hex
        started = time.perf_counter()
        package_id = normalize_package_id(value)
        if self.logger is not None:
            self.logger.info(
                "[MANIFEST SEARCH START] lookup_id=%s kind=package requested=%s normalized=%s",
                lookup_id,
                single_line(value, max_chars=100),
                package_id,
            )
        if not package_id:
            if self.logger is not None:
                self.logger.info(
                    "[MANIFEST SEARCH COMPLETE] lookup_id=%s kind=package source=none records=0 "
                    "elapsed_ms=%d reason=invalid_identity",
                    lookup_id,
                    int((time.perf_counter() - started) * 1000),
                )
            return []

        key = package_key(package_id)
        path = self.settings.package_manifest_root / "FAJ801" / f"{key}.jsonl"
        records = _read_jsonl(path)
        if self.logger is not None:
            self.logger.info(
                "[MANIFEST FILE_SEARCH] lookup_id=%s kind=package value=%s role=package "
                "path=%s exists=%s records=%d",
                lookup_id,
                package_id,
                path,
                path.is_file(),
                len(records),
            )
        if records:
            _trace_manifest_records(
                self.logger,
                lookup_id=lookup_id,
                lookup_kind="package",
                lookup_value=package_id,
                source="local_jsonl",
                records=records,
            )
            if self.logger is not None:
                self.logger.info(
                    "[MANIFEST SEARCH COMPLETE] lookup_id=%s kind=package value=%s source=local_jsonl "
                    "records=%d elapsed_ms=%d",
                    lookup_id,
                    package_id,
                    len(records),
                    int((time.perf_counter() - started) * 1000),
                )
            return records

        if self.logger is not None:
            self.logger.info(
                "[MANIFEST SEARCH COMPLETE] lookup_id=%s kind=package value=%s source=local_jsonl "
                "records=0 elapsed_ms=%d reason=no_local_records",
                lookup_id,
                package_id,
                int((time.perf_counter() - started) * 1000),
            )
        return []

    def package_bundle(self, value: str) -> Dict[str, Any]:
        lookup_id = uuid.uuid4().hex
        package_id = normalize_package_id(value)
        records = self.package_records(value, _lookup_id=lookup_id)
        documents = [record for record in records if _document(record) and _package_match(record, package_id)]
        documents.sort(
            key=lambda record: (
                str(record.get("doc_role") or "") != "package_document",
                str(record.get("filename") or ""),
            )
        )
        primary = documents[0] if documents else None
        if self.logger is not None:
            self.logger.info(
                "[MANIFEST PACKAGE_SELECTION] lookup_id=%s package_id=%s records=%d "
                "documents=%d primary_file=%s",
                lookup_id,
                package_id,
                len(records),
                len(documents),
                single_line((primary or {}).get("filename"), max_chars=160),
            )
        return {
            "package_id": package_id,
            "primary": primary,
            "documents": documents,
            "records": records,
        }

    def topic_records(self, slug: str) -> List[Dict[str, Any]]:
        lookup_id = uuid.uuid4().hex
        started = time.perf_counter()
        safe = re.sub(r"[^a-z0-9-]+", "-", str(slug or "").lower()).strip("-")
        if self.logger is not None:
            self.logger.info(
                "[MANIFEST SEARCH START] lookup_id=%s kind=topic requested=%s normalized=%s",
                lookup_id,
                single_line(slug, max_chars=120),
                safe,
            )
        if not safe:
            if self.logger is not None:
                self.logger.info(
                    "[MANIFEST SEARCH COMPLETE] lookup_id=%s kind=topic source=none records=0 "
                    "elapsed_ms=%d reason=invalid_topic",
                    lookup_id,
                    int((time.perf_counter() - started) * 1000),
                )
            return []
        path = self.settings.topic_manifest_root / f"{safe}.jsonl"
        records = _read_jsonl(path)
        if self.logger is not None:
            self.logger.info(
                "[MANIFEST FILE_SEARCH] lookup_id=%s kind=topic value=%s role=topic "
                "path=%s exists=%s records=%d",
                lookup_id,
                safe,
                path,
                path.is_file(),
                len(records),
            )
        _trace_manifest_records(
            self.logger,
            lookup_id=lookup_id,
            lookup_kind="topic",
            lookup_value=safe,
            source="local_jsonl",
            records=records,
        )
        if self.logger is not None:
            self.logger.info(
                "[MANIFEST SEARCH COMPLETE] lookup_id=%s kind=topic value=%s source=local_jsonl "
                "records=%d elapsed_ms=%d",
                lookup_id,
                safe,
                len(records),
                int((time.perf_counter() - started) * 1000),
            )
        return records


def _safe_asset_target(target: str) -> Optional[str]:
    value = target.strip().strip('"\'')
    if " \"" in value:
        value = value.split(" \"", 1)[0]
    parsed = urlparse(value)
    if parsed.scheme or parsed.netloc or value.startswith(("/", "#", "data:")):
        return None
    decoded = unquote(parsed.path).replace("\\", "/")
    pure = PurePosixPath(decoded)
    if not decoded or any(part in {"", ".", ".."} for part in pure.parts):
        return None
    return quote(str(pure), safe="/-_.~")


def rewrite_asset_links(content: str, prefix: str) -> str:
    prefix = "/" + prefix.strip("/") + "/"

    def replace(match: re.Match[str]) -> str:
        alt, target = match.group(1), match.group(2)
        safe = _safe_asset_target(target)
        if safe is None:
            return match.group(0)
        return f"![{alt}]({prefix}{safe})"

    return _IMAGE_RE.sub(replace, content or "")


def extract_image_links(content: str) -> List[Dict[str, str]]:
    seen: set[str] = set()
    links: List[Dict[str, str]] = []
    for alt, target in _IMAGE_RE.findall(content or ""):
        url = target.strip().strip('"\'')
        if not url.startswith(("/", "http://", "https://")) or url in seen:
            continue
        seen.add(url)
        links.append({"label": alt.strip() or Path(unquote(url)).name, "url": url})
    return links
