"""Pydantic contracts for the Ericsson Knowledge Base API."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class SearchFilters(BaseModel):
    filename: Optional[str] = None
    filenames: List[str] = Field(default_factory=list)
    feature_id: Optional[str] = None
    package_id: Optional[str] = None
    doc_type: Optional[str] = None
    doc_role: Optional[str] = None
    section_type: Optional[str] = None
    feature_association: Optional[str] = None
    access_type: Optional[str] = None


class SearchRequest(BaseModel):
    query: str = Field(min_length=1)
    limit: int = Field(default=5, ge=1, le=100)
    filters: SearchFilters = Field(default_factory=SearchFilters)


class FeatureRetrieveRequest(BaseModel):
    query: Optional[str] = None
    limit: int = Field(default=10, ge=1, le=100)
    include_related: bool = True


class PackageRetrieveRequest(BaseModel):
    query: Optional[str] = None
    limit: int = Field(default=10, ge=1, le=100)


class SearchResult(BaseModel):
    content: str
    metadata: Dict[str, Any] = Field(default_factory=dict)
