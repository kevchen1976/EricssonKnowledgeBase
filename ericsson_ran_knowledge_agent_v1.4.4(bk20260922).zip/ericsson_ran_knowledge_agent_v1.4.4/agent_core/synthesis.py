"""Grounded answer synthesis for retrieved Ericsson evidence."""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

from .clients import OllamaClient, ServiceClientError
from .contracts import Citation
from .settings import DEFAULT_SYSTEM_PROMPT

_WHITESPACE_RE = re.compile(r"\n{3,}")


def _source(hit: Dict[str, Any]) -> Dict[str, Any]:
    value = hit.get("_source", hit)
    return value if isinstance(value, dict) else {}


def _page_list(source: Dict[str, Any]) -> List[int]:
    start = int(source.get("page_start") or 0)
    end = int(source.get("page_end") or start or 0)
    if start <= 0:
        return []
    if end < start:
        end = start
    if end - start > 20:
        return [start, end]
    return list(range(start, end + 1))


def build_citations(evidence: Sequence[Dict[str, Any]]) -> List[Citation]:
    citations: List[Citation] = []
    for index, hit in enumerate(evidence, 1):
        source = _source(hit)
        citations.append(Citation(
            citation_id=f"E{index}",
            source=str(source.get("source_pdf") or source.get("source_markdown") or source.get("filename") or ""),
            title=str(source.get("title") or ""),
            pages=_page_list(source),
            heading_path=str(source.get("heading_path") or source.get("heading") or ""),
            score=float(hit.get("_score")) if hit.get("_score") is not None else None,
            evidence_tier=str(source.get("feature_association") or source.get("chunk_kind") or ""),
        ))
    return citations


def compact_evidence(evidence: Sequence[Dict[str, Any]], *, max_chars_each: int = 7000) -> str:
    blocks: List[str] = []
    for index, hit in enumerate(evidence, 1):
        source = _source(hit)
        content = str(source.get("content") or "").strip()
        content = _WHITESPACE_RE.sub("\n\n", content)
        if len(content) > max_chars_each:
            content = content[:max_chars_each].rstrip() + "\n[truncated]"
        details = [
            f"[E{index}]",
            f"Title: {source.get('title') or source.get('filename') or 'Unknown'}",
            f"Source: {source.get('source_pdf') or source.get('source_markdown') or source.get('filename') or 'Unknown'}",
            f"Pages: {source.get('page_start') or '?'}-{source.get('page_end') or source.get('page_start') or '?'}",
            f"Section: {source.get('heading_path') or source.get('heading') or 'Unknown'}",
            f"Association: {source.get('feature_association') or 'none'}",
        ]
        if source.get("feature_ids"):
            details.append("Feature identities: " + ", ".join(source["feature_ids"]))
        if source.get("package_ids"):
            details.append("Package identities: " + ", ".join(source["package_ids"]))
        blocks.append("\n".join(details) + "\n\n" + content)
    return "\n\n---\n\n".join(blocks)


def _extractive_answer(query: str, evidence: Sequence[Dict[str, Any]]) -> str:
    if not evidence:
        return "I could not find supporting material in the indexed Ericsson documentation."
    lines = ["The indexed Ericsson documentation provides the following relevant evidence:"]
    for index, hit in enumerate(evidence[:4], 1):
        source = _source(hit)
        content = str(source.get("content") or "").strip()
        # Prefer the first substantive paragraph and keep deterministic citations.
        paragraphs = [p.strip() for p in content.split("\n\n") if p.strip() and not p.lstrip().startswith("#")]
        snippet = paragraphs[0] if paragraphs else content
        if len(snippet) > 900:
            snippet = snippet[:900].rsplit(" ", 1)[0] + "…"
        title = str(source.get("title") or source.get("filename") or "Ericsson document")
        heading = str(source.get("heading_path") or "")
        prefix = f"**{title}**"
        if heading:
            prefix += f" — {heading}"
        lines.append(f"{prefix}: {snippet} [E{index}]")
    return "\n\n".join(lines)


def _extractive_graph_answer(graph_context: Dict[str, Any] | None) -> str:
    if not graph_context:
        return ""
    lines = ["The Ericsson graph provides the following relationship context:"]
    tool_results = graph_context.get("tool_results", []) if isinstance(graph_context, dict) else []
    shown = 0
    for wrapper in tool_results if isinstance(tool_results, list) else []:
        if not isinstance(wrapper, dict):
            continue
        tool = str(wrapper.get("tool") or "graph_tool")
        output = wrapper.get("output")
        if not isinstance(output, dict):
            continue
        results = output.get("results")
        if isinstance(results, list) and results:
            lines.append(f"**{tool}** returned {len(results)} relationship result(s).")
            for row in results[:8]:
                if not isinstance(row, dict):
                    continue
                entity = row.get("entity") if isinstance(row.get("entity"), dict) else {}
                feature = row.get("feature") if isinstance(row.get("feature"), dict) else {}
                target = row.get("target_entity") if isinstance(row.get("target_entity"), dict) else {}
                source = row.get("source_entity") if isinstance(row.get("source_entity"), dict) else {}
                names = [
                    str(source.get("name") or source.get("specific_problem") or "").strip(),
                    str(feature.get("name") or "").strip(),
                    str(entity.get("name") or entity.get("specific_problem") or "").strip(),
                    str(target.get("name") or target.get("specific_problem") or "").strip(),
                ]
                names = [name for name in names if name]
                if names:
                    lines.append("- " + " → ".join(names))
                    shown += 1
                if shown >= 12:
                    break
        else:
            resolution = output.get("alarm_resolution") or output.get("counter_resolution") or output.get("parameter_resolution")
            if isinstance(resolution, dict) and resolution.get("found"):
                lines.append(f"**{tool}** resolved an Ericsson graph entity but found no related Feature edge.")
        if shown >= 12:
            break
    return "\n".join(lines) if len(lines) > 1 else ""


def synthesize_answer(
    query: str,
    evidence: Sequence[Dict[str, Any]],
    *,
    ollama: OllamaClient | None,
    graph_context: Dict[str, Any] | None = None,
    history: str = "",
    effective_query: str = "",
) -> Tuple[str, List[str]]:
    if not evidence and not graph_context:
        return "I could not find supporting material in the indexed Ericsson documentation.", []

    warnings: List[str] = []
    if ollama is None:
        document_answer = _extractive_answer(query, evidence) if evidence else ""
        graph_answer = _extractive_graph_answer(graph_context)
        # Relationship retrieval is graph-authoritative, so even the deterministic
        # no-LLM fallback presents graph facts before document enrichment.
        if document_answer and graph_answer:
            return graph_answer + "\n\n" + document_answer, warnings
        if graph_answer:
            return graph_answer, warnings
        return document_answer or "I could not find supporting material in the indexed Ericsson documentation or graph.", warnings

    evidence_text = compact_evidence(evidence)
    graph_text = ""
    if graph_context:
        graph_text = (
            "ERICSSON NEO4J GRAPH CONTEXT — PRIMARY FOR SUPPORTED RELATIONSHIP FACTS:\n"
            "Use this graph context as the authoritative source for whether Feature/Counter/Parameter/Alarm "
            "relationships exist. For a relationship question, the returned relationship entity set must come "
            "from this graph context. Document/vector evidence may explain or corroborate graph-resolved entities "
            "but must not add extra relationship entities or override a graph result. If the graph resolves an "
            "entity but returns no edge, do not infer one from document co-occurrence.\n"
            + json.dumps(graph_context, ensure_ascii=False, indent=2, default=str)
        )
    system = DEFAULT_SYSTEM_PROMPT
    history_text = str(history or "").strip()
    history_section = ""
    if history_text:
        history_section = (
            "CONVERSATION HISTORY (context only; factual claims still require current evidence):\n"
            f"{history_text}\n\n"
        )
    resolved = str(effective_query or "").strip()
    resolved_section = ""
    if resolved and resolved != str(query).strip():
        resolved_section = (
            "RESOLVED RETRIEVAL QUESTION (from conversation-aware rewrite):\n"
            f"{resolved}\n\n"
        )
    if graph_text:
        source_sections = (
            f"{graph_text}\n\n"
            f"ERICSSON DOCUMENT / VECTOR EVIDENCE — SUPPLEMENTARY FOR RELATIONSHIP EXISTENCE, "
            f"AUTHORITATIVE FOR PROCEDURES AND EXPLANATION:\n{evidence_text}"
        )
    else:
        source_sections = f"ERICSSON DOCUMENT EVIDENCE:\n{evidence_text}"

    prompt = (
        f"{history_section}"
        f"USER QUESTION:\n{query}\n\n"
        f"{resolved_section}"
        f"{source_sections}\n\n"
        "Write a direct technical answer and preserve Ericsson terminology. "
        "For supported relationship questions, lead with the Neo4j graph result and treat it as authoritative. "
        "Do not add relationship entities solely because they appear in vector/document evidence. "
        "Use vector/document evidence to explain graph-resolved entities, procedures, correction instructions, "
        "configuration guidance and technical context. If graph and vector evidence conflict on relationship "
        "existence, keep the graph relationship result and describe the document evidence as context. "
        "If the graph resolved the entity but found no edge, say no current graph relationship was found rather "
        "than inferring one from semantic similarity. If graph retrieval failed and only documents are available, "
        "clearly qualify any relationship suggestion as document-based rather than graph-verified. "
        "Use [E1], [E2], etc. only for claims supported by document evidence. Every factual paragraph that relies on "
        "document evidence must include at least one valid [E#] marker before that paragraph is finished; emit those "
        "markers as part of the answer while streaming rather than waiting for a final references-only section. Graph "
        "facts need no [E#] marker unless the same claim is also supported by a document. Do not imply causality merely "
        "from a graph relationship. "
        "When native graph edge types differ, answer at the high-level family (related counter, parameter, or alarm) "
        "unless the user explicitly asks for native edge semantics."
    )
    try:
        answer = (
            ollama.generate(prompt, system=system, temperature=0.1, purpose="answer_synthesis")
            if isinstance(ollama, OllamaClient)
            else ollama.generate(prompt, system=system, temperature=0.1)
        )
        answer = answer.replace("<answer>", "").replace("</answer>", "").strip()
        return answer, warnings
    except ServiceClientError as exc:
        warnings.append(str(exc) + "; returned an extractive answer instead.")
        document_answer = _extractive_answer(query, evidence) if evidence else ""
        graph_answer = _extractive_graph_answer(graph_context)
        if graph_answer and document_answer:
            return graph_answer + "\n\n" + document_answer, warnings
        if graph_answer:
            return graph_answer, warnings
        return document_answer or "I could not find supporting material in the indexed Ericsson documentation or graph.", warnings
