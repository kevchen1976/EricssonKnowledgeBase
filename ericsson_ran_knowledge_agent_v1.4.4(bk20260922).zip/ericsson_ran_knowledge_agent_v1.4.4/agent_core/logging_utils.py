"""Request-correlated file logging helpers for the Ericsson services."""
from __future__ import annotations

import logging
import uuid
from contextlib import contextmanager
from contextvars import ContextVar, Token
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Iterator, Mapping

_REQUEST_ID: ContextVar[str] = ContextVar("ericsson_request_id", default="-")


def current_request_id() -> str:
    """Return the request identifier currently bound to this execution context."""
    return str(_REQUEST_ID.get() or "-")


def new_request_id() -> str:
    """Create a request identifier suitable for logs and SQLite audit rows."""
    return str(uuid.uuid4())


@contextmanager
def request_context(request_id: str | None = None) -> Iterator[str]:
    """Bind a request identifier for the duration of a query or HTTP request."""
    value = str(request_id or "").strip() or new_request_id()
    token: Token[str] = _REQUEST_ID.set(value)
    try:
        yield value
    finally:
        _REQUEST_ID.reset(token)


class RequestIdFilter(logging.Filter):
    """Inject the current request identifier into every emitted log record."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = current_request_id()
        return True


def _configure_handler(handler: logging.Handler) -> None:
    """Apply the common request-correlated Ericsson log format."""
    if not any(isinstance(item, RequestIdFilter) for item in handler.filters):
        handler.addFilter(RequestIdFilter())
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s %(levelname)s request_id=%(request_id)s %(message)s"
        )
    )


def configure_file_logger(name: str, path: Path, *, level: int = logging.INFO) -> logging.Logger:
    """Configure one UTF-8 file logger without adding duplicate handlers."""
    destination = Path(path).resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.propagate = False

    handler = next(
        (
            item
            for item in logger.handlers
            if isinstance(item, logging.FileHandler)
            and Path(getattr(item, "baseFilename", "")).resolve() == destination
        ),
        None,
    )
    if handler is None:
        handler = logging.FileHandler(destination, encoding="utf-8")
        logger.addHandler(handler)

    _configure_handler(handler)
    return logger


def configure_rotating_file_logger(
    name: str,
    path: Path,
    *,
    level: int = logging.INFO,
    max_bytes: int = 20 * 1024 * 1024,
    backup_count: int = 5,
) -> logging.Logger:
    """Configure a request-correlated rotating UTF-8 file logger.

    This is used by the dedicated Ollama trace so verbose prompts and responses
    do not expand the normal Agent log indefinitely. Repeated calls are safe:
    the same destination reuses its handler, and a changed destination replaces
    only handlers created by this helper.
    """
    destination = Path(path).resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.propagate = False

    existing: RotatingFileHandler | None = None
    for item in list(logger.handlers):
        if not isinstance(item, RotatingFileHandler):
            continue
        item_destination = Path(getattr(item, "baseFilename", "")).resolve()
        if item_destination == destination:
            existing = item
            continue
        if getattr(item, "_ericsson_managed_rotating_file", False):
            logger.removeHandler(item)
            item.close()

    handler = existing
    if handler is None:
        handler = RotatingFileHandler(
            destination,
            maxBytes=max(0, int(max_bytes)),
            backupCount=max(0, int(backup_count)),
            encoding="utf-8",
        )
        setattr(handler, "_ericsson_managed_rotating_file", True)
        logger.addHandler(handler)
    else:
        # Keep runtime reloads deterministic when only rotation settings change.
        handler.maxBytes = max(0, int(max_bytes))
        handler.backupCount = max(0, int(backup_count))

    _configure_handler(handler)
    return logger


def outbound_trace_headers(existing: Mapping[str, str] | None = None) -> dict[str, str]:
    """Return headers that propagate the current request identifier downstream."""
    headers = {str(key): str(value) for key, value in dict(existing or {}).items()}
    request_id = current_request_id()
    if request_id and request_id != "-":
        headers.setdefault("X-Request-ID", request_id)
    return headers


def single_line(value: object, *, max_chars: int = 240) -> str:
    """Render log content on one bounded line without changing source data."""
    text = " ".join(str(value or "").split())
    if max_chars > 0 and len(text) > max_chars:
        return text[: max_chars - 3].rstrip() + "..."
    return text


def single_line_words(value: object, *, max_words: int = 50, max_chars: int = 0) -> str:
    """Render one-line log text bounded by whole words.

    The source value is never modified. This helper is only for operational
    log previews, keeping the first ``max_words`` whitespace-delimited words.
    An optional character ceiling can be applied after the word ceiling.
    """
    text = " ".join(str(value or "").split())
    if max_words > 0:
        words = text.split()
        if len(words) > max_words:
            text = " ".join(words[:max_words]).rstrip() + "..."
    if max_chars > 0 and len(text) > max_chars:
        text = text[: max_chars - 3].rstrip() + "..."
    return text
