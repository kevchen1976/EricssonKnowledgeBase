"""Evidence-bound answer validation for Ericsson identities and citations."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Sequence, Set

from .ids import find_feature_ids, find_package_ids

_CITATION_RE = re.compile(r"\[E(\d+)\]")


@dataclass
class ValidationResult:
    answer: str
    warnings: List[str] = field(default_factory=list)
    unsupported_feature_ids: List[str] = field(default_factory=list)
    unsupported_package_ids: List[str] = field(default_factory=list)
    invalid_citations: List[int] = field(default_factory=list)
    missing_citations: bool = False


def append_evidence_reference_footer(answer: str, evidence_count: int) -> str:
    """Preserve an otherwise grounded answer and add valid evidence markers.

    This is intentionally a compact footer rather than claim-level citation
    rewriting.  The synthesis prompt still requires inline citations; the footer
    is a non-destructive recovery path when the model omits them.
    """
    text = str(answer or "").strip()
    count = max(0, int(evidence_count))
    if not text or count <= 0:
        return text
    refs = " ".join(f"[E{i}]" for i in range(1, count + 1))
    return text + f"\n\n**Evidence references:** {refs}"


def _collect(records: Iterable[Dict[str, Any]], keys: Sequence[str]) -> Set[str]:
    out: Set[str] = set()
    for record in records:
        source = record.get("_source", record)
        if not isinstance(source, dict):
            continue
        for key in keys:
            value = source.get(key)
            if isinstance(value, list):
                out.update(str(item) for item in value if item)
            elif value:
                out.add(str(value))
        content = str(source.get("content") or "")
        out.update(find_feature_ids(content))
        out.update(find_package_ids(content))
    return out


def _collect_graph_identities(value: Any) -> tuple[Set[str], Set[str]]:
    features: Set[str] = set()
    packages: Set[str] = set()

    def walk(item: Any) -> None:
        if isinstance(item, dict):
            for child in item.values():
                walk(child)
        elif isinstance(item, list):
            for child in item:
                walk(child)
        elif isinstance(item, str):
            features.update(find_feature_ids(item))
            packages.update(find_package_ids(item))

    walk(value)
    return features, packages


def validate_answer(
    answer: str,
    evidence: Sequence[Dict[str, Any]],
    *,
    user_feature_ids: Sequence[str] = (),
    user_package_ids: Sequence[str] = (),
    graph_context: Dict[str, Any] | None = None,
) -> ValidationResult:
    allowed_features = set(user_feature_ids)
    allowed_packages = set(user_package_ids)
    evidence_values = _collect(
        evidence,
        (
            "feature_id", "primary_feature_id", "owner_feature_id", "feature_ids",
            "included_feature_ids", "mentioned_feature_ids", "related_feature_ids", "package_id",
            "primary_package_id", "package_ids",
        ),
    )
    for value in evidence_values:
        if value.startswith("FAJ 121 "):
            allowed_features.add(value)
        elif value.startswith("FAJ 801 "):
            allowed_packages.add(value)

    graph_features, graph_packages = _collect_graph_identities(graph_context or {})
    allowed_features.update(graph_features)
    allowed_packages.update(graph_packages)

    answer_features = set(find_feature_ids(answer))
    answer_packages = set(find_package_ids(answer))
    unsupported_features = sorted(answer_features - allowed_features)
    unsupported_packages = sorted(answer_packages - allowed_packages)
    warnings: List[str] = []
    if unsupported_features:
        warnings.append(
            "The generated answer contained Ericsson feature identities not present in the user query or retrieved evidence: "
            + ", ".join(unsupported_features)
        )
    if unsupported_packages:
        warnings.append(
            "The generated answer contained Ericsson package identities not present in the user query or retrieved evidence: "
            + ", ".join(unsupported_packages)
        )

    citation_numbers = [int(value) for value in _CITATION_RE.findall(answer)]
    invalid_citations = sorted({number for number in citation_numbers if number < 1 or number > len(evidence)})
    if invalid_citations:
        warnings.append("The generated answer used invalid evidence markers: " + ", ".join(f"E{x}" for x in invalid_citations))
    missing_citations = bool(evidence) and not citation_numbers
    if missing_citations:
        warnings.append("The generated answer did not cite the retrieved Ericsson evidence.")

    return ValidationResult(
        answer=answer.strip(),
        warnings=warnings,
        unsupported_feature_ids=unsupported_features,
        unsupported_package_ids=unsupported_packages,
        invalid_citations=invalid_citations,
        missing_citations=missing_citations,
    )
