"""Deterministic graph-tool planning for the Ericsson agent.

This is deliberately not an LLM-generated Cypher layer. The agent selects from
small, read-only FastAPI tools and then combines their results with OpenSearch
retrieval. Feature-to-Feature questions are not routed through Neo4j; they stay
in semantic/document retrieval.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Sequence

from .clients import GraphClient, ServiceClientError


_COUNTER_RE = re.compile(r"(?<![A-Za-z0-9_])(?:[A-Za-z][A-Za-z0-9_]*\.)?pm[A-Za-z0-9_]+", re.I)
_QUALIFIED_ATTRIBUTE_RE = re.compile(
    r"(?<![A-Za-z0-9_])([A-Za-z][A-Za-z0-9_]*)\.([A-Za-z][A-Za-z0-9_]*)(?![A-Za-z0-9_])"
)
_SUPERVISOR_LOCAL_ENTITY_TASK = "SUPERVISOR_LOCAL_ENTITY_TASK"
_RELATION_TERMS = {
    "related", "relationship", "relationships", "uses", "used by", "associated",
    "feature", "features", "via feature", "introduced by", "affected by",
}

_ALARM_TERMS = {
    "alarm", "alarms", "specific problem", "probable cause", "corrective action",
    "correction instruction", "correction instructions", "remedy", "clear alarm",
}
_COUNTER_TERMS = {"counter", "counters", "pm counter", "ebs counter"}
_PARAMETER_TERMS = {"parameter", "parameters", "attribute", "attributes", "configuration"}
_FEATURE_TERMS = {"feature", "features", "faj 121"}
_FEATURE_TO_FEATURE_TERMS = {
    "similar feature", "equivalent feature", "feature dependency", "feature dependencies",
    "related feature", "related features", "feature to feature",
}


@dataclass(frozen=True)
class GraphToolCall:
    tool: str
    arguments: Dict[str, Any]


@dataclass
class GraphExecution:
    context: Dict[str, Any] | None = None
    calls: List[Dict[str, Any]] = field(default_factory=list)
    outputs: List[Dict[str, Any]] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    kb_queries: List[str] = field(default_factory=list)
    related_feature_ids: List[str] = field(default_factory=list)


def _contains_any(text: str, terms: Iterable[str]) -> bool:
    return any(term in text for term in terms)


def _extract_counter_refs(query: str) -> List[str]:
    """Return distinct concrete pm... tokens in appearance order."""
    out: List[str] = []
    seen: set[str] = set()
    for match in _COUNTER_RE.finditer(str(query or "")):
        value = match.group(0)
        key = value.casefold()
        if key not in seen:
            seen.add(key)
            out.append(value)
    return out


def _extract_counter_ref(query: str) -> str:
    refs = _extract_counter_refs(query)
    return refs[0] if refs else ""


def _extract_parameter_refs(query: str) -> List[str]:
    """Return distinct qualified MOC.attribute tokens, excluding pm counters."""
    out: List[str] = []
    seen: set[str] = set()
    for match in _QUALIFIED_ATTRIBUTE_RE.finditer(str(query or "")):
        owner, name = match.group(1), match.group(2)
        if name.casefold().startswith("pm"):
            continue
        value = f"{owner}.{name}"
        key = value.casefold()
        if key not in seen:
            seen.add(key)
            out.append(value)
    return out


def _extract_parameter_ref(query: str) -> str:
    refs = _extract_parameter_refs(query)
    return refs[0] if refs else ""


def _intent_flags(query: str) -> Dict[str, bool]:
    lower = " ".join(str(query or "").split()).casefold()
    has_counter_ref = bool(_COUNTER_RE.search(query or ""))
    has_qualified_ref = bool(_QUALIFIED_ATTRIBUTE_RE.search(query or ""))
    return {
        "alarm": _contains_any(lower, _ALARM_TERMS),
        "counter": has_counter_ref or _contains_any(lower, _COUNTER_TERMS),
        "parameter": _contains_any(lower, _PARAMETER_TERMS) or (has_qualified_ref and not has_counter_ref),
        "feature": _contains_any(lower, _FEATURE_TERMS),
        "feature_to_feature": _contains_any(lower, _FEATURE_TO_FEATURE_TERMS),
    }


def plan_graph_tools(
    query: str,
    *,
    feature_ids: Sequence[str] = (),
    limit: int = 20,
) -> List[GraphToolCall]:
    """Select a minimal graph-tool plan for one query."""
    flags = _intent_flags(query)
    if flags["feature_to_feature"]:
        # Feature-to-Feature knowledge deliberately remains in OpenSearch.
        return []

    relation_limit = max(20, min(300, int(limit) * 20))
    entity_limit = max(10, min(100, int(limit) * 5))
    calls: List[GraphToolCall] = []

    # Supervisor directional-comparison verification tasks are deliberately
    # vendor-local. Handle this BEFORE any Feature IDs found elsewhere in the
    # orchestration text so candidate descriptions cannot accidentally trigger
    # Feature traversal. Resolve only concrete local counters/MOAttributes.
    if _SUPERVISOR_LOCAL_ENTITY_TASK.casefold() in query.casefold():
        for counter_ref in _extract_counter_refs(query)[:6]:
            calls.append(GraphToolCall("counter_context", {"counter": counter_ref, "limit": entity_limit}))
        for parameter_ref in _extract_parameter_refs(query)[:6]:
            calls.append(GraphToolCall("parameter_context", {"parameter": parameter_ref, "limit": entity_limit}))
        # If there is no concrete local candidate, do not fall through into
        # generic graph traversal merely because words such as counter/parameter
        # or an incidental Feature ID appear in the supervisor context.
        return _dedupe_calls(calls)

    if feature_ids:
        for feature_id in feature_ids[:5]:
            if flags["counter"]:
                calls.append(GraphToolCall("feature_counters", {"feature": feature_id, "limit": relation_limit}))
            if flags["parameter"]:
                calls.append(GraphToolCall("feature_parameters", {"feature": feature_id, "limit": relation_limit}))
            if flags["alarm"]:
                calls.append(GraphToolCall("feature_alarms", {"feature": feature_id, "limit": relation_limit}))
            if not (flags["counter"] or flags["parameter"] or flags["alarm"]):
                calls.append(GraphToolCall("feature_context", {"feature": feature_id, "limit": entity_limit}))
        return _dedupe_calls(calls)

    # Multi-hop questions are handled before single-entity reverse lookups.
    # A concrete pm... token identifies a Counter source. Otherwise a
    # qualified MOC.attribute reference is treated as a Parameter source.
    if flags["counter"] and flags["parameter"]:
        counter_ref = _extract_counter_ref(query)
        parameter_ref = _extract_parameter_ref(query)
        if counter_ref:
            calls.append(GraphToolCall(
                "counter_parameters_via_features",
                {"counter": counter_ref, "limit": relation_limit},
            ))
        else:
            calls.append(GraphToolCall(
                "parameter_counters_via_features",
                {"parameter": parameter_ref or query, "limit": relation_limit},
            ))
        return calls

    # Concrete Counter/Parameter identifiers take precedence over generic words
    # such as "feature" or "functionality". This makes questions like
    # "which features use counter pmX?" resolve the counter first instead of
    # trying to resolve the whole sentence as a Feature name.
    counter_ref = _extract_counter_ref(query)
    parameter_ref = _extract_parameter_ref(query)
    lower = " ".join(str(query or "").split()).casefold()
    relation_requested = flags["feature"] or _contains_any(lower, _RELATION_TERMS)
    if counter_ref:
        tool = "counter_features" if relation_requested else "counter_context"
        calls.append(GraphToolCall(tool, {"counter": counter_ref, "limit": entity_limit}))
    elif parameter_ref:
        tool = "parameter_features" if relation_requested else "parameter_context"
        calls.append(GraphToolCall(tool, {"parameter": parameter_ref, "limit": entity_limit}))
    # Feature name may be embedded in a natural-language query. The graph API
    # resolver can recognise a full Feature name inside the query text.
    elif flags["feature"] and flags["counter"]:
        calls.append(GraphToolCall("feature_counters", {"feature": query, "limit": relation_limit}))
    elif flags["feature"] and flags["parameter"]:
        calls.append(GraphToolCall("feature_parameters", {"feature": query, "limit": relation_limit}))
    elif flags["feature"] and flags["alarm"]:
        calls.append(GraphToolCall("feature_alarms", {"feature": query, "limit": relation_limit}))
    elif flags["alarm"]:
        # Natural language may contain either a Feature name ("alarms related
        # to Outgoing NR IRAT Handover") or a specificProblem ("how to clear
        # Resource Allocation Failure alarm"). Try both safe directions.
        calls.append(GraphToolCall("alarm_features", {"alarm": query, "limit": entity_limit}))
        calls.append(GraphToolCall("feature_alarms", {"feature": query, "limit": relation_limit}))
    elif flags["counter"]:
        # A question such as "counters for Outgoing NR IRAT Handover" has no
        # pm... token. Try Feature->Counter and Counter->Feature.
        calls.append(GraphToolCall("feature_counters", {"feature": query, "limit": relation_limit}))
        calls.append(GraphToolCall("counter_features", {"counter": query, "limit": entity_limit}))
    elif flags["parameter"]:
        calls.append(GraphToolCall("feature_parameters", {"feature": query, "limit": relation_limit}))
        calls.append(GraphToolCall("parameter_features", {"parameter": query, "limit": entity_limit}))
    else:
        calls.append(GraphToolCall("search_context", {"query": query, "limit": entity_limit}))

    return _dedupe_calls(calls)


def _dedupe_calls(calls: Sequence[GraphToolCall]) -> List[GraphToolCall]:
    seen: set[tuple[str, str]] = set()
    out: List[GraphToolCall] = []
    for call in calls:
        key = (call.tool, repr(sorted(call.arguments.items())))
        if key in seen:
            continue
        seen.add(key)
        out.append(call)
    return out


def _invoke(client: GraphClient, call: GraphToolCall) -> Dict[str, Any]:
    method = getattr(client, call.tool, None)
    if not callable(method):
        raise ServiceClientError(f"Unknown Ericsson graph tool: {call.tool}")
    return method(**call.arguments)


def execute_graph_tools(client: GraphClient, calls: Sequence[GraphToolCall]) -> GraphExecution:
    execution = GraphExecution()
    for call in calls:
        public_call = {"tool": call.tool, "arguments": dict(call.arguments)}
        execution.calls.append(public_call)
        try:
            output = _invoke(client, call)
        except ServiceClientError as exc:
            execution.warnings.append(f"{call.tool}: {exc}")
            continue
        execution.outputs.append({"tool": call.tool, "output": output})

    if execution.outputs:
        execution.context = {
            "source": "Ericsson Neo4j",
            "authority": "primary_for_supported_relationships",
            "relationship_policy": (
                "Neo4j is authoritative for supported Feature/Counter/Parameter/Alarm relationship existence. "
                "When graph results exist, the relationship entity set must come from the graph; vector/document "
                "retrieval may explain or corroborate those entities but must not add extra relationships. "
                "If an entity resolves but no graph edge exists, do not infer an edge from semantic similarity. "
                "High-level relationship families are used for discovery; native edge types are metadata and do not "
                "need to be enumerated unless the user asks for them."
            ),
            "tool_results": execution.outputs,
        }
        execution.related_feature_ids = _collect_related_feature_ids(execution.outputs)
        execution.kb_queries = _derive_kb_queries(execution.outputs)
    return execution


def _walk(value: Any):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from _walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from _walk(child)


def _collect_related_feature_ids(outputs: Sequence[Dict[str, Any]]) -> List[str]:
    found: List[str] = []
    seen: set[str] = set()
    for wrapper in outputs:
        for obj in _walk(wrapper.get("output")):
            feature = obj.get("feature") if isinstance(obj.get("feature"), dict) else None
            candidates = [feature, obj.get("entity") if "Feature" in (obj.get("labels") or []) else None]
            resolution = obj.get("feature_resolution")
            if isinstance(resolution, dict):
                resolved = resolution.get("resolved")
                if isinstance(resolved, dict) and isinstance(resolved.get("entity"), dict):
                    candidates.append(resolved["entity"])
            for candidate in candidates:
                if not isinstance(candidate, dict):
                    continue
                identity = str(candidate.get("feature_identity") or "").strip()
                if identity.startswith("FAJ 121 ") and identity not in seen:
                    seen.add(identity)
                    found.append(identity)
    return found


def _derive_kb_queries(outputs: Sequence[Dict[str, Any]]) -> List[str]:
    """Build precise OpenSearch follow-up queries from graph-resolved entities."""
    queries: List[str] = []
    seen: set[str] = set()
    for wrapper in outputs:
        output = wrapper.get("output")
        if not isinstance(output, dict):
            continue
        # Entity-profile handoff: once Neo4j resolves the exact local counter or
        # MOAttribute, query the document KB with the compact qualified identity
        # instead of the full supervisor orchestration prompt.
        for resolution_key in ("counter_resolution", "parameter_resolution"):
            entity_resolution = output.get(resolution_key)
            if not isinstance(entity_resolution, dict):
                continue
            resolved = entity_resolution.get("resolved")
            if not isinstance(resolved, dict):
                continue
            qualified = str(resolved.get("qualified_name") or "").strip()
            entity = resolved.get("entity") if isinstance(resolved.get("entity"), dict) else {}
            if not qualified:
                owner = str(resolved.get("owner") or entity.get("mo_class") or "").strip()
                name = str(entity.get("name") or "").strip()
                qualified = f"{owner}.{name}" if owner and name else name
            if qualified and qualified not in seen:
                seen.add(qualified)
                queries.append(qualified)

        # Alarm correction is the most important graph->vector handoff. Search
        # documentation with the exact resolved specificProblem phrase.
        resolution = output.get("alarm_resolution")
        if isinstance(resolution, dict):
            candidates = resolution.get("candidates") or []
            top_score = resolution.get("top_score")
            for row in candidates:
                if top_score is not None and row.get("score") != top_score:
                    continue
                entity = row.get("entity") if isinstance(row, dict) else None
                if not isinstance(entity, dict):
                    continue
                specific_problem = str(entity.get("specific_problem") or entity.get("alarm_name") or "").strip()
                if specific_problem:
                    query = f'"{specific_problem}" alarm correction instructions probable cause recommended action'
                    if query not in seen:
                        seen.add(query)
                        queries.append(query)
        # Generic search_context nests the alarm resolution.
        resolutions = output.get("resolutions")
        if isinstance(resolutions, dict) and isinstance(resolutions.get("alarm"), dict):
            alarm_resolution = resolutions["alarm"]
            for row in alarm_resolution.get("candidates") or []:
                if alarm_resolution.get("top_score") is not None and row.get("score") != alarm_resolution.get("top_score"):
                    continue
                entity = row.get("entity") if isinstance(row, dict) else None
                if isinstance(entity, dict):
                    specific_problem = str(entity.get("specific_problem") or "").strip()
                    if specific_problem:
                        query = f'"{specific_problem}" alarm correction instructions probable cause recommended action'
                        if query not in seen:
                            seen.add(query)
                            queries.append(query)
    return queries[:3]


def _bounded_text(value: Any, max_chars: int = 1000) -> Any:
    if not isinstance(value, str):
        return value
    value = value.strip()
    if len(value) <= max_chars:
        return value
    return value[:max_chars].rstrip() + "...[truncated]"


def _compact_entity(entity: Any) -> Any:
    if not isinstance(entity, dict):
        return entity
    allowed = (
        "id", "name", "feature_identity", "feature_identity_norm", "access_type",
        "specific_problem", "fm_alarm_type_id", "event_type", "probable_cause",
        "default_severity", "description", "condition", "technology", "mo_class",
        "owner_moc_id", "pm_group", "measurement_name", "unit", "counter_type",
        "managed_function", "source_file", "source_kind",
    )
    return {
        key: _bounded_text(entity.get(key))
        for key in allowed
        if entity.get(key) not in (None, "", [])
    }


def _compact_evidence_list(value: Any) -> Any:
    if not isinstance(value, list):
        return value
    out = []
    for item in value[:5]:
        if not isinstance(item, dict):
            continue
        row = dict(item)
        if "evidence" in row:
            row["evidence"] = _bounded_text(row["evidence"], 700)
        out.append(row)
    return out


def _compact_graph_value(value: Any, *, max_results_per_tool: int) -> Any:
    if isinstance(value, list):
        return [_compact_graph_value(item, max_results_per_tool=max_results_per_tool) for item in value[:max_results_per_tool]]
    if not isinstance(value, dict):
        return _bounded_text(value)

    out: Dict[str, Any] = {}
    for key, child in value.items():
        if key in {"entity", "feature", "source_entity", "target_entity"}:
            out[key] = _compact_entity(child)
        elif key in {"evidence", "source_evidence", "target_evidence"}:
            out[key] = _compact_evidence_list(child)
        elif key == "candidates" and isinstance(child, list):
            candidates = []
            for row in child[:10]:
                if not isinstance(row, dict):
                    continue
                compact_row = dict(row)
                if isinstance(compact_row.get("entity"), dict):
                    compact_row["entity"] = _compact_entity(compact_row["entity"])
                candidates.append(compact_row)
            out[key] = candidates
        elif key == "results" and isinstance(child, list):
            out[key] = [
                _compact_graph_value(item, max_results_per_tool=max_results_per_tool)
                for item in child[:max_results_per_tool]
            ]
            out["returned_to_model"] = min(len(child), max_results_per_tool)
            out["total_results"] = len(child)
        else:
            out[key] = _compact_graph_value(child, max_results_per_tool=max_results_per_tool)
    return out


def compact_graph_context(context: Dict[str, Any] | None, *, max_results_per_tool: int = 30) -> Dict[str, Any] | None:
    """Bound and prune graph data before placing it in an LLM prompt/audit row."""
    if not context:
        return None
    return _compact_graph_value(context, max_results_per_tool=max_results_per_tool)

