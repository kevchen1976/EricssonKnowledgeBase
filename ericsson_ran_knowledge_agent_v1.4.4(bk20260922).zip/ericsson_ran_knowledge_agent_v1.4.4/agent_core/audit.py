"""Nokia-compatible SQLite query/answer audit trail for the Ericsson agent."""
from __future__ import annotations

import json
import logging
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger("ericsson_agent")


def _json(value: Any, default: Any) -> str:
    if value is None:
        value = default
    return json.dumps(value, ensure_ascii=False, default=str)


class AuditStore:
    """Persist every Agent API query and final answer without affecting responses."""

    def __init__(self, path: Path, *, enabled: bool = True) -> None:
        self.path = Path(path)
        self.enabled = bool(enabled)
        if self.enabled:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(
            str(self.path),
            timeout=30.0,
            check_same_thread=False,
        )
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA busy_timeout=30000")
        return connection

    def _initialize(self) -> None:
        try:
            with self._connect() as connection:
                connection.execute(
                    """
                    CREATE TABLE IF NOT EXISTS audit (
                        request_id TEXT PRIMARY KEY,
                        created_at TEXT,
                        session_id TEXT,
                        user_email TEXT,
                        query TEXT,
                        workflow TEXT,
                        tool_calls TEXT,
                        tool_outputs TEXT,
                        final_answer TEXT,
                        validation_ok INTEGER,
                        validation_errors TEXT,
                        judge_score REAL,
                        judge_json TEXT,
                        flagged INTEGER,
                        flagged_reason TEXT,
                        repaired INTEGER,
                        latency_ms INTEGER,
                        source TEXT,
                        feature_ids_json TEXT,
                        package_ids_json TEXT,
                        citation_count INTEGER,
                        citations_json TEXT,
                        warnings_json TEXT,
                        success INTEGER,
                        error TEXT,
                        response_json TEXT
                    )
                    """
                )
                connection.execute("CREATE INDEX IF NOT EXISTS idx_audit_created_at ON audit(created_at)")
                connection.execute("CREATE INDEX IF NOT EXISTS idx_audit_email ON audit(user_email)")
                connection.execute("CREATE INDEX IF NOT EXISTS idx_audit_workflow ON audit(workflow)")
                connection.execute("CREATE INDEX IF NOT EXISTS idx_audit_session ON audit(session_id)")
                self._ensure_legacy_query_audit_columns(connection)
                self._migrate_legacy_rows(connection)
        except Exception:
            # Audit initialization is best effort, matching the Nokia agent's
            # behavior: an audit failure must never make the Agent API unusable.
            logger.exception("[AUDIT] Failed to initialize SQLite audit database at %s", self.path)

    @staticmethod
    def _table_columns(connection: sqlite3.Connection, table: str) -> set[str]:
        try:
            return {str(row[1]) for row in connection.execute(f"PRAGMA table_info({table})").fetchall()}
        except sqlite3.Error:
            return set()

    def _ensure_legacy_query_audit_columns(self, connection: sqlite3.Connection) -> None:
        """Keep an existing v1.2.1 query_audit table useful after the patch."""
        existing = connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='query_audit'"
        ).fetchone()
        if not existing:
            return
        columns = self._table_columns(connection, "query_audit")
        additions = {
            "request_id": "TEXT",
            "tool_calls_json": "TEXT",
            "tool_outputs_json": "TEXT",
            "final_answer": "TEXT",
            "validation_ok": "INTEGER",
            "validation_errors_json": "TEXT",
            "citations_json": "TEXT",
            "response_json": "TEXT",
        }
        for name, column_type in additions.items():
            if name not in columns:
                connection.execute(f"ALTER TABLE query_audit ADD COLUMN {name} {column_type}")
        connection.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_query_audit_request_id "
            "ON query_audit(request_id) WHERE request_id IS NOT NULL"
        )

    def _migrate_legacy_rows(self, connection: sqlite3.Connection) -> None:
        """Copy pre-v1.2.2 query_audit rows once, leaving the old table intact."""
        existing = connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='query_audit'"
        ).fetchone()
        if not existing:
            return
        columns = self._table_columns(connection, "query_audit")
        if not columns or "query" not in columns:
            return
        migrated = 0
        for row in connection.execute("SELECT * FROM query_audit").fetchall():
            values = dict(row)
            legacy_id = values.get("request_id") or f"legacy-query-audit-{values.get('id', uuid.uuid4())}"
            cursor = connection.execute(
                """
                INSERT OR IGNORE INTO audit (
                    request_id, created_at, session_id, user_email, query, workflow,
                    tool_calls, tool_outputs, final_answer, validation_ok,
                    validation_errors, judge_score, judge_json, flagged,
                    flagged_reason, repaired, latency_ms, source,
                    feature_ids_json, package_ids_json, citation_count,
                    citations_json, warnings_json, success, error, response_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    str(legacy_id),
                    values.get("created_at"),
                    values.get("session_id"),
                    values.get("user_email"),
                    values.get("query"),
                    values.get("workflow"),
                    "[]",
                    "[]",
                    values.get("final_answer") or "",
                    int(bool(values.get("success"))),
                    "[]",
                    None,
                    "{}",
                    0,
                    "",
                    0,
                    values.get("latency_ms"),
                    values.get("source"),
                    values.get("feature_ids_json") or "[]",
                    values.get("package_ids_json") or "[]",
                    values.get("citation_count") or 0,
                    "[]",
                    values.get("warnings_json") or "[]",
                    int(bool(values.get("success"))),
                    values.get("error") or "",
                    "{}",
                ),
            )
            migrated += int(cursor.rowcount or 0)
        if migrated:
            logger.info("[AUDIT] Migrated %d legacy query_audit row(s) into audit", migrated)

    def record(
        self,
        *,
        query: str,
        workflow: str,
        source: str,
        latency_ms: int,
        success: bool,
        request_id: Optional[str] = None,
        created_at: Optional[str] = None,
        session_id: Optional[str] = None,
        user_email: Optional[str] = None,
        tool_calls: Any = None,
        tool_outputs: Any = None,
        final_answer: str = "",
        validation_ok: Optional[bool] = None,
        validation_errors: Any = None,
        judge_score: Optional[float] = None,
        judge_json: Any = None,
        flagged: bool = False,
        flagged_reason: str = "",
        repaired: bool = False,
        feature_ids: Any = None,
        package_ids: Any = None,
        citation_count: int = 0,
        citations: Any = None,
        warnings: Any = None,
        error: str = "",
        response: Any = None,
    ) -> str:
        """Write one complete query/answer row and return its request ID."""
        audit_id = str(request_id or uuid.uuid4())
        if not self.enabled:
            return audit_id
        if validation_ok is None:
            validation_ok = bool(success)
        created_value = created_at or datetime.now(timezone.utc).isoformat()
        values = {
            "request_id": audit_id,
            "created_at": created_value,
            "session_id": session_id,
            "user_email": user_email,
            "query": str(query or ""),
            "workflow": str(workflow or ""),
            "source": str(source or ""),
            "latency_ms": int(latency_ms),
            "feature_ids": feature_ids,
            "package_ids": package_ids,
            "citation_count": int(citation_count),
            "citations": citations,
            "warnings": warnings,
            "success": bool(success),
            "error": str(error or ""),
            "tool_calls": tool_calls,
            "tool_outputs": tool_outputs,
            "final_answer": str(final_answer or ""),
            "validation_ok": bool(validation_ok),
            "validation_errors": validation_errors,
            "response": response,
        }
        try:
            with self._connect() as connection:
                connection.execute(
                    """
                    INSERT OR REPLACE INTO audit (
                        request_id, created_at, session_id, user_email, query, workflow,
                        tool_calls, tool_outputs, final_answer, validation_ok,
                        validation_errors, judge_score, judge_json, flagged,
                        flagged_reason, repaired, latency_ms, source,
                        feature_ids_json, package_ids_json, citation_count,
                        citations_json, warnings_json, success, error, response_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        audit_id,
                        created_value,
                        session_id,
                        user_email,
                        values["query"],
                        values["workflow"],
                        _json(tool_calls, []),
                        _json(tool_outputs, []),
                        values["final_answer"],
                        int(bool(validation_ok)),
                        _json(validation_errors, []),
                        judge_score,
                        _json(judge_json, {}),
                        int(bool(flagged)),
                        str(flagged_reason or ""),
                        int(bool(repaired)),
                        int(latency_ms),
                        values["source"],
                        _json(feature_ids, []),
                        _json(package_ids, []),
                        int(citation_count),
                        _json(citations, []),
                        _json(warnings, []),
                        int(bool(success)),
                        values["error"],
                        _json(response, {}),
                    ),
                )
            logger.info("[AUDIT] Recorded query and answer request_id=%s", audit_id)
        except Exception:
            logger.exception("[AUDIT] Failed to record request_id=%s", audit_id)
            return audit_id

        # Preserve the pre-patch query_audit stream when it already exists, but
        # never let a compatibility write roll back the canonical Nokia-style row.
        try:
            with self._connect() as connection:
                self._record_legacy_compat(connection, **values)
        except Exception:
            logger.exception("[AUDIT] Legacy query_audit compatibility write failed request_id=%s", audit_id)
        return audit_id

    def _record_legacy_compat(
        self,
        connection: sqlite3.Connection,
        **values: Any,
    ) -> None:
        """Dual-write only when the pre-patch query_audit table already exists."""
        existing = connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='query_audit'"
        ).fetchone()
        if not existing:
            return
        connection.execute(
            """
            INSERT INTO query_audit (
                created_at, session_id, user_email, query, workflow, source,
                latency_ms, feature_ids_json, package_ids_json, citation_count,
                warnings_json, success, error, request_id, tool_calls_json,
                tool_outputs_json, final_answer, validation_ok,
                validation_errors_json, citations_json, response_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                values.get("created_at"),
                values.get("session_id"),
                values.get("user_email"),
                values.get("query"),
                values.get("workflow"),
                values.get("source"),
                values.get("latency_ms"),
                _json(values.get("feature_ids"), []),
                _json(values.get("package_ids"), []),
                values.get("citation_count") or 0,
                _json(values.get("warnings"), []),
                int(bool(values.get("success"))),
                values.get("error") or "",
                values.get("request_id"),
                _json(values.get("tool_calls"), []),
                _json(values.get("tool_outputs"), []),
                values.get("final_answer") or "",
                int(bool(values.get("validation_ok"))),
                _json(values.get("validation_errors"), []),
                _json(values.get("citations"), []),
                _json(values.get("response"), {}),
            ),
        )

    def get(self, request_id: str) -> Optional[Dict[str, Any]]:
        if not self.enabled:
            return None
        try:
            with self._connect() as connection:
                row = connection.execute(
                    "SELECT * FROM audit WHERE request_id = ?",
                    (str(request_id),),
                ).fetchone()
            return dict(row) if row else None
        except Exception:
            logger.exception("[AUDIT] Failed to read request_id=%s", request_id)
            return None

    def recent(self, limit: int = 50) -> List[Dict[str, Any]]:
        if not self.enabled:
            return []
        try:
            with self._connect() as connection:
                rows = connection.execute(
                    "SELECT * FROM audit ORDER BY created_at DESC LIMIT ?",
                    (max(1, int(limit)),),
                ).fetchall()
            return [dict(row) for row in rows]
        except Exception:
            logger.exception("[AUDIT] Failed to read recent audit rows")
            return []
