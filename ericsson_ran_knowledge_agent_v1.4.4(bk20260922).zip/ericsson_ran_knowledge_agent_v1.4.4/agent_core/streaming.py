"""Request-local streaming event hooks.

The normal Ericsson API remains synchronous. Streaming endpoints install a
request-local sink while the existing workflow runs in a worker thread. Only
answer-synthesis tokens are emitted; query-rewrite traffic remains internal.
"""
from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from typing import Any, Callable, Dict, Iterator, Optional

StreamEvent = Dict[str, Any]
StreamEventSink = Callable[[StreamEvent], None]

_STREAM_EVENT_SINK: ContextVar[Optional[StreamEventSink]] = ContextVar(
    "ericsson_stream_event_sink",
    default=None,
)


def has_stream_sink() -> bool:
    return _STREAM_EVENT_SINK.get() is not None


def emit_stream_event(event: StreamEvent) -> None:
    sink = _STREAM_EVENT_SINK.get()
    if sink is None:
        return
    sink(dict(event))


@contextmanager
def stream_events(sink: Optional[StreamEventSink]) -> Iterator[None]:
    if sink is None:
        yield
        return
    token = _STREAM_EVENT_SINK.set(sink)
    try:
        yield
    finally:
        _STREAM_EVENT_SINK.reset(token)
