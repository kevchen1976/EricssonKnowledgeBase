"""Compatibility facade for the Ericsson workflow implementation."""
from .workflow import EricssonAgent

__all__ = ["EricssonAgent"]
