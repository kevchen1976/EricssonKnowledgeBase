"""Filesystem locations shared by Ericsson agent settings modules."""
from __future__ import annotations

from .loader import PROJECT_ROOT

# Nokia-compatible location: the editable agent instruction file is stored at
# the project root and is loaded when the Agent service process starts.
SYSTEM_PROMPT_PATH = PROJECT_ROOT / "agentInstruction.txt"

__all__ = ["SYSTEM_PROMPT_PATH"]
