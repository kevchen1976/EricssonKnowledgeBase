"""Ericsson identity parsing and canonicalization."""
from __future__ import annotations

import re
from typing import Iterable, List

FEATURE_ID_RE = re.compile(r"(?<![A-Z0-9])FAJ\s*121\s*[-_/ ]?\s*(\d{4})(?!\d)", re.IGNORECASE)
PACKAGE_ID_RE = re.compile(r"(?<![A-Z0-9])FAJ\s*801\s*[-_/ ]?\s*(\d{4})(?!\d)", re.IGNORECASE)


def _dedupe(values: Iterable[str]) -> List[str]:
    seen: set[str] = set()
    out: List[str] = []
    for value in values:
        if value and value not in seen:
            seen.add(value)
            out.append(value)
    return out


def normalize_feature_id(value: str) -> str:
    match = FEATURE_ID_RE.search(str(value or ""))
    return f"FAJ 121 {match.group(1)}" if match else ""


def normalize_package_id(value: str) -> str:
    match = PACKAGE_ID_RE.search(str(value or ""))
    return f"FAJ 801 {match.group(1)}" if match else ""


def feature_key(value: str) -> str:
    normalized = normalize_feature_id(value)
    return normalized.replace(" ", "") if normalized else ""


def package_key(value: str) -> str:
    normalized = normalize_package_id(value)
    return normalized.replace(" ", "") if normalized else ""


def find_feature_ids(text: str) -> List[str]:
    return _dedupe(f"FAJ 121 {match.group(1)}" for match in FEATURE_ID_RE.finditer(text or ""))


def find_package_ids(text: str) -> List[str]:
    return _dedupe(f"FAJ 801 {match.group(1)}" for match in PACKAGE_ID_RE.finditer(text or ""))


def is_feature_id(value: str) -> bool:
    return bool(normalize_feature_id(value))


def is_package_id(value: str) -> bool:
    return bool(normalize_package_id(value))
