"""Deterministic Ericsson query routing.

Identity routing remains deterministic. Neo4j is selected only for supported
high-level entity relationships; Feature-to-Feature questions remain in the
semantic/document layer by design.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List

from .ids import find_feature_ids, find_package_ids

_GRAPH_TERMS = {
    "relationship", "relationships", "related", "uses counter", "counter", "counters",
    "parameter", "parameters", "attribute", "attributes", "kpi", "alarm", "alarms",
    "specific problem", "probable cause", "correction instruction", "corrective action",
    "impact", "feature context",
}
_FEATURE_TO_FEATURE_TERMS = {
    "feature dependency", "feature dependencies", "similar feature", "equivalent feature",
    "related feature", "related features", "feature to feature",
}
_PM_COUNTER_RE = re.compile(r"(?<![A-Za-z0-9_])(?:[A-Za-z][A-Za-z0-9_]*\.)?pm[A-Za-z0-9_]+", re.I)


@dataclass(frozen=True)
class RouteDecision:
    workflow: str
    query: str
    feature_ids: List[str] = field(default_factory=list)
    package_ids: List[str] = field(default_factory=list)
    use_graph: bool = False
    reason: str = ""


def route_query(query: str, *, graph_enabled: bool = False) -> RouteDecision:
    text = " ".join(str(query or "").split())
    features = find_feature_ids(text)
    packages = find_package_ids(text)
    lower = text.casefold()
    feature_to_feature = any(term in lower for term in _FEATURE_TO_FEATURE_TERMS)
    supported_graph_intent = any(term in lower for term in _GRAPH_TERMS) or bool(_PM_COUNTER_RE.search(text))
    graph_intent = graph_enabled and supported_graph_intent and not feature_to_feature

    if features:
        return RouteDecision(
            workflow="feature_lookup",
            query=text,
            feature_ids=features,
            package_ids=packages,
            use_graph=graph_intent,
            reason=(
                "Ericsson FAJ 121 feature identity detected; use graph enrichment for supported "
                "Feature-to-Counter/Parameter/Alarm questions"
                if graph_intent
                else "Ericsson FAJ 121 feature identity detected"
            ),
        )
    if packages:
        return RouteDecision(
            workflow="package_lookup",
            query=text,
            package_ids=packages,
            use_graph=False,
            reason="Ericsson FAJ 801 value-package identity detected; package routing is document-based",
        )
    if graph_intent:
        return RouteDecision(
            workflow="graph_assisted_search",
            query=text,
            use_graph=True,
            reason="Supported Ericsson entity relationship or alarm-enrichment query detected",
        )
    return RouteDecision(
        workflow="knowledge_search",
        query=text,
        reason=(
            "Feature-to-Feature questions use semantic/document retrieval"
            if feature_to_feature
            else "No explicit Ericsson identity or supported graph relationship detected; use corpus retrieval"
        ),
    )
