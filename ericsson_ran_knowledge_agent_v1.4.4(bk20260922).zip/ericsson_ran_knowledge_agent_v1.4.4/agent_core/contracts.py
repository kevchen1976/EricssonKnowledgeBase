"""Shared response contracts for the standalone agent and future supervisor."""
from __future__ import annotations

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class Citation(BaseModel):
    citation_id: str
    source: str
    title: str = ""
    pages: List[int] = Field(default_factory=list)
    heading_path: str = ""
    score: Optional[float] = None
    evidence_tier: str = ""


class QueryRequest(BaseModel):
    query: str = Field(min_length=1)
    session_id: Optional[str] = None
    limit: Optional[int] = Field(default=None, ge=1, le=100)
    include_evidence: bool = False


class QueryResponse(BaseModel):
    answer: str
    source: str
    vendor: str = "Ericsson"
    workflow: str = ""
    feature_ids: List[str] = Field(default_factory=list)
    package_ids: List[str] = Field(default_factory=list)
    citations: List[Citation] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    evidence: List[Dict[str, Any]] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)
