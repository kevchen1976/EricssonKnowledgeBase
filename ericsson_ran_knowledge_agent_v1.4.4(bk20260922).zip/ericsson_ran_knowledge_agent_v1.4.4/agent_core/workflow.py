"""End-to-end standalone Ericsson query workflow."""
from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Sequence

from .clients import GraphClient, KBClient, OllamaClient, ServiceClientError
from .contracts import QueryResponse
from .graph_tools import compact_graph_context, execute_graph_tools, plan_graph_tools
from .logging_utils import current_request_id, single_line, single_line_words
from .rewrite import looks_like_raw_alarm, rewrite_query_with_llm
from .routing import RouteDecision, route_query
from .settings import Settings
from .synthesis import build_citations, synthesize_answer
from .streaming import emit_stream_event
from .validation import append_evidence_reference_footer, validate_answer

logger = logging.getLogger("ericsson_agent")

_SUPERVISOR_LOCAL_ENTITY_TASK = "SUPERVISOR_LOCAL_ENTITY_TASK"


def _hits(payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    for key in ("retrievalResults", "results", "hits"):
        value = payload.get(key)
        if isinstance(value, list):
            return [item for item in value if isinstance(item, dict)]
    return []


def _source(hit: Dict[str, Any]) -> Dict[str, Any]:
    value = hit.get("_source", hit)
    return value if isinstance(value, dict) else {}


def _supervisor_local_kb_queries(query: str) -> List[str]:
    """Extract small vendor-local KB queries from a supervisor verification task.

    The supervisor prompt can contain instructions, source meaning and several
    local candidates. OpenSearch should receive only the local entity identity
    or semantic phrase, never the whole orchestration prompt.
    """
    text = str(query or "")
    queries: List[str] = []
    seen: set[str] = set()

    def add(value: str) -> None:
        value = " ".join(str(value or "").split()).strip()
        key = value.casefold()
        if value and key not in seen:
            seen.add(key)
            queries.append(value)

    for line in text.splitlines():
        stripped = line.strip()
        lower = stripped.casefold()
        if lower.startswith("entity:"):
            add(stripped.split(":", 1)[1])
        elif lower.startswith("external source meaning:"):
            # Use only if no local identity/candidate can be extracted.
            continue
        elif re.match(r"^\d+\.\s+", stripped):
            candidate = re.sub(r"^\d+\.\s+", "", stripped)
            candidate = candidate.split("|", 1)[0].strip()
            add(candidate)
        if len(queries) >= 2:
            break

    if not queries:
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.casefold().startswith("external source meaning:"):
                add(stripped.split(":", 1)[1])
                break
    return queries[:2]


def _merge_hits(groups: Iterable[Sequence[Dict[str, Any]]], limit: int) -> List[Dict[str, Any]]:
    by_key: Dict[str, Dict[str, Any]] = {}
    order: List[str] = []
    for group in groups:
        for hit in group:
            source = _source(hit)
            key = str(source.get("parent_id") or source.get("chunk_id") or hit.get("_id") or "")
            if not key:
                key = f"anonymous-{len(order)}"
            score = float(hit.get("_score") or 0.0)
            if key not in by_key:
                by_key[key] = hit
                order.append(key)
            elif score > float(by_key[key].get("_score") or 0.0):
                by_key[key] = hit
    values = [by_key[key] for key in order]
    values.sort(key=lambda item: float(item.get("_score") or 0.0), reverse=True)
    return values[:limit]


def _collect_ids(evidence: Sequence[Dict[str, Any]], route: RouteDecision) -> tuple[List[str], List[str]]:
    features = list(route.feature_ids)
    packages = list(route.package_ids)
    for hit in evidence:
        source = _source(hit)
        for key in ("feature_id", "primary_feature_id", "owner_feature_id"):
            value = str(source.get(key) or "")
            if value and value not in features:
                features.append(value)
        for value in source.get("feature_ids", []) if isinstance(source.get("feature_ids"), list) else []:
            if value and value not in features:
                features.append(str(value))
        for key in ("package_id", "primary_package_id"):
            value = str(source.get(key) or "")
            if value and value not in packages:
                packages.append(value)
        for value in source.get("package_ids", []) if isinstance(source.get("package_ids"), list) else []:
            if value and value not in packages:
                packages.append(str(value))
    return features, packages


def _log_evidence(evidence: Sequence[Dict[str, Any]]) -> None:
    shown = min(len(evidence), 5)
    logger.info("[AGENT FINAL_EVIDENCE] count=%d logged=%d", len(evidence), shown)
    for rank, hit in enumerate(evidence[:shown], 1):
        source = _source(hit)
        matched_children = source.get("matched_children") if isinstance(source.get("matched_children"), list) else []
        logger.info(
            "[AGENT EVIDENCE] rank=%d parent_id=%s score=%.8f matched_children=%d file=%s "
            "page=%s-%s section=%s snippet=%s",
            rank,
            source.get("parent_id") or hit.get("_id") or "",
            float(hit.get("_score") or 0.0),
            len(matched_children),
            single_line(source.get("filename"), max_chars=140),
            source.get("page_start") or "",
            source.get("page_end") or source.get("page_start") or "",
            single_line(source.get("heading_path") or source.get("heading"), max_chars=220),
            single_line_words(source.get("content"), max_words=50),
        )
    if len(evidence) > shown:
        logger.info("[AGENT EVIDENCE] omitted_candidates=%d", len(evidence) - shown)


@dataclass
class EricssonAgent:
    settings: Settings
    kb: KBClient | None = None
    graph: GraphClient | None = None
    ollama: OllamaClient | None = None

    def __post_init__(self) -> None:
        if self.kb is None:
            self.kb = KBClient(self.settings)
        if self.graph is None and self.settings.graph_enabled:
            self.graph = GraphClient(self.settings)
        if self.ollama is None and self.settings.llm_enabled:
            self.ollama = OllamaClient(self.settings)

    def run(
        self,
        query: str,
        *,
        limit: int | None = None,
        include_evidence: bool = False,
        history: str = "",
    ) -> QueryResponse:
        started = time.perf_counter()
        original_query = " ".join(str(query or "").split()).strip()
        effective_query = original_query
        supervisor_local_entity_task = _SUPERVISOR_LOCAL_ENTITY_TASK.casefold() in original_query.casefold()
        history_text = "" if supervisor_local_entity_task else str(history or "").strip()
        logger.info("[EXECUTE_WORKFLOW] Query: %r", original_query)
        if supervisor_local_entity_task:
            logger.info("[SUPERVISOR LOCAL ENTITY TASK] isolated_history=true query_rewrite=false")
        logger.info("[EXECUTE_WORKFLOW] History length: %d chars", len(history_text))
        if history_text:
            logger.info(
                "[EXECUTE_WORKFLOW] History preview: %s",
                single_line_words(history_text, max_words=50),
            )
        else:
            logger.info("[EXECUTE_WORKFLOW] History is empty")

        if (
            self.settings.enable_llm_query_rewrite
            and self.ollama is not None
            and not looks_like_raw_alarm(original_query)
            and not supervisor_local_entity_task
        ):
            effective_query = rewrite_query_with_llm(original_query, history_text, self.ollama)
            if effective_query != original_query:
                logger.info(
                    "[WORKFLOW] Using rewritten query=%r original_query=%r",
                    effective_query,
                    original_query,
                )
        else:
            logger.info(
                "[WORKFLOW] LLM query rewrite skipped enabled=%s llm_available=%s raw_alarm=%s supervisor_local_entity_task=%s",
                self.settings.enable_llm_query_rewrite,
                self.ollama is not None,
                looks_like_raw_alarm(original_query),
                supervisor_local_entity_task,
            )
        logger.info(
            "[WORKFLOW EFFECTIVE QUERY] original=%r effective=%r changed=%s",
            original_query,
            effective_query,
            effective_query != original_query,
        )

        requested_limit = self.settings.default_limit if limit is None else int(limit)
        actual_limit = min(max(1, requested_limit), self.settings.maximum_limit)
        route = route_query(effective_query, graph_enabled=self.settings.graph_enabled)
        warnings: List[str] = []
        hit_groups: List[List[Dict[str, Any]]] = []
        route_metadata: Dict[str, Any] = {
            "reason": route.reason,
            "original_query": original_query,
            "effective_query": effective_query,
            "rewritten_query": effective_query,
            "query_rewritten": effective_query != original_query,
            "history_chars": len(history_text),
            "query_rewrite_enabled": self.settings.enable_llm_query_rewrite,
            "supervisor_local_entity_task": supervisor_local_entity_task,
        }

        logger.info(
            "[AGENT ROUTE] request_id=%s workflow=%s reason=%s feature_ids=%s package_ids=%s "
            "use_graph=%s requested_limit=%s actual_limit=%d query=%r",
            current_request_id(),
            route.workflow,
            route.reason,
            route.feature_ids,
            route.package_ids,
            route.use_graph,
            limit,
            actual_limit,
            effective_query,
        )

        # Run the graph tools before OpenSearch. This allows an alarm query to
        # resolve the exact specificProblem first, then issue a precise vector
        # search for correction instructions. It also enables deterministic
        # multi-hop queries such as Counter -> Feature -> Parameter.
        graph_context: Dict[str, Any] | None = None
        graph_execution = None
        if route.use_graph and self.graph is not None:
            graph_calls = plan_graph_tools(
                effective_query,
                feature_ids=route.feature_ids,
                limit=actual_limit,
            )
            if graph_calls:
                logger.info(
                    "[AGENT GRAPH_PLAN] calls=%s",
                    [call.tool for call in graph_calls],
                )
                graph_execution = execute_graph_tools(self.graph, graph_calls)
                warnings.extend(graph_execution.warnings)
                graph_context = compact_graph_context(graph_execution.context)
                route_metadata["graph_tool_calls"] = graph_execution.calls
                route_metadata["graph_tool_outputs"] = graph_context.get("tool_results", []) if graph_context else []
                route_metadata["graph_kb_queries"] = graph_execution.kb_queries
                route_metadata["graph_related_feature_ids"] = graph_execution.related_feature_ids
                logger.info(
                    "[AGENT GRAPH_RESULT] calls=%d outputs=%d kb_queries=%d related_features=%d",
                    len(graph_execution.calls),
                    len(graph_execution.outputs),
                    len(graph_execution.kb_queries),
                    len(graph_execution.related_feature_ids),
                )

        assert self.kb is not None
        try:
            if route.workflow == "feature_lookup":
                manifests: List[Dict[str, Any]] = []
                per_feature_limit = max(2, actual_limit)
                for feature_id in route.feature_ids:
                    logger.info(
                        "[AGENT KB_CALL] operation=retrieve_feature feature_id=%s limit=%d include_related=true",
                        feature_id,
                        per_feature_limit,
                    )
                    payload = self.kb.retrieve_feature(
                        feature_id,
                        effective_query,
                        limit=per_feature_limit,
                        include_related=True,
                    )
                    payload_hits = _hits(payload)
                    hit_groups.append(payload_hits)
                    logger.info(
                        "[AGENT KB_RESULT] operation=retrieve_feature feature_id=%s parents=%d warnings=%d "
                        "fallback_type=%s",
                        feature_id,
                        len(payload_hits),
                        len(payload.get("warnings", []) or []),
                        payload.get("fallback_type") or "",
                    )
                    manifest = payload.get("manifest")
                    if isinstance(manifest, dict):
                        manifests.append(manifest)
                    warnings.extend(str(value) for value in payload.get("warnings", []) if value)
                route_metadata["manifests"] = manifests
            elif route.workflow == "package_lookup":
                manifests = []
                for package_id in route.package_ids:
                    logger.info(
                        "[AGENT KB_CALL] operation=retrieve_package package_id=%s limit=%d",
                        package_id,
                        max(2, actual_limit),
                    )
                    payload = self.kb.retrieve_package(package_id, effective_query, limit=max(2, actual_limit))
                    payload_hits = _hits(payload)
                    hit_groups.append(payload_hits)
                    logger.info(
                        "[AGENT KB_RESULT] operation=retrieve_package package_id=%s parents=%d warnings=%d "
                        "fallback_type=%s",
                        package_id,
                        len(payload_hits),
                        len(payload.get("warnings", []) or []),
                        payload.get("fallback_type") or "",
                    )
                    manifest = payload.get("manifest")
                    if isinstance(manifest, dict):
                        manifests.append(manifest)
                    warnings.extend(str(value) for value in payload.get("warnings", []) if value)
                route_metadata["manifests"] = manifests
            else:
                graph_profile_only = bool(
                    graph_execution
                    and graph_execution.calls
                    and all(
                        str(call.get("tool") or "") in {"counter_context", "parameter_context"}
                        for call in graph_execution.calls
                    )
                )
                if graph_profile_only and graph_execution is not None and graph_execution.kb_queries:
                    # Do not search the full supervisor orchestration prompt. Use
                    # one or two exact graph-resolved local identities instead.
                    per_query_limit = max(2, min(actual_limit, 4))
                    for compact_query in graph_execution.kb_queries[:2]:
                        logger.info(
                            "[AGENT KB_CALL] operation=entity_profile_search limit=%d query=%r",
                            per_query_limit,
                            compact_query,
                        )
                        payload = self.kb.search(compact_query, limit=per_query_limit)
                        payload_hits = _hits(payload)
                        hit_groups.append(payload_hits)
                        logger.info(
                            "[AGENT KB_RESULT] operation=entity_profile_search parents=%d warnings=%d fallback_type=%s",
                            len(payload_hits),
                            len(payload.get("warnings", []) or []),
                            payload.get("fallback_type") or "",
                        )
                        warnings.extend(str(value) for value in payload.get("warnings", []) if value)
                    route_metadata["entity_profile_kb_queries"] = graph_execution.kb_queries[:2]
                elif supervisor_local_entity_task:
                    # Graph can be disabled, a candidate may fail exact graph
                    # resolution, or the supervisor may intentionally supply only
                    # semantic context. Still keep the document query compact.
                    compact_queries = _supervisor_local_kb_queries(original_query)
                    per_query_limit = max(2, min(actual_limit, 4))
                    for compact_query in compact_queries:
                        logger.info(
                            "[AGENT KB_CALL] operation=supervisor_local_search limit=%d query=%r",
                            per_query_limit,
                            compact_query,
                        )
                        payload = self.kb.search(compact_query, limit=per_query_limit)
                        payload_hits = _hits(payload)
                        hit_groups.append(payload_hits)
                        logger.info(
                            "[AGENT KB_RESULT] operation=supervisor_local_search parents=%d warnings=%d fallback_type=%s",
                            len(payload_hits),
                            len(payload.get("warnings", []) or []),
                            payload.get("fallback_type") or "",
                        )
                        warnings.extend(str(value) for value in payload.get("warnings", []) if value)
                    route_metadata["supervisor_local_kb_queries"] = compact_queries
                else:
                    logger.info("[AGENT KB_CALL] operation=search limit=%d", actual_limit)
                    payload = self.kb.search(effective_query, limit=actual_limit)
                    payload_hits = _hits(payload)
                    hit_groups.append(payload_hits)
                    logger.info(
                        "[AGENT KB_RESULT] operation=search parents=%d warnings=%d fallback_type=%s",
                        len(payload_hits),
                        len(payload.get("warnings", []) or []),
                        payload.get("fallback_type") or "",
                    )
                    warnings.extend(str(value) for value in payload.get("warnings", []) if value)

            # Graph-resolved entities can drive additional precise OpenSearch
            # searches. Most importantly, an alarm specificProblem is used as
            # the exact semantic-search query for correction instructions.
            extra_queries = (
                []
                if route_metadata.get("entity_profile_kb_queries") or route_metadata.get("supervisor_local_kb_queries")
                else list(graph_execution.kb_queries) if graph_execution is not None else []
            )
            for expanded_query in extra_queries:
                if expanded_query.strip().casefold() == effective_query.strip().casefold():
                    continue
                logger.info(
                    "[AGENT KB_CALL] operation=graph_expanded_search limit=%d query=%r",
                    actual_limit,
                    expanded_query,
                )
                expanded_payload = self.kb.search(expanded_query, limit=actual_limit)
                expanded_hits = _hits(expanded_payload)
                # Prefer the exact graph-resolved alarm query when independent
                # search score ranges differ. The original score remains in
                # the hit payload; this only affects cross-query merge order.
                for expanded_hit in expanded_hits:
                    expanded_hit["_score"] = float(expanded_hit.get("_score") or 0.0) + 2.0
                    expanded_hit["_graph_expanded_query"] = expanded_query
                hit_groups.append(expanded_hits)
                warnings.extend(str(value) for value in expanded_payload.get("warnings", []) if value)
                logger.info(
                    "[AGENT KB_RESULT] operation=graph_expanded_search parents=%d fallback_type=%s",
                    len(expanded_hits),
                    expanded_payload.get("fallback_type") or "",
                )

            # For graph-first reverse lookups (alarm/counter/parameter ->
            # Feature), retrieve a small amount of the related Feature
            # documentation too. This gives the synthesis layer both exact
            # graph relationships and explanatory vector evidence.
            related_ids = list(graph_execution.related_feature_ids) if graph_execution is not None else []
            already_routed = set(route.feature_ids)
            for feature_id in [value for value in related_ids if value not in already_routed][:3]:
                logger.info(
                    "[AGENT KB_CALL] operation=graph_related_feature feature_id=%s limit=2",
                    feature_id,
                )
                related_payload = self.kb.retrieve_feature(
                    feature_id,
                    effective_query,
                    limit=2,
                    include_related=False,
                )
                related_hits = _hits(related_payload)
                hit_groups.append(related_hits)
                warnings.extend(str(value) for value in related_payload.get("warnings", []) if value)
                logger.info(
                    "[AGENT KB_RESULT] operation=graph_related_feature feature_id=%s parents=%d",
                    feature_id,
                    len(related_hits),
                )
        except ServiceClientError as exc:
            logger.warning("[AGENT KB_ERROR] error=%s", single_line(exc, max_chars=500))
            if graph_context:
                warnings.append(str(exc) + "; continued with Neo4j graph evidence only.")
            else:
                emit_stream_event({
                    "type": "workflow",
                    "workflow": route.workflow,
                    "source": "ericsson_agent",
                })
                return QueryResponse(
                    answer="The Ericsson knowledge-base service is unavailable, so I could not retrieve supporting documentation.",
                    source="ericsson_agent",
                    workflow=route.workflow,
                    feature_ids=route.feature_ids,
                    package_ids=route.package_ids,
                    warnings=[str(exc)],
                    metadata=route_metadata,
                )

        evidence = _merge_hits(hit_groups, actual_limit)
        logger.info(
            "[AGENT EVIDENCE_MERGE] input_groups=%d input_hits=%d selected_parents=%d limit=%d",
            len(hit_groups),
            sum(len(group) for group in hit_groups),
            len(evidence),
            actual_limit,
        )
        _log_evidence(evidence)

        stream_source = "ericsson_kb_graph" if graph_context else "ericsson_kb"
        emit_stream_event({
            "type": "workflow",
            "workflow": route.workflow,
            "source": stream_source,
        })

        synthesis_started = time.perf_counter()
        logger.info(
            "[AGENT SYNTHESIS_START] evidence_count=%d graph_used=%s llm_enabled=%s",
            len(evidence),
            bool(graph_context),
            self.ollama is not None,
        )
        answer, synthesis_warnings = synthesize_answer(
            original_query,
            evidence,
            ollama=self.ollama,
            graph_context=graph_context,
            history=history_text,
            effective_query=effective_query,
        )
        synthesis_ms = int((time.perf_counter() - synthesis_started) * 1000)
        warnings.extend(synthesis_warnings)
        logger.info(
            "[AGENT SYNTHESIS_COMPLETE] elapsed_ms=%d answer_chars=%d warnings=%d preview=%s",
            synthesis_ms,
            len(answer),
            len(synthesis_warnings),
            single_line(answer, max_chars=320),
        )

        validation = validate_answer(
            answer,
            evidence,
            user_feature_ids=route.feature_ids,
            user_package_ids=route.package_ids,
            graph_context=graph_context,
        )
        warnings.extend(validation.warnings)
        logger.info(
            "[AGENT VALIDATION] unsupported_feature_ids=%s unsupported_package_ids=%s "
            "invalid_citations=%s missing_citations=%s warnings=%s",
            validation.unsupported_feature_ids,
            validation.unsupported_package_ids,
            validation.invalid_citations,
            validation.missing_citations,
            validation.warnings,
        )
        hard_validation_failure = bool(
            validation.unsupported_feature_ids
            or validation.unsupported_package_ids
            or validation.invalid_citations
        )
        route_metadata["validation_hard_failure"] = hard_validation_failure
        route_metadata["citation_footer_applied"] = False
        route_metadata["validation_fallback_applied"] = False

        if hard_validation_failure:
            # Unsupported Ericsson identities and invalid citation references are
            # hard grounding failures.  These still require the deterministic
            # evidence-only fallback.  Missing citation markers alone are treated
            # separately below so a correct streamed answer is not discarded at
            # completion merely because the model forgot inline [E#] markers.
            logger.warning(
                "[AGENT VALIDATION_FALLBACK] replacing LLM answer with evidence-only answer "
                "unsupported_feature_ids=%s unsupported_package_ids=%s invalid_citations=%s",
                validation.unsupported_feature_ids,
                validation.unsupported_package_ids,
                validation.invalid_citations,
            )
            answer, fallback_warnings = synthesize_answer(
                original_query,
                evidence,
                ollama=None,
                graph_context=graph_context,
                history=history_text,
                effective_query=effective_query,
            )
            warnings.extend(fallback_warnings)
            warnings.append(
                "LLM output was replaced with an evidence-only answer because it introduced unsupported Ericsson identities "
                "or invalid evidence markers."
            )
            route_metadata["validation_fallback_applied"] = True
            validation = validate_answer(
                answer,
                evidence,
                user_feature_ids=route.feature_ids,
                user_package_ids=route.package_ids,
                graph_context=graph_context,
            )
            logger.info(
                "[AGENT FALLBACK_VALIDATION] unsupported_feature_ids=%s unsupported_package_ids=%s "
                "invalid_citations=%s missing_citations=%s",
                validation.unsupported_feature_ids,
                validation.unsupported_package_ids,
                validation.invalid_citations,
                validation.missing_citations,
            )
        elif validation.missing_citations and evidence:
            # A missing citation marker is a formatting/traceability defect, not
            # evidence that the generated technical content is wrong. Preserve the
            # streamed answer and attach a compact reference footer instead of
            # replacing the entire answer with the extractive evidence summary.
            answer = append_evidence_reference_footer(validation.answer, len(evidence))
            warnings.append(
                "The generated answer omitted inline evidence markers; the answer was preserved and retrieved evidence "
                "references were appended at completion."
            )
            route_metadata["citation_footer_applied"] = True
            logger.warning(
                "[AGENT CITATION_REPAIR] preserved streamed answer and appended evidence references count=%d",
                len(evidence),
            )
            validation = validate_answer(
                answer,
                evidence,
                user_feature_ids=route.feature_ids,
                user_package_ids=route.package_ids,
                graph_context=graph_context,
            )
            logger.info(
                "[AGENT CITATION_REPAIR_VALIDATION] invalid_citations=%s missing_citations=%s answer_chars=%d",
                validation.invalid_citations,
                validation.missing_citations,
                len(validation.answer),
            )
        feature_ids, package_ids = _collect_ids(evidence, route)
        if graph_execution is not None:
            for feature_id in graph_execution.related_feature_ids:
                if feature_id not in feature_ids:
                    feature_ids.append(feature_id)
        citations = build_citations(evidence)
        route_metadata.update({
            "evidence_count": len(evidence),
            "graph_used": bool(graph_context),
            "direct_feature_lookup": route.workflow == "feature_lookup",
        })
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        logger.info(
            "[AGENT COMPLETE] workflow=%s elapsed_ms=%d evidence_count=%d citations=%d "
            "feature_ids=%s package_ids=%s warnings=%d",
            route.workflow,
            elapsed_ms,
            len(evidence),
            len(citations),
            feature_ids,
            package_ids,
            len(warnings),
        )
        return QueryResponse(
            answer=validation.answer,
            source="ericsson_kb_graph" if graph_context else "ericsson_kb",
            workflow=route.workflow,
            feature_ids=feature_ids,
            package_ids=package_ids,
            citations=citations,
            warnings=list(dict.fromkeys(warnings)),
            evidence=[_source(hit) | {"score": hit.get("_score")} for hit in evidence] if include_evidence else [],
            metadata=route_metadata,
        )
