"""TOC-aware, section-parent / child-window chunking for Ericsson Markdown.

The design follows the proven Nokia strategy supplied with this project:

* one real document-outline section is stored once as a parent document;
* parent sections are not split by a token limit;
* only child windows are embedded and searched;
* child windows use the embedding model tokenizer, 300-token windows and
  60-token overlap by default;
* procedure-like sections up to the configured procedure limit can remain one
  child so ordered operational steps are not fragmented;
* child documents contain only a parent reference, never duplicate parent text.
"""
from __future__ import annotations

import hashlib
import re
from typing import Any, Dict, Iterable, List, Sequence

from agent_core.ids import find_feature_ids, find_package_ids
from agent_core.settings import Settings

from .manifest_loader import ManifestStore
from .markdown_parser import extract_image_paths, parse_markdown_sections
from .models import ChildChunk, MarkdownBlock, ParentChunk
from .tokenization import count_tokens, get_token_codec

PROCEDURE_HEADING_RE = re.compile(
    r"\b(activating|deactivating|configuring|verifying|activation|deactivation|"
    r"configuration|operation check|operational flow|procedure|migration|upgrade|"
    r"integration|expansion|refresh|installation|generation|return of licenses)\b",
    re.IGNORECASE,
)


def _hash_id(*parts: str) -> str:
    payload = "\x1f".join(str(part) for part in parts)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _dedupe(values: Iterable[Any]) -> List[str]:
    seen: set[str] = set()
    out: List[str] = []
    for value in values:
        text = str(value or "").strip()
        if text and text not in seen:
            seen.add(text)
            out.append(text)
    return out


def _metadata_list(record: Dict[str, Any], key: str) -> List[str]:
    value = record.get(key, [])
    if isinstance(value, list):
        return _dedupe(value)
    return [str(value)] if value else []


def _selected_metadata(document: Dict[str, Any], section: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(document)
    merged.update({key: value for key, value in section.items() if value not in (None, "", [], {})})
    doc_role = str(merged.get("doc_role") or "general_document")
    owner_feature_id = str(merged.get("owner_feature_id") or "").strip()
    included = _dedupe(
        _metadata_list(document, "included_feature_ids")
        + _metadata_list(section, "included_feature_ids")
    )
    feature_ids = _dedupe(
        _metadata_list(document, "feature_ids")
        + included
        + _metadata_list(section, "feature_ids")
    )
    mentioned = _dedupe(
        _metadata_list(document, "mentioned_feature_ids")
        + _metadata_list(section, "mentioned_feature_ids")
    )
    related = _dedupe(
        _metadata_list(document, "related_feature_ids")
        + _metadata_list(section, "related_feature_ids")
    )

    # General guidelines may cite Ericsson identities without owning them.
    if doc_role == "general_document" and not owner_feature_id:
        mentioned = _dedupe(mentioned + feature_ids + included)
        feature_ids = []
        included = []

    explicit_association = str(merged.get("feature_association") or "").strip().lower()
    if owner_feature_id:
        feature_association = "primary"
    elif doc_role == "package_document" and (included or feature_ids):
        feature_association = explicit_association if explicit_association in {"related", "mentioned"} else "included"
    elif related:
        feature_association = "related"
    elif mentioned:
        feature_association = explicit_association if explicit_association in {"related", "mentioned"} else "mentioned"
    elif explicit_association in {"primary", "included", "related", "mentioned", "none"}:
        feature_association = explicit_association
    else:
        feature_association = "none"

    package_ids = _dedupe(_metadata_list(document, "package_ids") + _metadata_list(section, "package_ids"))
    return {
        "vendor": merged.get("vendor", "Ericsson"),
        "corpus_id": merged.get("corpus_id", "ericsson-ran"),
        "filename": merged.get("filename", ""),
        "source_markdown": merged.get("source_markdown", merged.get("filename", "")),
        "source_pdf": merged.get("source_pdf", ""),
        "title": merged.get("title", ""),
        "doc_type": merged.get("doc_type", "general_document"),
        "doc_role": doc_role,
        "feature_id": merged.get("feature_id", ""),
        "primary_feature_id": merged.get("primary_feature_id", ""),
        "owner_feature_id": owner_feature_id,
        "feature_ids": feature_ids,
        "included_feature_ids": included,
        "mentioned_feature_ids": mentioned,
        "related_feature_ids": related,
        "feature_title": merged.get("feature_title", ""),
        "package_id": merged.get("package_id", ""),
        "primary_package_id": merged.get("primary_package_id", ""),
        "package_ids": package_ids,
        "package_names": _dedupe(_metadata_list(document, "package_names") + _metadata_list(section, "package_names")),
        "access_types": _dedupe(_metadata_list(document, "access_types") + _metadata_list(section, "access_types")),
        "node_types": _dedupe(_metadata_list(document, "node_types") + _metadata_list(section, "node_types")),
        "licensing": merged.get("licensing", ""),
        "topics": merged.get("topics", ""),
        "topic_aliases": _dedupe(_metadata_list(document, "topic_aliases") + _metadata_list(section, "topic_aliases")),
        "section_type": merged.get("section_type", "general"),
        "feature_association": feature_association,
        "manifest_record_id": section.get("record_id", document.get("record_id", "")),
        "manifest_priority": int(section.get("priority") or document.get("priority") or 0),
        "prerequisites": _dedupe(_metadata_list(section, "prerequisites") + _metadata_list(document, "prerequisites")),
        "restriction_status": merged.get("restriction_status", ""),
        "question_templates": _dedupe(_metadata_list(section, "question_templates") + _metadata_list(document, "question_templates")),
        "content_retrievable": bool(merged.get("content_retrievable", True)),
    }


def _embedding_text(
    metadata: Dict[str, Any],
    heading_path: str,
    content: str,
    *,
    mode: str = "content",
) -> str:
    """Return the exact text sent to the embedding model.

    ``content`` is the default because it mirrors the supplied Nokia strategy:
    the stored child window is exactly what is embedded. Metadata enrichment is
    retained as an explicit opt-in experiment rather than silently changing the
    vector space.
    """
    if mode == "content":
        return str(content or "").strip()
    if mode != "content_plus_metadata":
        raise ValueError(f"Unsupported embedding_input_mode: {mode!r}")

    lines = [
        f"Vendor: {metadata.get('vendor', 'Ericsson')}",
        f"Document: {metadata.get('title') or metadata.get('filename')}",
    ]
    if metadata.get("feature_id"):
        lines.append(f"Feature Identity: {metadata['feature_id']}")
    if metadata.get("feature_title"):
        lines.append(f"Feature Name: {metadata['feature_title']}")
    if metadata.get("feature_ids"):
        lines.append("Feature Identities: " + ", ".join(metadata["feature_ids"]))
    if metadata.get("included_feature_ids"):
        lines.append("Included Feature Identities: " + ", ".join(metadata["included_feature_ids"]))
    if metadata.get("mentioned_feature_ids"):
        lines.append("Mentioned Feature Identities: " + ", ".join(metadata["mentioned_feature_ids"]))
    if metadata.get("package_ids"):
        lines.append("Value Package Identities: " + ", ".join(metadata["package_ids"]))
    if heading_path:
        lines.append(f"Section: {heading_path}")
    if metadata.get("topics"):
        lines.append(f"Topics: {metadata['topics']}")
    lines.append(content)
    return "\n".join(str(value) for value in lines if value)


def _is_procedure_like(heading: str, text: str) -> bool:
    heading_says_procedure = bool(PROCEDURE_HEADING_RE.search(heading or ""))
    body = text or ""
    body_has_label = bool(
        re.search(
            r"(?mi)^\s*(?:Steps?|Procedure|Operational Process|Prerequisites)\s*:?[ \t]*$",
            body,
        )
    )
    body_has_steps = bool(re.search(r"(?m)^\s*1(?:\.|\))\s+", body))
    return (heading_says_procedure or body_has_label) and (body_has_label or body_has_steps)


def _add_heading_prefix(child_text: str, heading_path: str) -> str:
    child_text = str(child_text or "").strip()
    heading_path = str(heading_path or "").strip()
    if not heading_path or not child_text:
        return child_text
    normalized_heading = re.sub(r"[^0-9A-Za-z]+", " ", heading_path).lower().strip()
    normalized_start = re.sub(r"[^0-9A-Za-z]+", " ", child_text[: max(100, len(heading_path) + 30)]).lower().strip()
    if normalized_heading and normalized_start.startswith(normalized_heading):
        return child_text
    return f"Section: {heading_path}\n\n{child_text}"


def _split_text_to_children(parent: ParentChunk, settings: Settings) -> List[str]:
    codec = get_token_codec(
        settings.embedding_model_path,
        local_files_only=settings.local_files_only,
    )
    tokens = codec.encode(parent.content, add_special_tokens=False)
    if not tokens:
        return []

    if (
        settings.keep_procedure_sections
        and _is_procedure_like(parent.heading_path or parent.heading, parent.content)
        and len(tokens) <= settings.procedure_max_tokens
    ):
        return [parent.content.strip()]

    maximum = max(1, int(settings.child_max_tokens))
    overlap = max(0, int(settings.child_overlap_tokens))
    step = maximum - overlap
    if step <= 0:
        step = max(1, maximum // 2)

    children: List[str] = []
    for start in range(0, len(tokens), step):
        child_tokens = tokens[start : start + maximum]
        child_text = codec.decode(child_tokens, skip_special_tokens=True).strip()
        if settings.add_heading_to_children and start > 0:
            child_text = _add_heading_prefix(child_text, parent.heading_path)
        if child_text:
            children.append(child_text)
        if start + maximum >= len(tokens):
            break
    return children


def build_parent_chunks(
    filename: str,
    title: str,
    markdown: str,
    document_record: Dict[str, Any],
    manifest_store: ManifestStore,
    settings: Settings,
    source_sha256: str,
) -> List[ParentChunk]:
    """Create one parent for every real Ericsson document section.

    ``parent_max_tokens`` is intentionally diagnostic only, matching the Nokia
    strategy.  A long section is still one parent and is divided only into
    searchable child windows.
    """
    parents: List[ParentChunk] = []
    sections = parse_markdown_sections(markdown, include_preamble=settings.include_document_preamble)
    codec = get_token_codec(settings.embedding_model_path, local_files_only=settings.local_files_only)

    for parent_order, section in enumerate(sections, 1):
        body = "\n\n".join(block.text for block in section.blocks if block.text.strip()).strip()
        if not body and not section.heading:
            continue

        section_record = manifest_store.match_section(filename, section.heading, section.heading_path)
        metadata = _selected_metadata(document_record, section_record)
        metadata["filename"] = filename
        metadata["title"] = title
        metadata["source_sha256"] = source_sha256

        discovered_feature_ids = find_feature_ids(section.text)
        doc_role = str(metadata.get("doc_role") or "general_document")
        if discovered_feature_ids:
            if doc_role == "general_document" and not metadata.get("owner_feature_id"):
                metadata["mentioned_feature_ids"] = _dedupe(
                    _metadata_list(metadata, "mentioned_feature_ids") + discovered_feature_ids
                )
                if metadata.get("feature_association") == "none":
                    metadata["feature_association"] = "mentioned"
            elif doc_role == "package_document":
                metadata["included_feature_ids"] = _dedupe(
                    _metadata_list(metadata, "included_feature_ids") + discovered_feature_ids
                )
                metadata["feature_ids"] = _dedupe(
                    _metadata_list(metadata, "feature_ids") + discovered_feature_ids
                )
                if metadata.get("feature_association") == "none":
                    metadata["feature_association"] = "included"
            elif not metadata.get("feature_ids"):
                metadata["feature_ids"] = discovered_feature_ids
        if not metadata.get("package_ids") and doc_role != "general_document":
            metadata["package_ids"] = find_package_ids(section.text)

        heading_markup = "#" * max(1, min(6, section.level))
        content = f"{heading_markup} {section.heading}\n\n{body}".strip()
        parent_token_count = count_tokens(content, codec=codec)
        parent_id = _hash_id(
            settings.corpus_id,
            filename,
            "section-parent",
            str(parent_order),
            section.heading_path,
        )
        parent_meta = dict(metadata)
        parent_meta.update({
            "heading": section.heading,
            "heading_number": section.heading_number,
            "heading_level": section.level,
            "heading_path": section.heading_path,
            "page_start": section.page_start,
            "page_end": section.page_end,
            "parent_order": parent_order,
            "record_kind": "parent",
            "chunk_kind": "markdown",
            "parent_strategy": "one_real_section",
            "parent_token_count": parent_token_count,
            "parent_soft_limit": settings.parent_max_tokens,
            "parent_exceeds_soft_limit": parent_token_count > settings.parent_max_tokens,
            "chunk_tokenizer": getattr(codec, "name", "unknown"),
        })
        parents.append(ParentChunk(
            parent_id=parent_id,
            filename=filename,
            title=title,
            heading=section.heading,
            heading_path=section.heading_path,
            section_type=str(parent_meta.get("section_type") or "general"),
            feature_association=str(parent_meta.get("feature_association") or "none"),
            page_start=section.page_start,
            page_end=section.page_end,
            content=content,
            image_paths=extract_image_paths(content),
            metadata=parent_meta,
            parent_order=parent_order,
            blocks=list(section.blocks),
        ))
    return parents


def build_manifest_fact_parents(
    filename: str,
    title: str,
    document_record: Dict[str, Any],
    facts: Sequence[Dict[str, Any]],
    settings: Settings,
    source_sha256: str,
) -> List[ParentChunk]:
    """Turn high-priority manifest facts into normal parent records.

    This preserves the same two-index contract for facts: the fact is stored once
    in the parent index and its searchable child references that parent.
    """
    if not settings.include_manifest_facts:
        return []

    codec = get_token_codec(settings.embedding_model_path, local_files_only=settings.local_files_only)
    parents: List[ParentChunk] = []
    for order, fact in enumerate(facts, 1):
        fact_text = str(fact.get("fact") or fact.get("answer_summary") or "").strip()
        if not fact_text:
            continue
        metadata = _selected_metadata(document_record, fact)
        heading = str(fact.get("section_heading") or "Manifest fact").strip()
        heading_path = str(fact.get("heading_path") or heading).strip()
        questions = _metadata_list(fact, "question_templates")
        content_parts = [f"## {heading}", fact_text]
        if questions:
            content_parts.append("Questions answered: " + " | ".join(questions))
        content = "\n\n".join(content_parts).strip()
        page_start = int(fact.get("page_start") or 1)
        page_end = int(fact.get("page_end") or page_start)
        parent_order = 100000 + order
        parent_id = _hash_id(
            settings.corpus_id,
            filename,
            "manifest-fact-parent",
            str(fact.get("record_id") or order),
        )
        token_count = count_tokens(content, codec=codec)
        metadata.update({
            "filename": filename,
            "title": title,
            "source_sha256": source_sha256,
            "heading": heading,
            "heading_number": "",
            "heading_level": 2,
            "heading_path": heading_path,
            "page_start": page_start,
            "page_end": page_end,
            "parent_order": parent_order,
            "record_kind": "parent",
            "chunk_kind": "manifest_fact",
            "manifest_record_id": fact.get("record_id", ""),
            "manifest_priority": int(fact.get("priority") or 100),
            "parent_strategy": "manifest_fact_parent",
            "parent_token_count": token_count,
            "parent_soft_limit": settings.parent_max_tokens,
            "parent_exceeds_soft_limit": token_count > settings.parent_max_tokens,
            "chunk_tokenizer": getattr(codec, "name", "unknown"),
        })
        parents.append(ParentChunk(
            parent_id=parent_id,
            filename=filename,
            title=title,
            heading=heading,
            heading_path=heading_path,
            section_type=str(metadata.get("section_type") or "general"),
            feature_association=str(metadata.get("feature_association") or "none"),
            page_start=page_start,
            page_end=page_end,
            content=content,
            image_paths=[],
            metadata=metadata,
            parent_order=parent_order,
            blocks=[MarkdownBlock(content, page_start, page_end, "paragraph")],
        ))
    return parents


def build_child_chunks(parents: Sequence[ParentChunk], settings: Settings) -> List[ChildChunk]:
    """Create embedded/searchable children that reference stored parents."""
    codec = get_token_codec(settings.embedding_model_path, local_files_only=settings.local_files_only)
    children: List[ChildChunk] = []
    for parent in parents:
        child_texts = _split_text_to_children(parent, settings)
        for child_order, content in enumerate(child_texts, 1):
            if not content.strip():
                continue
            token_count = count_tokens(content, codec=codec)
            chunk_id = _hash_id(parent.parent_id, "child", str(child_order), content)
            metadata = dict(parent.metadata)
            # The complete parent must never be copied into a child document.
            metadata.pop("parent_content", None)
            metadata.update({
                "parent_id": parent.parent_id,
                "parent_storage_id": parent.parent_id,
                "parent_page_start": parent.page_start,
                "parent_page_end": parent.page_end,
                "parent_order": parent.parent_order,
                "heading": parent.heading,
                "heading_path": parent.heading_path,
                "section_type": parent.section_type,
                "feature_association": parent.feature_association,
                "image_paths": parent.image_paths,
                "record_kind": "child",
                "chunk_kind": str(parent.metadata.get("chunk_kind") or "markdown"),
                "below_minimum_chunk_tokens": token_count < settings.minimum_chunk_tokens,
                "child_window_tokens": settings.child_max_tokens,
                "child_overlap_tokens": settings.child_overlap_tokens,
                "chunk_tokenizer": getattr(codec, "name", "unknown"),
                "embedding_input_mode": settings.embedding_input_mode,
                "parent_content_sha256": hashlib.sha256(parent.content.encode("utf-8")).hexdigest(),
            })
            children.append(ChildChunk(
                chunk_id=chunk_id,
                parent_id=parent.parent_id,
                content=content,
                embedding_text=_embedding_text(
                    metadata,
                    parent.heading_path,
                    content,
                    mode=settings.embedding_input_mode,
                ),
                # Like the supplied Nokia strategy, the child inherits the full
                # semantic parent page range. Exact evidence remains available in
                # the matched child text returned with the parent.
                page_start=parent.page_start,
                page_end=parent.page_end,
                child_order=child_order,
                token_count=token_count,
                metadata=metadata,
            ))
    return children


def build_manifest_fact_chunks(
    filename: str,
    title: str,
    document_record: Dict[str, Any],
    facts: Sequence[Dict[str, Any]],
    settings: Settings,
    source_sha256: str,
) -> List[ChildChunk]:
    """Compatibility wrapper retained for callers from Ericsson agent v1.0."""
    parents = build_manifest_fact_parents(
        filename,
        title,
        document_record,
        facts,
        settings,
        source_sha256,
    )
    return build_child_chunks(parents, settings)
