"""Tokenizer utilities aligned with the Nokia BGE parent/child strategy.

Production chunk boundaries use the tokenizer that belongs to the configured
embedding model (normally BAAI/bge-large-en-v1.5). A deterministic regex codec
is retained for offline validation environments where model files are absent.

Important implementation detail
-------------------------------
The section parser intentionally tokenizes complete parent sections so it can
measure them and split them into child windows. Parent sections may be longer
than the embedding model limit. Hugging Face tokenizers emit a model-length
warning by default even when tokenization is being used only for counting or
splitting. This module disables that warning for deliberate, non-truncating
count/split operations. The actual embedding path separately performs a strict
preflight check against ``SentenceTransformer.max_seq_length``.
"""
from __future__ import annotations

import os
import re
from functools import lru_cache
from pathlib import Path
from typing import Any, List, Optional, Sequence


_MAX_REASONABLE_MODEL_LENGTH = 1_000_000


def _finite_model_length(value: Any) -> Optional[int]:
    """Normalize tokenizer model-length sentinels to a usable integer.

    Some Hugging Face tokenizers use a very large sentinel when no finite model
    limit is declared. Such values are not useful for an embedding safety guard.
    """
    try:
        parsed = int(value)
    except (TypeError, ValueError, OverflowError):
        return None
    if parsed <= 0 or parsed >= _MAX_REASONABLE_MODEL_LENGTH:
        return None
    return parsed


class RegexTokenCodec:
    """Small reversible fallback used only when a Hugging Face tokenizer is unavailable."""

    _token_re = re.compile(r"\w+|[^\w\s]", re.UNICODE)

    @property
    def name(self) -> str:
        return "regex-fallback"

    @property
    def model_max_length(self) -> None:
        # The regex fallback cannot claim an exact transformer model limit.
        return None

    def num_special_tokens_to_add(self, pair: bool = False) -> int:
        del pair
        return 0

    def encode(self, text: str, add_special_tokens: bool = False) -> List[str]:
        del add_special_tokens
        return self._token_re.findall(str(text or ""))

    def decode(self, tokens: Sequence[Any], skip_special_tokens: bool = True) -> str:
        del skip_special_tokens
        if not tokens:
            return ""
        out = " ".join(str(token) for token in tokens)
        out = re.sub(r"\s+([,.;:!?%\)\]\}])", r"\1", out)
        out = re.sub(r"([\(\[\{])\s+", r"\1", out)
        out = re.sub(r"\s+([/])\s+", r"\1", out)
        out = re.sub(r"\s+", " ", out)
        return out.strip()


class HuggingFaceTokenCodec:
    def __init__(self, tokenizer: Any, name: str) -> None:
        self._tokenizer = tokenizer
        self._name = name

    @property
    def name(self) -> str:
        return self._name

    @property
    def model_max_length(self) -> Optional[int]:
        return _finite_model_length(getattr(self._tokenizer, "model_max_length", None))

    def num_special_tokens_to_add(self, pair: bool = False) -> int:
        method = getattr(self._tokenizer, "num_special_tokens_to_add", None)
        if not callable(method):
            return 0
        try:
            return int(method(pair=pair))
        except TypeError:
            return int(method(pair))

    def encode(self, text: str, add_special_tokens: bool = False) -> List[int]:
        """Tokenize without truncation and without false model-length warnings.

        This method is used to count and split complete source sections. A long
        source section is expected and safe here because it is not being passed
        to the transformer. The embedding provider performs the real model-input
        limit check immediately before encoding.
        """
        value = str(text or "")
        common = {
            "add_special_tokens": bool(add_special_tokens),
            "padding": False,
            "truncation": False,
            "return_attention_mask": False,
            "return_token_type_ids": False,
        }

        # ``verbose=False`` is the supported Transformers control for suppressing
        # advisory warnings from deliberate no-truncation tokenization. Keep a
        # compatibility fallback for unusual/custom tokenizer implementations.
        try:
            encoded = self._tokenizer(value, verbose=False, **common)
            input_ids = encoded["input_ids"] if isinstance(encoded, dict) else encoded.input_ids
            return list(input_ids)
        except (TypeError, AttributeError, KeyError):
            try:
                return list(
                    self._tokenizer.encode(
                        value,
                        add_special_tokens=bool(add_special_tokens),
                        truncation=False,
                        verbose=False,
                    )
                )
            except TypeError:
                # Last-resort compatibility path. Modern Hugging Face tokenizers
                # take ``verbose``; custom tokenizers might not.
                return list(
                    self._tokenizer.encode(
                        value,
                        add_special_tokens=bool(add_special_tokens),
                        truncation=False,
                    )
                )

    def decode(self, tokens: Sequence[Any], skip_special_tokens: bool = True) -> str:
        return str(self._tokenizer.decode(list(tokens), skip_special_tokens=skip_special_tokens)).strip()


def _resolved_source(model_path: str | Path | None) -> str:
    if model_path:
        return str(model_path)
    configured = os.getenv("ERICSSON_CHUNK_TOKENIZER_PATH") or os.getenv("EMBEDDING_MODEL_PATH")
    return configured or "BAAI/bge-large-en-v1.5"


@lru_cache(maxsize=8)
def _load_codec_cached(source: str, local_files_only: bool) -> Any:
    try:
        from transformers import AutoTokenizer

        path = Path(source).expanduser()
        if local_files_only and not path.exists():
            # Do not trigger an accidental network request on production hosts
            # configured for local-only models.
            return RegexTokenCodec()
        tokenizer_source = str(path.resolve()) if path.exists() else source
        tokenizer = AutoTokenizer.from_pretrained(
            tokenizer_source,
            local_files_only=local_files_only,
            use_fast=True,
        )
        return HuggingFaceTokenCodec(tokenizer, tokenizer_source)
    except Exception:
        return RegexTokenCodec()


def get_token_codec(
    model_path: str | Path | None = None,
    *,
    local_files_only: bool = True,
) -> Any:
    """Return a cached reversible tokenizer for section child windows."""
    source = _resolved_source(model_path)
    return _load_codec_cached(source, bool(local_files_only))


def count_tokens(
    text: str,
    *,
    codec: Any | None = None,
    model_path: str | Path | None = None,
    local_files_only: bool = True,
    add_special_tokens: bool = False,
) -> int:
    active = codec or get_token_codec(model_path, local_files_only=local_files_only)
    return len(active.encode(str(text or ""), add_special_tokens=add_special_tokens))
