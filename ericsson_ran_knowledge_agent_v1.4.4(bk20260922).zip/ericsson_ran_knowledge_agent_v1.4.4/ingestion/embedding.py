"""Embedding providers for ingestion and query-time retrieval.

The production provider fails closed when an input is longer than the loaded
SentenceTransformer model can process. This prevents silent truncation from
creating incomplete Ericsson child vectors.
"""
from __future__ import annotations

import hashlib
import math
from pathlib import Path
from typing import Any, Dict, List, Optional, Protocol, Sequence


_MAX_REASONABLE_MODEL_LENGTH = 1_000_000


class Embedder(Protocol):
    @property
    def dimension(self) -> int: ...

    @property
    def name(self) -> str: ...

    def encode(self, texts: Sequence[str]) -> List[List[float]]: ...


class EmbeddingInputLengthError(ValueError):
    """Raised before model inference when one or more inputs would be truncated."""

    def __init__(
        self,
        *,
        max_input_tokens: int,
        violations: Sequence[Dict[str, Any]],
        total_violations: int,
    ) -> None:
        self.max_input_tokens = int(max_input_tokens)
        self.violations = [dict(value) for value in violations]
        self.total_violations = int(total_violations)
        details = "; ".join(
            f"{item.get('label') or 'input'}={item.get('token_count')} tokens"
            for item in self.violations[:5]
        )
        remainder = max(0, self.total_violations - len(self.violations[:5]))
        suffix = f"; and {remainder} more" if remainder else ""
        super().__init__(
            "Embedding input exceeds the model maximum and would be silently truncated: "
            f"limit={self.max_input_tokens}; {details}{suffix}. "
            "Reduce child/procedure size or metadata enrichment before rebuilding the index."
        )


def _finite_model_length(value: Any) -> Optional[int]:
    try:
        parsed = int(value)
    except (TypeError, ValueError, OverflowError):
        return None
    if parsed <= 0 or parsed >= _MAX_REASONABLE_MODEL_LENGTH:
        return None
    return parsed


def _tokenizer_input_ids(tokenizer: Any, text: str, *, add_special_tokens: bool = True) -> List[int]:
    """Return untruncated model input IDs without advisory length warnings."""
    value = str(text or "")
    common = {
        "add_special_tokens": bool(add_special_tokens),
        "padding": False,
        "truncation": False,
        "return_attention_mask": False,
        "return_token_type_ids": False,
    }
    try:
        encoded = tokenizer(value, verbose=False, **common)
        input_ids = encoded["input_ids"] if isinstance(encoded, dict) else encoded.input_ids
        return list(input_ids)
    except (TypeError, AttributeError, KeyError):
        try:
            return list(
                tokenizer.encode(
                    value,
                    add_special_tokens=bool(add_special_tokens),
                    truncation=False,
                    verbose=False,
                )
            )
        except TypeError:
            return list(
                tokenizer.encode(
                    value,
                    add_special_tokens=bool(add_special_tokens),
                    truncation=False,
                )
            )


def resolve_model_max_input_tokens(model: Any, tokenizer: Any, override: int = 0) -> int:
    """Resolve the effective input ceiling, preferring the strictest finite limit."""
    candidates = [
        _finite_model_length(getattr(model, "max_seq_length", None)),
        _finite_model_length(getattr(tokenizer, "model_max_length", None)),
    ]
    detected = [value for value in candidates if value is not None]
    detected_limit = min(detected) if detected else None

    override_value = _finite_model_length(override)
    if override_value is not None:
        if detected_limit is not None and override_value > detected_limit:
            raise ValueError(
                "EMBEDDING_MAX_INPUT_TOKENS cannot exceed the loaded model limit: "
                f"configured={override_value}, detected={detected_limit}"
            )
        return override_value

    if detected_limit is None:
        raise RuntimeError(
            "Could not determine a finite embedding model input limit. "
            "Set EMBEDDING_MAX_INPUT_TOKENS to the model-supported value."
        )
    return detected_limit


class SentenceTransformerEmbedder:
    def __init__(
        self,
        model_path: str | Path,
        *,
        device: str = "cpu",
        normalize: bool = True,
        local_files_only: bool = True,
        batch_size: int = 32,
        max_input_tokens: int = 0,
    ) -> None:
        from sentence_transformers import SentenceTransformer

        self.model_path = Path(model_path)
        if local_files_only and not self.model_path.is_dir():
            raise FileNotFoundError(
                f"Local embedding model directory not found: {self.model_path}. "
                "Point EMBEDDING_MODEL_PATH at the same local model used by the Nokia KB, "
                "or set LOCAL_FILES_ONLY=false on a connected staging host."
            )
        source = str(self.model_path) if self.model_path.exists() else str(model_path)
        try:
            self._model = SentenceTransformer(source, device=device, local_files_only=local_files_only)
            self._device = device
        except Exception:
            if device == "cpu":
                raise
            self._model = SentenceTransformer(source, device="cpu", local_files_only=local_files_only)
            self._device = "cpu"

        self._normalize = bool(normalize)
        self._batch_size = int(batch_size)
        self._tokenizer = getattr(self._model, "tokenizer", None)
        if self._tokenizer is None:
            raise RuntimeError(
                "The loaded SentenceTransformer does not expose its tokenizer; "
                "strict embedding-length validation cannot be performed."
            )

        # New Sentence Transformers releases expose get_embedding_dimension().
        # Retain the old method only as compatibility for older deployments.
        dimension_method = getattr(self._model, "get_embedding_dimension", None)
        if callable(dimension_method):
            dimension = dimension_method()
        else:
            legacy_method = getattr(self._model, "get_sentence_embedding_dimension", None)
            dimension = legacy_method() if callable(legacy_method) else None
        if not dimension:
            probe = self._model.encode(["dimension probe"], show_progress_bar=False)
            dimension = len(probe[0])

        self._dimension = int(dimension)
        self._name = source
        self._max_input_tokens = resolve_model_max_input_tokens(
            self._model,
            self._tokenizer,
            int(max_input_tokens or 0),
        )
        self._validated_input_count = 0
        self._largest_input_tokens = 0
        self._largest_input_label = ""

    @property
    def dimension(self) -> int:
        return self._dimension

    @property
    def name(self) -> str:
        return self._name

    @property
    def device(self) -> str:
        return self._device

    @property
    def max_input_tokens(self) -> int:
        return self._max_input_tokens

    @property
    def validated_input_count(self) -> int:
        return self._validated_input_count

    @property
    def largest_input_tokens(self) -> int:
        return self._largest_input_tokens

    @property
    def largest_input_label(self) -> str:
        return self._largest_input_label

    def count_input_tokens(self, text: str) -> int:
        # Special tokens are included because this is the actual model input.
        return len(_tokenizer_input_ids(self._tokenizer, str(text or ""), add_special_tokens=True))

    def validate_inputs(
        self,
        texts: Sequence[str],
        *,
        labels: Optional[Sequence[str]] = None,
    ) -> List[int]:
        if labels is not None and len(labels) != len(texts):
            raise ValueError("Embedding validation labels must match the number of texts")

        counts: List[int] = []
        violations: List[Dict[str, Any]] = []
        total_violations = 0
        for index, text in enumerate(texts):
            label = str(labels[index]) if labels is not None else f"input[{index}]"
            count = self.count_input_tokens(text)
            counts.append(count)
            self._validated_input_count += 1
            if count > self._largest_input_tokens:
                self._largest_input_tokens = count
                self._largest_input_label = label
            if count > self._max_input_tokens:
                total_violations += 1
                if len(violations) < 20:
                    violations.append({
                        "label": label,
                        "token_count": count,
                        "max_input_tokens": self._max_input_tokens,
                        "preview": str(text or "")[:240].replace("\n", " "),
                    })

        if total_violations:
            raise EmbeddingInputLengthError(
                max_input_tokens=self._max_input_tokens,
                violations=violations,
                total_violations=total_violations,
            )
        return counts

    def encode(self, texts: Sequence[str]) -> List[List[float]]:
        if not texts:
            return []
        # Defense in depth: callers cannot bypass the pre-ingestion audit and
        # accidentally rely on SentenceTransformer's silent truncation.
        self.validate_inputs(texts)
        vectors = self._model.encode(
            list(texts),
            batch_size=self._batch_size,
            normalize_embeddings=self._normalize,
            convert_to_numpy=True,
            show_progress_bar=False,
        )
        return [vector.astype(float).tolist() for vector in vectors]


class DeterministicHashEmbedder:
    """Small deterministic test embedder. Never use for production retrieval."""

    def __init__(self, dimension: int = 32) -> None:
        self._dimension = dimension

    @property
    def dimension(self) -> int:
        return self._dimension

    @property
    def name(self) -> str:
        return f"deterministic-hash-{self._dimension}"

    @property
    def max_input_tokens(self) -> int:
        # No transformer model is involved in this offline-only embedder.
        return 0

    def validate_inputs(
        self,
        texts: Sequence[str],
        *,
        labels: Optional[Sequence[str]] = None,
    ) -> List[int]:
        del labels
        return [0 for _ in texts]

    def encode(self, texts: Sequence[str]) -> List[List[float]]:
        out: List[List[float]] = []
        for text in texts:
            raw = bytearray()
            counter = 0
            while len(raw) < self._dimension * 4:
                raw.extend(hashlib.sha256(f"{counter}:{text}".encode("utf-8")).digest())
                counter += 1
            values = []
            for i in range(self._dimension):
                integer = int.from_bytes(raw[i * 4:(i + 1) * 4], "big", signed=False)
                values.append((integer / 2**31) - 1.0)
            norm = math.sqrt(sum(v * v for v in values)) or 1.0
            out.append([v / norm for v in values])
        return out
