"""Discover prepared Markdown and attach manifest metadata."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Iterator, List, Tuple

from agent_core.ids import find_feature_ids, find_package_ids, normalize_feature_id, normalize_package_id
from agent_core.settings import Settings

from .chunker import (
    build_child_chunks,
    build_manifest_fact_parents,
    build_parent_chunks,
)
from .manifest_loader import ManifestStore
from .models import ChildChunk, ParentChunk, PreparedDocument


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _as_list(value: Any) -> List[str]:
    if isinstance(value, list):
        values = value
    elif isinstance(value, (tuple, set)):
        values = list(value)
    elif value:
        values = [value]
    else:
        values = []
    out: List[str] = []
    for item in values:
        text = str(item or "").strip()
        if text and text not in out:
            out.append(text)
    return out


def _normalize_ids(values: List[str], normalizer) -> List[str]:
    out: List[str] = []
    for value in values:
        normalized = normalizer(value)
        if normalized and normalized not in out:
            out.append(normalized)
    return out


def _sidecar(path: Path) -> Dict[str, Any]:
    sidecar = path.with_name(path.name + ".metadata.json")
    if not sidecar.exists():
        return {}
    try:
        value = json.loads(sidecar.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            return {}
        # The preparation pipeline follows the Nokia sidecar contract and wraps
        # attributes in ``metadataAttributes``. Accept an unwrapped dictionary as
        # well so manually prepared corpora remain ingestible.
        wrapped = value.get("metadataAttributes")
        return dict(wrapped) if isinstance(wrapped, dict) else value
    except Exception:
        return {}


def _minimal_document_record(path: Path, markdown: str, settings: Settings) -> Dict[str, Any]:
    sidecar = _sidecar(path)
    title = str(sidecar.get("title") or path.stem)
    owner = normalize_feature_id(str(sidecar.get("owner_feature_id") or sidecar.get("feature_id") or ""))
    doc_role = str(sidecar.get("doc_role") or ("feature_document" if owner else "general_document"))
    discovered_feature_ids = find_feature_ids(markdown)
    explicit_feature_ids = _normalize_ids(_as_list(sidecar.get("feature_ids")), normalize_feature_id)
    explicit_included_ids = _normalize_ids(_as_list(sidecar.get("included_feature_ids")), normalize_feature_id)
    explicit_mentioned_ids = _normalize_ids(_as_list(sidecar.get("mentioned_feature_ids")), normalize_feature_id)
    explicit_related_ids = _normalize_ids(_as_list(sidecar.get("related_feature_ids")), normalize_feature_id)

    if owner:
        feature_ids = list(dict.fromkeys([owner] + explicit_feature_ids))
        included_feature_ids = explicit_included_ids
        mentioned_feature_ids = list(
            dict.fromkeys(
                explicit_mentioned_ids
                + [value for value in discovered_feature_ids if value != owner and value not in explicit_related_ids]
            )
        )
    elif doc_role == "package_document":
        feature_ids = list(dict.fromkeys(explicit_feature_ids + explicit_included_ids + discovered_feature_ids))
        included_feature_ids = list(dict.fromkeys(explicit_included_ids + feature_ids))
        mentioned_feature_ids = explicit_mentioned_ids
    else:
        # General documents can mention a Feature Identity without owning or
        # including it. Keep the direct feature fields empty in the manifest
        # fallback so they cannot be mistaken for Feature Descriptions.
        feature_ids = []
        included_feature_ids = []
        mentioned_feature_ids = list(
            dict.fromkeys(
                explicit_mentioned_ids
                + explicit_feature_ids
                + explicit_included_ids
                + [value for value in discovered_feature_ids if value not in explicit_related_ids]
            )
        )

    explicit_package_ids = _normalize_ids(_as_list(sidecar.get("package_ids")), normalize_package_id)
    package_ids = explicit_package_ids
    if doc_role in {"feature_document", "package_document"} and not package_ids:
        package_ids = find_package_ids(markdown)
    return {
        "record_kind": "document",
        "manifest_stage": "document",
        "record_id": f"{path.name}#document",
        "vendor": settings.vendor,
        "corpus_id": settings.corpus_id,
        "filename": path.name,
        "source_markdown": path.name,
        "source_pdf": str(sidecar.get("source_pdf") or ""),
        "title": title,
        "doc_type": str(sidecar.get("doc_type") or "general_document"),
        "doc_role": doc_role,
        "feature_id": owner,
        "primary_feature_id": owner,
        "owner_feature_id": owner,
        "feature_ids": feature_ids,
        "included_feature_ids": included_feature_ids,
        "mentioned_feature_ids": mentioned_feature_ids,
        "related_feature_ids": explicit_related_ids,
        "feature_title": str(sidecar.get("feature_title") or (title if owner else "")),
        "package_id": str(sidecar.get("package_id") or ""),
        "primary_package_id": str(sidecar.get("primary_package_id") or ""),
        "package_ids": package_ids,
        "package_names": _as_list(sidecar.get("package_names")),
        "access_types": _as_list(sidecar.get("access_types")),
        "node_types": _as_list(sidecar.get("node_types")),
        "licensing": str(sidecar.get("licensing") or ""),
        "topics": str(sidecar.get("topics") or title),
        "topic_aliases": _as_list(sidecar.get("topic_aliases")),
        "content_retrievable": True,
        "page_start": int(sidecar.get("page_start") or 1),
        "page_end": int(sidecar.get("page_end") or 1),
    }


def load_prepared_documents(settings: Settings, manifest_store: ManifestStore) -> List[PreparedDocument]:
    if not settings.markdown_root.exists():
        raise FileNotFoundError(f"Markdown root not found: {settings.markdown_root}")
    docs: List[PreparedDocument] = []
    for path in sorted(settings.markdown_root.glob("*.md")):
        markdown = path.read_text(encoding="utf-8")
        document_record = manifest_store.document(path.name)
        if not document_record:
            document_record = _minimal_document_record(path, markdown, settings)
        document_record = dict(document_record)
        document_record["vendor"] = settings.vendor
        document_record["corpus_id"] = settings.corpus_id
        document_record["filename"] = path.name
        document_record.setdefault("source_markdown", path.name)
        docs.append(PreparedDocument(
            markdown_path=path,
            filename=path.name,
            title=str(document_record.get("title") or path.stem),
            source_sha256=file_sha256(path),
            document_record=document_record,
            section_records=manifest_store.sections(path.name),
            fact_records=manifest_store.facts(path.name),
            relationship_records=manifest_store.relationships(path.name),
        ))
    if not docs:
        raise ValueError(f"No Markdown files found in {settings.markdown_root}")
    return docs


def build_parents_for_document(
    document: PreparedDocument,
    manifest_store: ManifestStore,
    settings: Settings,
) -> List[ParentChunk]:
    """Build Markdown-section and manifest-fact parents for one document."""
    markdown = document.markdown_path.read_text(encoding="utf-8")
    parents = build_parent_chunks(
        document.filename,
        document.title,
        markdown,
        document.document_record,
        manifest_store,
        settings,
        document.source_sha256,
    )
    parents.extend(build_manifest_fact_parents(
        document.filename,
        document.title,
        document.document_record,
        document.fact_records,
        settings,
        document.source_sha256,
    ))
    return parents


def build_parent_child_for_document(
    document: PreparedDocument,
    manifest_store: ManifestStore,
    settings: Settings,
) -> Tuple[List[ParentChunk], List[ChildChunk]]:
    """Return separately stored parents and separately embedded children."""
    parents = build_parents_for_document(document, manifest_store, settings)
    return parents, build_child_chunks(parents, settings)


def build_chunks_for_document(
    document: PreparedDocument,
    manifest_store: ManifestStore,
    settings: Settings,
) -> List[ChildChunk]:
    """Compatibility wrapper returning only children, as in agent v1.0."""
    _parents, children = build_parent_child_for_document(document, manifest_store, settings)
    return children


def graph_staging_records(documents: List[PreparedDocument]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for document in documents:
        for record in document.relationship_records:
            if str(record.get("record_kind", "")) in {"package_feature", "relationship"}:
                enriched = dict(record)
                enriched.setdefault("vendor", "Ericsson")
                enriched.setdefault("source_markdown", document.filename)
                out.append(enriched)
    return out
