"""OpenSearch mappings for Ericsson child vectors and stored parents."""
from __future__ import annotations

from typing import Any, Dict

from agent_core.settings import Settings


def _common_properties() -> Dict[str, Any]:
    return {
        "doc_id": {"type": "keyword"},
        "storage_role": {"type": "keyword"},
        "retrieval_contract": {"type": "keyword"},
        "content_sha256": {"type": "keyword"},
        "parent_content_sha256": {"type": "keyword"},
        "child_content_sha256": {"type": "keyword"},
        "embedding_input_mode": {"type": "keyword"},
        "embedding_token_count": {"type": "integer"},
        "embedding_model_max_tokens": {"type": "integer"},
        "embedding_truncated": {"type": "boolean"},
        "vendor": {"type": "keyword"},
        "corpus_id": {"type": "keyword"},
        "filename": {"type": "keyword"},
        "source_markdown": {"type": "keyword"},
        "source_pdf": {"type": "keyword"},
        "title": {"type": "text", "fields": {"keyword": {"type": "keyword", "ignore_above": 512}}},
        "heading": {"type": "text", "fields": {"keyword": {"type": "keyword", "ignore_above": 512}}},
        "heading_number": {"type": "keyword"},
        "heading_level": {"type": "integer"},
        "heading_path": {"type": "text", "fields": {"keyword": {"type": "keyword", "ignore_above": 2048}}},
        "topics": {"type": "text"},
        "question_templates": {"type": "text"},
        "doc_type": {"type": "keyword"},
        "doc_role": {"type": "keyword"},
        "feature_id": {"type": "keyword"},
        "primary_feature_id": {"type": "keyword"},
        "owner_feature_id": {"type": "keyword"},
        "feature_ids": {"type": "keyword"},
        "included_feature_ids": {"type": "keyword"},
        "mentioned_feature_ids": {"type": "keyword"},
        "related_feature_ids": {"type": "keyword"},
        "feature_title": {"type": "text", "fields": {"keyword": {"type": "keyword", "ignore_above": 512}}},
        "package_id": {"type": "keyword"},
        "primary_package_id": {"type": "keyword"},
        "package_ids": {"type": "keyword"},
        "package_names": {"type": "keyword", "ignore_above": 512},
        "access_types": {"type": "keyword"},
        "node_types": {"type": "keyword", "ignore_above": 512},
        "licensing": {"type": "text"},
        "topic_aliases": {"type": "keyword"},
        "section_type": {"type": "keyword"},
        "feature_association": {"type": "keyword"},
        "record_kind": {"type": "keyword"},
        "chunk_kind": {"type": "keyword"},
        "manifest_record_id": {"type": "keyword"},
        "source_sha256": {"type": "keyword"},
        "ingestion_run_id": {"type": "keyword"},
        "schema_version": {"type": "keyword"},
        "image_paths": {"type": "keyword", "ignore_above": 2048},
        "prerequisites": {"type": "keyword", "ignore_above": 1024},
        "restriction_status": {"type": "text"},
        "page_start": {"type": "integer"},
        "page_end": {"type": "integer"},
        "parent_page_start": {"type": "integer"},
        "parent_page_end": {"type": "integer"},
        "parent_order": {"type": "integer"},
        "parent_strategy": {"type": "keyword"},
        "parent_token_count": {"type": "integer"},
        "parent_soft_limit": {"type": "integer"},
        "parent_exceeds_soft_limit": {"type": "boolean"},
        "chunk_tokenizer": {"type": "keyword", "ignore_above": 1024},
        "manifest_priority": {"type": "integer"},
        "ingested_at": {"type": "date"},
    }


def child_index_body(settings: Settings, dimension: int) -> Dict[str, Any]:
    """Search index: child text and embedding only; no duplicated parent text."""
    properties = _common_properties()
    properties.update({
        "content": {"type": "text"},
        "embedding_text": {"type": "text", "index": False},
        "embedding": {
            "type": "knn_vector",
            "dimension": dimension,
            "data_type": "float",
            "method": {
                "name": "hnsw",
                "engine": settings.vector_engine,
                "space_type": settings.vector_space_type,
                "parameters": {
                    "ef_construction": settings.hnsw_ef_construction,
                    "m": settings.hnsw_m,
                },
            },
        },
        "chunk_id": {"type": "keyword"},
        "child_order": {"type": "integer"},
        "token_count": {"type": "integer"},
        "below_minimum_chunk_tokens": {"type": "boolean"},
        "child_window_tokens": {"type": "integer"},
        "child_overlap_tokens": {"type": "integer"},
        "parent_id": {"type": "keyword"},
        # Physical parent OpenSearch ID. It differs from parent_id during a safe
        # incremental replacement run and is the value used for mget.
        "parent_storage_id": {"type": "keyword"},
    })
    return {
        "settings": {
            "index": {
                "knn": True,
                "knn.algo_param.ef_search": settings.knn_ef_search,
                "number_of_shards": settings.index_shards,
                "number_of_replicas": settings.index_replicas,
                "refresh_interval": "30s",
            }
        },
        "mappings": {"dynamic": True, "properties": properties},
    }


def parent_index_body(settings: Settings) -> Dict[str, Any]:
    """Context index: each complete section is stored once, without a vector."""
    properties = _common_properties()
    properties.update({
        "content": {"type": "text"},
        "parent_id": {"type": "keyword"},
        "parent_storage_id": {"type": "keyword"},
    })
    return {
        "settings": {
            "index": {
                "number_of_shards": settings.index_shards,
                "number_of_replicas": settings.index_replicas,
                "refresh_interval": "30s",
            }
        },
        "mappings": {"dynamic": True, "properties": properties},
    }


def chunk_index_body(settings: Settings, dimension: int) -> Dict[str, Any]:
    """Backward-compatible alias for the child mapping."""
    return child_index_body(settings, dimension)
