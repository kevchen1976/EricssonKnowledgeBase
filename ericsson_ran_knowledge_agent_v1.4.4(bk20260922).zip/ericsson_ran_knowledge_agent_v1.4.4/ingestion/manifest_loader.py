"""Load and index the Ericsson combined JSONL manifest."""
from __future__ import annotations

import json
import re
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from agent_core.ids import normalize_feature_id, normalize_package_id


def _norm(value: str) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip().casefold()


def _read_jsonl(path: Path) -> List[Dict[str, Any]]:
    records: List[Dict[str, Any]] = []
    if not path.exists():
        return records
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            line = line.strip()
            if not line:
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSONL at {path}:{line_no}: {exc}") from exc
            if isinstance(value, dict):
                records.append(value)
    return records


def _normalize_record(record: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(record)
    if out.get("feature_id"):
        out["feature_id"] = normalize_feature_id(str(out["feature_id"])) or str(out["feature_id"])
    if out.get("owner_feature_id"):
        out["owner_feature_id"] = normalize_feature_id(str(out["owner_feature_id"])) or str(out["owner_feature_id"])
    if out.get("package_id"):
        out["package_id"] = normalize_package_id(str(out["package_id"])) or str(out["package_id"])
    for key, normalizer in (
        ("feature_ids", normalize_feature_id),
        ("included_feature_ids", normalize_feature_id),
        ("mentioned_feature_ids", normalize_feature_id),
        ("related_feature_ids", normalize_feature_id),
        ("package_ids", normalize_package_id),
    ):
        values = out.get(key, [])
        if not isinstance(values, list):
            values = [values] if values else []
        clean: List[str] = []
        for value in values:
            normalized = normalizer(str(value))
            if normalized and normalized not in clean:
                clean.append(normalized)
        out[key] = clean
    return out


@dataclass
class ManifestStore:
    records: List[Dict[str, Any]]
    documents_by_filename: Dict[str, Dict[str, Any]]
    sections_by_filename: Dict[str, List[Dict[str, Any]]]
    facts_by_filename: Dict[str, List[Dict[str, Any]]]
    relationships_by_filename: Dict[str, List[Dict[str, Any]]]

    @classmethod
    def load(cls, path: Path) -> "ManifestStore":
        records = [_normalize_record(r) for r in _read_jsonl(path)]
        documents: Dict[str, Dict[str, Any]] = {}
        sections: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        facts: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        relationships: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        for record in records:
            filename = str(record.get("filename") or record.get("source_markdown") or "").strip()
            if not filename:
                continue
            kind = str(record.get("record_kind") or record.get("manifest_stage") or "").strip()
            if kind == "document":
                documents[filename] = record
            elif kind == "section":
                sections[filename].append(record)
            elif kind == "fact":
                facts[filename].append(record)
            else:
                relationships[filename].append(record)
        for bucket in (sections, facts, relationships):
            for filename in bucket:
                bucket[filename].sort(key=lambda r: (
                    int(r.get("section_order") or 0),
                    str(r.get("record_id") or ""),
                ))
        return cls(records, documents, dict(sections), dict(facts), dict(relationships))

    def document(self, filename: str) -> Dict[str, Any]:
        return dict(self.documents_by_filename.get(filename, {}))

    def sections(self, filename: str) -> List[Dict[str, Any]]:
        return [dict(x) for x in self.sections_by_filename.get(filename, [])]

    def facts(self, filename: str) -> List[Dict[str, Any]]:
        return [dict(x) for x in self.facts_by_filename.get(filename, [])]

    def relationships(self, filename: str) -> List[Dict[str, Any]]:
        return [dict(x) for x in self.relationships_by_filename.get(filename, [])]

    def match_section(self, filename: str, heading: str, heading_path: str) -> Dict[str, Any]:
        candidates = self.sections_by_filename.get(filename, [])
        hp = _norm(heading_path)
        h = _norm(heading)
        for record in candidates:
            if hp and _norm(str(record.get("heading_path", ""))) == hp:
                return dict(record)
        for record in candidates:
            if h and _norm(str(record.get("section_heading", ""))) == h:
                return dict(record)
        # Fallback for extractors that altered heading numbers or whitespace.
        for record in candidates:
            rh = _norm(str(record.get("section_heading", "")))
            if h and (h in rh or rh in h):
                return dict(record)
        return {}

    def document_records(self) -> Iterable[Dict[str, Any]]:
        return self.documents_by_filename.values()
