from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List

from agent_core.constants import CHILD_STORAGE_ROLE, PARENT_CHILD_CONTRACT, PARENT_STORAGE_ROLE


@dataclass
class MarkdownBlock:
    text: str
    page_start: int
    page_end: int
    kind: str = "paragraph"


@dataclass
class MarkdownSection:
    order: int
    heading: str
    heading_path: str
    level: int
    page_start: int
    page_end: int
    blocks: List[MarkdownBlock] = field(default_factory=list)
    heading_number: str = ""

    @property
    def text(self) -> str:
        body = "\n\n".join(block.text.strip() for block in self.blocks if block.text.strip())
        if self.heading:
            return f"{'#' * max(1, min(6, self.level))} {self.heading}\n\n{body}".strip()
        return body.strip()


@dataclass
class ParentChunk:
    parent_id: str
    filename: str
    title: str
    heading: str
    heading_path: str
    section_type: str
    feature_association: str
    page_start: int
    page_end: int
    content: str
    image_paths: List[str]
    metadata: Dict[str, Any]
    parent_order: int
    blocks: List[MarkdownBlock] = field(default_factory=list)

    def to_source(self) -> Dict[str, Any]:
        """Return the parent OpenSearch source.

        Parent records intentionally contain the complete semantic section once
        and never contain an embedding.  Child records reference this document by
        ``parent_storage_id`` after ingestion assigns the physical OpenSearch ID.
        """
        source = dict(self.metadata)
        source.pop("embedding", None)
        source.pop("embedding_text", None)
        source.pop("parent_content", None)
        source.update({
            "storage_role": PARENT_STORAGE_ROLE,
            "retrieval_contract": PARENT_CHILD_CONTRACT,
            "content_sha256": hashlib.sha256(self.content.encode("utf-8")).hexdigest(),
            "doc_id": self.parent_id,
            "parent_id": self.parent_id,
            "content": self.content,
            "filename": self.filename,
            "title": self.title,
            "heading": self.heading,
            "heading_path": self.heading_path,
            "section_type": self.section_type,
            "feature_association": self.feature_association,
            "page_start": self.page_start,
            "page_end": self.page_end,
            "parent_order": self.parent_order,
            "image_paths": list(self.image_paths),
        })
        return source


@dataclass
class ChildChunk:
    chunk_id: str
    parent_id: str
    content: str
    embedding_text: str
    page_start: int
    page_end: int
    child_order: int
    token_count: int
    metadata: Dict[str, Any]

    def to_source(self, embedding: List[float] | None = None) -> Dict[str, Any]:
        """Return the searchable child source without duplicating parent text."""
        source = dict(self.metadata)
        # Fail closed if an older caller supplied the legacy duplicated field.
        source.pop("parent_content", None)
        source.update({
            "storage_role": CHILD_STORAGE_ROLE,
            "retrieval_contract": PARENT_CHILD_CONTRACT,
            "child_content_sha256": hashlib.sha256(self.content.encode("utf-8")).hexdigest(),
            "doc_id": self.chunk_id,
            "chunk_id": self.chunk_id,
            "parent_id": self.parent_id,
            "content": self.content,
            "embedding_text": self.embedding_text,
            "page_start": self.page_start,
            "page_end": self.page_end,
            "child_order": self.child_order,
            "token_count": self.token_count,
        })
        if embedding is not None:
            source["embedding"] = embedding
        return source


@dataclass
class PreparedDocument:
    markdown_path: Path
    filename: str
    title: str
    source_sha256: str
    document_record: Dict[str, Any]
    section_records: List[Dict[str, Any]]
    fact_records: List[Dict[str, Any]]
    relationship_records: List[Dict[str, Any]]
