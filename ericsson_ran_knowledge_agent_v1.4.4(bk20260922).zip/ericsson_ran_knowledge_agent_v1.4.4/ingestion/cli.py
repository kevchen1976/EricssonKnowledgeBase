from __future__ import annotations

import argparse
import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from agent_core.settings import get_settings

from .embedding import DeterministicHashEmbedder
from .pipeline import make_embedder, run_ingestion, settings_for_prepared_root


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Chunk Ericsson Markdown/manifests and ingest them into Ericsson-only OpenSearch indexes."
    )
    parser.add_argument("--prepared-root", type=Path, required=True, help="Output directory produced by the Ericsson preparation pipeline")
    parser.add_argument("--manifest", type=Path, default=None, help="Optional combined_manifest.jsonl override")
    parser.add_argument("--mode", choices=["dry-run", "rebuild", "incremental"], default="dry-run")
    parser.add_argument("--version", default=datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S"), help="Backing-index version token for rebuild mode")
    parser.add_argument("--preview-dir", type=Path, default=None)
    parser.add_argument("--skip-embeddings", action="store_true", help="Only valid for dry-run; writes chunks without vectors")
    parser.add_argument("--test-embedder", action="store_true", help="Use a deterministic 32-dimensional test vector; never use for production")
    parser.add_argument("--bulk-chunk-size", type=int, default=250)
    parser.add_argument("--delete-old", action="store_true", help="After a successful alias switch, delete previous Ericsson backing indexes")
    parser.add_argument("--log-level", default="INFO")
    return parser


def main(argv=None) -> int:
    args = _parser().parse_args(argv)
    logging.basicConfig(level=getattr(logging, args.log_level.upper(), logging.INFO), format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    settings = settings_for_prepared_root(get_settings(), args.prepared_root, args.manifest)
    if args.skip_embeddings and args.mode != "dry-run":
        raise SystemExit("--skip-embeddings can only be used with --mode dry-run")
    if args.test_embedder and args.mode != "dry-run":
        raise SystemExit("--test-embedder can only be used with --mode dry-run")
    if args.delete_old and args.mode != "rebuild":
        raise SystemExit("--delete-old can only be used with --mode rebuild")
    if args.test_embedder:
        embedder = DeterministicHashEmbedder(32)
    elif args.skip_embeddings:
        embedder = None
    else:
        embedder = make_embedder(settings)
    report = run_ingestion(
        settings,
        mode=args.mode,
        version=args.version,
        embedder=embedder,
        preview_dir=args.preview_dir,
        bulk_chunk_size=args.bulk_chunk_size,
        delete_old=args.delete_old,
    )
    print(json.dumps(report.to_dict(), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
