"""End-to-end Ericsson parent-child OpenSearch ingestion with filesystem manifests.

Nokia parity: combined/routing manifests are read from prepared JSONL files and
are not copied into a dedicated OpenSearch index.
"""
from __future__ import annotations

import hashlib
import json
import logging
import uuid
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

from agent_core.constants import PARENT_CHILD_CONTRACT, RETRIEVAL_SCHEMA
from agent_core.settings import Settings

from .embedding import EmbeddingInputLengthError, Embedder, SentenceTransformerEmbedder
from .index_schema import child_index_body, parent_index_body
from .manifest_loader import ManifestStore
from .models import ChildChunk, ParentChunk, PreparedDocument
from .opensearch_store import (
    backing_names,
    bulk_index,
    create_index,
    delete_by_run_id,
    delete_stale_by_filenames,
    make_client,
    refresh,
    remove_indices,
    resolve_write_index,
    switch_aliases_atomic,
    validate_index_configuration,
    validate_index_name,
    vector_dimension,
)
from .prepared_loader import (
    build_parent_child_for_document,
    build_parents_for_document,
    graph_staging_records,
    load_prepared_documents,
)

logger = logging.getLogger(__name__)
SCHEMA_VERSION = RETRIEVAL_SCHEMA


@dataclass
class IngestionReport:
    mode: str
    run_id: str
    prepared_root: str
    markdown_documents: int
    parents_indexed: int
    children_indexed: int
    parent_index: str
    child_index: str
    parent_alias: str
    child_alias: str
    embedding_model: str
    embedding_dimension: int
    manifest_storage: str = "filesystem_jsonl"
    embedding_model_max_tokens: int = 0
    embedding_inputs_checked: int = 0
    largest_embedding_input_tokens: int = 0
    largest_embedding_input_label: str = ""
    embedding_inputs_over_limit: int = 0
    deleted_parents: int = 0
    deleted_children: int = 0
    failures: int = 0
    old_parent_indices: List[str] = field(default_factory=list)
    old_child_indices: List[str] = field(default_factory=list)
    preview_directory: str = ""

    @property
    def chunks_indexed(self) -> int:
        """Backward-compatible metric: searchable chunks are child records."""
        return self.children_indexed

    @property
    def chunk_index(self) -> str:
        return self.child_index

    @property
    def chunk_alias(self) -> str:
        return self.child_alias

    def to_dict(self) -> Dict[str, Any]:
        value = asdict(self)
        value.update({
            "chunks_indexed": self.children_indexed,
            "chunk_index": self.child_index,
            "chunk_alias": self.child_alias,
        })
        return value


def settings_for_prepared_root(settings: Settings, prepared_root: Path, combined_manifest: Optional[Path] = None) -> Settings:
    prepared_root = prepared_root.expanduser().resolve()
    return replace(
        settings,
        prepared_root=prepared_root,
        markdown_root=(prepared_root / "markdown").resolve(),
        combined_manifest=(combined_manifest or prepared_root / "combined_manifest.jsonl").expanduser().resolve(),
        feature_manifest_root=(prepared_root / "routing-manifest/by-feature-id").resolve(),
        package_manifest_root=(prepared_root / "routing-manifest/by-package-id").resolve(),
        topic_manifest_root=(prepared_root / "routing-manifest/by-topic").resolve(),
        mentioned_feature_manifest_root=(prepared_root / "routing-manifest/by-mentioned-feature-id").resolve(),
    )


def make_embedder(settings: Settings) -> SentenceTransformerEmbedder:
    return SentenceTransformerEmbedder(
        settings.embedding_model_path,
        device=settings.embedding_device,
        normalize=settings.embedding_normalize,
        local_files_only=settings.local_files_only,
        batch_size=settings.embedding_batch_size,
        max_input_tokens=settings.embedding_max_input_tokens,
    )


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _incremental_physical_id(run_id: str, logical_id: str) -> str:
    value = f"{str(run_id).strip()}\x1f{str(logical_id).strip()}"
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _physical_parent_id(parent_id: str, run_id: str, *, incremental: bool) -> str:
    return _incremental_physical_id(run_id, parent_id) if incremental else parent_id


def _iter_parents(
    documents: Sequence[PreparedDocument],
    store: ManifestStore,
    settings: Settings,
) -> Iterator[ParentChunk]:
    for document in documents:
        parents = build_parents_for_document(document, store, settings)
        if not parents:
            logger.warning("No parents generated for %s", document.filename)
        yield from parents


def _iter_children(
    documents: Sequence[PreparedDocument],
    store: ManifestStore,
    settings: Settings,
) -> Iterator[ChildChunk]:
    for document in documents:
        _parents, children = build_parent_child_for_document(document, store, settings)
        if not children:
            logger.warning("No children generated for %s", document.filename)
        yield from children


@dataclass
class EmbeddingPreflightReport:
    inputs_checked: int = 0
    model_max_tokens: int = 0
    largest_input_tokens: int = 0
    largest_input_label: str = ""
    over_limit_inputs: int = 0


def _embedding_input_label(chunk: ChildChunk) -> str:
    filename = str(chunk.metadata.get("filename") or "unknown-document")
    heading = str(chunk.metadata.get("heading_path") or chunk.metadata.get("heading") or "unknown-section")
    return f"{filename} :: {heading} :: child {chunk.child_order} :: {chunk.chunk_id}"


def preflight_embedding_inputs(
    documents: Sequence[PreparedDocument],
    store: ManifestStore,
    settings: Settings,
    embedder: Embedder,
    *,
    batch_size: int = 512,
) -> EmbeddingPreflightReport:
    """Validate final child embedding inputs before any OpenSearch write.

    Parent sections are intentionally allowed to exceed the transformer limit;
    only the final child ``embedding_text`` values are checked. Production
    SentenceTransformer ingestion therefore cannot silently truncate content.
    """
    report = EmbeddingPreflightReport(
        model_max_tokens=int(getattr(embedder, "max_input_tokens", 0) or 0),
    )
    validator = getattr(embedder, "validate_inputs", None)
    if not callable(validator) or report.model_max_tokens <= 0:
        logger.warning(
            "Embedding provider %s does not expose a finite model-input guard; "
            "preflight token validation was skipped.",
            getattr(embedder, "name", type(embedder).__name__),
        )
        return report

    pending: List[ChildChunk] = []

    def validate_batch(values: List[ChildChunk]) -> None:
        if not values:
            return
        texts = [chunk.embedding_text for chunk in values]
        labels = [_embedding_input_label(chunk) for chunk in values]
        counts = validator(texts, labels=labels)
        report.inputs_checked += len(values)
        for label, count in zip(labels, counts):
            count_value = int(count)
            if count_value > report.largest_input_tokens:
                report.largest_input_tokens = count_value
                report.largest_input_label = label

    try:
        for child in _iter_children(documents, store, settings):
            pending.append(child)
            if len(pending) >= max(1, int(batch_size)):
                validate_batch(pending)
                pending = []
        validate_batch(pending)
    except EmbeddingInputLengthError as exc:
        report.over_limit_inputs = exc.total_violations
        raise

    logger.info(
        "Embedding preflight passed: inputs=%d largest=%d model_max=%d largest_input=%s",
        report.inputs_checked,
        report.largest_input_tokens,
        report.model_max_tokens,
        report.largest_input_label or "n/a",
    )
    return report


def _parent_sources(
    parents: Iterable[ParentChunk],
    *,
    run_id: str,
    ingested_at: str,
    settings: Settings,
    incremental: bool,
) -> Iterator[Tuple[str, Dict[str, Any]]]:
    for parent in parents:
        storage_id = _physical_parent_id(parent.parent_id, run_id, incremental=incremental)
        source = parent.to_source()
        source.update({
            "parent_storage_id": storage_id,
            "vendor": settings.vendor,
            "corpus_id": settings.corpus_id,
            "ingestion_run_id": run_id,
            "ingested_at": ingested_at,
            "schema_version": SCHEMA_VERSION,
        })
        yield storage_id, source


def _child_sources(
    children: Iterable[ChildChunk],
    embedder: Embedder,
    *,
    run_id: str,
    ingested_at: str,
    settings: Settings,
    incremental: bool,
) -> Iterator[Tuple[str, Dict[str, Any]]]:
    batch: List[ChildChunk] = []

    def emit(values: List[ChildChunk]) -> Iterator[Tuple[str, Dict[str, Any]]]:
        texts = [chunk.embedding_text for chunk in values]
        labels = [_embedding_input_label(chunk) for chunk in values]
        validator = getattr(embedder, "validate_inputs", None)
        token_counts = validator(texts, labels=labels) if callable(validator) else [0] * len(values)
        vectors = embedder.encode(texts)
        if len(vectors) != len(values):
            raise RuntimeError("Embedding provider returned the wrong number of vectors")
        for chunk, vector, embedding_token_count in zip(values, vectors, token_counts):
            storage_id = _physical_parent_id(chunk.parent_id, run_id, incremental=incremental)
            source = chunk.to_source(vector)
            # Fail closed if a v1.0 caller included legacy duplicated context.
            source.pop("parent_content", None)
            source.update({
                "parent_storage_id": storage_id,
                "vendor": settings.vendor,
                "corpus_id": settings.corpus_id,
                "ingestion_run_id": run_id,
                "ingested_at": ingested_at,
                "schema_version": SCHEMA_VERSION,
                "embedding_model": embedder.name,
                "embedding_token_count": int(embedding_token_count),
                "embedding_model_max_tokens": int(getattr(embedder, "max_input_tokens", 0) or 0),
                "embedding_truncated": False,
            })
            physical_id = _incremental_physical_id(run_id, chunk.chunk_id) if incremental else chunk.chunk_id
            yield physical_id, source

    for chunk in children:
        batch.append(chunk)
        if len(batch) >= settings.embedding_batch_size:
            yield from emit(batch)
            batch = []
    if batch:
        yield from emit(batch)


def _child_sources_without_embeddings(
    children: Iterable[ChildChunk],
    *,
    run_id: str,
    ingested_at: str,
    settings: Settings,
) -> Iterator[Tuple[str, Dict[str, Any]]]:
    for child in children:
        source = child.to_source(None)
        source.pop("parent_content", None)
        source.update({
            "parent_storage_id": child.parent_id,
            "vendor": settings.vendor,
            "corpus_id": settings.corpus_id,
            "ingestion_run_id": run_id,
            "ingested_at": ingested_at,
            "schema_version": SCHEMA_VERSION,
            "embedding_model": "not-generated",
        })
        yield child.chunk_id, source


def _write_jsonl(path: Path, records: Iterable[Dict[str, Any]]) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with path.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
            count += 1
    return count


def write_preview(
    output_dir: Path,
    documents: Sequence[PreparedDocument],
    store: ManifestStore,
    settings: Settings,
    *,
    embedder: Optional[Embedder] = None,
) -> Tuple[int, int]:
    """Write separate parent/child preview streams without touching OpenSearch."""
    output_dir.mkdir(parents=True, exist_ok=True)
    parents_path = output_dir / "parents.jsonl"
    children_path = output_dir / "children.jsonl"
    graph_path = output_dir / "graph_staging_relationships.jsonl"
    run_id = "preview"
    ingested_at = _utc_now()

    parent_count = _write_jsonl(
        parents_path,
        (
            {"_id": doc_id, "_source": source}
            for doc_id, source in _parent_sources(
                _iter_parents(documents, store, settings),
                run_id=run_id,
                ingested_at=ingested_at,
                settings=settings,
                incremental=False,
            )
        ),
    )

    children = _iter_children(documents, store, settings)
    if embedder is None:
        child_sources = _child_sources_without_embeddings(
            children,
            run_id=run_id,
            ingested_at=ingested_at,
            settings=settings,
        )
    else:
        child_sources = _child_sources(
            children,
            embedder,
            run_id=run_id,
            ingested_at=ingested_at,
            settings=settings,
            incremental=False,
        )
    child_count = _write_jsonl(
        children_path,
        ({"_id": doc_id, "_source": source} for doc_id, source in child_sources),
    )

    _write_jsonl(graph_path, graph_staging_records(list(documents)))
    return parent_count, child_count


def run_ingestion(
    settings: Settings,
    *,
    mode: str,
    version: str,
    embedder: Optional[Embedder] = None,
    preview_dir: Optional[Path] = None,
    bulk_chunk_size: int = 250,
    delete_old: bool = False,
) -> IngestionReport:
    mode = mode.lower().strip()
    if mode not in {"dry-run", "rebuild", "incremental"}:
        raise ValueError("mode must be one of: dry-run, rebuild, incremental")

    validate_index_configuration(settings)
    store = ManifestStore.load(settings.combined_manifest)
    documents = load_prepared_documents(settings, store)
    run_id = str(uuid.uuid4())
    ingested_at = _utc_now()

    if mode == "dry-run":
        destination = (preview_dir or settings.prepared_root / "ingestion-preview").resolve()
        parent_count, child_count = write_preview(
            destination,
            documents,
            store,
            settings,
            embedder=embedder,
        )
        return IngestionReport(
            mode=mode,
            run_id=run_id,
            prepared_root=str(settings.prepared_root),
            markdown_documents=len(documents),
            parents_indexed=parent_count,
            children_indexed=child_count,
            parent_index="",
            child_index="",
            parent_alias=settings.parent_alias,
            child_alias=settings.child_alias,
            embedding_model=embedder.name if embedder else "not-generated",
            embedding_dimension=embedder.dimension if embedder else 0,
            preview_directory=str(destination),
        )

    if embedder is None:
        embedder = make_embedder(settings)

    try:
        embedding_preflight = preflight_embedding_inputs(documents, store, settings, embedder)
    except EmbeddingInputLengthError as exc:
        failure_path = settings.logs_dir / f"embedding_preflight_failure_{run_id}.json"
        failure_path.parent.mkdir(parents=True, exist_ok=True)
        failure_path.write_text(
            json.dumps({
                "run_id": run_id,
                "embedding_model": getattr(embedder, "name", "unknown"),
                "embedding_dimension": getattr(embedder, "dimension", 0),
                "embedding_model_max_tokens": exc.max_input_tokens,
                "embedding_inputs_over_limit": exc.total_violations,
                "violations": exc.violations,
                "opensearch_touched": False,
            }, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        logger.error("Embedding preflight failed before OpenSearch was modified; see %s", failure_path)
        raise

    client = make_client(settings)

    old_parent_indices: List[str] = []
    old_child_indices: List[str] = []
    deleted_parents = 0
    deleted_children = 0
    incremental_stale_cleanup_started = False

    if mode == "rebuild":
        child_index, parent_index = backing_names(settings, version)
        created: List[str] = []
        try:
            create_index(client, parent_index, parent_index_body(settings), settings)
            created.append(parent_index)
            create_index(client, child_index, child_index_body(settings, embedder.dimension), settings)
            created.append(child_index)
        except BaseException:
            remove_indices(client, created, settings)
            raise
    else:
        parent_index = resolve_write_index(client, settings.parent_alias) or ""
        child_index = resolve_write_index(client, settings.child_alias) or ""
        if not parent_index or not child_index:
            raise RuntimeError(
                "Incremental mode requires Ericsson parent and child aliases to point to write indexes. "
                "Run rebuild mode for the initial parent-child ingestion."
            )
        for index_name in (parent_index, child_index):
            validate_index_name(index_name, settings)
        existing_dimension = vector_dimension(client, child_index, settings)
        if existing_dimension is not None and existing_dimension != embedder.dimension:
            raise RuntimeError(
                f"Embedding dimension mismatch: child index={existing_dimension}, model={embedder.dimension}. "
                "Use rebuild mode with a new version when changing embedding models."
            )
        filenames = [doc.filename for doc in documents]

    parent_success = child_success = failures = 0
    try:
        parent_documents = _parent_sources(
            _iter_parents(documents, store, settings),
            run_id=run_id,
            ingested_at=ingested_at,
            settings=settings,
            incremental=mode == "incremental",
        )
        parent_success, parent_failures = bulk_index(
            client,
            parent_index,
            parent_documents,
            settings,
            chunk_size=bulk_chunk_size,
        )

        child_documents = _child_sources(
            _iter_children(documents, store, settings),
            embedder,
            run_id=run_id,
            ingested_at=ingested_at,
            settings=settings,
            incremental=mode == "incremental",
        )
        child_success, child_failures = bulk_index(
            client,
            child_index,
            child_documents,
            settings,
            chunk_size=bulk_chunk_size,
        )

        failures = len(parent_failures) + len(child_failures)
        if failures:
            failure_path = settings.logs_dir / f"ingestion_failures_{run_id}.json"
            failure_path.parent.mkdir(parents=True, exist_ok=True)
            failure_path.write_text(
                json.dumps({
                    "parent_failures": parent_failures,
                    "child_failures": child_failures,
                }, indent=2, default=str),
                encoding="utf-8",
            )
            raise RuntimeError(f"OpenSearch bulk ingestion had {failures} failures; see {failure_path}")

        if mode == "incremental":
            incremental_stale_cleanup_started = True
            # Remove stale child references before removing their old parents.
            # This avoids a transient interval in which a live stale child could
            # point at a parent that has already been deleted.
            deleted_children = delete_stale_by_filenames(client, child_index, filenames, run_id, settings)
            deleted_parents = delete_stale_by_filenames(client, parent_index, filenames, run_id, settings)

        refresh(client, parent_index, child_index)
    except BaseException:
        if mode == "rebuild":
            try:
                remove_indices(client, [parent_index, child_index], settings)
            except Exception as cleanup_exc:
                logger.exception("Could not remove failed Ericsson rebuild indexes: %s", cleanup_exc)
        elif mode == "incremental" and not incremental_stale_cleanup_started:
            for index_name in (parent_index, child_index):
                try:
                    delete_by_run_id(client, index_name, run_id, settings)
                except Exception as cleanup_exc:
                    logger.exception(
                        "Could not roll back records from failed Ericsson incremental run %s in %s: %s",
                        run_id,
                        index_name,
                        cleanup_exc,
                    )
        elif mode == "incremental":
            logger.error(
                "Incremental ingestion failed after stale deletion started. The live indexes may contain a mixed "
                "generation; inspect ingestion_run_id=%s and prefer a rebuild.",
                run_id,
            )
        raise

    if mode == "rebuild":
        old_targets = switch_aliases_atomic(
            client,
            {
                settings.parent_alias: parent_index,
                settings.child_alias: child_index,
            },
            settings,
        )
        old_parent_indices = old_targets.get(settings.parent_alias, [])
        old_child_indices = old_targets.get(settings.child_alias, [])
        if delete_old:
            remove_indices(client, old_parent_indices, settings, exclude=[parent_index])
            remove_indices(client, old_child_indices, settings, exclude=[child_index])

    report = IngestionReport(
        mode=mode,
        run_id=run_id,
        prepared_root=str(settings.prepared_root),
        markdown_documents=len(documents),
        parents_indexed=parent_success,
        children_indexed=child_success,
        parent_index=parent_index,
        child_index=child_index,
        parent_alias=settings.parent_alias,
        child_alias=settings.child_alias,
        embedding_model=embedder.name,
        embedding_dimension=embedder.dimension,
        embedding_model_max_tokens=embedding_preflight.model_max_tokens,
        embedding_inputs_checked=embedding_preflight.inputs_checked,
        largest_embedding_input_tokens=embedding_preflight.largest_input_tokens,
        largest_embedding_input_label=embedding_preflight.largest_input_label,
        embedding_inputs_over_limit=embedding_preflight.over_limit_inputs,
        deleted_parents=deleted_parents,
        deleted_children=deleted_children,
        failures=failures,
        old_parent_indices=old_parent_indices,
        old_child_indices=old_child_indices,
    )
    report_path = settings.logs_dir / f"ingestion_report_{run_id}.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report.to_dict(), indent=2), encoding="utf-8")
    return report
