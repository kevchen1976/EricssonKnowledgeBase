#!/usr/bin/env python3
"""Executable and import facade for the optional Ericsson Graph API."""
from graph_api import app
from agent_core.config import GRAPH_API_PORT, SERVICE_BIND_HOST

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host=SERVICE_BIND_HOST, port=GRAPH_API_PORT)
