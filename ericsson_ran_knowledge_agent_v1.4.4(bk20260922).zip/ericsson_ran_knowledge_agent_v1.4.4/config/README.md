# Configuration

`settings.json` contains safe defaults. Copy `services.env.example` to
`services.env` for deployment-specific values and credentials. Process
environment variables take precedence.

OpenSearch is shared physically with Nokia but Ericsson uses separate parent
and child aliases. The Ericsson Neo4j service is also separate and defaults to
`bolt://localhost:7688`.

Never commit `NEO4J_PASSWORD`, OpenSearch credentials, or Redis credentials.

Graph trace controls are deployment environment values:

```dotenv
GRAPH_LOG_MAX_BYTES=20971520
GRAPH_LOG_BACKUP_COUNT=5
GRAPH_LOG_QUERY_PREVIEW_CHARS=1200
GRAPH_LOG_PARAMETER_PREVIEW_CHARS=1000
```

They control the rotating `logs/ericsson_graph_api.log` and
`logs/ericsson_graph_queries.log` files. Query values are bounded for logs and
parameters named like passwords, secrets, or tokens are redacted.
