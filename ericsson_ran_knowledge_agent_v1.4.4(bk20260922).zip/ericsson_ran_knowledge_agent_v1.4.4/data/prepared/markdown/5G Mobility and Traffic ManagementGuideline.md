<!-- page: 5 -->
<!-- ericsson-canonical-meta: {"canonical_version":"1.1.2","title":"Trademark List"} -->
# 1 Purpose

This document provides guidelines on developing customized mobility and traffic management strategies for Ericsson 5G network deployments. The strategies are designed to maximize the benefit for 5G capable users whilst maintaining or improving service quality for legacy users.

The current Ericsson solution supports both standalone (SA) and non-standalone (NSA) 5G deployments:

- Standalone (SA) 5G: UEs connect to the 5G core (5GC) using the 3GPP New Radio (NR) Radio Access Technology (RAT) for 5G. The connection can either be via a master node only, or via both a master node and a secondary node, known as NR Dual Connectivity (NR-DC). This is also known as Option 2.

- Non-standalone (NSA) 5G: UEs connect to the Evolved Packet Core (EPC) using both LTE and NR, using the 3GPP configuration EN-DC (also known as Option 3x). This option is called non-standalone because UEs that are connected to the network through NR also have a connection through LTE.

This document covers both these deployment options and therefore encompasses mobility on both NR and LTE. It also covers the Ericsson Spectrum Sharing (ESS) solution, where the same spectrum is dynamically shared between NR and LTE.

# 2 Scope

This document covers the 2026 Q2 release of LTE and NR software (referred to in this document as 'the current release'). Changes from previous releases are summarized in Section 14.

NOTE:

Always check the release notes for variations in functionality; for example, some functionality may be introduced in different releases for high-band and low-band, or for a dedicated NR carrier and an ESS carrier. The CPI documents LTE RAN Feature Status & 5G SW Feature Status list the current status and possible feature restrictions.

This document covers both 5G options supported by Ericsson, namely Standalone 5G (SA) and Non-standalone 5G (NSA).

The focus is on Radio Access Network functionality. However, core network functionality is covered at a high level where relevant.

LTE functionality is covered only where relevant for the 5G solution; the remainder is covered in the CPI document LTE Mobility and Traffic Management Guideline .

Recommended parameter values are provided for common deployment cases in the CPI document RAN Parameter Recommendations. This guideline provides recommended values only for cases which fall outside that document.

<!-- page: 6 -->

# 3 Definitions

The following conventions are used in this document:

- Names of MO classes, structures, attributes, and their values are shown in courier font .

- Names of Ericsson software features and functions are shown in italics .

- Names of 3GPP information elements and their values are shown in italics .

The following terms and acronyms are used in this document:

| Term                                                    | Definition                                                                                                                                                                                                                            |
|---------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 3GPP                                                    | 3rd Generation Partnership Project                                                                                                                                                                                                    |
| 5GC                                                     | 5G Core                                                                                                                                                                                                                               |
| 5QI                                                     | 5G Quality of Service Indicator                                                                                                                                                                                                       |
| 5G_Idle_Go 5G_Idle_Stay 5G_HO_Go 5G_Cov_Stay 5G_LB_Stay | These refer to the five anchor management strategies which are defined in this document. The strategies are used to maximize EN- DC availability, by steering EN-DC capable UEs towards LTE cells which can act as anchors for EN-DC. |
| Anchor                                                  | An LTE cell which supports EN-DC                                                                                                                                                                                                      |
| AMF                                                     | Access and Mobility Management Function (in 5GC)                                                                                                                                                                                      |
| A-MLC                                                   | The gNodeB feature NR Advanced Multi-Layer Coordination                                                                                                                                                                               |
| ANR                                                     | The feature Automated Neighbor Relations (in both eNodeB & gNodeB)                                                                                                                                                                    |
| ARFCN                                                   | Absolute Radio Frequency Channel Number                                                                                                                                                                                               |
| ARP                                                     | Allocation and Retention Priority                                                                                                                                                                                                     |
| ASGH                                                    | Advanced Subscriber Group Handling                                                                                                                                                                                                    |
| BCS                                                     | Bandwidth Combination Set                                                                                                                                                                                                             |
| BIC                                                     | The eNodeB feature Basic Intelligent Connectivity                                                                                                                                                                                     |
| BNR                                                     | The eNodeB feature Best Neighbor Relations for Intra-LTE Load Management                                                                                                                                                              |
| BSR                                                     | Buffer Status Report                                                                                                                                                                                                                  |
| BWTISHO                                                 | The gNodeB feature Bandwidth-Triggered Inter-System Handover                                                                                                                                                                          |
| CA                                                      | Carrier Aggregation                                                                                                                                                                                                                   |
| CAIMC                                                   | The eNodeB feature Capability-Aware Idle Mode Control                                                                                                                                                                                 |
| CC                                                      | Component Carrier                                                                                                                                                                                                                     |
| CPI                                                     | Customer Product Information                                                                                                                                                                                                          |
| CS                                                      | Circuit Switched                                                                                                                                                                                                                      |
| CSM                                                     | The eNodeB feature Cell Sleep Mode                                                                                                                                                                                                    |

<!-- page: 7 -->

| Term        | Definition                                                                                                                                                                                                                                                                                            |
|-------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| CSI         | Channel State Information                                                                                                                                                                                                                                                                             |
| DACM        | The gNodeB feature Data-Aware Carrier Management                                                                                                                                                                                                                                                      |
| DAM         | The gNodeB feature NR Data-Aware Mobility                                                                                                                                                                                                                                                             |
| DCCM        | The gNodeB feature Dynamic Component Carrier Management                                                                                                                                                                                                                                               |
| DCSC        | The gNodeB feature Dynamic Cell Set Change During Mobility                                                                                                                                                                                                                                            |
| DL          | Downlink                                                                                                                                                                                                                                                                                              |
| DRB         | Data Radio Bearer                                                                                                                                                                                                                                                                                     |
| DRX         | Discontinuous Reception                                                                                                                                                                                                                                                                               |
| EARFCN      | EUTRA Absolute Radio Frequency Channel Number                                                                                                                                                                                                                                                         |
| EBS-N       | The ENM feature Event Based Statistics - NR                                                                                                                                                                                                                                                           |
| eLTE        | Evolved LTE. In eLTE, the eNodeB is connected to the 5GC, as defined in 3GPP Rel-15. Relevant only for 5G deployment options 4, 5 and 7; which are not required by Ericsson 5G solutions.                                                                                                             |
| EN-DC       | EUTRAN-NR Dual Connectivity. This is also known as Option 3x.                                                                                                                                                                                                                                         |
| ENDCHO      | An inter-frequency handover on LTE which is triggered by one of the following features: EN-DC Triggered Handover During Setup or EN-DC Triggered Handover During Connected Mode Mobility . The purpose of ENDCHO is to move the UE to an LTE cell which is better suited to provide it with EN-DC.    |
| eNodeB, eNB | The eNodeB provides LTE user plane and control plane protocol terminations towards the UE and is connected via the S1 interface to the EPC.                                                                                                                                                           |
| ENM         | Ericsson Network Manager                                                                                                                                                                                                                                                                              |
| EPC         | Evolved Packet Core                                                                                                                                                                                                                                                                                   |
| EPS         | Evolved Packet System                                                                                                                                                                                                                                                                                 |
| ESM         | EPS Subscription Manager                                                                                                                                                                                                                                                                              |
| ESS         | Ericsson Spectrum Sharing. An Ericsson 5G solution where spectrum is dynamically shared between an NR carrier and an LTE carrier.                                                                                                                                                                     |
| FAJ         | Prefix given to an Ericsson value package number or feature number                                                                                                                                                                                                                                    |
| FR          | Frequency Range (FR1 or FR2 in NR)                                                                                                                                                                                                                                                                    |
| gNodeB, gNB | The gNodeB provides NR user plane and control plane protocol terminations towards the UE and is connected via the NG interface to the 5GC. Note: In this document the term gNodeB is also used to refer to the NR Node in an EN-DC context, even though EN-DC does not involve connection to the 5GC. |
| HARQ        | Hybrid Automatic Repeat Request                                                                                                                                                                                                                                                                       |
| HO          | Handover                                                                                                                                                                                                                                                                                              |

<!-- page: 8 -->

| Term   | Definition                                                                                                                                                                                                             |
|--------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| HRL    | Handover Restriction List (an information element defined in 3GPP TS 36.413)                                                                                                                                           |
| HSS    | Home Subscriber Server                                                                                                                                                                                                 |
| IDLe   | Inter-DU Link Ethernet                                                                                                                                                                                                 |
| IE     | Information Element (in a 3GPP message) Shown in italics in this guideline.                                                                                                                                            |
| IFLB   | The eNodeB feature Inter-Frequency Load Balancing                                                                                                                                                                      |
| IMMCI  | Idle Mode Mobility Control Information                                                                                                                                                                                 |
| IMS    | IP Multimedia Subsystem                                                                                                                                                                                                |
| IRAT   | Inter Radio Access Technology                                                                                                                                                                                          |
| KPI    | Key Performance Indicator                                                                                                                                                                                              |
| LTE    | Long Term Evolution (4G Radio Interface Standard)                                                                                                                                                                      |
| LTM    | L1/L2 Triggered Mobility                                                                                                                                                                                               |
| MAC    | Media Access Control                                                                                                                                                                                                   |
| MBB    | Mobile Broadband                                                                                                                                                                                                       |
| MCG    | Master Cell Group                                                                                                                                                                                                      |
| MCPC   | Mobility Control at Poor Coverage A feature in the eNodeB, and a function within the feature NR Mobility in the gNodeB                                                                                                 |
| MCPTT  | Mission Critical Push-To-Talk                                                                                                                                                                                          |
| MLC    | The feature Multi-Layer Coordination                                                                                                                                                                                   |
| MLSTM  | The eNodeB feature Multi-Layer Service-Triggered Mobility                                                                                                                                                              |
| MME    | Mobility Management Entity                                                                                                                                                                                             |
| MN     | Master Node (eNodeB in an EN-DC deployment or FR1 gNodeB in a NR-DC deployment)                                                                                                                                        |
| MOM    | Managed Object Model                                                                                                                                                                                                   |
| MR-DC  | Multi-RAT Dual Connectivity (EN-DC is one type of MR-DC)                                                                                                                                                               |
| MRL    | Mobility Restriction List (information element defined in 3GPP TS 38.413)                                                                                                                                              |
| NAS    | Non-Access Stratum                                                                                                                                                                                                     |
| NCGI   | NR Cell Global Identity                                                                                                                                                                                                |
| NG     | The network interface between gNodeB and 5GC                                                                                                                                                                           |
| NSA    | Non-standalone 5G A 5G deployment option where UEs connect to the network using both LTE and NR RATs. The Ericsson NSA solution uses the 3GPP configuration EN-DC; also known as Option 3x, along with LTE (Option 1). |
| NR     | New Radio (5G Radio Interface Standard)                                                                                                                                                                                |
| NR-DC  | NR-NR Dual Connectivity                                                                                                                                                                                                |

<!-- page: 9 -->

| Term                        | Definition                                                                                                             |
|-----------------------------|------------------------------------------------------------------------------------------------------------------------|
| NUTB                        | The eNodeB feature NR UE Throughput Booster                                                                            |
| Option 1 Option 2 Option 3x | Terms used to describe UE to network connectivity options. Option 1 is LTE, Option 2 is NR, Option 3x is EN-DC.        |
| PCTM                        | The gNodeB feature Prohibited Cell-Triggered Mobility                                                                  |
| PDCP                        | Packet Data Convergence Protocol                                                                                       |
| PDSCH                       | Physical Downlink Shared Channel                                                                                       |
| PI                          | Performance Indicator                                                                                                  |
| PLMN                        | Public Land Mobile Network                                                                                             |
| PRB                         | Physical Resource Block                                                                                                |
| PCell                       | Primary Cell                                                                                                           |
| PSCell                      | Primary Secondary Cell                                                                                                 |
| PUSCH                       | Physical Uplink Shared Channel                                                                                         |
| QCI                         | Quality of Service Class Identifier                                                                                    |
| RAT                         | Radio Access Technology                                                                                                |
| RFSP                        | RAT Frequency Selection Priority                                                                                       |
| RLC                         | Radio Link Control                                                                                                     |
| RLF                         | Radio Link Failure                                                                                                     |
| RRC                         | Radio Resource Control                                                                                                 |
| RRM                         | Radio Resource Management                                                                                              |
| RSRP                        | Reference Signal Received Power                                                                                        |
| RSRQ                        | Reference Signal Received Quality                                                                                      |
| RTT                         | Round Trip Time                                                                                                        |
| RwR                         | Release-with-Redirect                                                                                                  |
| S-NSSAI                     | Single-Network Slice Selection Assistance Information                                                                  |
| SA                          | Standalone (5G) A 5G deployment option where UEs connect to the core network using the NR RAT. Also known as Option 2. |
| SCell                       | Secondary Cell (for Carrier Aggregation)                                                                               |
| SCG                         | Secondary Cell Group                                                                                                   |
| SCTS                        | The gNodeB feature NR Small Cell Traffic Steering                                                                      |
| SGNB                        | Secondary gNodeB                                                                                                       |
| SGSN                        | Serving GPRS Support Node                                                                                              |
| SIB                         | System Information Broadcast                                                                                           |
| SINR                        | Signal to Interference Plus Noise Ratio                                                                                |
| SN                          | Secondary Node (gNodeB in an EN-DC or FR2 gNodeB in an NR- DC deployment)                                              |
| SPID                        | Subscriber Profile ID                                                                                                  |

<!-- page: 10 -->

| Term    | Definition                                                                      |
|---------|---------------------------------------------------------------------------------|
| SRB     | Signaling Radio Bearer                                                          |
| SPIFHO  | The eNodeB feature Service or Priority-Triggered Inter-Frequency Handover       |
| SRVCC   | Single Radio Voice Call Continuity                                              |
| SSB     | Synchronization Signal and Physical Broadcast Channel Block                     |
| SSLM    | The eNodeB feature Service Specific Load Management                             |
| SS_RSRP | Synchronization Signal Reference Signal Received Power                          |
| SS_RSRQ | Synchronization Signal Reference Signal Received Quality                        |
| STM     | The eNodeB feature Subscriber Triggered Mobility                                |
| S1      | The network interface between eNodeB and EPC                                    |
| TAC     | Tracking Area Code                                                              |
| UAI     | UE Assistance Information                                                       |
| UE      | User Equipment                                                                  |
| UL      | Uplink                                                                          |
| UL 2L   | Uplink 2-layer transmission                                                     |
| VoIP    | Voice over IP                                                                   |
| VoLTE   | Voice over LTE                                                                  |
| VoNR    | Voice over NR                                                                   |
| Xn      | The network interface between gNodeBs                                           |
| X2      | The network interface between eNodeBs and between eNodeB and gNodeB (for EN-DC) |

# 4 Mobility and Connectivity Overview

This section provides an overview of concepts and functionality which are fundamental to understanding 5G mobility and traffic management.

## 4.1 Frequency Ranges & Bands

5G uses a new global (3GPP) standard for the air interface, called New Radio (NR). The standard includes the definition of the frequencies and frequency bands that the UE can use to connect to the network.

3GPP 38.101 defines two Frequency Ranges (FRs) for NR:

Table 4-1 - 3GPP Frequency Ranges for NR

| Frequency Range   | Definition        |
|-------------------|-------------------|
| FR1               | 410 - 7125 MHz    |
| FR2               | 24250 - 52600 MHz |

Table 4-1 - 3GPP Frequency Ranges for NR

<!-- page: 11 -->

Additionally, the Ericsson radio solutions further classify frequencies into low-band, mid-band or high-band, depending on the duplex method used, as follows:

Table 4-2 - Definition of Low, Mid and High-Bands

| Name      | Frequency Range   | Duplex Method   |
|-----------|-------------------|-----------------|
| Low-Band  | FR1               | FDD             |
| Mid-Band  | FR1               | TDD             |
| High-Band | FR2               | TDD             |

Table 4-2 - Definition of Low, Mid and High-Bands

The 3GPP specifications sometimes have separate requirements for the two frequency ranges, FR1 and FR2. Furthermore, some of the Ericsson radio products (both hardware and software) have different capabilities in low, mid and high-bands. Where relevant, the differences are highlighted in this document.

## 4.2 Connectivity Options

Ericsson products support four options for how a UE connects to the core network using the 4G and/or 5G radio access networks at a given point in time. They are shown in Figure 4-1. If the UE is capable of more than one option, then the used option can be changed during the life of the connection. A given network node (or cell) can simultaneously support UEs connected by different options.

<!-- page: 12 -->

![Figure on page 12](5G_Mobility_and_Traffic_Management_Guideline_images/page_012_image_002.png)

Figure 4-1 - Connectivity Options

- LTE : This is the legacy (4G) connectivity option, where the UE connects to the EPC using LTE only. A single eNodeB terminates both the control plane (S1-C) and the user plane (S1-U) connections from the EPC, and provides both control and user plane connections to the UE. This connectivity option is also known as Option 1.

<!-- page: 13 -->

- NR NSA Dual Connectivity (EN-DC) : LTE-NR Dual Connectivity is a 5G connectivity option where the UE connects to the EPC using a master node on LTE and a secondary node on NR. The master node terminates the control plane connection from the MME (S1-C), and has a control plane connection to the UE.  The secondary node terminates the user plane connection from the EPC (S1-U) and has a user plane connection to the UE, both directly over NR and indirectly over LTE via the master node and the X2-U interface. Additionally, the UE may simultaneously have a user plane connection to the EPC directly through the eNodeB, for radio bearers which cannot be terminated on the secondary node. Ericsson products support EN-DC using NR frequencies in both FR1 and FR2. EN-DC is also known as Option 3x.

- NR SA : NR SA is a 5G connectivity option where UE connects to the 5GC using NR only. A single gNodeB terminates both the control plane (NG-C) and the user plane (NG-U) connections from the 5GC, and has both control and user plane connections to the UE. In the current release, this connectivity option is supported in FR1, and in FR2 for fixed wireless access with limited mobility. This connectivity option is also known as Option 2.

- NR SA Dual Connectivity (NR-DC) : NR-NR Dual Connectivity is a 5G connectivity option where the UE connects to the 5GC using NR only, but with both a master node and a secondary node. The master node terminates the control plane from the 5GC (NG-C), and has a control plane connection to the UE. The secondary node terminates the user plane from the 5GC (NG-U) and has a user plane connection to the UE, both directly and via the master node using the Xn-U interface. Additionally, the UE may simultaneously have a user plane connection to the 5GC directly through the master node, for bearers which cannot be terminated on the secondary node. In the current release, the master node connection always uses FR1 frequencies, and the secondary node connection always uses FR2 frequencies.

The connectivity option used by a particular radio bearer at any given time depends on several factors, such as the UE capability (for example the supported band combinations) the coverage from the different layers, and the network configuration. Regardless of which connectivity option is used, the UE is always connected by at least one cell on the master node. This cell is called the Primary Cell (PCell). If the UE is using EN-DC or NR-DC, then the UE is additionally connected by at least one cell on the secondary node. This cell is called the Primary Secondary Cell (PSCell). Finally, if the UE is configured with Carrier Aggregation (CA), then it is additionally connected to the network using one or more Secondary Cells (SCells). For both EN-DC and NR-DC, the SCells can be configured on the master or secondary RATs, or both.

Figure 4-2 shows some examples of UEs using the four different connectivity options. For each UE, the circles show which cells the UE is using and their roles. For EN-DC, two UEs are shown, one with the PSCell on FR1 and one with the PSCell on FR2. For UEs connected by EN-DC and NR-DC, two bearers are shown; one configured with dual connectivity (meaning both PCell and PSCells are present) and the other without dual connectivity (no PSCell). Only a subset of configurations and combinations is shown here; others are possible. Section 4.6 provides more detail on CA, including the allowed number and location of SCells.

<!-- page: 14 -->

![Figure on page 14](5G_Mobility_and_Traffic_Management_Guideline_images/page_014_image_002.png)

Figure 4-2 - Connectivity Options and Cell Roles

- The current release has only limited mobility support for NR SA with PCell on FR2. For more information refer to the feature description for NR Standalone High-Band for Fixed Wireless Access in CPI.

## 4.3 Ericsson Spectrum Sharing (ESS)

Ericsson Spectrum Sharing (ESS) is a solution to enable efficient NR deployment in LTE FDD frequency bands. With ESS, an NR carrier and an LTE carrier are deployed simultaneously on the same frequency, using the same Ericsson Radio System equipment. This avoids the need for a dedicated NR carrier, facilitating rapid deployment of wide area 5G coverage and enabling a smooth transition between LTE and NR as the network evolves. ESS is supported with both NR NSA and SA.

ESS dynamically shares the LTE spectrum with NR NSA and/or NR SA, of bandwidth 10, 15 or 20 MHz. The split of PRBs between LTE and NR is adjusted every millisecond in response to offered traffic variations on the two technologies, as shown in Figure 4-3.

<!-- page: 15 -->

![Figure on page 15](5G_Mobility_and_Traffic_Management_Guideline_images/page_015_image_001.png)

Figure 4-3 - Ericsson Spectrum Sharing Between LTE and NR

ESS requires that the LTE and NR carriers have the same bandwidth and center frequency. In case of NR NSA, the anchor for the ESS NR carrier must be an LTE carrier on another frequency; it cannot be the LTE carrier on the ESS frequency.

ESS requires support in the UE, using the toolbox of UE capabilities for spectrum sharing between NR and LTE defined by 3GPP in Release 15.4.0.

ESS causes a small reduction in LTE capacity due to NR overhead. However, ESS allows a smooth transition from LTE to NR which is not possible if the carrier is instead statically re-farmed from LTE to NR.

## 4.4 Mobility States

With the introduction of 5G SA, there are two core networks:

- EPC : The Evolved Packet Core, which is used for LTE and 5G NSA

- 5GC : The 5G Core, which is used for 5G SA

Each of these core networks has two functionalities that manage the state of the UE.

The first functionality manages registration of the UE on the network. In EPC this functionality is called EPS Mobility Management (EMM) and in 5GC it is called Registration Management (RM). In both EMM and RM there are two states, deregistered and registered:

- Deregistered : The UE is not in contact with the network. It is turned off, out of coverage, etc.

- Registered : The UE is known to the network and can send or receive traffic when required.

<!-- page: 16 -->

The second functionality manages the signaling connection between the UE and core. In EPC this functionality is called EPS Connection Management (ECM) and in 5GC it is called Connection Management (CM). In both ECM and CM there are two states, idle and connected:

- Idle : In idle mode, the UE does not consume radio resources (other than paging channel) and must transition to connected state before sending or receiving traffic

- Connected : In connected mode, the UE location is known at a cell level and can send data to or receive data from the network, and so is consuming radio resources.

The terminology used to describe these states is slightly different in the EPC and the 5GC. The differences are shown in Figure 4-4; blue for the EPC and orange for the 5GC.

![Figure on page 16](5G_Mobility_and_Traffic_Management_Guideline_images/page_016_image_002.png)

Figure 4-4 - UE Mobility States in EPC and 5GC

<!-- page: 17 -->

### 4.4.1 ECM-IDLE/CM-IDLE, Idle Mode

In idle mode, all UE related information in the radio network is released. This reduces load in the eNodeB or gNodeB during long periods of inactivity. The core network retains the UE context and information about established bearers, but there is no explicit signaling between the UE and the core network.

However, the UE is still in EMM-REGISTERED/RM-REGISTERED state, indicating that it is attached to the network and may transition to connected mode in response to a paging request, user activity or other reason, without having to perform a full attach procedure.

An eNodeB or gNodeB does not know how many UEs are camped within its coverage area in idle mode. The location of an idle UE is only known within a Tracking Area List, which is a group of Tracking Areas configured in the core network. Idle mode reselection parameters are broadcast in each cell, and a UE is responsible for evaluating nearby cells and camping on the correct cell as determined by the broadcasted parameters. A UE which moves into a cell which is not in the current Tracking Area List must change to connected state to signal this to the network (via a Tracking Area Update), before returning to idle again.

In idle mode the UE is responsible for selecting and reselecting between cells, frequencies and access technologies, using information broadcast by the eNodeB or gNodeB.

Further information on idle mode procedures is provided in Section 6 for NSA and Section 8 for SA.

### 4.4.2 ECM-CONNECTED/CM-CONNECTED, Connected Mode

In connected mode the UE makes no mobility decisions and responsibility is transferred to the network; an exception to this is the RRC re-establishment procedure, where a UE may relocate to a new cell due to a radio link failure whilst in connected mode.

A UE can be instructed (via RRC Reconfiguration messaging) to report certain mobility events, such as when the serving cell signal drops below a particular level. This, in turn, causes the network to take further action, such as instructing the UE to configure further measurements or perform a handover.

Further information on connected mode procedures is provided in Section 6 for NSA and Section 8 for SA.

### 4.4.3 RRC State

There is also a UE state which is managed by RAN, namely the RRC state; RRC_IDLE, RRC_CONNECTED or RRC_INACTIVE.

- RRC_IDLE : The UE has no signaling connection to RAN. This state is used in both LTE and NR SA.

- RRC_CONNECTED : The UE has a signaling connection to the RAN. This state is used in both LTE and NR SA.

<!-- page: 18 -->

- RRC_INACTIVE : The UE has a suspended connection to RAN. This state is used only for NR SA as it requires a 5GC.

These RRC states are shown in Figure 4-5 for NR SA.

![Figure on page 18](5G_Mobility_and_Traffic_Management_Guideline_images/page_018_image_002.png)

Figure 4-5 - RRC States in NR SA

#### 4.4.3.1 RRC_INACTIVE State - SA

The RRC_INACTIVE state enables more efficient handling of the UEs that transition frequently between activity and inactivity. It allows the UE to move back and forth between a low power consumption state (RRC_INACTIVE) and full connectivity (RRC_CONNECTED) in an efficient way. The transition from RRC_INACTIVE to RRC_CONNECTED is faster and requires less signaling than the transition from RRC_IDLE to RRC_CONNECTED.

The UE can enter RRC_INACTIVE state only from RRC_CONNECTED state, and only when instructed to do so by the network due to inactivity (as described in Section 8.2.4.1). Other release causes (e.g. abnormal releases) result in a transition to RRC_IDLE.

From a mobility perspective, RRC_INACTIVE state is most similar to RRC_IDLE state. UEs in RRC_INACTIVE state follow the idle mode procedures for autonomous cell selection and reselection, using the parameters broadcast in system information. This means that the idle mode mobility strategy components, such as the reselection priorities, thresholds, offsets, and timers, do not need to be altered when RRC_INACTIVE state is introduced to the network.

When a UE is in RRC_INACTIVE state, its location is known within a RAN Notification Area (RNA). The RNA is specific to each UE and, in the current release, consists of the cells in the serving gNodeB that have an NRCellRelation from the serving cell and meet the PLMN and TA filtering conditions. The UE is notified of the cells in the RNA when it is released to RRC_INACTIVE state.

If an RRC_INACTIVE UE moves to a cell outside the RNA, then it initiates the RNA update procedure. By contrast, if an idle UE moves to a cell outside the registered tracking area list, then it initiates a tracking area update.

If the network needs to contact an RRC_INACTIVE UE for downlink signaling or data, then the RAN pages the UE within the RNA. The UE monitors both RAN and 5GC paging, so the 5GC can contact the UE even if the RAN paging is unsuccessful.

<!-- page: 19 -->

An RRC_INACTIVE UE must return to RRC_CONNECTED state (using the RRC connection resume procedure) to respond to a page, send uplink signaling or data, or perform an RNA update.

An RRC_INACTIVE UE is considered by the core network to be in CM-CONNECTED state. The core network is not aware of transitions between RRC_CONNECTED and RRC_INACTIVE state. However, to enable RRC_INACTIVE state, the core network must supply the gNodeB with Core Network Assistance Information (CNAI), which the gNodeB uses for RRC_INACTIVE state procedures.

For further details on RRC_INACTIVE state, refer to the RRC Inactive State feature description in CPI.

## 4.5 5G Status Icon on UE - NSA

Network operators and UE vendors require some way of indicating to the end user that 5G service is potentially available, for example by displaying a 5G icon on the phone's screen. The criteria for displaying a 5G icon are not standardized by 3GPP and it is up to the UE vendor and operator to decide under what conditions a 5G indication should be displayed. The decision is straightforward in a 5G SA deployment: the UE can display the 5G icon whenever the serving master RAT is NR. However, in an NSA deployment (EN-DC), the UE is not always aware whether 5G service is available, as the UE camps on LTE in idle mode and the control plane is on LTE in connected mode.

To assist the UE in idle mode for NSA EN-DC, 3GPP have standardized a 1-bit indication per cell and PLMN called upperLayerIndication-r15 that is broadcast in LTE SIB2. This bit can be used by the network operator to indicate that 5G service is potentially available to an EN-DC capable UE. However, the bit can be set independently of the functionality actually provided by the cell or related cells. As such, the operator decides whether to set the bit and the UE decides how the bit impacts the display of any 5G indication. This bit is the only 3GPP agreed mechanism for determining the availability of 5G when camped on LTE in idle mode. In connected mode the EN-DC capable UE has additional information to determine whether 5G service is potentially available. For example, the UE can consider whether it is configured with measurements to detect NR coverage, whether it has actually detected NR coverage and whether it has any bearers connected to an NR cell.

The GSM Association (GSMA) recommends one configuration as a default for determining whether to display the 5G status icon. The configuration is shown in Table 4-3. GSMA submitted this recommendation to 3GPP in a liaison statement (SP-190216, LS Reply to 3GPP RAN on Work Status of 5GSI). The table can be summarized to a single, simple recommendation; show the indication if the LTE cell supports NSA, otherwise don't show it . This implies; set the upper layer indication to ON when the LTE cell supports NSA, and OFF otherwise.

<!-- page: 20 -->

Table 4-3 - GSMA Recommendations for the UE Indication

| State                                                                                 | UE Indication   |
|---------------------------------------------------------------------------------------|-----------------|
| 1. Idle under or connected to LTE cell not supporting NSA                             | 4G              |
| 2. Idle under or connected to LTE cell supporting NSA and no detection of NR coverage | 5G              |
| 3. Connected to LTE only under LTE cell supporting NSA and detection of NR coverage   | 5G              |
| 4. Idle under LTE cell supporting NSA and detection of NR coverage                    | 5G              |
| 5. Connected to LTE + NR under LTE cell supporting NSA                                | 5G              |

Table 4-3 - GSMA Recommendations for the UE Indication

Figure 4-6 summarizes the recommendation for displaying the 5G icon in an example NSA network deployment. The top pane shows the coverage from the NR and LTE cells, and in which LTE cells EN-DC is enabled and the upperLayerIndication-r15 bit is set. The lower pane shows where the 5G Icon will be ON and OFF, given the UE state (shown in black on the left) and the GSMA state (circled). The example assumes that the operator has chosen not to enable EN-DC in the LTE cell on the right, due to the poor NR coverage.

![Figure on page 20](5G_Mobility_and_Traffic_Management_Guideline_images/page_020_image_001.png)

Figure 4-6 - Example of 5G Icon Configuration in an NSA Network

It is up to the network operator, UE vendor and possibly regulators to determine whether the GSMA recommendations are followed or not. Additionally, a vendor could choose to use different icons for different states, for example a hollow icon to indicate 5G is potentially available and a solid icon to indicate 5G is being used, or different icons such as 5G and 5G+ for further differentiation.

The upper layer indication can be set either manually or automatically. If EUtranCellFDD/TDD.upperLayerAutoConfEnabled = true , then it is set automatically by the feature Basic Intelligent Connectivity as described in Section 10.2.1.5, otherwise it is set manually using the parameters shown in Table 4-4.

<!-- page: 21 -->

Table 4-4 - Parameters for Controlling the upperLayerIndication-r15

| MO                           | Attribute                   | Description                                                                                                                  |
|------------------------------|-----------------------------|------------------------------------------------------------------------------------------------------------------------------|
| EUtranCellFDD/ EUtranCellTDD | primaryUpperLayerInd        | Indicates whether upperLayerIndication-r15 is set for the PLMN identified by ENodeBFunction.eNodeBPlmnId (ON/OFF)            |
| EUtranCellFDD/ EUtranCellTDD | additionalUpperLayerIndList | Indicates whether upperLayerIndication-r15 is set for any additional PLMN identities that may be broadcast in SIB1. (ON/OFF) |

Table 4-4 - Parameters for Controlling the upperLayerIndication-r15

Note: For some UE implementations, NAS signaling (containing NR restriction) can prevent an EN-DC capable UE from displaying any 5G icon even if upperLayerIndication-r15 in SIB2 is correctly received in the UE.

## 4.6 Carrier Aggregation

Carrier Aggregation (CA) is a key feature in LTE and is standardized for NR in the first 3GPP NR release, namely 15. It allows user plane data to be transmitted over multiple serving cells, either in the downlink to the UE (downlink CA) or in the uplink from UE (uplink CA) or both. This enables higher user data rates and helps distribute the traffic load over multiple carriers. CA can also be used to extend the downlink coverage of cells on high frequency bands, by allowing the uplink (which is typically the limiting link) to be carried by cells on lower frequency bands, which have better coverage. The degree to which CA can be used by a particular UE depends on the capability of the UE and the network, and the traffic profile of the UE; continuous data transfers are able to use CA more readily than intermittent ones.

CA is possible in both the UL and the DL, depending on the connectivity type and the frequency range, as shown in Table 4-5.

Table 4-5 - High Level CA Capabilities

| Connectivity     | DL CA NR              | UL CA NR             | DL CA LTE   | UL CA LTE   |
|------------------|-----------------------|----------------------|-------------|-------------|
| NSA (EN-DC, FR1) | Yes                   | No                   | Yes         | No          |
| NSA (EN-DC, FR2) | Yes                   | Yes                  | Yes         | No          |
| SA (FR1)         | Yes                   | Yes*                 | -           | -           |
| SA (FR2)**       | Yes                   | Yes                  | -           | -           |
| SA (NR-DC)       | Yes in FR1 Yes in FR2 | No in FR1 Yes in FR2 | -           | -           |

Table 4-5 - High Level CA Capabilities

* FDD + FDD, FDD + TDD and TDD + FDD are supported, with limits on the maximum inter-antenna distance.

** For Fixed Wireless Access in NR SA FR2, with limited mobility.

<!-- page: 22 -->

When connected to the network, the UE is always connected by at least one cell in both the uplink and the downlink, the Primary Cell (PCell). Additionally, when CA is configured, one or more Secondary Cells (SCells) are added to the connection in either the downlink or both the downlink and uplink, via RRC signaling. Collectively, the PCell and SCell(s) are known as Component Carriers (CCs). The PCell always carries the RRC connection and the related RRC and NAS signaling. The choice of PCell is controlled by mobility and handover functionality (which is the primary focus of this guideline) and is not impacted explicitly by CA procedures. However, the choice of PCell impacts the potential for setting up CA. For example, in NSA the choice of LTE anchor carrier can impact the available CA configurations in both LTE and NR.

CA is implemented on the MAC and Layer 1 (L1) and is transparent to higher layers. The MAC layer is responsible for scheduling, link adaptation, dynamic activation and deactivation of CCs and multiplexing user data flows to the different CCs.

Figure 4-7 shows how CA is implemented in the different connectivity options (LTE, ENDC, NR SA and NR-DC). Since CA occurs at the MAC layer, and the aggregation associated with dual connectivity (EN-DC and NR-DC) occurs at the PDCP layer, CA and DC can be used together.

![Figure on page 22](5G_Mobility_and_Traffic_Management_Guideline_images/page_022_image_002.png)

Figure 4-7 - Dual Connectivity and Carrier Aggregation

The functionality described in this chapter applies to all the relevant connectivity options, unless otherwise stated.

### 4.6.1 Band Combinations and Capabilities

CA can aggregate CCs in various combinations, depending on the UE capability and the spectrum configured in the network.

For 2 CCs, the possible combinations can be categorized into: intra-band contiguous, intraband non-contiguous and inter-band, as shown in Figure 4-8. For 2 CCs to be considered contiguous, their center frequency spacing must be less than or equal to the nominal channel spacing, as defined by 3GPP.

<!-- page: 23 -->

![Figure on page 23](5G_Mobility_and_Traffic_Management_Guideline_images/page_023_image_001.png)

Figure 4-8 - Types of CA Combinations for 2 CCs

For more than 2 CCs, mixtures of the above combinations are possible, as shown in Figure 4-9. This is just one example; many high-order combinations are possible.

![Figure on page 23](5G_Mobility_and_Traffic_Management_Guideline_images/page_023_image_002.png)

Figure 4-9 - Example of High-Order Carrier Aggregation for 5 CCs

The allowed CA band combinations are specified in 3GPP, jointly for the DL and UL, in the following specifications:

- FR1:  3GPP 38.101-1

- ·

- FR2:  3GPP 38.101-2

- Dual Connectivity (including EN-DC and NR-DC) and CA between FR1 and FR2: 3GPP 38.101-3

A CA band combination is built up from one or more contiguous downlink parts and one or more contiguous uplink parts, each of which is defined by a Bandwidth Class. The Bandwidth Class describes the number of CCs and the total aggregated bandwidth of the contiguous part. The aggregated bandwidth is specified in PRBs for LTE, and in MHz for NR.

The band combinations supported by a particular UE are retrieved by the network, either directly from the UE using the RRC Capability Enquiry and Response, or indirectly from the core network for attached UEs. To limit the size of the UE 's response, the NW only requests band combinations for bands that are configured in the eNodeB (for LTE or NSA) or gNodeB (for SA). This is described in more detail for NSA in Section 6.2.1.

<!-- page: 24 -->

̶

Figure 4-10 gives an example of a UE capability response, contained within the UE Capability Information message. Specifically, this example shows an excerpt from the Information Element (IE) UE-MRDC-Capability , which contains the CA capabilities for EN-DC.

Figure 4-10 - An Example of a Band Combination

**Notes for Figure 4-10:**

- The detailed ASN.1 message shown here is summarized using the formal 3GPP notation shown in 2 and 3.

- DC_1A-3C_n257M describes the downlink capabilities:

̶

- DC:  indicates that an LTE part and an NR part follows

- 1A: 1 = LTE Band 1, A = a single CC of up to 100 PRBs

̶

- 3C: 3 = LTE Band 3, C = two contiguous CCs of up to 200 PRBs total

̶

- n257M: n257 = NR Band 257, M = 8 contiguous CCs up to 800 MHz total

- DC_1A_n257G describes the uplink capabilities:

̶

- DC:  indicates that an LTE part and an NR part follows

̶

- 1A: 1 = LTE Band 1, A = a single CC of up to 100 PRBs

̶

- n257G: n257 = NR Band 257, G = 2 contiguous CCs up to 200 MHz total

<!-- page: 25 -->

Note that in this example, in LTE only Band 1 has both uplink and downlink capabilities, so this is the only band which can be used for PCells.

The following are additional examples of band combinations, using the nomenclature in 3GPP.

| • CA_n41A-n71A   | NR SA inter-band CA n41A = NR band 41 (TDD), one CC of bandwidth class A n71A = NR band 71 (FDD), one CC of bandwidth class A                                                                                                         |
|------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| • CA_n78(2A)     | NR SA Intra-band non-contiguous CA n78 = NR Band 78 (TDD) (2A) = 2 non-contiguous intra-band CCs of bandwidth class A Note that non-contiguous band combinations are listed as separate entries in the detailed ASN.1 message itself. |

The above examples refer to information contained in IE UE-MRDC-Capability . Another relevant IE is the UE-NR-Capability , which contains the NR SA capabilities and additional information relevant for EN-DC operation.

Within a band combination, a UE may support only certain combinations of bandwidths of the individual CCs. These are defined by Bandwidth Combination Sets (BCSs) which are also specified in the three 3GPP specifications previously mentioned.

The eNodeB and gNodeB validate the signaled UE capability against the allowed band combinations and bandwidth combination sets for each RAT, as specified in 3GPP. Refer to CPI Compliance and Compatibility for further details on the 3GPP specification compliance.

Note that different UE models might support different band combinations even if they are based on the same chipset, for example due to device design constraints or operatorspecific implementations.

### 4.6.2 SCell Configuration and Measurements

For a cell to be used as an SCell for a particular PCell, the NRCellRelation that points from the PCell to the SCell must have:

- sCellCandidate = ALLOWED (for both DL and UL CA) or ONLY_ALLOWED_FOR_DL (for DL only)

The attribute sCellCandidate can be set manually, or it can be set automatically using the feature Automated Carrier Aggregation (for more information, refer to the feature description in CPI). If it is set manually, it must not be set to ALLOWED or ONLY_ALLOWED_FOR_DL on intra-frequency cell relations, because cells on the same frequency cannot be used as SCells.

Initial SCell selection is blind, meaning it does not involve a coverage measurement from the UE. The initial SCell on each SCell frequency is selected as follows:

- If the feature Automated Carrier Aggregation is not active:

<!-- page: 26 -->

̶

̶

- To allow a cell to be used for initial SCell selection, the NRCellRelation to the cell must have the coverageIndicator set as follows:

- FR1: coverageIndicator = 2 (OVERLAP) , 3 (CONTAINED_IN) or 1 (COVERS)

- FR2: coverageIndicator = 2 (OVERLAP)

- The coverageIndicator should be set to one of these values only for the cell which has the best coverage overlap with the PCell on each frequency, and it should be set to 0 (NONE) on all other NRCellRelation instances. This guarantees that the cell with the best coverage overlap is prioritized.

- If the feature Automated Carrier Aggregation is active:

̶

- The blind selection algorithm selects the cell with the highest cell usefulness that is above the required threshold and has caStatusActive = true . If no such cell is available, the legacy method (described above) is used. Refer to the feature description of Automated Carrier Aggregation for further details.

If a candidate cell is blocked for traffic (due to manual barring, cell soft lock, or cell sleep preparation), it is not selected for CA configuration. Refer to Section 10.3.35 for further details.

Once an SCell has been selected on each relevant frequency, the gNodeB chooses which SCell frequency(s) to use for initial SCell selection. If there is more than one possibility, then the gNodeB uses the frequencies that maximize the potential throughput (by matching the UE supported band combinations with the available CA frequencies). The throughput estimate considers factors such as effective carrier bandwidth (considering ESS, if configured), the number of MIMO layers, and the maximum modulation scheme.

The throughput estimate is either downlink or uplink, depending on the value of CaCellProfileUeCfg . servingCellSelectionPolicy , as follows:

- servingCellSelectionPolicy = PRIORITIZE_DL_THP The downlink throughput is used. If the feature Advanced Multi-Layer Coordination is enabled, then the throughput estimate also considers the cell load.

- servingCellSelectionPolicy = PRIORITIZE_UL_THP The uplink throughput is used. If the feature Uplink-Aware Advanced Multi-Layer Coordination is enabled, then the throughput estimate also considers the cell load.

- servingCellSelectionPolicy = PRIO_DL_THP_THEN_PCELL_UL_THP The downlink throughput is used first, followed by the uplink throughput. If the features Advanced Multi-Layer Coordination and Uplink-Aware Advanced Multi-Layer Coordination are enabled, then the throughput estimates also consider the cell load.

The gNodeB then configures the UE with the chosen SCells via RRC signaling. A given NR SCell is configured either for DL only, or for both DL and UL.

UL SCell configuration depends on CaCellProfileUeCfg . ulCaConfigurationMode as follows:

<!-- page: 27 -->

- If ulCaConfigurationMode = IMMEDIATE , then the UL SCell is configured immediately.

- If ulCaConfigurationMode = DELAYED_ALWAYS , then UL SCell configuration is delayed until the event A1PR is received, confirming the UL coverage.

- If ulCaConfigurationMode = DELAYED_CONDITIONAL , then configuration of the UL SCell depends on whether a UE TX power reduction is needed. A power reduction is needed if the power class supported by the UE for the new UL band combination is lower power than the currently used power class.

̶

- If a power reduction is not needed, then the UL SCell is configured immediately, without need for A1PR or A2PR measurements.

̶

- If a power reduction is needed, then the SCell(s) are configured for DL only, and the UE is configured with a PCell Event A1 measurement (A1PR) to detect when coverage is good enough to configure the UL. When the A1PR is received, the UL SCell is configured, and the A1PR measurement is replaced with an A2PR measurement to detect if PCell coverage becomes poor enough to deconfigure the UL SCell. This procedure is illustrated in Figure 4-11.  For the parameters and trigger level formulas used for A1PR and A2PR, see Section 11.2.7.

![Figure on page 27](5G_Mobility_and_Traffic_Management_Guideline_images/page_027_image_002.png)

Figure 4-11 - UL SCell Configuration Involving a Power Reduction (4CC NR SA example)

<!-- page: 28 -->

̶

In FR1 CA, the UE is configured with additional layer 3 measurements at SCell configuration to facilitate SCell activation and deactivation (Event A1/A2) and to enable intra-frequency SCell change (Event A6). For SA, the Event A2 triggers SCell deactivation but not SCell deconfiguration. For NSA, the Event A2 can also trigger SCell deconfiguration, as described in the feature description for NR Intelligent SCell Management in CPI.

In FR2 CA, no additional layer 3 measurements are set up when SCells are configured, noting that intra-frequency SCell change is not supported in the current software revision for FR2.

In SA, PCell mobility triggers the old SCell(s) to be deconfigured in the source PCell and new SCell(s) to be selected for the target PCell.

Similarly, PSCell mobility in EN-DC or NR-DC triggers the old SCell(s) to be deconfigured in the source PSCell and new SCell(s) to be selected for the target PSCell.

For further information refer to the FR1 CA feature descriptions NR DL Carrier Aggregation and NR UL Carrier Aggregation, and in the FR2 CA feature descriptions NR 8CC DL Carrier Aggregation High-Band and NR Uplink Carrier Aggregation High-Band .

### 4.6.3 SCell Activation and Deactivation

Configured SCells are dynamically activated and deactivated on lower layers via MAC signaling. When an SCell is active, the UE continuously monitors PDCCH for incoming data transmissions, and reports channel quality information to the gNodeB. This consumes UE power even if data is not transmitted to the UE. To reduce UE power consumption and enable more efficient use of radio resources, the gNodeB therefore activates and deactivates the SCell, according to signal strength and optionally user traffic demands in FR1, and user traffic demands alone in FR2.

#### 4.6.3.1 SCell Activation and Deactivation in FR1

In FR1 CA, SCells are activated and deactivated using layer 3 measurements (Event A1 and A2 respectively). Additionally, if the feature Data-Aware Carrier Management (DACM) is enabled, activation and deactivation depend on the RLC user buffer sizes in the downlink and/or the uplink, and the estimated number of slots needed to empty the buffer. This improves UE battery life when traffic is intermittent.

Activation and deactivation are configured per UE group and operate as follows:

- If Data-Aware Carrier Management (DACM) is not enabled:

̶

- At initial blind SCell Configuration, all configured SCells are activated

- Following this, SCells are deactivated and activated using layer 3 measurements (Event A2 and A1 respectively), as described in Section 11.2.7.

- If Data-Aware Carrier Management (DACM) is enabled:

̶

- At initial blind SCell configuration:

<!-- page: 29 -->

̶

- If the DL buffer exceeds the activation threshold, then all SCells are activated

- If only the UL buffer exceeds the threshold, then only the SCell configured for UL is activated

- Following this the SCells are deactivated and activated using a combination of the layer 3 measurements (Event A2 and A1 respectively) and the buffer criteria. Activation occurs if the coverage is good (Event A1) and the amount of data in the buffer exceeds the activation threshold in either the uplink or downlink. Deactivation occurs if coverage degrades (Event A2) or if both the uplink and downlink buffers fall below the deactivation thresholds. The thresholds are set separately in the DL and UL using the attributes in CaSCellHandlingUeCfg .

- Deactivation and activation are also governed by prohibit and delay timers to avoid excessive transitions due to rapid traffic fluctuations, as described in the feature description for Data-Aware Carrier Management .

̶

Additionally, after initial SCell configuration, if the UE is unable to report any layer 3 measurements on an SCell for a supervision time, for example because the UE has no coverage from the SCell, then the gNodeB acts as follows:

**· NSA**

When the supervision time expires, the gNodeB deactivates the SCell. However, the SCell remains configured, unless the feature NR Intelligent SCell Management is used to deconfigure the SCell when the time expires.

The supervision time is: 680 ms + timeToTrigger1, where

̶

timeToTrigger1 is either MAX( CaCellMeasProfileUeCfg.rsrpSCellCoverage.timeToTrigger , CaCellMeasProfileUeCfg.rsrpSCellCoverage.timeToTriggerA1 ) or MAX( CaCellMeasProfileUeCfg.rsrqSCellCoverage.timeToTrigger , CaCellMeasProfileUeCfg.rsrqSCellCoverage.timeToTriggerA1 ) or MAX( CaCellMeasProfileUeCfg.sinrSCellCoverage.timeToTrigger , CaCellMeasProfileUeCfg.sinrSCellCoverage.timeToTriggerA1 ) depending on the trigger quantity CaCellMeasProfileUeCfg.sCellCoverageTriggerQuantity .

**· SA**

When the supervision time expires, the gNodeB considers the SCell coverage 'unknown' and deactivates it, but leaves it configured.

The supervision time is: 1500 ms + MAX(timeToTrigger1, timeToTrigger2), where

̶

- timeToTrigger1 is as described above

̶

- timeToTrigger2 is

TrStSaCellProfileUeCfg.rsrpPCellCandidate.timeToTrigger , and applies only if UL CA is configured and MLC is enabled.

<!-- page: 30 -->

All active SCells are deactivated if the UE reports UAI overheating. When overheating ceases, SCells can be reactivated. For more information, see Section 10.3.21.

After an intra-frequency SCell change, the new SCell is activated immediately if DACM is not enabled, or according to the buffer status in the downlink and/or the uplink if DACM is enabled.

For further information on activation and deactivation in FR1, refer to the feature description for NR DL Carrier Aggregation in CPI.

#### 4.6.3.2 SCell Activation and Deactivation in FR2

In FR2 CA, the feature Dynamic Component Carrier Management enables the automatic deactivation and reactivation of SCells based on data traffic activity. Refer to the feature description in CPI for more information.

### 4.6.4 SCell Scheduling

After an SCell is activated, data can be scheduled on it. The decision to schedule data on a particular SCell is made per TTI. Scheduling is handled differently on FR1 and FR2.

- In FR1 CA , downlink data is sent either on a single component carrier (CC) or on multiple CCs as shown in Table 4-6. In the context of this table, the following definitions apply:

̶

- A local cell is a cell on the same capacity module as the PCell (SA) or PSCell (NSA)

̶

- An external cell is a cell that is connected via an E5 link using the Advanced RAN Coordination feature; so any cell that is not on the same capacity module as the PCell (SA) or PSCell (NSA).

Table 4-6 - Scheduling data in FR1

<!-- page: 31 -->

| Connectivity   | Setting of pCellDlDataOffload   | Data in DL Buffer > caBufferSplitThresh ?   | Scheduling Outcome *                                                                                                                                                                                                                                                                                                                                                                                                                    |
|----------------|---------------------------------|---------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| SA             | false                           | No                                          | All DL data is sent on a single local cell, which is either the PCell or an activated SCell, in the following preference order: 1. The local cell that has the largest pipe size and does not have a pending retransmission (either the PCell or a local SCell), if there is one. 2. The local cell that has the largest pipe size (either the PCell or a local SCell).                                                                 |
| SA             | false                           | Yes                                         | DL data is split between the PCell and all activated SCell(s) in proportion to pipe size.                                                                                                                                                                                                                                                                                                                                               |
| SA             | true **                         | No                                          | All DL data is sent on the cell that has the largest pipe size (either the PCell or an activated local or external SCell).                                                                                                                                                                                                                                                                                                              |
| SA             | true **                         | Yes                                         | DL data is split between the PCell and all activated SCell(s) in proportion to pipe size.                                                                                                                                                                                                                                                                                                                                               |
| NSA            | -                               | No                                          | All DL data is sent on a single cell, which is either the PSCell or an activated SCell, in the following preference order: 1. The local cell that has the largest pipe size and does not have a pending retransmission (either the PSCell or a local SCell), if there is one. 2. The external SCell with the largest pipe size, if there is one. 3. The local cell that has the largest pipe size (either the PSCell or a local SCell). |
| NSA            | -                               | Yes                                         | DL data is split between the PSCell and all activated SCell(s) in proportion to pipe size.                                                                                                                                                                                                                                                                                                                                              |

* For SA, any traffic that has SchedulingProfile.dlCaSchedulingMode = PCELL_ONLY is always sent on the PCell. SRB traffic is always carried on the PCell (SA) or PSCell (NSA). Before SCell(s) are activated, all traffic is sent on the PCell (SA) or PSCell (NSA).

** The attribute pCellDlDataOffload is introduced by the feature NR Carrier Aggregation Data Steering . It impacts SA connections only and can be set to true on low-band (NR FDD) cells only.

If the SCell is on an ESS carrier, then the gNodeB is aware of dynamic variations in the available NR resources and can schedule them accordingly. SCell scheduling may be temporarily suspended in DL if the UE is at risk of overheating, and resumed when the UE has cooled. The UE signals the thermal state via known channel state information signatures. During this procedure, the SCells are kept activated; only scheduling is suspended.

- In FR2 CA , DL data is transmitted on multiple CCs if the data buffer is larger than a predefined threshold. In the UL, the PSCell is always scheduled and the SCell is scheduled only if the radio quality and the UE power headroom are sufficient. The feature CQI-Based UE Energy Efficiency Enhancement may temporarily suspend SCell scheduling in both UL and DL if the UE is at risk of overheating, and resume scheduling when the UE has cooled. The UE signals the thermal state via known channel state information signatures. During this procedure, the SCells are kept activated; only scheduling is suspended.

<!-- page: 32 -->

Data for a particular CC is scheduled using PDCCH resources on that CC. Cross-carrier scheduling is not supported in the current release. Uplink control information, including L1 feedback for all CCs, is transmitted on the primary cell.

For further information on scheduling for FR1 refer to: NR DL Carrier Aggregation , NR UL Carrier Aggregation and NR Carrier Aggregation Data Steering. For FR2, refer to CQIBased UE Energy Efficiency Enhancement , NR 8CC DL Carrier Aggregation High-Band and NR Uplink Carrier Aggregation High-Band .

### 4.6.5 Carrier Aggregation Capabilities and Features

Carrier Aggregation can be supported with all CCs allocated on either the same Baseband Unit (Intra-BB) or with CCs deployed on two different Baseband units (Inter-BB). The two basebands are interconnected with the feature Advanced RAN Coordination (FAJ 121 5271) over a fast IDLe link using an Ericsson proprietary interface. This interconnection can occur between basebands on the same or different physical sites, for flexible deployments. Refer to the CPI feature description Advanced RAN Coordination for more information.

Many CA combinations are supported, including FDD only, TDD only and a mix of FDD and TDD. For details of the supported combinations, refer to the following feature descriptions in CPI:

- NR DL Carrier Aggregation

- NR DL Carrier Aggregation for Coverage Extension

- TDD PCell Support for DL Carrier Aggregation Low/Mid-Band

- NR 3CC DL Carrier Aggregation

- NR 4CC DL Carrier Aggregation

- NR 5CC DL Carrier Aggregation

- NR 6CC DL Carrier Aggregation

- NR Uplink Carrier Aggregation

- NR 4CC DL Carrier Aggregation High-Band

- NR 8CC DL Carrier Aggregation High-Band

- Mixed Bandwidth Support for Carrier Aggregation High-Band

- NR Uplink Carrier Aggregation High-Band

In FR1, NRCellRelation . sCellCandidate defines the supported transmission directions and is set to = ALLOWED (to enable both DL and UL) or = ONLY_ALLOWED_FOR_DL (to enable DL only).

In FR2, NRSectorCarrier.txDirection defines the supported transmission directions and is set to DL (to enable DL only) or DL_AND_UL (to enable both DL and UL).

CA capabilities can be modified (restricted) at the UE group level using, for example, the following attributes in each instance of CaCellProfileUeCfg :

- blockedSCellFreqList - arfcnValueNRDl values that are not allowed as SCells

- maxDlCcAllowed - maximum number of DL CCs allowed

<!-- page: 33 -->

̶

- if maxDlCcAllowed is set to = 1, then DL and UL CA are disabled

- maxUlCcAllowed - maximum number of UL CCs allowed

̶

- if maxUlCcAllowed is set to = 1, then UL CA is disabled

- ulTxSwitchingAllowed - enables/disables uplink TX switching. Setting to false disables it, regardless of UE capability.

This functionality can be used to disable CA for UEs with a VoNR bearer; refer to the 5G Voice SA RAN Solution Guideline for details.

Refer to respective CPI feature description for more information on supported inter-BB scenarios and maximum supported Advanced RAN Coordination partners.

UEs that are not capable of SA CA in low and mid bands (FR1) can be placed in a UE group so that they can be treated differently (for example, given different mobility settings). Such UEs are identified using the parameter pCellOnlyUe in the selectionCriteria of the relevant UE group definition. For more information, refer to the feature description for Flexible UE Grouping for Limited Capability UEs in CPI.

## 4.7 Measurement Quantities

To assist with managing mobility, 5G UEs can make measurements of both the NR and LTE radio environments. In idle mode (and in RRC_INACTIVE state in SA), UEs use the results of the measurements to make mobility decisions autonomously. In RRC_CONNECTED state, UEs send the results to the network, which makes the decisions.

The LTE measurements are unchanged from legacy LTE and are described in the LTE Mobility and Traffic Management Guideline .

The NR measurements are standardized in 3GPP TS 38.215. Six radio signal measurement quantities are defined. Three are based on measurements of the secondary synchronization signal (which is part of the SSB block) and three are based on the CSI reference signal (CSI-RS). The measurement quantities for NR are called SS-RSRP, SSRSRQ, SS-SINR, CSI-RSRP, CSI-RSRQ and CSI-SINR.

In the current software release, the NR measurement quantities that are used for triggering mobility decisions are SS_RSRP, SS_RSRQ and SS_SINR (sometimes abbreviated to RSRP, RSRQ and SINR). These are explained below.

Additionally, the radio signal quality can be measured in the uplink by the base station. The uplink measurement quantity used by the gNodeB in NR is uplink SINR (UL_SINR).

### 4.7.1 SS_RSRP: Synchronization Signal - Reference Signal Received Power

The NR downlink is divided into a time-frequency grid of slots and resource blocks, which are further divided into a time-frequency grid of resource elements. A pre-defined subset of these resource elements is used to carry the secondary synchronization signal.

<!-- page: 34 -->

SS_RSRP is defined as the linear average over the power contributions (in [W]) of the resource elements that carry secondary synchronization signals. In other words, SS_RSRP is the average received power of a single reference signal resource element. SS_RSRP is measured by the UE and is reported to the network via measurement reports when required.

SS_RSRP indicates signal strength but does not strongly indicate signal quality. A user close to multiple cells may have strong SS_RSRP but a poor-quality signal (low downlink SS_SINR) due to interference, potentially leading to a degraded experience. SS_RSRP has a reporting range from -156 dBm to -31 dBm. This is greater than the range in LTE, to accommodate additional variations due to beamforming.

SS_RSRP is similar to RSRP in LTE and is used for similar purposes. However, the values are not necessarily directly comparable, due to differences in the link budgets and power configurations of the two systems, and the use of beamforming.

### 4.7.2 SS_RSRQ: Synchronization Signal - Reference Signal Received Quality

SS_RSRQ measures the ratio of SS_RSRP to all downlink received power. It is calculated as (N * SS_RSRP) / NR carrier RSSI, where N is the number of resource blocks in the NR carrier RSSI measurement bandwidth. The measurements of SS_RSRP and RSSI are made over the same set of resource blocks in the frequency domain. SS_RSRQ has a reporting range from -43 dB to +20 dB.

SS_RSRQ is intended to represent the downlink signal quality. However, since the denominator (RSSI) includes power from all sources, SS_RSRQ is impacted not only by other cell interference, external interference and thermal noise (which all degrade signal quality) but also by the traffic load on the serving cell (which does not degrade signal quality). Furthermore, the measured RSSI depends on the UE implementation, particularly in idle mode. This means that two UEs in identical radio and load conditions may measure different RSRQ values.

Finally, when beamforming is used, the impact of traffic load on measured RSSI varies depending on whether the measuring UE is covered by any transmitting beams or not, including traffic beams serving the UE. SS_RSRQ also depends on the configuration of SSB and the number of symbols and time over which RSSI is measured, see 3GPP 36.214 and 38.215. These impacts make it difficult to determine suitable triggering levels for SS_RSRQ and it is therefore not recommended as a triggering quantity.

### 4.7.3 SS_SINR: Synchronization Signal - Signal to Interference Plus Noise Ratio

SS_SINR measures the signal to interference plus noise ratio on the secondary synchronization signal symbols (SSS). It is defined as the linear average over the power contribution (in Watts) of the resource elements carrying SSS divided by the linear average of the noise and interference power contribution (in Watts) over the resource elements carrying SSS within the same frequency bandwidth, see 3GPP 38.215.

<!-- page: 35 -->

Unlike SS_RSRQ, SS_SINR is not affected by the traffic load on the serving cell, which makes it a more stable and reliable measure of signal quality.

### 4.7.4 UL_SINR: Uplink Signal to Interference plus Noise Ratio

Unlike the downlink measurement quantities, UL_SINR is not standardized by 3GPP. It is measured by the gNodeB, based on uplink transmissions from the UE to the NR serving cell. The measured SINR is normalized to the estimated maximum achievable uplink SINR, which is the SINR that would be received if the UE had transmitted with maximum power on one PRB. This makes it independent of the number of PRBs used for the uplink transmission.

As UL_SINR is measured by the gNodeB, it does not require a measurement event to be configured in the UE itself, and it does not require measurement gaps.

## 4.8 Connected Mode Measurements

Connected mode measurements are configured in the UE via dedicated RRC messages, which instruct the UE to set up, evaluate and report a measurement event. For SA, the measurements are configured by the gNodeB. For NSA, some measurements are configured by the eNodeB and some by the gNodeB. When an event is triggered, the UE sends a measurement report to the network which can then trigger a mobility action.

Measurements on NR cells are defined in 3GPP TS 36.331 and TS 38.331, and contain several elements in common: a triggering quantity, a filtering coefficient, a threshold value, a hysteresis, and a timer before triggering.

UEs in connected mode are required to perform any configured measurements when the RSRP drops below sMeasure . There are two sMeasure attributes, one configured in the eNodeB and the other in the gNodeB. See Section 11.2.1 for further information.

### 4.8.1 Triggering Quantity

In the current software release, SS_RSRP, SS_RSRQ, SS_SINR and UL_SINR can be used for triggering mobility and connectivity procedures:

- SS_RSRP is the default and is recommended for all measurement events on NR frequencies.

- SS_SINR can be added if a measure of signal quality is required.

- SS_RSRQ is not recommended as a triggering quantity, for the reasons detailed in Section 4.7.2.

- UL_SINR can be added if a measure of uplink signal quality is required.

<!-- page: 36 -->

### 4.8.2 Filter Coefficients

All connected mode UE measurements are filtered at both Layer 1 and Layer 3 by the UE before event evaluation and reporting.

The Layer 1 filter is UE implementation specific.

The Layer 3 filter is a simple exponential filter with a factor of 1/(2 k/4 ), where k is the filter coefficient as defined in 3GPP 36.331 and 38.331:

- A value of 0 indicates that the measured result is only Layer 1 filtered

- A value of 4 (default) corresponds to a weighting of 1/(2 4/4 ) = 0.5, that is, the next filtered value is the average of the new measurement and the last filtered value

- A value of 8 corresponds to a weighting of 0.25, that is, the next filtered value is the weighted sum of 25% of the new measurement and 75% of the last filtered value

Larger values of k make the filter less responsive, reducing the impact of momentary fading at the cost of a longer time-to-trigger the event.

The value of k is set as follows:

- For the Events B1 and B2 that are configured by the eNodeB for measuring NR, a fixed value of k = 4 is used for both SS_RSRP and SS_RSRQ.

- For measurements configured by the gNodeB, k is set with the following attributes in UeMCCellProfile :

̶

- filterCoefficientEUtraRsrp for LTE RSRP measurements

̶

- filterCoefficientEUtraRsrq for LTE RSRQ measurements

̶

- filterCoefficientEUtraSinr for LTE SINR measurements

- filterCoefficientNrRsrpLow for NR ' low ' frequency SS_RSRP measurements

- filterCoefficientNrRsrpHigh for NR ' high ' frequency SS_RSRP measurements

- filterCoefficientNrRsrqLow for NR ' low ' frequency SS_RSRQ measurements

- filterCoefficientNrRsrqHigh for NR ' high ' frequency SS_RSRQ measurements

- filterCoefficientNrSinrLow for NR ' low ' frequency SS_SINR measurements

- filterCoefficientNrSinrHigh for NR ' high ' frequency SS_SINR measurements

̶

̶

̶

̶

̶

̶

<!-- page: 37 -->

For the NR filters, the 'High' attributes are used for measuring frequencies whose ARFCN is higher than UeMCCellProfile.freqClassificationThreshold . Otherwise the 'Low' attributes are used.

### 4.8.3 Threshold, Hysteresis and Time-To-Trigger

Figure 4-12 provides a generic example to explain how the event threshold, hysteresis and time-to-trigger together control event triggering.

In this example, the event is triggered by a rising signal. Alternatively, events can be triggered by a falling signal, or by a combination of a rising signal and a falling signal; refer to Section 4.8.5 for details.

On NR, the downlink measured signal quantity can be SS_RSRP, SS_RSRQ or SS_SINR (sometimes abbreviated to RSRP, RSRQ and SINR), depending on the event. In the uplink it is UL_SINR.

On LTE, the downlink measured signal quantity can be RSRP, RSRQ or SINR.

![Figure on page 37](5G_Mobility_and_Traffic_Management_Guideline_images/page_037_image_002.png)

Figure 4-12 - Event Triggering Process

Notes for Figure 4-12:

- The undulating line represents the signal after filtering has been applied.

- The threshold and the hysteresis combine to determine the 'entering level' and the 'leaving level' .

<!-- page: 38 -->

- The 'entering level' in this example is equal to the threshold plus the hysteresis. When the signal is above the entering level continually for timeToTrigger the event is 'entered' and the first measurement report is ' triggered '. For a downlink measurement, the report is sent from the UE to the network. For an uplink measurement, the report is sent internally within the node.

- Once the event has been entered, the report is re-sent every reportInterval, up to a total of reportAmount times, or until the event is 'left'.

- The 'leaving level' in this example is equal to the threshold minus the hysteresis. When the signal is below this level continually for timeToTrigger the event is 'left'. This can trigger a reportOnLeave to be sent, but this is not normally configured. No further reports are sent once the event has been left.

- The entering level and the timeToTrigger together control when the event is first sent. If the threshold and hysteresis are changed but the entering level remains the same, then the first report is sent at the same point.

- A shorter timeToTrigger results in the event being entered more easily, and more reports being sent. timeToTrigger is typically set between 40 ms and 640 ms depending on the event.

### 4.8.4 Measurement Gaps - General

Measurement gaps are periods of time when the UE suspends reception and transmission on serving frequency(s), to perform measurements on other frequency(s). Serving frequencies are those used for the PCell, PSCell and SCell, where configured.

Depending on the UE capability, measurements of non-serving frequencies can be performed with or without gaps (gapless measurement). Gapless measurements improve the end user experience since there is no reduction in user throughput while measuring.

![Figure on page 38](5G_Mobility_and_Traffic_Management_Guideline_images/page_038_image_002.png)

Figure 4-13 - Measurement Gaps & Gapless Measurement

<!-- page: 39 -->

Measurement gaps can be configured either per UE, or per frequency range (FR), known as independent measurement gaps. The difference is shown in Figure 4-14. Note that in this figure, FR1 and FR2 may contain both serving frequencies and other frequencies, potentially of different RATs. For example, with per UE gaps, measurement on any frequency in FR1 requires a gap in any serving frequencies in both FR1 and FR2.

![Figure on page 39](5G_Mobility_and_Traffic_Management_Guideline_images/page_039_image_002.png)

Figure 4-14 - Independent Measurement Gaps

If multiple measurements are conducted in parallel (typically the case when searching for a candidate) and any of them requires a gap, then a gap is configured. For per UE gaps, only one gap is configured. For per FR gaps, at most two gaps are configured, one per FR.

Whether measurement gaps are configured depends on:

- The RAT(s) that the UE is connected to

- The RAT and 3GPP frequency range (FR) being measured

- Whether the UE reports that it supports independentGapConfig , as indicated by the IE independentGapConfig in UE capability.

Note, however, that most UEs can perform FR2 B1 measurements (for EN-DC setup) and FR2 A4 measurements (for NR-DC setup) without configuring measurement gaps (gapless measurements), even though they do not indicate this by including the independentGapConfig IE in the UE capability. For such UEs, unnecessary measurement gaps can be avoided by disabling measurement gaps for FR2, as described in the following sections.

In NR SA, the UE can, optionally, indicate that it does not require gaps for measuring in a particular band, using the IE needForGapsInfoNR.

<!-- page: 40 -->

In addition to the sections below, more information on measurement gaps can be found in Measurement Gap-Aware NR Scheduling in CPI.

#### 4.8.4.1 Measurement Gaps - NSA

Whether B1 measurement gaps are used for EN-DC SN addition depends on:

- The setting of EUtranCellFDD/TDD.endcB1MeasGapConfig , which has the following values: 0 ( ENABLED ), 1 ( DISABLED ), 2 ( DISABLED_FR1 ) and 3 ( DISABLED_FR2 )

̶

- The cell level setting of endcB1MeasGapConfig can be overridden at the subscriber group level using the attribute EndcUserProfile.endcB1MeasGapConfigOverride .

̶

- UEs are assigned to subscriber groups using the feature Advanced Subscriber Group Handling (ASGH), as described in Section 10.2.5.

- Whether the UE reports that it supports independentGapConfig

- Whether the measured frequencies include FR1 and/or FR2

Figure 4-15 summarizes the possible outcomes.

![Figure on page 40](5G_Mobility_and_Traffic_Management_Guideline_images/page_040_image_002.png)

Figure 4-15 - Configuration of Gaps for EN-DC B1 Measurements

Note however, that if gapless measurements are configured for a particular FR, but the UE does not support gapless measurements on that FR, then the UE will not be able to perform the B1 measurements or set up EN-DC on that FR.

When a UE has an EN-DC connection, the need for measurement gaps depends on the measured frequency range and on whether the UE reports that it supports independentGapConfig , as shown in Table 4-7.

<!-- page: 41 -->

Table 4-7 - Measurement gaps for a UE with an EN-DC connection

| PCell location   | PSCell location   | Non-serving frequency being measured   | Gaps required on FR1? (on both LTE & NR if used)           | Gaps required on FR2?                                      |
|------------------|-------------------|----------------------------------------|------------------------------------------------------------|------------------------------------------------------------|
| FR1              | FR1               | FR1 (for PCell or PSCell mobility)     | Yes                                                        | NA                                                         |
| FR1              | FR1               | FR2 (for PSCell mobility)              | Yes, unless UE indicates support of independent gap config | NA                                                         |
| FR1              | FR2               | FR1 (for PCell or PSCell mobility)     | Yes                                                        | Yes, unless UE indicates support of independent gap config |
| FR1              | FR2               | FR2 (for PSCell mobility)              | Yes, unless UE indicates support of independent gap config | Yes                                                        |

Table 4-7 - Measurement gaps for a UE with an EN-DC connection

#### 4.8.4.2 Measurement Patterns - NSA

In the eNodeB, the measurement gap pattern is controlled with the attribute EUtranCellFDD/TDD.measGapPattern for a UE that is not configured with EN-DC and EUtranCellFDD/TDD.measGapPattEndc for a UE that is configured with EN-DC.

The supported measurement gap patterns for both LTE and EN-DC are 40 and 80 ms periodicity. To minimize the throughput reduction caused by the measurement gaps, set measGapPattern and measGapPattEndc = 1 (80 ms periodicity). An 80 ms periodicity has approximately half the throughput reduction of a 40 ms periodicity, while 40 ms has more opportunities to measure.

#### 4.8.4.3 Measurement Gaps & Patterns - SA

In NR SA, gaps are used for measuring non-serving frequencies as follows:

- For measuring LTE frequencies, gaps are always used

- For measuring non-serving NR frequencies within FR1, gaps are used unless GNBCUCPFunction.nrNeedForGapsSupported = true and the UE supports measurement gap requirement information reporting. In this case, the UE dynamically informs the network whether it requires gaps on the relevant NR bands using needForGapsInfoNR , at RRCReconfigurationComplete and RRCResumeComplete . Need for gaps reporting is stopped while NR-DC is configured.

- For measuring FR2 frequencies for NR-DC SN addition using A4, gaps are not configured if any of the following conditions are fulfilled:

̶

- UE reports that it supports independentGapConfig, or

- UE does not report support of independentGapConfig and CapabilityHandlingUeCfg . gaplessFr2InterFreqMeasSupp = true , or

̶

<!-- page: 42 -->

̶

- UE reports that it does not require gaps to measure frequencies in the given band, using needForGapsInfoNR

If none of these conditions are fulfilled, measurement gaps are configured using 'Per UE gap'. This can be configured per UE group, and the gap configuration can change if the UE group changes.

The measurement gap patterns supported for NR SA are:

|   Gap Pattern ID | Measurement Gap Length   | Measurement Gap Repetition Period   | Used for Measuring                                                                                                                                                    |
|------------------|--------------------------|-------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                0 | 6 ms                     | 40 ms                               | - LTE frequencies for EPS fallback                                                                                                                                    |
|                1 | 6 ms                     | 80 ms                               | - LTE frequencies for purposes other than EPS fallback - NR FR1 non-serving frequencies - NR FR2 non-serving frequencies for UEs that do not support independent gaps |
|                2 | 3 ms                     | 40 ms                               | - LTE frequencies for EPS fallback                                                                                                                                    |
|                3 | 3 ms                     | 80 ms                               | - LTE frequencies for purposes other than EPS fallback - NR FR1 non-serving frequencies                                                                               |
|               14 | 5.5 ms                   | 80 ms                               | - NR FR2 non-serving frequencies for UEs that support independent gaps                                                                                                |

Where there is a choice between a 3 ms gap pattern and a 6 ms gap pattern, the 3 ms pattern is chosen if all of the following apply:

- UE indicates support for a 3 ms gap pattern (2 or 3) in supportedGapPattern or supportedGapPattern-NROnly-r16

- A 3 ms gap completely covers the SMTC window specified in all of the measurement objects (for NR measurements)

- The 3 ms gap allows the UE to measure LTE synchronization signals (for LTE measurements)

- The SFN of the source cell aligns with the SFN of the target cells (for LTE measurements)

- The attribute GNBDUFunction.MeasGapLengthMode is set to a value that allows a 3 ms gap length, as follows:

̶

- ALL_3MS - 3 ms gap length is configured for both non-serving FR1 and LTE measurements, if possible.

̶

- NR_FR1_3MS - 3 ms gap length is configured for only non-serving FR1 measurements, if possible.

- EUTRAN_3MS - 3 ms gap length is configured for only LTE measurements, if possible.

̶

- OFF - 6 ms gap length is always configured.

̶

<!-- page: 43 -->

For more information, refer to the feature description for Measurement Gap-Aware NR Scheduling in CPI.

### 4.8.5 Measurement Events

The event-based measurements associated with 5G, both SA and NSA, are: A1, A2, A3, A5, A6, B1 and B2. These events are described in detail in the following sections and are summarized in Table 4-8.

Measurements which are not associated with 5G, for example legacy LTE measurements, are described in the LTE Mobility and Traffic Management Guideline.

Note that the UE capability for simultaneous measurements is limited; see 3GPP TS 36.133 Section 8.2 and 3GPP TS 38.133 Section 9.1.4.

#### 4.8.5.1 Event A1: Serving Becomes Better than Threshold

Event A1, shown in Figure 4-16, is used to detect good NR serving cell coverage. The measured signal quantity depends on what the event is used for. In the downlink, the possible quantities are SS_RSRP, SS_RSRQ or SS_SINR. In the uplink the measured quantity is UL_SINR.

![Figure on page 43](5G_Mobility_and_Traffic_Management_Guideline_images/page_043_image_002.png)

Figure 4-16 - Event A1 - Serving Becomes Better than Threshold

Event A1 is used for the following purposes:

- For MCPC in SA, Event A1 Leaving Search Zone is used to detect good NR PCell coverage, to stop the search for a better cell, as described in Section 8.3.7. See Section 11.2.7.4 for the parameters and trigger level formulas.

- For MCPC in NSA, Event A1 Leaving Search Zone is used to detect good NR PSCell coverage, to stop the search for a better cell, as described in Section 6.3.2. See Section 11.2.9 for the parameters and trigger level formulas.

<!-- page: 44 -->

̶

- For DL CA in FR1, for both SA and NSA, Event A1 is used to detect good NR SCell coverage and triggers SCell activation on the MAC layer. See Section 11.2.7 for the parameters and trigger level formulas. It is not used for CA in FR2.

- In FR1 SA, configuring an SCell for UL can lead to a reduction in the maximum UE power if the power class supported by the UL band combination is lower than the currently used power class. If so, an A1 measurement (CA A1PR) is used to confirm PCell coverage and trigger configuration of the SCell for UL. See Section 11.2.7.4 for the parameters and trigger level formulas.

- In SA, for Multi-Layer Coordination (MLC):

̶

- Event A1 (MLC A1UL) is used to detect whether an SCell that is configured for DL use has good enough coverage to be configured for UL use. See Section 11.2.11.1 for the parameters and trigger level formulas.

̶

- Event A1 (MLC A1PR) is used if an MLC SCell reselection would require a UE power class reduction due to the UL CA band combination. The A1 event checks that the PCell coverage is good enough to avoid entering the MCPC search zone when the power class reduction occurs. See Section 11.2.11.2 for the parameters and trigger level formulas.

- Event A1 (MLC A1UL 2L) is used to determine whether the current PCell coverage is good enough to support 2-layer uplink transmission, when the best candidate cell set involves an MLC SCell reselection to 2-layer uplink transmission on the current PCell (whose UL coverage is unknown). See Section 11.2.11.2 for the parameters and trigger level formulas.

#### 4.8.5.2 Event A2: Serving Becomes Worse than Threshold

Event A2, shown in Figure 4-17, is used to detect poor serving cell coverage. The measured signal quantity depends on what the event is used for. In the downlink, the possible quantities are SS_RSRP, SS_RSRQ or SS_SINR. In the uplink the measured quantity is UL_SINR.

<!-- page: 45 -->

![Figure on page 45](5G_Mobility_and_Traffic_Management_Guideline_images/page_045_image_001.png)

Figure 4-17 - Event A2 - Serving Becomes Worse than Threshold

Event A2 is used for the following purposes:

- For MCPC in SA:

̶

- Event A2 Entering Search Zone is used to detect poor NR PCell coverage, and trigger entry to the search zone, where the UE searches for better cells on other frequencies. See Section 8.3.7 for the procedure and Section 11.2.8.2 for the parameters and trigger level formulas.

̶

- Event A2 Critical Coverage is used detect critical NR PCell coverage, and trigger handover or release-with-redirect to either NR or LTE. See Section 11.2.8.3 for the parameters and trigger level formulas.

- For MCPC in NSA:

̶

- Event A2 Entering Search Zone is used to detect poor NR PSCell coverage, and trigger entry to the search zone, where the UE searches for better cells on other frequencies. See Section 6.3.2 for the procedure and Section 11.2.9 for the parameters and trigger level formulas.

̶

- Event A2 Critical Coverage is used to detect critical NR PSCell coverage, and trigger PSCell change to a stored lower priority candidate, or trigger SN release. See Section 6.3.4 for the procedure and Section 11.2.9 for the parameters and trigger level formulas.

- For NR-DC in SA, Event A2 Critical Coverage is used to detect critical NR PSCell coverage (NR-DC), and trigger SN release. See Section 8.3.8 for the procedure and Section 11.2.16 for the parameters and trigger level formulas.

- For DL CA in NSA and SA, in FR1, Event A2 is used to detect poor NR SCell coverage, which triggers SCell deactivation at the MAC layer. See Section 11.2.7 for the parameters and trigger level formulas. Event A2 is not used for CA in FR2.

<!-- page: 46 -->

- For voice fallback in SA, Event A2 Critical is used to detect poor NR PCell coverage, which triggers a blind release-with-redirect to LTE, via the feature EPS Fallback for IMS Voice . See Section 8.3.13.2 for the procedure and Section 11.2.5 for the parameters and trigger level formulas.

- For emergency call fallback in SA, Event A2 Critical is used to detect poor NR PCell coverage, which triggers a blind release-with-redirect to LTE, via the feature NR Emergency Fallback to LTE . See Section 8.3.14.1 for the procedure and Section 11.2.5 for the parameters and trigger level formulas.

- For UL CA in FR1 SA, Event A2 Power Reduction (CA A2PR) is used to detect poor NR PCell coverage in DL to deconfigure UL CA when the UE has maximum transmit power reduction due to a power class change. See Section 11.2.7.5 for the parameters and trigger level formulas.

- For MLC in SA, Event A2 (MLC A2UL) is used to detect an SCell that is configured for DL use has poor coverage and is therefore not a valid UL SCell candidate for MLC. See Section 11.2.11.3 for the parameters and trigger level formulas.

- For Positioning of UEs without PDU Session , Event A2 used to release the signaling connection without PDU session. See Section 11.2.15.1 for the parameters and trigger level formulas.

#### 4.8.5.3 Event A3: Neighbor NR Cell Becomes Offset Better than Serving Cell

Event A3, shown in Figure 4-18, is used to detect when a NR neighboring cell becomes offset better than the serving cell. Depending on what the event is used for, the measured signal quantity can be SS_RSRP, SS_RSRQ or SS_SINR.

![Figure on page 46](5G_Mobility_and_Traffic_Management_Guideline_images/page_046_image_002.png)

Figure 4-18 - Event A3 - Neighbor Becomes Offset Better than Serving Cell

This event is used for both SA and NSA mobility:

<!-- page: 47 -->

- For SA, Event A3 is used to detect when a neighboring NR PCell or PSCell (in the case of NR-DC) becomes offset better than the serving NR PCell or PSCell, which triggers the intra-frequency mobility procedure described in Section 8.3.3 (PCell HO) or Section 8.3.5 (PSCell change). See Section 11.2.4 for the parameters and trigger level formulas.

- For SA, Event A3 (LTM) is for L1/L2 Triggered Mobility to detect when a neighboring NR PCell becomes offset better than the serving NR PCell, which triggers an intrafrequency intra-gNodeB LTM cell switch, as described in Section 8.3.4. See Section 11.2.17 for the parameters and trigger level formulas.

- For MCPC SA, Event A3 can be used to detect when a neighboring NR PCell becomes offset better than the serving NR PCell, which triggers the inter-frequency mobility procedure described in Section 8.3.7. See Section 11.2.8.5 for the parameters and trigger level formulas.

- For NSA, Event A3 is used to detect when a neighboring NR PSCell becomes offset better than the serving NR PSCell, which triggers the intra-frequency PSCell change procedure described in Section 6.3.1. See Section 11.2.4 for the parameters and trigger level formulas.

- For SA, Event A3 is used by the feature Positioning of UEs without PDU Session to release a signaling-only connection, which does not have a PDU session. See Section 11.2.15.2 for the parameters and trigger level formulas.

#### 4.8.5.4 Event A4: Neighbor Becomes Better than Threshold

Event A4, shown in Figure 4-19, is used to detect when a neighbor cell becomes better than a threshold. The measured signal quantity is SS_RSRP, SS_RSRQ or SS_SINR.

![Figure on page 47](5G_Mobility_and_Traffic_Management_Guideline_images/page_047_image_002.png)

Figure 4-19 - Event A4 - Neighbor Becomes Better than Threshold

When the UE is on SA, Event A4 is used to detect good NR cell coverage on FR2 PSCell candidates, for NR-DC SN addition. For the parameters and trigger level formulas, see Section 11.2.12.

<!-- page: 48 -->

#### 4.8.5.5 Event A5: Serving Becomes Worse than Threshold 1 and Neighbor Better than Threshold 2

Event A5, shown in Figure 4-20, is used to detect when the serving NR cell becomes worse than threshold 1 and a neighbor NR cell on another frequency becomes better than threshold 2. Depending on what the event is used for, the measured signal quantity can be SS_RSRP, SS_RSRQ or SS_SINR.

![Figure on page 48](5G_Mobility_and_Traffic_Management_Guideline_images/page_048_image_002.png)

Figure 4-20 - Event A5 - Serving Becomes Worse than Threshold 1 and Neighbor Better than Threshold 2

- For Mobility Control at Poor Coverage (MCPC) in SA, Event A5 Inter-Frequency Candidate is used to detect poor serving NR PCell coverage and good coverage on a neighboring inter-frequency cell, which triggers the inter-frequency handover procedure described in Section 7.2.4. See Section 10.2.10 for the parameters and trigger level formulas.

- For Mobility Control at Poor Coverage (MCPC) in NSA, Event A5 Inter-Frequency Candidate is used to detect poor serving NR PSCell coverage and good coverage on a neighboring inter-frequency PSCell, which triggers the inter-frequency PSCell change procedure described in Section 6.3.2. See Section 11.2.9 for the parameters and trigger level formulas.

- For PSCell Change to Higher Priority in NSA, Event A5 Inter-Frequency High Priority PSCell is used to detect good coverage of a neighboring inter-frequency PSCell, which triggers the inter-frequency PSCell change procedure described in Section 6.3.3. See Section 11.2.10 for the parameters and trigger level formulas.

- For Multi-Layer Coordination (MLC) in SA:

̶

- Event A5 (MLC A5 PCell, MLC A5 SCell) is used by MLC to detect good coverage on an inter-frequency DL candidate PCell or SCell, to enable inter-frequency handover or SCell reselection, as described in Section 8.3.9. See Section 11.2.11.4 for the parameters and trigger level formulas.

<!-- page: 49 -->

̶

- Event A5 (MLC A5UL) is used by MLC UL SCell reselection to detect whether a non-serving cell has good enough coverage to be configured as an UL SCell. See Section 11.2.11.5 for the parameters and trigger level formulas.

- Event A5 (MLC A5UL 2L) is used by MLC to detect good coverage for UL 2-layer transmission on an inter-frequency candidate PCell, to enable handover. See Section 11.2.11.4 for the parameters and trigger level formulas.

̶

- For NR Cell Soft Lock and Prohibited Cell-Triggered Mobility in SA, Event A5 Cell Offload Inter-Frequency Candidate is used to detect good coverage on a neighboring inter-frequency cell. See Section 11.2.14.1 for the parameters and trigger level formulas.

#### 4.8.5.6 Event A6: Neighbor Becomes Offset Better than SCell

Event A6, shown in Figure 4-21, is used to detect when an NR intra-frequency neighboring SCell becomes offset better than the serving SCell. The measured signal quantity can be SS_RSRP, SS_RSRQ or SS_SINR.

![Figure on page 49](5G_Mobility_and_Traffic_Management_Guideline_images/page_049_image_002.png)

Figure 4-21 - Event A6 - Neighbor Becomes Offset Better than SCell

For DL CA, Event A6 is used for both SA and NSA to trigger SCell change in FR1. It is similar to Event A3, but whereas Event A3 is used for the primary cell, Event A6 is used to find better SCells within a given frequency layer. See Section 6.3.6 for the NSA procedure, Section 8.3.6 for the SA procedure, and Section 11.2.7 for the parameters and trigger level formulas for both SA and NSA.

#### 4.8.5.7 Event B1: IRAT Neighbor Becomes Better than Threshold

Event B1, shown in Figure 4-22, is used to detect acceptable coverage on another RAT. Depending on what the event is used for, the measured signal quantity can be either SS_RSRP, SS_RSRQ or SS_SINR for NR, or RSRP or RSRQ for LTE.

<!-- page: 50 -->

![Figure on page 50](5G_Mobility_and_Traffic_Management_Guideline_images/page_050_image_001.png)

Figure 4-22 - Event B1 - IRAT Neighbor Becomes Better than Threshold

When the UE is on LTE, Event B1 is used to detect good NR cell coverage for the following purposes:

- For NSA, Event B1 is used to detect good NR cell coverage for SN addition and ENDC triggered handover, as described in Section 6.2.3. For the parameters and trigger level formulas, see Section 11.2.2 for SN addition and Section 11.2.6 for EN-DC triggered handover.

- For SA, Event B1 is used to detect good NR cell coverage for release-with-redirect or handover from LTE to SA, as described in Sections 8.3.1 and 8.3.2.1. For parameters and trigger level formulas, see Section 11.2.3.1.

When the UE is on NR SA, Event B1 is used to detect good LTE coverage for the following purposes:

- For voice fallback in SA, Event B1 is used to detect good LTE cell coverage, and triggers either release-with-redirect or handover, as described in Section 8.3.13.2. For parameters and trigger level formulas, see Section 11.2.5.

- For emergency fallback in SA, Event B1 is used to detect good LTE cell coverage, and triggers either release-with-redirect or handover, as described in Section 8.3.14.1. For parameters and trigger level formulas, see Section 11.2.5.

- For NR Cell Soft Lock and Prohibited Cell-Triggered Mobility in SA, Event B1 Cell Offload Inter-RAT Candidate is used to detect good coverage on a neighboring interRAT cell (LTE). For the parameters and trigger level formulas, see Section 11.2.14.2.

<!-- page: 51 -->

#### 4.8.5.8 Event B2: Serving Becomes Worse than Threshold 1 and IRAT Neighbor Becomes Better than Threshold 2

Event B2, shown in Figure 4-23, is used to detect when the serving NR cell becomes worse than threshold 1 and an LTE neighbor cell becomes better than threshold 2, or vice versa. Depending on what the event is used for, the measured signal quantity can be SS_RSRP, SS_RSRQ or SS_SINR for NR, or RSRP, RSRQ or SINR for LTE.

![Figure on page 51](5G_Mobility_and_Traffic_Management_Guideline_images/page_051_image_002.png)

Figure 4-23 - Event B2 - Serving Becomes Worse than Threshold 1 and IRAT Neighbor Becomes Better than Threshold 2

When the UE is on LTE, Event B2 is used to detect good NR cell coverage for the following purposes:

- For SA, when the UE is in the LTE poor coverage, Event B2 is used by MCPC to trigger handover or release-with-redirect from LTE to SA, as described in Section 8.3.2.2. For parameters and trigger level formulas, see Section 11.2.3.2.

When the UE is on NR SA, Event B2 is used to detect good LTE coverage for the following purposes:

- For SA, Event B2 is used by MCPC to trigger handover or release-with-redirect from SA to LTE, as described in Section 8.3.11. For parameters and trigger level formulas, see Section 11.2.8.6.

- For SA, Event B2 is used by Bandwidth-Triggered Inter-System Handover to detect good LTE cell coverage, and triggers handover or release-with-redirect from SA to LTE, as described in Section 8.3.10. For parameters and trigger level formulas, see Section 11.2.13.

<!-- page: 52 -->

#### 4.8.5.9 Measurement Event Summary

Table 4-8 - Summary of Measurement Events Associated with 5G

| Event            | UE Connection   | Purpose of Measurement                                                                                                                                   | Set in Node   | Main MO(s)             |
|------------------|-----------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|---------------|------------------------|
| A1 (MCPC)        | SA - FR1        | Used by MCPC to detect good NR PCell coverage, to stop the search for a better cell.                                                                     | gNodeB        | McpcPCellProfileUeCfg  |
| A1 (MCPC UL)     | SA - FR1        | Used by MCPC to detect good UL NR SINR on the PCell, to stop the search for a better cell.                                                               | gNodeB        | UlQualMcpcMeasCfg      |
| A1 (MCPC)        | NSA - FR1 & FR2 | Used by MCPC to detect good NR PSCell coverage, to stop the search for a better cell.                                                                    | gNodeB        | McpcPSCellProfileUeCfg |
| A1 (CA)          | SA & NSA - FR1  | Used by CA to detect good NR SCell coverage, to activate a DL SCell at MAC layer.                                                                        | gNodeB        | CaCellMeasProfileUeCfg |
| A1 (CA A1PR)     | SA - FR1        | Used by UL CA to detect that the NR PCell coverage is good enough to configure UL CA, when the configuration would involve a UE power class reduction.   | gNodeB        | TrStSaCellProfileUeCfg |
| A1 (MLC A1UL)    | SA - FR1        | Used by MLC to detect good NR SCell coverage for an UL SCell reselection.                                                                                | gNodeB        | TrStSaCellProfileUeCfg |
| A1 (MLC A1PR)    | SA - FR1        | Used by MLC to detect that the NR PCell coverage is good enough for UL SCell reselection, when the reselection would involve a UE power class reduction. | gNodeB        | TrStSaCellProfileUeCfg |
| A1 (MLC A1UL 2L) | SA - FR1        | Used by MLC is used to determine whether the current PCell coverage is good enough to support 2-layer uplink transmission.                               | gNodeB        | TrStSaCellProfileUeCfg |
| A2 (MCPC)        | SA - FR1        | Used by MCPC to detect poor NR PCell coverage, to start the search for a better cell or detect critical coverage.                                        | gNodeB        | McpcPCellProfileUeCfg  |
| A2 (MCPC UL)     | SA - FR1        | Used by MCPC to detect poor UL NR SINR on the PCell, to start the search for a better cell.                                                              | gNodeB        | UlQualMcpcMeasCfg      |
| A2 (MCPC)        | SA - FR1        | Used by MCPC to detect critical NR PCell coverage, to trigger handover or release-with-redirect to either NR or LTE.                                     | gNodeB        | McpcPCellProfileUeCfg  |
| A2 (MCPC UL)     | SA - FR1        | Used by MCPC to detect critical UL NR SINR on the PCell, to trigger handover or release-with- redirect to either NR or LTE.                              | gNodeB        | UlQualMcpcMeasCfg      |

Table 4-8 - Summary of Measurement Events Associated with 5G

<!-- page: 53 -->

| Event               | UE Connection            | Purpose of Measurement                                                                                                                                     | Set in Node   | Main MO(s)                     |
|---------------------|--------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------|--------------------------------|
| A2 (NR-DC)          | SA - FR2                 | Used by NR-DC to detect critical NR PSCell coverage, to trigger SN release.                                                                                | gNodeB        | McpcNrdcPSCellProfileUeCfg     |
| A2 (MCPC)           | NSA - FR1 & FR2          | Used by MCPC to detect poor NR PSCell coverage, to start the search for a better cell or detect critical coverage.                                         | gNodeB        | McpcPSCellProfileUeCfg         |
| A2 (MCPC)           | NSA - FR1 & FR2          | Used by MCPC to detect critical NR PSCell coverage, to trigger SN release.                                                                                 | gNodeB        | McpcPSCellProfileUeCfg         |
| A2 (CA)             | SA & NSA - FR1           | Used by CA to detect poor NR SCell coverage, to deactivate (and possibly deconfigure) an DL SCell at MAC layer.                                            | gNodeB        | CaCellMeasProfileUeCfg         |
| A2 (EPS Fallback)   | SA - FR1                 | Used to detect critical NR PCell coverage, to trigger release-with- redirect for EPS fallback for IMS voice and emergency call EPS fallback.               | gNodeB        | McfbCellProfileUeCfg           |
| A2 (CA A2PR)        | SA - FR1                 | Used by UL CA to detect that the NR PCell coverage is not good enough to configure UL CA, when the configuration would involve a UE power class reduction. | gNodeB        | TrStSaCellProfileUeCfg         |
| A2 (MLC A2UL)       | SA - FR1                 | Used by MLC to detect that the coverage of an NR SCell is not good enough for UL SCell reselection.                                                        | gNodeB        | TrStSaCellProfileUeCfg         |
| A2 (no PDU session) | SA - FR1                 | Used by Positioning of UEs without PDU Session , to detect critical NR PCell coverage, which triggers connection release.                                  | gNodeB        | UeNoDrbPCellProfileUeCfg       |
| A3                  | NSA - FR1 & FR2 SA - FR1 | Used to detect a better NR PCell (SA), NR PSCell (NR-DC) or NR PSCell (EN-DC), to trigger intra- frequency mobility.                                       | gNodeB        | IntraFreqMCCellProfileUeCfg    |
| A3 (LTM)            | SA - FR1                 | Used to detect a better NR PCell (SA) for L1/L2 Triggered Mobility to trigger intra-frequency intra- gNodeB cell switch.                                   | gNodeB        | IntraFreqMCLtmCellProfileUeCfg |
| A3 (MCPC SA)        | SA - FR1                 | Used by MCPC to detect a better NR PCell (SA), to trigger inter- frequency mobility.                                                                       | gNodeB        | McpcPCellProfileUeCfg          |
| A3 (no PDU session) | SA - FR1                 | Used by Positioning of UEs without PDU Session , to detect a better coverage from a neighbor NR PCell, which triggers connection release.                  | gNodeB        | UeNoDrbPCellProfileUeCfg       |

<!-- page: 54 -->

| Event                             | UE Connection   | Purpose of Measurement                                                                                                                                                | Set in Node   | Main MO(s)              |
|-----------------------------------|-----------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------|-------------------------|
| A4 (NR-DC)                        | SA - FR1        | Used to detect good FR2 NR cell coverage, to trigger SN addition for NR-DC.                                                                                           | gNodeB        | NrdcMnCellProfileUeCfg  |
| A5 (MCPC)                         | SA - FR1        | Used by MCPC to detect poor NR PCell coverage (Thr1) and good inter-frequency PCell candidate coverage (Thr2), to trigger inter- frequency handover.                  | gNodeB        | McpcPCellProfileUeCfg   |
| A5 (MCPC)                         | NSA - FR1 & FR2 | Used by MCPC to detect poor NR PSCell coverage (Thr1) and good inter-frequency PSCell candidate coverage (Thr2), to trigger inter- frequency PSCell change.           | gNodeB        | McpcPSCellProfileUeCfg  |
| A5 (PSCell change to Higher Prio) | NSA - FR1 & FR2 | Used to detect good inter- frequency PSCell candidate coverage (Thr2), to trigger inter- frequency PSCell change to a higher priority frequency.                      | gNodeB        | TrStPSCellProfileUeCfg  |
| A5 (MLC A5PCell, A5SCell)         | SA - FR1        | Used by MLC to detect good inter-frequency PCell or SCell candidate coverage (Thr2), to trigger handover or SCell reselection.                                        | gNodeB        | TrStSaCellProfileUeCfg  |
| A5 (MLC A5UL 2L)                  | SA - FR1        | Used by MLC to detect good inter-frequency PCell candidate UL2L coverage (Thr2), to trigger handover.                                                                 | gNodeB        | TrStSaCellProfileUeCfg  |
| A5 (MLC A5UL)                     | SA - FR1        | Used by MLC to detect that an SCell candidate has good enough coverage for UL SCell reselection.                                                                      | gNodeB        | TrStSaCellProfileUeCfg  |
| A5 (Soft lock, PCTM)              | SA - FR1        | Used to detect good inter- frequency PCell candidate coverage (Thr2), to trigger handover via NR Cell Soft Lock or Prohibited Cell-Triggered Mobility (PCTM).         | gNodeB        | OffloadCellProfileUeCfg |
| A6 (CA)                           | SA & NSA - FR1  | Used by DL CA to detect a better NR SCell, to trigger intra- frequency SCell change.                                                                                  | gNodeB        | CaCellMeasProfileUeCfg  |
| B1 (EPS Fallback)                 | SA - FR1        | Used by voice fallback to detect good LTE cell coverage, to trigger EPS fallback for IMS voice and emergency call EPS fallback via release-with-redirect or handover. | gNodeB        | McfbCellProfileUeCfg    |
| B1 (Soft lock, PCTM)              | SA - FR1        | Used by NR Cell Soft Lock or Prohibited Cell-Triggered Mobility (PCTM) to detect good LTE cell coverage.                                                              | gNodeB        | OffloadCellProfileUeCfg |

<!-- page: 55 -->

| Event             | UE Connection   | Purpose of Measurement                                                                                                                                               | Set in Node   | Main MO(s)             |
|-------------------|-----------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------|------------------------|
| B2 (MCPC)         | SA - FR1        | Used by MCPC to detect poor NR PCell coverage (Thr1) and good IRAT LTE candidate coverage (Thr2), to trigger IRAT handover or release-with-redirect.                 | gNodeB        | McpcPCellProfileUeCfg  |
| B2 (BWTISHO, DAM) | SA - FR1        | Used by Bandwidth-Triggered Inter-System Handover to detect good LTE cell coverage.                                                                                  | gNodeB        | TrStSaCellProfileUeCfg |
| B1 (EN-DC)        | LTE             | Used to detect good NR cell coverage (FR1 or FR2), to trigger SN addition or EN-DC triggered handover.                                                               | eNodeB        | ReportConfigB1GUtra    |
| B1 (LTE to SA)    | LTE             | Used to detect good NR cell coverage (FR1), to trigger handover or release-with-redirect from LTE to NR SA.                                                          | eNodeB        | ReportConfigB1NR       |
| B2 (LTE to SA)    | LTE             | Used by MCPC to detect poor LTE PCell coverage (Thr1) and good NR SA candidate coverage (Thr2), to trigger IRAT handover or release-with-redirect from LTE to NR SA. | eNodeB        | ReportConfigB2NR       |

### 4.8.6 Number of Measurements

The maximum number of inter-frequency and inter-RAT measurements that can be configured simultaneously in a UE is set by the following attributes:

- maxNrInterFreqMeasEndc = 10 (default) to 32 Maximum number of NR inter-frequency measurements in an EN-DC connected UE

- maxNrInterFreqMeasSa = 10 (default) to 32 Maximum number of NR inter-frequency measurements for an SA connected UE

- maxNrIratMeasSa = 10 (default) to 32 Maximum number of inter-RAT (LTE) measurements for an SA connected UE

For each of these, 3GPP requires the UE to support a minimum of 10. However, as UEs typically support more than 10, it is possible to configure more.

In this context a ' measurement ' is a Measurement ID, which consists of a combination of a measurement object and a reporting configuration. Typically, this equates to a unique combination of the event type (A1, A2, A3, A4, A5, A6, B1 or B2), the measurement quantity (RSRP, RSRQ or SINR) and the frequency being measured (either an NR frequency or an LTE frequency).

For example, an SA-connected UE in the MCPC search zone for both RSRP and RSRQ, measuring two candidate NR frequencies and one candidate LTE frequency requires 6 measurements:

<!-- page: 56 -->

- 4 * A5 Inter-frequency candidate measurements: 2 other NR frequencies * 2 quantities

- 2 * B2 EUtran candidate measurements: 1 LTE frequency * 2 quantities

Any measurements configured on PCell, PSCell or SCell frequencies do not count towards the maxNrInterFreqMeasEndc and/or maxNrInterFreqMeasSa limits, because those frequencies are serving cell frequencies. Instead, these measurements contribute towards the maximum number of measurements per serving NR frequency, which is 9.

### 4.8.7 Number of Reported Cells

For most A3, A4, A5, A6, B1 and B2 measurement events, the maximum number of non-serving cells that the UE can include in the measurement report is configurable using the attribute maxReportCells . This attribute appears under different MO classes, depending on the feature or function configuring the measurement. The settable range is 1 to 8. If the attribute is not available for a particular feature or function, then the value is set by an internal gNodeB parameter.

Setting a value greater than 1 allows better UE positioning accuracy, for improved network planning, optimization, and troubleshooting. However, regardless of how many cells are reported, the gNodeB evaluates only the first reported (strongest) cell for most mobility functions. The exception is the EPS-fallback B1 measurement, where the gNodeB can evaluate any of the reported cells.

<!-- page: 57 -->

# 5 Connectivity and Bearers - EN-DC

This section describes how UEs connect to the network using EN-DC in Ericsson's 5G NSA solution. There is a strong emphasis on the underlying radio bearers and how they are managed.

## 5.1 Radio Bearer Types - EN-DC

The UE connects to the radio network using two different types of radio bearer:

- Signaling Radio Bearer (SRB):  The SRB transports Layer 3 signaling to and from the UE in connected mode. In NSA, the SRB is carried over the LTE RAT (the Master RAT) via the eNodeB.

- Data Radio Bearer (DRB):  A DRB transports Layer 3 user plane data to and from the UE. In connected mode the UE has one or more DRBs.

For EN-DC, the DRBs are described by two characteristics:

- The node which terminates the S1-U interface from the core:

̶

- Master Node (MN) or

̶

- Secondary Node (SN)

- The cell groups which provide the resources for the bearer over the air interface:

̶

- Master Cell Group (MCG) or

̶

- Secondary Cell Group (SCG)

̶

- Split (both MCG and SCG provide resources)

The MCG has one primary cell (PCell), and one or more secondary cells (SCells) if LTE carrier aggregation is configured.

The SCG also has one primary cell (PSCell), and one or more SCells if NR carrier aggregation is configured.

In the NSA solution, there are three types of DRB:

- MN Terminated MCG DRB

- SN Terminated MCG DRB

- SN Terminated Split DRB

The SRB and the three DRB types are shown in Figure 5-1.

<!-- page: 58 -->

![Figure on page 58](5G_Mobility_and_Traffic_Management_Guideline_images/page_058_image_002.png)

Figure 5-1 - Bearer Types in an EN-DC Capable Network

Which DRBs a UE can use depends on its capability:

- UEs which are not EN-DC capable (legacy LTE UEs) can use one or more MN Terminated MCG DRBs only.

- EN-DC capable UEs can use one or more MN terminated DRBs, or one or more SN terminated DRBs, or combinations of the two. However, the network does not configure the UE simultaneously with two different types of SN Terminated DRB (that is an SN Terminated Split DRB and an SN Terminated MCG DRB).

## 5.2 Radio Bearer Transitions - EN-DC

In response to mobility or service triggers, the network sets up and releases bearers and initiates transitions between them. The possible transitions between the bearer types for bearers that are allowed to be split bearers are shown in Figure 5-2. In addition, the UE can be released to idle mode from any bearer state.

<!-- page: 59 -->

![Figure on page 59](5G_Mobility_and_Traffic_Management_Guideline_images/page_059_image_002.png)

Figure 5-2 - Bearer Type Transitions for EN-DC

**Notes for Figure 5-2:**

- Initial context setup, incoming handover and RRC re-establishment result in the setup of an MN Terminated MCG DRB.

- SN addition involves reconfiguring an MN terminated MCG DRB into an SN terminated split DRB when the preconditions for EN-DC are fulfilled. The SN addition is typically measurement-based but can also be configuration-based. If it is measurement-based, then the UE is configured with an Event B1 measurement to detect NR coverage and SN addition occurs when an Event B1 report is received from the UE. Event B1 is further described in Section 4.8.5.7.

- SCG release occurs when a bearer is set up that prevents other bearers being configured as SN Terminated Split DRBs, for example at VoLTE call setup. SCG resources for all SN Terminated split DRBs are released but the PDCP context is kept. SCG release can also occur if the UE reports overheating, see Section 10.2.1.9.

- SCG addition is triggered by reception of a B1 measurement. The B1 measurement is started, for example, when a VoLTE bearer that prevents other bearers being configured as SN terminated Split DRBs is released. All SN Terminated MCG DRBs make this transition at the same time. SCG addition can also occur if the UE reports that it is no longer overheated.

<!-- page: 60 -->

- There are two SN release transitions, both labelled with 5. The transition from the SN Terminated Split DRB state is triggered by NR radio link failure, some LTE mobility events or RRC connection re-establishment. The transition from the SN Terminated MCG Bearer state is triggered only by LTE mobility or RRC connection reestablishment events (as there are no SCG resources in this case). All SN Terminated DRBs make this transition at the same time.

If the UE has multiple bearers, then all bearers do not necessarily make the same transitions at the same time; more details are provided in Section 6.

## 5.3 Split Bearer User Plane Functions - EN-DC

This section describes the functions which control the flow of user data over an SN Terminated Split Bearer.

A split bearer has two sets of radio resources:

- Master Cell Group (MCG) resources in the Master Node (eNodeB)

- Secondary Cell Group (SCG) resources in the Secondary Node (gNodeB)

These two sets of resources are served by a common PDCP entity located in the Secondary Node, as shown in Figure 5-3.

Figure 5-3 - SN Terminated Split Bearer Resources

The PDCP entity controls the flow of user data over the MCG and SCG resources using the following features and functions:

**· Uplink / Downlink Decoupling**

The feature Uplink-Downlink Decoupling enables uplink and downlink user data transmissions to be sent independently over LTE or NR. For example, the downlink can use NR while the uplink uses LTE.

**· Downlink User Plane Switching**

This function enables fast switching of downlink user plane data between MCG and SCG resources (effectively between LTE and NR) in response to varying NR radio quality.

<!-- page: 61 -->

**· Uplink User Plane Switching**

This function enables fast switching of uplink user plane data between MCG and SCG resources (effectively between LTE and NR) in response to varying NR radio quality.

**· Downlink User Plane Aggregation**

This function enables simultaneous use of both MCG and SCG resources for downlink user data transmission when required by data flow and allowed by NR radio quality.

**· Uplink User Plane Aggregation**

This function enables simultaneous use of both MCG and SCG resources for uplink user data transmission when required by data flow.

**· Flow Control**

This function controls the flow of data over MCG and SCG resources to manage the latencies and minimize packet reordering during aggregation.

These functions exist within the context of a split bearer, until SN or SCG release occurs, as described in Section 6.2.5.

In addition to the downlink and uplink user plane aggregation described above, the MCG and SCG can each support Downlink Carrier Aggregation on the cells within their respective cell groups, as described in Section 5.3.4, and Uplink Carrier Aggregation as described in Section 5.3.5.

The above functions are described in more detail in the following sections. These sections make the following assumptions:

- The feature Service-Adaptive Uplink User Plane Profile is activated. This feature enables uplink cell group switching and aggregation to be configured at the UE group and 5QI/QCI level, separately for EN-DC and NR-DC.

- GNBCUUPFunction.altDepHServAdapUPProfEnabled = true . This allows the user plane functions to be controlled with the new MO classes rather than the old deprecated MO classes.

- servAdapUPProfUlDepHEnabled = false in all of GNBCUCPFunction , GNBCUUPFunction and GNBDUFunction . This disables deprecation handling and ensures that uplink cell group switching and aggregation can be configured at the UE group level using the newer MOs and attributes.

### 5.3.1 Uplink-Downlink Decoupling

The feature Uplink-Downlink Decoupling enables uplink and downlink user data transmissions to be sent independently over LTE or NR. For example, the downlink can use NR while the uplink uses LTE. This improves NR coverage by simultaneously taking advantage of the high peak data rate and low-latency of the NR downlink, and the strong coverage of the low-band LTE uplink.

<!-- page: 62 -->

![Figure on page 62](5G_Mobility_and_Traffic_Management_Guideline_images/page_062_image_001.png)

Figure 5-4 - Coverage Extension Due to EN-DC Uplink-Downlink Decoupling

Note that whenever user data is sent on the NR downlink, the associated uplink signaling (for example the Layer 1 and Layer 2 HARQ feedback and RLC Status Reports) is carried on the NR uplink. This means that simultaneous uplink transmission on NR and LTE can occur regardless of whether NR or LTE is used for uplink user data.

### 5.3.2 Downlink User Plane Switching

Downlink user plane switching allows the downlink user plane to be switched dynamically between MCG and SCG resources based on the estimated SINR of the NR downlink. The SINR is estimated using CQI feedback from the UE.

Downlink user plane switching is illustrated in Figure 5-5.

<!-- page: 63 -->

![Figure on page 63](5G_Mobility_and_Traffic_Management_Guideline_images/page_063_image_002.png)

Figure 5-5 - Downlink User Plane Switching

**Notes for Figure 5-5:**

- Initially, when an SN Terminated Split Bearer is established (for example due to reception of a B1 measurement report), the downlink user plane uses SCG (NR) resources. The SCG resources continue to be used while the NR DL SINR remains acceptable.

- When the NR DL SINR falls below CgSwitchCfg . dlScgLowQualThresh , an immediate switch to the MCG (LTE) resources is triggered. This switch is also triggered if CQI reports are not received successfully from the UE. Any unsent data is forwarded to the eNodeB for transmission.

- Even if the NR DL SINR becomes acceptable again (above CgSwitchCfg . dlScgLowQualThresh + CgSwitchCfg . dlScgLowQualHyst ), a switch back to the SCG (NR) resources cannot occur until the prohibit timer expires.

- When the UserPlaneProfileUeCfg.dlPdcpScgRetProhibitTime expires, and if the quality remains acceptable, a switch back to the SCG (NR) resources is triggered. Any unsent data is forwarded to the gNodeB for transmission.

If the UE has more than one SN Terminated Split Bearer, all are switched at the same time and use the same downlink resources.

A downlink user data flow at the PDCP layer requires an uplink signaling flow at Layer 1 and Layer 2, for example HARQ and RLC Status Reports. This uplink signaling is carried on the same cell group as the downlink data flow:

<!-- page: 64 -->

- The Layer 1 and Layer 2 signaling associated with the SCG downlink user plane is always carried on the SCG uplink.

- The Layer 1 and Layer 2 signaling associated with the MCG downlink user plane is always carried on the MCG uplink.

The CQI feedback used to assess SINR involves periodical polling of the UE, and the related signaling consumes resources even if the SCG is not being used. To free up these resources in cases of very high NR usage, leg switching can be disabled on low and midband cells by setting CgSwitchCfg.dlCgSwitchMode = DISABLED . It is enabled by default. If disabled, it is recommended to enable the A2 Critical Coverage SN release functionality, as described in Section 6.3.4, and carefully tune the related trigger threshold to avoid NR radio link failures.

### 5.3.3 Uplink User Plane Switching

Uplink user plane switching allows the primary path for the uplink user plane to be switched dynamically between MCG and SCG resources.

When an SN Terminated Split DRB is set up, the primary path initially used for the uplink can be either the MCG or the SCG.  This is configured per 5QI or QCI using the attribute UlDataSplitUeCfg.initialUlPrimaryPathMode . This attribute can be set to MCG , SCG or COVERAGE_BASED . When it is set to COVERAGE_BASED , the initial primary path depends on the PSCell coverage, as shown in Figure 5-6. This process is followed for each SN Terminated Split DRB that is set up, so different DRBs can use different initial primary paths.

![Figure on page 64](5G_Mobility_and_Traffic_Management_Guideline_images/page_064_image_002.png)

Figure 5-6 - Choice of Initial Primary UL Path when an SN Terminated Split DRB is Set Up

<!-- page: 65 -->

After the initial primary UL path is chosen, it can be switched back and forth between the MCG and SCG based on reports of the NR uplink Layer 1 SINR, measured by the gNodeB. The switch is performed using RRC signaling (3GPP IE primaryPath ) to reconfigure the UE to use the new primary uplink path. This contrasts with downlink user plane switching, which does not require the UE to be reconfigured.

Primary UL path switching is enabled at the cell and UE group level by setting UlCgSwitchCfg.ulCgSwitchMode = ENABLED . When enabled, switching is controlled at the 5QI/QCI level, by setting DcUlCfg.ulPrimaryPathMode to one of the following values:

- MCG - The MCG is used as the primary path, regardless of whether the received report indicates good quality or poor quality.

- KEEP_SCG - The SCG is used as the primary path, regardless of whether the received report indicates good quality or poor quality.

- SCG - The SCG is used if the received report indicates good quality, and the MCG is used if the received report indicates poor quality.

An example of the switching process is shown in Figure 5-7 and the following notes.

![Figure on page 65](5G_Mobility_and_Traffic_Management_Guideline_images/page_065_image_002.png)

Figure 5-7 - Uplink User Plane Switching

<!-- page: 66 -->

**Notes for Figure 5-7:**

- The resource initially used for the uplink is configured per 5QI or QCI with the attribute UlDataSplitUeCfg.initialUlPrimaryPathMode (to MCG, COVERAGE_BASED or SCG). This is signaled to the UE via RRC at SN addition. In this example the attribute is set to SCG. If uplink user plane switching is disabled, the initial selection is kept statically throughout the lifetime of the SN Terminated Split Bearer.

# 2 When the estimated NR UL SINR falls below

UlCgSwitchCfg.ulScgLowQualThresh , an RRC reconfiguration to MCG (LTE) resources is triggered. The estimated SINR is normalized to the maximum achievable SINR; which would be measured if the UE were using only a single resource block. This normalization must be considered when setting ulScgLowQualThresh . For example, if the minimum requirement for acceptable NR performance is N resource blocks with a SINR of X dB on each of those resource blocks, then ulScgLowQualThresh should be set to X + 10 * log10(N). In other words, the threshold should be increased by 3 dB for each doubling of the number of required resource blocks.

- Even if the NR UL SINR becomes acceptable again (above ulScgLowQualThresh + ulScgLowQualHyst ), a switch back to SCG (NR) resources cannot occur until the prohibit timer UserPlaneProfileUeCfg.ulPdcpScgRetProhibitTime expires.

- When the timer expires, and the quality remains acceptable, a switch back to SCG (NR) resources is triggered.

If the UE has more than one SN Terminated Split Bearer, then they can use different primary paths, depending on the settings of initialUlPrimaryPathMode and ulPrimaryPathMode .  This is shown in Figure 5-8 and the following notes.

<!-- page: 67 -->

![Figure on page 67](5G_Mobility_and_Traffic_Management_Guideline_images/page_067_image_002.png)

Figure 5-8 - Uplink User Plane Switching for Multiple DRBs

**Notes for Figure 5-8:**

- When each SN Terminated Split Bearer is first established, the primary path is determined by initialUlPrimaryPathMode for the relevant 5QI.

- The first UL quality report is received, and it indicates poor PSCell quality. This triggers primary path evaluation for all of the DRBs.

- A:  Remains on MCG, as ulPrimaryPathMode = MCG

- B:  Remains on MCG, as ulPrimaryPathMode = SCG and the quality is poor

- C:  Switches to SCG, as ulPrimaryPathMode = KEEP_SCG

- D:  Switches to MCG, as ulPrimaryPathMode = MCG . This transition (along with the transition for E) starts the timer ulPdcpScgRetProhibitTime , which applies to all DRBs.

- E:  Switches to MCG, as ulPrimaryPathMode = SCG and the quality is poor

- F: Remains on SCG, as ulPrimaryPathMode = KEEP_SCG

- An UL quality report is received that indicates good PSCell quality

- A & D:  Remain on MCG, as ulPrimaryPathMode = MCG

- B & E:  Remain on MCG, because although the quality is good, ulPdcpScgRetProhibitTime prevents the switch to SCG.

<!-- page: 68 -->

- C & F:  Remain on SCG, as ulPrimaryPathMode = KEEP_SCG

- The timer ulPdcpScgRetProhibitTime expires

- B & E:  Can now switch to SCG

- The other DRBs do not switch, as their ulPrimaryPathMode settings prevent any further switching

- An UL quality report is received that indicates poor PSCell quality

- B & E:  Switch to MCG, as the quality is poor. This restarts

ulPdcpScgRetProhibitTime

An uplink user data flow at the PDCP layer requires a downlink signaling flow at Layer 1 and Layer 2, for example HARQ and RLC status reports. This downlink signaling is carried on the same cell group as the uplink data flow:

- The Layer 1 and Layer 2 signaling associated with the SCG uplink user plane is always carried on the SCG downlink.

- The Layer 1 and Layer 2 signaling associated with the MCG uplink user plane is always carried on the MCG downlink.

### 5.3.4 Downlink User Plane Aggregation

The licensed feature LTE-NR Downlink Aggregation (FAJ 121 4912) enables transmission of downlink user plane data simultaneously on both the MCG and SCG resources of an SN Terminated Split Bearer. Different packets are sent on the two cell groups. The feature improves the end user throughput.

Figure 5-9 illustrates the transitions involved with LTE-NR Downlink Aggregation , and how this function interacts with downlink user plane switching (described in Section 5.3.2).

<!-- page: 69 -->

![Figure on page 69](5G_Mobility_and_Traffic_Management_Guideline_images/page_069_image_002.png)

Figure 5-9 - Downlink User Plane Aggregation and Switching for a Split Bearer

Notes for Figure 5-9:

- Good NR DL SINR (derived from the CQI measured on the Primary SCell) triggers a switch from MCG to SCG resources (see Section 5.3.2).

- Poor NR DL SINR or a lack of CQI reports triggers a switch to MCG resources only (see Section 5.3.2).

- DL aggregation is triggered for a SN Terminated Split Bearer when the NR DL SINR is good enough for the SCG to be used (see Section 5.3.2) and if the PDCP packets are waiting in the PDCP buffer for longer than UserPlaneProfileUeCfg.dcDlAggActTime .

- Downlink aggregation is stopped and returned to downlink using only SCG resources if the PDCP buffer is emptied (all packets sent and acknowledged) and kept empty for a time of UserPlaneProfileUeCfg.dcDlAggExpiryTimer .

- Downlink aggregation is stopped and returned to downlink using only MCG resources if NR DL SINR is poor or there is a lack of CQI reports.

In addition to the transitions shown, an NR RLF or A2 Critical Coverage SN release may occur in any of the three states, causing transition to an MN Terminated MCG Bearer.

<!-- page: 70 -->

Performing high rate transfers using LTE-NR DL aggregation adds challenges compared to transmission over a single path, which has less variation in transmission delays. The receiving PDCP entity in the UE has to ensure in-sequence delivery to higher layers and performs packet reordering during a certain allowed time window, which is configured via the attribute CUCP5qi.tReorderingDl . The UE is also required by 3GPP 38.306 to dimension its reordering buffer size to enable a certain peak rate. These constraints cause packet losses if they are not met, which has a negative end-user performance impact during aggregation.

The gNodeB takes actions to minimize PDCP packet reordering in the UE and avoid packet losses:

- Before downlink aggregation is initiated, a duplicate packet is transmitted to ensure that the UE is not in DRX (Discontinuous Reception) sleep state. This could otherwise add to the time difference between the transmission paths.

- During downlink aggregation, if a large time difference is detected between the two paths, the gNodeB temporarily suspends data transmission on the path with the oldest buffer age. Downlink aggregation can only be resumed after a pre-determined time.

The feature LTE-NR Downlink Aggregation is enabled by setting the attribute featureState to ACTIVATED in the FeatureState=CXC4012273 MO instance.

Downlink and uplink user plane aggregation can be used in combination with DL carrier aggregation (on MAC and L1 layer), as the two functions are independent.

DL CA is supported for all three NSA bearer types:

- MN Terminated MCG Bearer

- SN Terminated Split Bearer

- SN Terminated MCG Bearer

Figure 5-10 illustrates the co-existing aggregation functionality.

<!-- page: 71 -->

![Figure on page 71](5G_Mobility_and_Traffic_Management_Guideline_images/page_071_image_002.png)

Figure 5-10 - Downlink User Plane Aggregation and Carrier Aggregation (High-Band Example)

For Downlink carrier aggregation on LTE, the MCG consists of one primary cell (PCell) and one or more secondary cells (SCells), each on a different frequency. The SCell activation and deactivation thresholds can be controlled separately for EN-DC connections, using the following attributes in the CarrierAggregationFunction MO:

dcSCellActDeactDataThres , dcSCellActDeactDataThresHyst and dcSCellDeactDelayTimer .

For Downlink carrier aggregation on NR, the SCG consists of one primary secondary cell (PSCell) and one or more secondary cells (SCells), each on a different frequency.

DL Carrier Aggregation in NSA does not impact Downlink User Plane Switching behavior, since user plane switching considers only the PSCell SINR, not the SCell.

UEs do not support simultaneous connection to an LTE SCell and an NR PSCell on the same carrier frequency. Therefore, if the UE has an LTE SCell set up on a given carrier, then the SCell is deconfigured if an NR PSCell is set up on the same carrier. This is particularly relevant for ESS deployments where both LTE and NR are provided on the same carrier.

The selection of an EN-DC band combination involves SCell selection in both the eNodeB and the gNodeB according to their respective methods and configuration. This happens sequentially. First the eNodeB signals a set of allowed band combinations (IE allowedBCListMRDC ) to the gNodeB during the SN addition procedure (X2AP: SGNB ADDITION REQUEST). Then the gNodeB selects the NR band combination according to its criteria and signals the selection to the eNodeB (X2AP: SGNB ADDITION REQUEST ACK). This list of band combinations is not re-negotiated for the life of the EN-DC connection, and therefore also dictates the possible band combinations for inter-frequency PSCell change procedure.

<!-- page: 72 -->

The parameter CarrierAggregationFunction.endcCaPolicy determines whether EN-DC band combination selection maximizes the potential aggregated LTE throughput ( LTE_PREFERRED ) or the NR throughput ( NR_PREFERRED ). This is achieved by changing the set of allowed band combinations that are signaled by the eNodeB to the gNodeB.

**· LTE_PREFERRED**

The eNodeB selects a subset of EN-DC band combinations that includes the serving LTE PCell band and the selected NR PSCell band, and maximizes the potential aggregated LTE throughput. The eNodeB sends this subset of combinations, ordered by decreasing potential aggregated LTE throughput, to the gNodeB. From this subset, the gNodeB then selects the first band combination which maximizes the potential NR aggregated throughput. Note however, that the gNodeB is choosing from a subset that is not guaranteed to include the band combination(s) with the overall highest potential NR throughput.

**· NR_PREFERRED**

The eNodeB selects all possible EN-DC combinations that include the serving LTE PCell band and any possible NR PSCell bands, orders them by decreasing potential aggregated LTE throughput, and sends them to the gNodeB. The gNodeB then selects the first band combination that maximizes the potential aggregated NR throughput, according to the gNodeB criteria and UE capabilities. This method also ensures that all potential NR target frequencies are available for PSCell change between bands using MCPC as described in Section 10.3.4.2, or PSCell Change to Higher Priority as described in Section 10.3.17.

Set CarrierAggregationFunction.endcBcsValidation = true to ensure that only band combinations defined in 3GPP TS 36.101 are considered in the above process.

**When selecting SCells, the eNodeB uses the method set by**

CarrierAggregationFunction.dynamicSCellSelectionMethod . However, the feature Global SCell Evaluation is not supported in combination with EN-DC.

- If dynamicSCellSelectionMethod = GLOBAL_EVALUATION , then the selection uses Configurable SCell Priority if that feature is enabled.

- If not, then the selection uses Dynamic SCell Selection .

When the eNodeB is configured to use the Configurable SCell Priority feature ( CarrierAggregationFunction.dynamicSCellSelectionMethod = PRIORITIZED )  together with CarrierAggregationFunction.endcCaPolicy = NR_PREFERRED, none of the configured LTE frequency relation or SCell priorities are considered by the eNodeB.

When the secondary node is released, the eNodeB then reselects LTE SCells using the method specified by dynamicSCellSelectionMethod (including GLOBAL_EVALUATION ).

<!-- page: 73 -->

### 5.3.5 Uplink User Plane Aggregation

The licensed feature LTE-NR Uplink Aggregation (FAJ 121 5091) enables transmission of uplink user plane data (PDCP layer) simultaneously on both the MCG and SCG resources of an SN Terminated Split Bearer. The feature improves the end user throughput.

Assuming that uplink user plane switching is enabled ( ulPrimaryPathMode = SCG ), switching and aggregation work together as shown in Figure 5-11.

- UL User Plane Switching is described in Section 5.3.3, and determines whether the primary uplink path is SCG or MCG depending on the SINR. The decision to change the primary path is made by the gNodeB and is signaled to the UE using an RRC Connection Reconfiguration message sent by the eNodeB.

- UL User Plane Aggregation determines whether the UE sends uplink data on only the primary cell group or on both cell groups. This decision is made by the UE per DRB, depending on the amount of data in the UL PDCP buffer. During aggregation the primary path can change due to user plane switching, while the UE continues transmitting on both MCG and SCG.

![Figure on page 73](5G_Mobility_and_Traffic_Management_Guideline_images/page_073_image_001.png)

Figure 5-11 - Uplink User Plane Aggregation and Switching for a Split Bearer

The threshold for using uplink aggregation is set per UE group and 5QI/QCI, and depends on which UL primary path is used:

- If the primary path is MCG, then the threshold is set with the attribute UlDataSplitUeCfg.ulDataSplitThreshMcg .

- If the primary path is SCG, then the attribute used to set the threshold depends on the PSCell RSRP and/or UL quality:

̶

- If the PSCell quality is below UlCgSwitchCfg.ulScgLowQualThresh or the PSCell RSRP is below InitialCgUeCfg.ulScgInitialLowRsrpThresh , then the data split threshold is set with the attribute UlDataSplitUeCfg.ulDataSplitThreshScgLow

<!-- page: 74 -->

̶

- Otherwise the data split threshold is set with the attribute UlDataSplitUeCfg.ulDataSplitThreshScg .

When the amount of data in the UE uplink PDCP buffer equals or exceeds this threshold, then the UE splits the DRB uplink data and sends uplink PDCP PDUs on both the MCG and the SCG paths. Otherwise, the UE sends the data only on the primary path, as determined by uplink user plane switching.

If the data split threshold is set to 0, the uplink data split is always active for capable UEs. If set to -1, the split is not allowed.

During UL aggregation, different delays on the MCG and SCG paths can result in packets arriving out of order in the gNodeB. The receiving PDCP entity in the gNodeB therefore reorders the packets to ensure in order delivery to higher layers. The reordering time window is set via the attribute CUCP5qi.tReorderingUl . Once this timer expires, delayed PDCP packets cannot be delivered in the correct order. However, the packets can still be delivered to the higher layers during a configurable time, set by AqmCfg.tOooUlDelivery . During this time, the delayed packets are delivered immediately without reordering, but can still provide useful information to the higher layer TCP protocol, helping to maintain a steady flow.

The feature LTE-NR Uplink Aggregation is enabled by setting the attribute featureState to ACTIVATED in the FeatureState=CXC4012375 MO instance.

To use uplink user plane aggregation, the UE must be capable of uplink EN-DC aggregation (3GPP IE splitDRB-withUL-Both-MCG-SCG ).

Downlink and uplink user plane aggregation can be used in combination with UL carrier aggregation (on MAC and L1 layer), as the two functions are independent.

![Figure on page 74](5G_Mobility_and_Traffic_Management_Guideline_images/page_074_image_001.png)

Figure 5-12 illustrates the co-existing aggregation functionality.

Figure 5-12 - Uplink User Plane and Carrier Aggregation (High-Band Example)

<!-- page: 75 -->

UL Carrier Aggregation does not impact Uplink User Plane Switching behavior, since user plane switching considers only the PSCell SINR, not the SCell.

### 5.3.6 Flow Control

Flow control manages the flow of downlink PDCP packets over the MCG (LTE) and SCG (NR) user plane paths for split bearers. Its objective is to make the PDCP packets arrive in the correct order at the UE, even though they are delivered over two different paths. This minimizes the need for PDCP packet reordering in the UE during downlink user plane switching and aggregation.

Flow control is executed in the common PDCP entity, which is in the gNodeB for a split compares the measured values with the target values configured in

UserPlaneProfileUeCfg.dlPdcpMcgSpsTargetTime UserPlaneProfileUeCfg.dlPdcpScgSpsTargetTime (for the SCG).

bearer. It measures the PDCP packet latency on the MCG and SCG user plane paths and (for the MCG) and

Based on the result of the comparison, flow control takes the following actions (independently on the MCG and SCG paths):

- If the measured latency does not exceed the target value, then flow control takes no action; it sends packets received from S1-U down to the RLC layer immediately.

- If the measured latency exceeds the target, then flow control limits the flow rate towards the relevant RLC entity and the remaining packets are buffered to be sent later. This eventually reduces the measured latency till it is once again below the target value.

By taking these actions, flow control minimizes both the need for packet forwarding at downlink user plane switching and packet reordering in the UE.

<!-- page: 76 -->

# 6 Mobility and Connectivity Procedures - NSA

This section describes NSA mobility and connectivity procedures. The procedures are triggered by one of the following changes:

- Service activity (for example establishing or releasing a data or voice bearer)

- Changes in NR coverage (for example leading to intra-frequency mobility or radio link failure)

- Changes in LTE coverage (for example leading to intra-frequency, inter-frequency or inter-RAT mobility, or radio link failure)

- Load management by the eNodeB (for example leading to inter-frequency handover)

In some cases, the procedure depends on which radio bearers are in use when the procedure is triggered.

Figure 6-1 shows an example of a series of NSA procedures for a UE moving through network with a single LTE layer and a single NR layer. The first procedure (on the left) is triggered by the establishment of a data bearer. Subsequent procedures are triggered by changes in NR and LTE coverage as the UE moves from left to right. The indicated sections provide more detail on each procedure. This simple example shows only a small subset of the procedures covered in this section; for example, it does not show EN-DC triggered handover, which can be used to move the UE between LTE layers to provide better access to EN-DC. The full set of procedures is given in the following sections. The examples used to illustrate the procedures assume that the default DRB is mapped to QCI9. If not, then replace all references to QCI9 with the appropriate QCI.

<!-- page: 77 -->

![Figure on page 77](5G_Mobility_and_Traffic_Management_Guideline_images/page_077_image_002.png)

Figure 6-1 - Example of NSA Mobility Procedures

**Inter-Site Anchoring Considerations**

To facilitate seamless mobility and maximize EN-DC availability, EN-DC should be configured between all LTE and NR cell pairs that have significant overlapping coverage. Depending on the physical distance between the relevant eNodeB and gNodeB, this may require inter-site anchoring. For inter-site anchoring to be possible, all involved nodes (both eNodeB and gNodeB) must meet the synchronization requirements for EN-DC. These are specified by the feature Basic Intelligent Connectivity , which requires the feature IEEE 1588 Time and Phase Synchronization as a prerequisite.

Figure 6-2, and the notes following it, show how inter-site anchoring can be used to improve EN-DC availability and streamline mobility.

<!-- page: 78 -->

![Figure on page 78](5G_Mobility_and_Traffic_Management_Guideline_images/page_078_image_002.png)

Figure 6-2 - Examples of Inter-Site Anchoring

Notes for Figure 6-2:

- Even when the gNodeB and eNodeB are co-sited, the exact coverage boundary is generally unpredictable, and the LTE and NR boundaries may not coincide. Inter-site anchoring ensures EN-DC can be set up between all the combinations of LTE and NR coverage that the UE could encounter.

- At the edge of an NR deployment, NR cell coverage is likely to extend into other sites. Inter-site anchoring ensures this additional NR coverage can be used for EN-DC. This can typically occur when the NR cells are not deployed at every site. Note that NR coverage extension is not due to a superior propagation, but rather a lack of NR neighbors that limit the service area of the NR cell, i.e. the area where the NR cell is the best server.

- When the LTE and NR layers are not built on the same site grid, or when the downlink powers of cells are very different, inter-site anchoring ensures that the different combinations of overlapping cells can be used for EN-DC. Note that the ENDC activation is attempted only with the best NR cell in the B1 report.

- An LTE cell may overlap with multiple NR cells, particularly when NR is deployed as small cells using FR2. Inter-site anchoring allows EN-DC to be set up with any of the overlapping NR cells.

To identify the NR cells with overlapping coverage and set up the neighbor relations required for EN-DC, the feature Automated Neighbor Relations can be used, as described in Section 10.2.16.

<!-- page: 79 -->

## 6.1 Idle Mode Procedures - NSA

In NSA, UEs in idle mode camp on LTE and follow legacy LTE procedures, for example:

- PLMN Selection

- System information acquisition

- Cell selection and reselection (intra-frequency, inter-frequency and inter-RAT)

- Tracking area updates and paging

These procedures are described in the LTE Mobility and Traffic Management Guideline.

Those aspects of idle mode behavior which are new with NSA are described in the following sections.

### 6.1.1 Upper Layer Indication - NSA

In NSA, UEs camp on LTE in idle mode, so they are not necessarily aware that the selected cell is EN-DC capable or that NR coverage exists. The network can, however, advise UEs that 5G service is potentially available by broadcasting an 'upper layer indication ' in system information. This indication is used by UEs when deciding whether to display a 5G status icon. The upper layer indication is described in detail in 4.5.

### 6.1.2 Idle Mode Reselection - NSA

In NSA, the default idle mode reselection behavior of EN-DC capable UEs mirrors that of legacy LTE UEs (as described in the LTE Mobility and Traffic Management Guideline).

To obtain different idle mode reselection behavior for EN-DC capable UEs, two features are available:

- Capability-Aware Idle Mode Control (CAIMC)

- Subscriber Triggered Mobility (STM)

Guidelines on how to use these two features for this purpose are provided in Section 9.2.1.

NR cells which support NSA only (not SA) do not provide idle mode services. UEs do not attempt to camp on NSA only cells, for the following reasons:

- UEs which are capable of NSA only (not SA) do not reselect to the NR cells in idle mode as they are not capable of doing so.

- UEs which are capable of SA and are camped on the LTE network in idle mode do not reselect to the NR cells because the LTE cells are not configured to instruct UEs to measure the NR frequencies for idle mode reselection.

<!-- page: 80 -->

- UEs which are capable of 5G standalone operation and enter the NR coverage area without camping on LTE first, are prevented from attempting to camp on the NSA-only cells because a Tracking Area Code (TAC) is not broadcast from these cells.

In a network which supports both NSA and SA, UEs in idle mode are permitted to reselect to the NR cells and camp on them, as described in Section 8.1.

## 6.2 Data Bearer Setup and Release Procedures - NSA

This section describes the NSA procedures associated with establishing and releasing a data bearer for transferring MBB data. VoLTE procedures are covered in Section 6.3.6.

### 6.2.1 UE EN-DC Capability Enquiry - NSA

Before the eNodeB can configure a UE with EN-DC, it needs to know which EN-DC band combinations the UE supports. The eNodeB obtains this information from the MME if available. If not, or if the information received from the MME does not cover the bands of interest, then the eNodeB sends a UE capability enquiry (with rat-type: eutra-nr, nr) to the UE.

This capability enquiry includes a list of NR bands (those defined within the GUtranSyncSignalFrequency instances) and a list of LTE bands (those defined within the EUtranFrequency instances). The UE responds with those band combinations that it supports; it does not include band combinations containing bands which fall outside those two lists.

For each GUtranSyncSignalFrequency , the eNodeB uses the following rules to determine which NR bands to include in the capability enquiry:

- If GUtranSyncSignalFrequency.band = -1, then all of the bands defined in the GUtranSyncSignalFrequency.bandList are included. The bandList is generated automatically by the eNodeB and includes all of the possible overlapping bands for the configured GUtranSyncSignalFrequency.arfcn .

- If GUtranSyncSignalFrequency.band is set to a value other than -1, then only this band is included. The band can only be set to values which appear in the bandList . This option can be used to limit the size of the capability enquiry message which is sent to the UE.

- Note that performing a TermPointToGNB lock/unlock operation, or an NRCellDU.bandListManual modification, can result in the value of GUtranSyncSignalFrequency.band being changed from its current setting to the first value in the NRCellDU.bandList .

The GUtranSyncSignalFrequency MO instances can be created either manually or automatically by the system:

<!-- page: 81 -->

**· Manual Creation of GUtranSyncSignalFrequency**

When GUtranSyncSignalFrequency is created manually, the band attribute is automatically set to -1. If desired, it can then be manually changed to one of the values in the automatically created GUtranSyncSignalFrequency.bandList .

**· Automatic Creation of GUtranSyncSignalFrequency**

The system automatically creates GUtranSyncSignalFrequency MO instances when an X2 link is set up between an eNodeB and a gNodeB. In this case the band attribute is automatically set to the first element in the ENDC-X2SetupResponse>Served NR Cell Information->FreqBandList, which is sent from the gNodeB to the eNodeB during the X2 setup. This list is taken from NRCellDU.bandListManual if it is configured, or from NRCellDU.bandList if the manual list is not configured. The bandList is generated automatically by the gNodeB to include all possible overlapping bands, in ascending order; so the first element in the bandList is always the band with the lowest band number.

The number of LTE and NR bands included by the eNodeB in the UE capability enquiry message varies, depending on the frequencies defined in the network. A larger number of defined bands leads to a larger number of possible supported bands and band combinations that the UE must include in its capability response message, which impacts the message size. The size therefore depends on the both the bands configured in the network and the UE capabilities.

For release 15 or earlier UEs, if the PDCP SDU message size exceeds 8188 octets, then the UE truncates its capability information to fit this size. The discarded capabilities can lead to the eNodeB choosing a non-optimal EN-DC or CA configuration for the UE.

To manage the message size and prevent the loss of capability information, the capability enquiry and response can be performed in a step-wise manner. This is controlled by the ENodeBFunction attribute ueCapabilityEnquirySteps . Three settings are possible: ONE_STEP , TWO_STEP and THREE_STEP .  Table 6-1 shows the procedures which result from these settings, and the recommendations for use.

Table 6-1 - Multi-Step UE Capability Enquiry

| ueCapability- EnquirySteps   | Procedure at Initial Attach                                                                                                                                                                                                                                                                                                                          | Procedure at UE Capability Refresh                                                                                                                                                                                                                                                                                                                   | Recommended Use                                                                  |
|------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------|
| ONE_STEP                     | See TWO_STEP                                                                                                                                                                                                                                                                                                                                         | The eNodeB sends one RRC UE Capability Enquiry message to the UE, with the RAT-TYPE containing EUTRA , EUTRA-NR and NR . The UE responds with one message containing all three capabilities.                                                                                                                                                         | Use if all the capabilities combined are likely to fit into 8188 octets.         |
| TWO_STEP                     | The eNodeB sends one RRC UE Capability Enquiry message to the UE, with the RAT-TYPE containing EUTRA . The UE responds with its EUTRA capabilities. If the UE is EN-DC capable, the eNodeB sends a second enquiry message with the RAT-TYPE containing EUTRA and EUTRA-NR . The UE responds with a second message containing these two capabilities. | The eNodeB sends one RRC UE Capability Enquiry message to the UE, with the RAT-TYPE containing EUTRA . The UE responds with its EUTRA capabilities. If the UE is EN-DC capable, the eNodeB sends a second enquiry message with the RAT-TYPE containing EUTRA and EUTRA-NR . The UE responds with a second message containing these two capabilities. | Use if only the EUTRA-NR and NR capabilities are likely to fit into 8188 octets. |

Table 6-1 - Multi-Step UE Capability Enquiry

<!-- page: 82 -->

| ueCapability- EnquirySteps   | Procedure at Initial Attach                                                                                                                                                                                                                                                                                                                                                                   | Procedure at UE Capability Refresh                                                                                                                                                                                                                                                               | Recommended Use                                                                        |
|------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------|
| THREE_STEP                   | The eNodeB sends one RRC UE Capability Enquiry message to the UE, with the RAT-TYPE containing EUTRA . The UE responds with its EUTRA capabilities. If the UE is EN-DC capable, the eNodeB sends two further enquiry messages, with the RAT-TYPE set to EUTRA and NR respectively. The UE then responds with two further messages, containing its EUTRA- NR and NR capabilities respectively. | Assuming the eNodeB knows the UE is EN-DC capable, the eNodeB sends three RRC UE Capability Enquiry messages to the UE, with the RAT-TYPE set to EUTRA, EUTRA-NR and NR respectively. The UE then responds with three messages, containing its EUTRA, EUTRA-NR and NR capabilities respectively. | Use if the EUTRA-NR and NR capabilities combined are unlikely to fit into 8188 octets. |

UEs that support UL segmentation (introduced in 3GPP Release 16) can divide the UE capability information into up to 16 segments, to avoid truncation. The eNodeB counter EUtranCellFDD/TDD.pmRrcSegmentAttUl counts how often this occurs.

To further reduce the UE capability message size, it is possible to disable the enquiry for RATs to which mobility is not required. This can be done in the eNodeB as follows:

- For WCDMA, deactivate the feature Coverage-Triggered WCDMA Session Continuity

- For GSM, deactivate the feature Coverage-Triggered GERAN Session Continuity

### 6.2.2 Data Bearer Setup from Idle Mode - NSA

Data bearer setup from idle mode typically occurs when there is MBB data to be sent on either the uplink or the downlink.

When the UE enters connected mode, the following bearers are set up in the eNodeB and the UE:

- An SRB for signaling.

- A Master Node Terminated Master Cell Group Data Radio Bearer (MN Terminated MCG DRB). The QCI used for this bearer is operator configurable; a typical value is QCI9.

- If the UE is registered in the IMS network, then an IMS signaling DRB is also set up, using QCI5. This is also an MN Terminated MCG DRB.

<!-- page: 83 -->

![Figure on page 83](5G_Mobility_and_Traffic_Management_Guideline_images/page_083_image_001.png)

Figure 6-3 - Bearer Setup from Idle Mode for an IMS-registered UE

Data bearers are always initially set up as MN Terminated MCG Bearers. This type of bearer provides LTE (MCG) resources only. NR (SCG) resources are added, if allowed, by a subsequent SN addition procedure, which converts the bearer to an SN Terminated Split Bearer, as described in Section 6.2.3.

### 6.2.3 Secondary Node Addition - NSA

Secondary Node (SN) addition is the procedure used to make NR resources available to a UE that already has LTE resources. The procedure includes adding a Secondary Cell Group (SCG) by converting one or more MN Terminated MCG Bearers into SN Terminated Split Bearers, as shown in Figure 6-4 and Figure 6-5.

![Figure on page 83](5G_Mobility_and_Traffic_Management_Guideline_images/page_083_image_002.png)

Figure 6-4 - Secondary Node Addition, Single Bearer Example

![Figure on page 83](5G_Mobility_and_Traffic_Management_Guideline_images/page_083_image_003.png)

Figure 6-5 - Secondary Node Addition, Multiple Bearer Example

<!-- page: 84 -->

Secondary Node Addition is either configuration-based or measurement-based. Configuration-based involves a blind setup to a pre-configured NR cell. Measurementbased involves UE measurements to detect and report coverage from NR cells. Which of these two options is used, depends on whether the LTE cell is configured with a reference to an NR cell.

The NR cell reference is defined with the following attribute:

- EUtranCellFDD . extGUtranCellRef

- EUtranCellTDD . extGUtranCellRef

If extGUtranCellRef is defined, then SN addition is configuration-based in the following cases:

- Initial context setup

- Incoming handover

Otherwise, SN addition is always measurement-based. Measurement-based SN addition uses the B1 measurement to detect coverage from NR cells.

The conditions necessary to start measurements, which frequency(s) are measured, and in what sequence they are measured, are all described in detail in Section 10.2.1.

The parameters controlling the B1 measurement triggering level are detailed in Section 11.2.2.

#### 6.2.3.1 Prerequisites for SN Addition

The following are prerequisites for SN addition:

- The feature Basic Intelligent Connectivity is activated.

- UE is EN-DC capable. UE capability IE en-DC-r15 is set to supported.

- The ENodeBFunction.endcAllowed attribute is set to true for the eNodeB.

This setting is overridden for UEs which belong to specific subscriber groups, using the attribute EndcUserProfile.endcAllowedOverride . If this attribute is true , ENDC is allowed for the subscriber group. If it is false , EN-DC is not allowed for the subscriber group.

It is recommended to set endcAllowed and endcAllowedOverride identically network-wide.

- The establishmentCause IE in the RRCConnectionRequest message is not set to emergency.

<!-- page: 85 -->

̶

̶

̶

̶

̶

- SN addition can be prevented if the Handover Restriction List (HRL) contains the value NRrestrictedinEPSasSecondaryRAT in the NR Restriction in EPS as Secondary RAT information element. There are three cases where SN addition is allowed:

̶

- The NR restriction is not present in the HRL. In this case SN addition is allowed.

- The NR restriction is present in the HRL, but the feature Enhanced NR Restriction is activated. In this case, SN addition is allowed on FR1 (low-band and mid-band NR carriers) but not on FR2 (high-band NR carrier).

- The NR restriction is present in the HRL, but it is ignored because the parameter ENodeBFunction.zzzTemporary67 = 1. In this case SN addition is allowed on all bands. This setting can be used to quickly de-restrict access to EN-DC (for example during a special event) without the need to change the NR restriction configuration in the core network.

Section 6.2.3.3 contains more information on the NR restriction.

- At least one PLMN ID matches. The PLMNs for which EN-DC is supported are configured in the EUtranCellFDD/TDD.endcAllowedPlmnList . If endcAllowedPlmnList is empty, then EN-DC is not allowed in that LTE cell. At setup, the PLMNs received from the MME in the HRL are compared with the PLMN IDs configured in the endcAllowedPlmnList of the serving LTE cell. If at least one PLMN ID matches, EN-DC is allowed for the UE. If no HRL is received from the MME, EN-DC is allowed for the UE if the ENodeBFunction.eNodeBPlmnId is listed in the endcAllowedPlmnList .

- An EN-DC band combination exists, meeting the following requirements:

̶

- The EN-DC band combination is included in the MR-DC Capabilities signaled from the UE to the eNodeB.

̶

- The band combination has the same LTE band as the serving LTE cell.

- The band combination has the same NR band as one external NR cell defined and hosted by a gNodeB with X2 connectivity.

- The UE indicates support for simultaneousRxTxInterBandENDC for the band combination for combinations involving TDD (FDD-TDD or TDD-TDD)

- If ENodeBFunction.endcIntraBandBlocked = true (default) and CarrierAggregationFunction.endcCaPolicy = NR_PREFERRED , then the LTE and NR bands must not overlap.

- Note that the default setting can prevent EN-DC on a band combination that is otherwise valid. If this occurs, set endcIntraBandBlocked = false to disable this block.

- The serving LTE frequency is not listed in the attribute GUtranFreqRelation.endcNotAllowedEUtranFreqRef

<!-- page: 86 -->

- Criteria related to VoLTE and MCPTT.

If the NR band in the selected band combination is low or mid-band (FR1), then at least one of the following conditions is met:

̶

- None of the bearers established for this UE has serviceType = VoIP or PTT (for example, VoLTE and Mission Critical Push to Talk)

- The UE indicates support for Dynamic Power Sharing for the selected EN-DC band combination.

̶

- The attribute endcSplitAllowedNonDynPwrShUe is true

If the NR band in the selected band combination is high-band (FR2), then at least one of the following conditions is met

- None of the bearers established for this UE has serviceType = VoIP or PTT (for example, VoLTE and Mission Critical Push to Talk)

̶

̶

- The attribute inhibitEndcFr2Volte is false

- Split is allowed for at least one bearer:

̶

- For at least one bearer, ARP value of the bearer > meNbS1TermReqArpLev of that same bearer and the ARP value is not listed in meNbS1TermExclArpList . Refer to Section 6.4 for details.

- No bearer prevents other bearers from being split. In other words, all bearers allow other bearers to be split:

̶

- For all bearers, ARP value of the bearer > splitNotAllowedUeArpLev of that same bearer. Refer to Section 6.4 for details.

- The UE uplink connection is not in TTI bundling mode.

- The UE is not overheated (see Section 10.2.1.9)

In addition to these prerequisites, there is a mechanism to inhibit SN addition while a mobile originated voice call (with the establishment cause set to mo-VoiceCall in the RRCConnectionRequest) is being set up:

- If ENodeBFunction.endcSplitAllowedMoVoice = true, then this mechanism does not apply, and SN addition is not impacted.

- If ENodeBFunction.endcSplitAllowedMoVoice = false, then the guard timer ENodeBFunction.tMoVoiceBearerEstSupervision is started. This guard timer inhibits SN addition until it is stopped by one of the following events:

̶

- The MO voice call is successfully setup, or

̶

- The MO voice call establishment fails, or

̶

- The guard timer expires (default 2 s)

̶

<!-- page: 87 -->

- When this inhibition stops, the other prerequisites for SN addition (listed above) are applied.

There is also a mechanism to inhibit SN addition for a configurable time after a VoLTE RAB is released. The mechanism is enabled by setting endcInhibitTime , and/or endcInhibitTimeOverride > 0, as described in Section 6.4.

#### 6.2.3.2 Preventing Recurring EN-DC Setup Failures

The feature Basic Intelligent Connectivity contains a function to detect and prevent recurring EN-DC setup failures, for a particular UE on a particular NR frequency. For more information refer to 10.2.1.10.

#### 6.2.3.3 Preventing SN Addition for Subscribers Without a 5G Subscription

Operators may wish to prevent subscribers without a 5G subscription from accessing 5G resources, even when the subscriber's UE is 5G capable.

This can be achieved using either NR Restriction or Subscriber Profile ID (SPID), as described below:

**Using NR Restriction to control access to EN-DC**

The MME feature NR Access Control uses the NR Restriction in EPS as Secondary RAT IE to indicate whether a particular UE is restricted from accessing NR NSA. This IE is optionally included in the Handover Restriction List (HRL) which is sent from the MME to the eNodeB over S1-C, or between eNodeBs over X2-AP at handover. The MME includes the IE and sets its value to NRrestrictedinEPSasSecondaryRAT if the HSS restricts the UE from using NR NSA, or if the UE 's IMSI falls within an IMSI range which is configured with a restriction in the MME itself. By default, the IE is not included and access to NR NSA is not restricted.

<!-- page: 88 -->

![Figure on page 88](5G_Mobility_and_Traffic_Management_Guideline_images/page_088_image_001.png)

Figure 6-6 - Handover Restriction List and NR Restriction

How the NR restriction IE is handled by the eNodeB depends on whether the eNodeB feature Enhanced NR Restriction is active, and on the value of ENodeBFunction.zzzTemporary67 , as follows:

- The NR restriction is not present in the HRL. In this case the UE can access EN-DC.

- The NR restriction is present in the HRL, but the feature Enhanced NR Restriction is activated . In this case, the UE can access EN-DC on FR1 (low-band and mid-band NR carriers) but not on FR2 (high-band NR carriers).

The Enhanced NR Restriction feature therefore allows an operator who has both FR1 and FR2 to reserve the FR2 spectrum for 'prioritized' users only; namely users that do not have the NR restriction. This feature is provided because 3GPP currently has no support for band-level restriction of FR1 and FR2 resources.

- The NR restriction is present in the HRL, but it is ignored because the parameter ENodeBFunction.zzzTemporary67 = 1. In this case the UE can access EN-DC on all bands.

This setting can be used to quickly de-restrict access to EN-DC to all EN-DC bands (for example during a special event) without the need to change the NR restriction configuration in the core network.

The NR Restriction does not impact the Differentiate A2 Threshold functionality in the NR Mobility feature.

<!-- page: 89 -->

**Using SPID to control access to EN-DC**

The Subscriber Profile ID (SPID) is a number from 1 to 256 which is set per subscriber in the HSS and can be used to indicate which subscribers have access to NSA.

The SPID is transferred from the HSS to the MME and from there to the eNodeB, where it can be used to selectively control access to EN-DC per subscriber group, using the ASGH Framework feature, in one of two ways:

- Restrict access to EN-DC only for certain SPID values

̶

- Set ENodeBFunction.endcAllowed = true

- Set EndcUserProfile.endcAllowedOverride = false for the subscriber groups which are not allowed to access EN-DC

̶

- Allow access to EN-DC only for certain SPID values

̶

- Set ENodeBFunction.endcAllowed = false

- Set EndcUserProfile.endcAllowedOverride = true for the subscriber groups which are allowed to access EN-DC

̶

These settings have the following limitations:

- They do not impact subscribers that are prevented from using EN-DC by the NR Restriction; such subscribers remain unable to access to EN-DC.

- They do not impact the feature Capability-Aware Idle Mode Control (CAIMC).

- They do not impact the Differentiate A2 Threshold for EN-DC Capable UE functionality in the Basic Intelligent Connectivity feature, described in Section 10.2.1.6.

To ensure predictable access to EN-DC, set endcAllowed and endcAllowedOverride identically network-wide.

#### 6.2.3.4 Preventing SN Addition for Misbehaving UEs

Some EN-DC capable UEs may misbehave when configured with split bearers. To avoid split bearers being configured for such UEs, the eNodeB feature Differentiated UE Handling can be used. This feature allows the operator to treat UEs differently based on the device type. The device type is communicated from the MME to the eNodeB via the Masked International Mobile Equipment Identity Software Version (IMEISV).

The IMEISV contains:

- The Type Allocation Code (TAC), used to identify the device type

- The masked serial number (SNR), masked to prevent identification of the end user

- Software version number (SVN), used to identify the software version in use by the UE

<!-- page: 90 -->

The Differentiated UE Handling feature provides a framework to control which IMEISVs can use split bearer. Two approaches are possible per feature:

- Disallow split bearer for problematic devices only (not-allowed list), or

- Allow split bearer for certain devices only (allowed list)

**Disallow Split Bearer for Problematic Devices Only (not-allowed list)**

Use the following steps to disallow split bearer use on problematic devices only, and allow it on all other capable devices:

- First, allow by default:

̶

- Include the value 6 ( FEATURE_NAME7 , which is Basic Intelligent Connectivity , ENDC-Triggered Handover during Setup , and EN-DC-Triggered Handover during Connected Mode Mobility ) in the array

ImeisvTable.listOfFeaturesDefaultOn

- Second, disallow on problematic devices:

̶

- Configure ImeisvProfile.listOfTacSvSns with the details of the problematic devices.

̶

- Include the value 6 ( FEATURE_NAME7 , which is Basic Intelligent Connectivity , ENDC-Triggered Handover during Setup , and EN-DC-Triggered Handover during Connected Mode Mobility ) in the array

ImeisvProfile.listOfFeaturesToTurnOff

**Allow Split Bearer for Certain Devices Only (allowed list)**

Use the following steps to allow split bearer only on certain devices, for example the devices used in a trial:

- First, disallow by default:

̶

- Include the value 6 ( FEATURE_NAME7 , which is Feature Basic Intelligent Connectivity , EN-DC-Triggered Handover during Setup , and EN-DC-Triggered Handover during Connected Mode Mobility ) in the array

ImeisvTable.listOfFeaturesDefaultOff

- Second, allow on non-problematic devices:

̶

- Configure ImeisvProfile.listOfTacSvSns with the details of the allowed devices.

̶

- Include the value 6 ( FEATURE_NAME7 , which is feature Basic Intelligent Connectivity , EN-DC-Triggered Handover During Setup , and EN-DC-Triggered Handover During Connected Mode Mobility ) in the array

ImeisvProfile.listOfFeaturesToTurnOn Note that any one device must only be included in either the not-allowed list or allowed list, not both.

<!-- page: 91 -->

#### 6.2.3.5 Preventing SN Addition on ESS Carriers for Non-Compliant UEs

When a UE reports an ESS NR cell in the Event B1, before attempting SN addition the gNodeB checks that the UE is capable of EN-DC on the ESS NR cell. To be capable, the UE must support:

- Rate matching around LTE CRS

- DMRS symbol locations that do not collide with LTE CRS

If the UE does not support these capabilities, the gNodeB rejects the SN addition request by sending X2AP: SGNB ADDITION REQUEST REJECT with cause value radioNetwork:unspecified to the eNodeB.

When the eNodeB receives the reject with this cause value, it increments the PM counter pmEndcSetupFailUeCap . The subsequent handling by the eNodeB depends on the setting of CarrierAggregationFunction.endcCaPolicy (introduced in Section 5.3.4):

- endcCaPolicy = LTE_PREFERRED

As long as the triggering conditions are fulfilled, the UE re-reports the same B1 event multiple times, the gNodeB rejects the SN addition request multiple times, and the eNodeB increments the counter multiple times.

- endcCaPolicy = NR_PREFERRED

After the gNodeB rejects the first SN addition request, the eNodeB disallows the ESS capable NR frequency for that UE and no further SN addition request attempts occur in this serving LTE cell on this NR frequency for this UE. Any following periodic B1 measurement does not include a disallowed NR frequency. The disallowed list is kept until the UE is released or handed over to another cell. The list is not transferred to the target during handover.

If other (non-ESS) NR frequency(s) are configured, then the UE continues to search for a suitable NR cell on those.

To prioritize non-ESS carriers over ESS carriers, set endcB1MeasPriority to a higher value on the non-ESS carrier (which typically has a larger bandwidth). See section 10.2.1 for more information on setting endcB1MeasPriority .

#### 6.2.3.6 Preventing SN Addition with Particular NR Cells

ANR can sometimes add a GUtranCellRelation to a distant NR cell that is unsuitable for EN-DC. To prevent EN-DC using such cells, set isEndcAllowed = false on the GUtranCellRelation . Additionally, set isRemoveAllowed = false on the GUtranCellRelation , to prevent ANR from removing and recreating the relation with isEndcAllowed = true .

<!-- page: 92 -->

#### 6.2.3.7 Preventing SN Addition Attempts to Other Vendor gNodeBs

ENDC does not work with some vendor's gNodeB s. To prevent SN addition attempts with these gNodeBs, which will fail, the gNodeBs can be blocklisted by including the gNodeB IDs in the ENodeBFunction.blockedGNodeBList .

#### 6.2.3.8 Secondary Node Addition Failure

The procedure to add a secondary node may fail. One cause of failure is an unsuccessful random access on the NR cell. Random access for SN addition is supervised by the timer GNBDUFunction.Rrc.t304 , which is set in the gNodeB and signaled to the UE in the RRC Reconfiguration message. If t304 expires before the random access is successfully completed, then the UE reports a radio link failure (RLF) to the eNodeB.

If SN addition fails, the PDCP is moved from the SN (gNodeB) back to the MN (eNodeB), which includes reconfiguring the SN Terminated Split Bearer to an MN Terminated MCG Bearer. The eNodeB then configures a B1 measurement in the UE to detect NR coverage (regardless of whether the eNodeB uses configuration-based or measurement-based SN addition) and, if a B1 report is received from the UE, the eNodeB reattempts SN addition.

#### 6.2.3.9 EN-DC Triggered Handover (ENDCHO)

A UE is typically provided with EN-DC service using the serving LTE cell. However, if another LTE cell is better suited to provide the UE with EN-DC, then it can be moved to that cell using EN-DC triggered handover (ENDCHO).

Another LTE cell is better suited to provide the UE with EN-DC in the following cases:

- The UE cannot use the serving LTE cell for EN-DC, for example because the cell is not capable of EN-DC, or because the UE does not support the EN-DC band combinations available on the cell, or because the combination of LTE and NR frequencies has been manually disallowed on the serving LTE cell. The UE can, however, use another LTE cell for EN-DC.

- The UE can use the serving LTE cell for EN-DC, but the UE does not have coverage from the required NR frequency(s). However, the UE does have coverage from a lower priority NR frequency that the UE can use for EN-DC if it moves to another LTE cell.

- The UE can use the serving LTE cell for EN-DC and the UE has coverage from the required NR frequency(s). However, the UE also has coverage from a higher priority NR frequency that it can use for EN-DC if it moves to another LTE cell.

ENDCHO functionality is provided by the features shown in Table 6-2 and Figure 6-7. See the indicated sections for more detail.

<!-- page: 93 -->

Table 6-2 - EN-DC Triggered Handover Features

| Feature Name                                                              | Node Type   | Trigger                                    | Measurements Configured   |
|---------------------------------------------------------------------------|-------------|--------------------------------------------|---------------------------|
| EN-DC Triggered Handover During Connection Setup (Section 10.2.13)        | Baseband    | Connection setup                           | B1 and A5                 |
| EN-DC Triggered Handover During Connected Mode Mobility (Section 10.2.15) | Baseband    | Incoming handover and RRC re-establishment | B1 and A5                 |

Table 6-2 - EN-DC Triggered Handover Features

![Figure on page 93](5G_Mobility_and_Traffic_Management_Guideline_images/page_093_image_001.png)

Figure 6-7 - EN-DC Triggered Handover Procedures Notes for Figure 6-7:

- UE A - EN-DC Triggered Handover During Setup

<!-- page: 94 -->

̶

̶

- Assume that the serving LTE cell does not support EN-DC, because the endcAllowedPlmnList is empty. Assume also that it is configured with a GUtranFreqRelation , which allows the NR frequency to be measured for ENDCHO.

- The ENDCHO procedure is triggered when the UE performs an initial context setup

- The eNodeB configures the UE with an A5 measurement to detect coverage from an EN-DC capable LTE cell, and a B1 measurement to detect coverage from NR.

̶

- When the B1 report is received, it is stored and the eNodeB waits for the A5 report.

- If the A5 report is received within ReportConfigB1GUtra . reportIntervalB1 (default value 240 ms) of the B1 report, then eNodeB instructs the UE to perform the ENDCHO.  If the A5 report is received after this time expires then it cannot be used in combination with that B1 report for ENDCHO.

̶

- Upon receiving the incoming handover, the eNodeB initiates SN addition using the forwarded B1 measurement results.

̶

- UE B - EN-DC Triggered Handover During Connected Mode Mobility

̶

- This is like UE A case, but the triggers for ENDCHO are incoming handover and RRC re-establishment rather than initial context setup.  After this, the process is the same.

#### 6.2.3.10 Controlling Allowed Frequency Combinations for EN-DC

It is sometimes desirable to control which LTE and NR frequency combinations can be used for EN-DC, either by SN addition and/or by EN-DC triggered handover. There are two main attributes to control this:

- EUtranFreqRelation.endcHoFreqPriority Setting endcHoFreqPriority to -1 prevents all ENDCHO to the LTE frequency. Setting endcHoFreqPriority to 0 to 7 determines which LTE frequencies to measure for ENDCHO if not all can be measured (higher value takes priority).

- GUtranFreqRelation.endcNotAllowedEUtranFreqRef This attribute contains a list of references to LTE frequencies that are not allowed to be

used for EN-DC in combination with the NR frequency of the GUtranFreqRelation . The attribute can therefore be used to prevent either SN addition or ENDCHO or both, as follows:

̶

- SN addition: Including the serving LTE cell frequency in the list prevents SN addition using the NR frequency.

- ENDCHO: Including a neighboring LTE frequency in the list prevents the combination of that frequency and the NR frequency being targeted for ENDCHO.

̶

̶

<!-- page: 95 -->

Figure 6-8 illustrates how these two attributes can be used to control whether EN-DC is allowed on various frequency combinations. In this example, the UE is served by LTE Cell A on frequency 870. The desired outcome, shown in the table, is purely to demonstrate configuration options; it is not intended to represent a real case.

![Figure on page 95](5G_Mobility_and_Traffic_Management_Guideline_images/page_095_image_002.png)

Figure 6-8 - Controlling SN Addition versus EN-DC Triggered Handover

As a more practical example, Figure 6-9 and the following notes show how to prevent EN-DC on an undesirable frequency combination. In this case, the undesirable combination is LTE 5 MHz + NR 10 MHz, which has the lowest total bandwidth of the four possible frequency combinations.

<!-- page: 96 -->

![Figure on page 96](5G_Mobility_and_Traffic_Management_Guideline_images/page_096_image_002.png)

Figure 6-9 - Eliminating an Undesirable Frequency Combination for EN-DC

Notes for Figure 6-9:

- & 2)   When the UE is within coverage of NR 100 MHz, the undesirable frequency combination can be prevented by giving NR 100 MHz a higher endcB1MeasPriority than NR 10 MHz This causes NR 100 MHz to be measured first, so SN addition occurs with this frequency.

- & 4)   When the UE does not have coverage from NR 100 MHz, an additional solution is needed to prevent EN-DC on the undesirable frequency combination. The solution is to include a reference to the LTE 5 MHz carrier in the endcNotAllowedEUtranFreqRef of the GUtranFreqRelation from LTE 5 MHz to NR 10 MHz. This prevents SN addition using that frequency combination and forces ENDCHO (as shown by 4), while still allowing SN addition in cases (1), (2) and (3). Note, however, that this solution assumes that LTE 20 MHz coverage is better than or equal to that of LTE 5 MHz. If not, then there will be areas where the ENDCHO will not be possible, and EN-DC cannot be set up.

An additional practical example is provided in Figure 6-10. In this example there are two operators who both use Ericsson equipment but do not have an X2 interface configured between them. This makes it impossible to set up EN-DC using LTE from one operator and NR from the other. The notes below the figure show how to use

endcNotAllowedEUtranFreqRef to prevent the eNodeB from attempting to target inappropriate (inter-operator) frequency combinations for SN addition or ENDCHO. In this example, assume that the UEs are capable of EN-DC on all frequency combinations and are allowed to use both PLMNs.

<!-- page: 97 -->

![Figure on page 97](5G_Mobility_and_Traffic_Management_Guideline_images/page_097_image_001.png)

Figure 6-10 - Inter-Operator Example of Using endcNotAllowedEUtranFreqRef

**Notes for Figure 6-10:**

- When the UE camps on LTE 1 in this location, NR 3 can be used for ENDCHO, but not for SN addition.

̶

- To prevent NR 3 being considered for SN addition, add a reference to frequency LTE 1 in the endcNotAllowedEUtranFreqRef of the GUtranFreqRelation from LTE 1 to NR 3

- When the UE camps on LTE 2, EN-DC is available only via ENDCHO, and only with two of the four possible frequency combinations.

- To prevent LTE 1 + NR 3 from being considered for ENDCHO, add a reference to frequency LTE 1 in the endcNotAllowedEUtranFreqRef of the GUtranFreqRelation from LTE 2 to NR 3

- To prevent LTE 3 + NR 1 from being considered for ENDCHO, add a reference to frequency LTE 3 in the endcNotAllowedEUtranFreqRef of the GUtranFreqRelation from LTE 2 to NR 1

- When the UE camps on LTE 3 in this location, NR 1 can be used for ENDCHO, but not for SN addition.

- To prevent NR 1 being considered for SN addition, add a reference to frequency LTE 3 in the endcNotAllowedEUtranFreqRef of the GUtranFreqRelation from LTE 3 to NR 1

<!-- page: 98 -->

### 6.2.4 Data Bearer Addition - NSA

The addition of an MBB data bearer is triggered by subscriber activity, for example when the subscriber starts an application requiring QoS treatment which is different from that of the default bearer.

Additional bearers are set up as either MN or SN terminated as follows:

- If the additional bearer is allowed to be configured as an SN Terminated bearer, then it is set up to match any pre-existing SN Terminated bearers, either as an SN Terminated Split DRB or as an SN Terminated MCG DRB.

- If the additional bearer is not allowed to be configured as an SN Terminated bearer, then it is set up as an MN Terminated MCG DRB.

- If the additional bearer prevents other bearers from being configured as split bearers, then any pre-existing SN Terminated Split DRBs are reconfigured as SN Terminated MCG DRBs.

- Setting up a mix of additional bearer types is supported.

Figure 6-11 shows an example where two additional bearers are set up, one as an SN Terminated Split DRB and one as an MN Terminated MCG DRB. In this example none of the bearers prevent other bearers from being configured as split.

![Figure on page 98](5G_Mobility_and_Traffic_Management_Guideline_images/page_098_image_001.png)

Figure 6-11 - Bearer Addition Procedure

### 6.2.5 Secondary Node Release (keeping Master Node) - NSA

Secondary Node Release, keeping the Master Node, can be initiated either by the Master Node or the Secondary Node.

The Master Node initiates a Secondary Node release in the following cases:

- MN receives SCGFailureInformationNR message from the UE, due to Radio Link Failure

- MN detects LTE mobility due to intra-cell, intra-frequency or inter-frequency (those cases where it is not possible to keep the SN, see Section 6.6.1)

<!-- page: 99 -->

The Secondary Node initiates a Secondary Node release in the following cases:

- SN detects expiry of the Random Access Supervision Timer or failure in another part of the SCG Addition process

- SN detects that RLC exceeds its maximum downlink retransmission

- SN detects NR cell lock

- SN receives an A2 critical report from the UE, as described in Section 6.3.4.

Secondary Node Release, keeping the Master Node, is not triggered by inactivity; inactivity causes release to idle mode, as described in Section 6.2.6.2.

When the SN is released, any SN terminated bearers are transitioned to MN Terminated MCG Bearers, as shown in Figure 6-12. The eNodeB then configures a B1 measurement in the UE to detect NR coverage and, if a B1 report is received from the UE, the eNodeB attempts SN addition.

![Figure on page 99](5G_Mobility_and_Traffic_Management_Guideline_images/page_099_image_002.png)

Figure 6-12 - SN Release - Split Bearer Example

### 6.2.6 Release to Idle Mode - NSA

UE release from connected mode to idle mode is triggered by either the MME or the eNodeB. Reasons for the eNodeB to trigger a release are UE inactivity or LTE Radio Link Failure.

For inactivity, the procedure depends on the bearers in use by the UE. There are two cases:

- UE with only Master Node (MN) terminated bearers

- UE with one or more Secondary Node (SN) terminated bearers

In both cases the release decision is taken by the MN (eNodeB). However, when the UE has an SN terminated bearer, the eNodeB obtains assistance from the SN. The following sections provide more detail on these two cases.

<!-- page: 100 -->

At release to idle mode, the feature Capability-Aware Idle Mode Control can be used to alter the idle mode reselection behavior of UEs, for example to steer EN-DC capable UEs towards EN-DC capable LTE carriers. This is described in Section 9.2.1.1.

#### 6.2.6.1 Inactivity Release - UE with only MN terminated bearers

If the UE has only MN terminated bearers (no SN terminated bearers), then the inactivity release is identical to that for legacy LTE. The eNodeB releases the UE if no data has been sent in the uplink or the downlink on any DRB for a period of at least Rcs.tInactivityTimer (set in the eNodeB) and no NAS message has been sent or received for at least 4 seconds.

#### 6.2.6.2 Inactivity Release - UE with an SN terminated bearer

If the UE has one or more SN terminated bearers, then both the MN (eNodeB) and the SN (gNodeB) monitor UE activity. The monitoring is performed at the PDCP layer. The MN monitors the activity of any MN terminated DRBs. The SN monitors the activity of SN terminated DRBs and informs the eNodeB of the results over the X2-AP interface.

The node responsible for actually releasing a UE due to inactivity is the eNodeB. It releases the UE when all DRBs (both MN and SN terminated) have been inactive for a period of at least Rcs.tInactivityTimer (set in the eNodeB) and no NAS message has been sent or received for at least 4 seconds. To achieve this, the following processes are followed.

**SN (gNodeB) Inactivity Monitoring**

The SN considers a UE inactive if all SN terminated DRBs have been inactive in both the uplink and the downlink for a period of at least

InactivityProfileUeCfg.tInactivityTimerEndcSn (default 5 sec). The SN informs the MN (eNodeB) of the UE inactivity by sending the notification SGNB Activity Notification (inactive) over the X2-AP interface.

The SN considers a UE active if any SN terminated DRB has any activity in either the uplink or downlink. The SN informs the MN (eNodeB) of the UE activity by sending the notification SGNB Activity Notification (active) over the X2-AP interface.

The SN does not initiate release based on inactivity. It simply notifies the eNodeB of the activity, and the eNodeB determines when to release the UE.

**MN (eNodeB) Inactivity Monitoring**

The UE is released to idle mode when the eNodeB decides that the DRBs (both MN and SN terminated) are inactive and NAS signaling has not occurred for at least 4 seconds.

The eNodeB uses the following rules to decide whether a DRB is inactive:

<!-- page: 101 -->

- Any MN terminated DRB is considered inactive by the eNodeB when no data has been transmitted in either the uplink or the downlink on that DRB for at least Rcs.tInactivityTimer .

- All SN terminated DRBs are considered inactive by the eNodeB when the notification SGNB Activity Notification (inactive) is received by the eNodeB and an additional waiting time has elapsed without receiving an active notification. The additional waiting time is Rcs.tInactivityTimer - 5s, or zero if Rcs.tInactivityTimer = 4s. The additional waiting time does not depend on the setting of tInactivityTimerEndcSn .

Figure 6-13 summarizes the procedure for release due to inactivity for a UE with both an MN terminated MCG DRB and an SN terminated split DRB.

![Figure on page 101](5G_Mobility_and_Traffic_Management_Guideline_images/page_101_image_002.png)

Figure 6-13 - Release due to Inactivity - Split Bearer Example

## 6.3 NR Coverage-Triggered Mobility Procedures - NSA

This section covers mobility procedures that are triggered by changes in NR coverage.

NR measurement reports that arrive during an LTE handover can cause problems. To prevent such problems set EUtranCellFDD / TDD . nrMeasRepBlockedDuringHO = true . This prevents the eNodeB from forwarding NR measurements to the gNodeB during LTE handover.

<!-- page: 102 -->

### 6.3.1 NR Intra-Frequency PSCell Change - NSA

This procedure is enabled by the gNodeB feature NR Mobility (FAJ 121 5041), Section 10.3.4.1.

Two NR cells are considered intra-frequency if they share the same SSB frequency and SSB subcarrier spacing, meaning they have identical values for the following attributes:

- NRCellDU . ssbFrequency (or ssbFrequencyAutoSelected if ssbFrequency = 0

- NRCellDU . ssbSubCarrierSpacing

Note, however, that the two cells do not need to have the same bandwidth ( bSChannelBwDL and bSChannelBwUL ) to be considered intra-frequency, as shown in Figure 6-14.

![Figure on page 102](5G_Mobility_and_Traffic_Management_Guideline_images/page_102_image_001.png)

Figure 6-14 - Intra-Frequency and Inter-Frequency Examples

NR intra-frequency PSCell change is triggered by the gNodeB when an NR A3 report is received from the UE (forwarded by the eNodeB). The procedure is shown in Figure 6-15.

![Figure on page 102](5G_Mobility_and_Traffic_Management_Guideline_images/page_102_image_002.png)

Figure 6-15 - NR Intra-Frequency PSCell Change

Notes for Figure 6-15:

)

<!-- page: 103 -->

̶

- Serving SN receives (via the eNodeB) an NR Event A3 report from the UE

- Serving SN initiates a PSCell change

For the PSCell change to be performed the following must be fulfilled:

- Target cell is configured in the serving SN ( NRCellCU or ExternalNRCellCU with matching nRPCI exists).

- A neighbor relation exists between the serving and reported cells, either a manuallycreated NRCellRelation with isHoAllowed = true , or an ANR-created lwNeighborRel (which always allows PSCell change).

- For inter-gNodeB PSCell change:

̶

- The serving eNodeB has an X2 link configured ( TermPointToGNB MO, with operationalState = ENABLED ) to the gNodeB hosting the target NR cell. This allows the LTE cell to be used as an anchor for the target NR cell.

̶

- If a GUtranCellRelation exists between the LTE PCell and the target PSCell, then GUtranCellRelation . isEndcAllowed = true .

In this case, the outcome is determined as follows:

- ·

- The action is determined by

IntraFreqMCCellProfileUeCfg . endcActionEvalFail :

- If endcActionEvalFail = IGNORE , then the existing EN-DC configuration is kept, and Cell A remains the PSCell.

- If endcActionEvalFail = RELEASE , then an SN initiated SN Release is triggered and the eNodeB configures a B1 measurement in the UE.

̶

If the PSCell change request is rejected by the target gNodeB due to insufficient UE capabilities or by the eNodeB due to misconfiguration, then the target cell can be blocklisted for the lifetime of the UE connection in the source gNodeB; refer to Section 6.3.2.1 for further details.

NR neighbor relations can be either manually-created or automatically created by ANR. Manually-created neighbor relations are represented by an instance of the MO NRCellRelation . Automatically-created neighbor relations are represented by an entry in the read-only attribute lwNeighborRel . Figure 6-16 shows the managed objects involved.

<!-- page: 104 -->

![Figure on page 104](5G_Mobility_and_Traffic_Management_Guideline_images/page_104_image_002.png)

Figure 6-16 - Key Managed Objects for NR Neighbor Configuration

**Notes for Figure 6-16:**

- This solid line indicates that the NRCellRelation MO is a child of the NRCellCU MO.

- This dashed line indicates the nRCellRef for an intra -gNodeB relation. For example, a relation from NRCellCUA to NRCellCUB consists of an NRCellRelation which is a child of NRCellCUA and contains an nRCellRef attribute pointing to NRCellCUB .

- This dashed line indicates the nRCellRef for an inter -gNodeB relation. For example, a relation from NRCellCUA to ExternalNRCellCUC consists of an NRCellRelation which is a child of NRCellCUA and contains an nRCellRef attribute pointing to ExternalNRCellCUC .

- Neighbor relations created by ANR are represented as entries in the read-only attribute lwNeighborRel . These can be either intra or inter-gNodeB.

### 6.3.2 NR Inter-Frequency PSCell Change - NSA

This procedure is enabled by the Mobility Control at Poor Coverage (MCPC) functionality under the gNodeB feature NR Mobility , Section 10.3.4.2.

<!-- page: 105 -->

![Figure on page 105](5G_Mobility_and_Traffic_Management_Guideline_images/page_105_image_002.png)

Figure 6-17 - NR Inter-Frequency PSCell Change

Notes for Figure 6-17:

- Serving SN receives (via the eNodeB) an Event A2 Entering Search Zone report from the UE and configures an Event A5 measurement in the UE to search for a suitable inter-frequency target

- Serving gNodeB receives (via the eNodeB) an Event A5 Inter-Frequency Candidate from the UE

- Inter-frequency PSCell change to NR Cell B occurs if the reported cell is high priority. If the reported cell is low priority, the report is stored for possible later use; see Section 10.3.4.2 for details.

For the inter-frequency PSCell change to be performed the following must be fulfilled:

- The target cell must be configured in the serving SN ( NRCellCU or ExternalNRCellCU with matching nRPCI exists)

- A neighbor relation exists between the serving and reported cell, either a manuallycreated NRCellRelation with isHoAllowed = true , or an ANR-created lwNeighborRel (which always allows PSCell change).

- For inter-gNodeB PSCell change:

̶

- The serving eNodeB has an X2 link configured ( TermPointToGNB MO, with operationalState = ENABLED ) to the gNodeB hosting the target NR cell. This allows the LTE cell to be used as an anchor for the target NR cell.

̶

- If a GUtranCellRelation exists between the LTE PCell and the target PSCell, then GUtranCellRelation . isEndcAllowed = true .

<!-- page: 106 -->

- The UE Handover Restriction List (HRL) contains at least one PLMN supported by the target cell, and the TAC used in the target cell is not forbidden by the HRL.

̶

- If the gNodeB has not received the HRL from the eNodeB, then the used PLMN in the source cell must also be supported by the target cell.

Note that the parameter inhibitEndcFr2Volte does not impact PSCell change.

If the reported PCI does not have a corresponding neighbor relation, and cannot be identified using ANR, then the PSCell change cannot be initiated. The measurement report is then discarded, and the UE stays in the search zone and waits for a new measurement report.

An inter-frequency PSCell change can also be triggered by an A2 Critical Coverage measurement report, if MCPC has stored a low priority PSCell change candidate, as described in Section 10.3.4.2.

#### 6.3.2.1 Blocklisting due to Rejected PSCell Change

If the PSCell change request is rejected by the target gNodeB due to insufficient UE capabilities or by the eNodeB due to misconfiguration, then the target cell is blocklisted for the lifetime of the UE connection in the source gNodeB. This prevents further PSCell change attempts to that cell.

Examples of misconfiguration are a missing GUtranSyncSignalFrequency , GUtranFreqRelation , ExternalGNodeBFunction , ExternalGUtranCell or TermPointToGNB .

However, blocklisting a PSCell due to eNodeB misconfiguration makes it more difficult to detect and address the configuration error. To disable blocklisting due to misconfiguration, set ENodeBFunction.diffX2CauseMisconfig = true .

### 6.3.3 NR Inter-Frequency PSCell Change to Higher Priority - NSA

This procedure, shown in Figure 6-18, is enabled by the gNodeB feature PSCell Change to Higher Priority , summarized in Section 10.3.17.

This feature enables a UE in good radio conditions to periodically search for a PSCell on a higher priority NR frequency. If a suitable cell is found, then the feature initiates an interfrequency PSCell change.  The change is triggered by the gNodeB when an NR A5 report is received from the UE (forwarded by the eNodeB). The target may be either FR1 or FR2.

<!-- page: 107 -->

![Figure on page 107](5G_Mobility_and_Traffic_Management_Guideline_images/page_107_image_002.png)

Figure 6-18 - NSA Inter-frequency PSCell Change to Higher Priority

**Notes for Figure 6-18:**

- Serving eNodeB receives an Event B1 report from the UE on NR1

- Serving eNodeB initiates SN addition with NR Cell in NR1

- Serving gNodeB configures (via the eNodeB) NR A5 measurements on NR2 higher priority frequency. However, there is no coverage from NR2 in this area, so the Event A5 is not triggered.

- Serving gNodeB stops the NR A5 measurements

- After a waiting period, the serving gNodeB re-configures NR A5 measurements on the NR2 higher priority frequency

- Serving gNodeB receives (via the eNodeB) an Event A5 report from the UE for a higher priority NR2 cell

- Serving gNodeB initiates inter-frequency PSCell change to NR2

For the inter-frequency PSCell change to be performed the following must be fulfilled:

- Target cell must be configured in the serving SN ( NRCellCU or ExternalNRCellCU with matching nRPCI exists)

- A neighbor relation exists between the serving and reported cells, either a manuallycreated NRCellRelation with isHoAllowed = true , or an ANR-created lwNeighborRel (which always allows PSCell change).

<!-- page: 108 -->

- For inter-gNodeB PSCell change:

̶

- The serving eNodeB has an X2 link configured ( TermPointToGNB MO, with operationalState = ENABLED ) to the gNodeB hosting the target NR cell. This allows the LTE cell to be used as an anchor for the target NR cell.

̶

- If a GUtranCellRelation exists between the LTE PCell and the target PSCell, then GUtranCellRelation . isEndcAllowed = true .

- The UE Handover Restriction List (HRL) contains at least one PLMN supported by the target cell, and the TAC used in the target cell is not forbidden by the HRL.

̶

- If the gNodeB has not received the HRL from the eNodeB, then the used PLMN in the source cell must also be supported by the target cell.

If the reported PCI does not have a corresponding neighbor relation, and cannot be identified using ANR, then the PSCell change cannot be initiated. The measurement report is then discarded, and the UE stays in the measurement state and waits for a new measurement report.

If the PSCell change request is rejected by the target gNodeB due to insufficient UE capabilities or by the eNodeB due to misconfiguration, then the target cell can be blocklisted for the lifetime of the UE connection in the source gNodeB; refer to Section 6.3.2.1 for further details.

Note that the parameter inhibitEndcFr2Volte does not impact PSCell change.

### 6.3.4 NR Critical Coverage SN Release - NSA

This procedure, shown in Figure 6-19, is enabled by the Mobility Control at Poor Coverage (MCPC) functionality under the gNodeB feature NR Mobility , Section 10.3.4.2.

<!-- page: 109 -->

![Figure on page 109](5G_Mobility_and_Traffic_Management_Guideline_images/page_109_image_002.png)

Figure 6-19 - NR Critical Coverage SN Release - NSA

Notes for Figure 6-19:

- The gNodeB receives (via the eNodeB) an Event A2 Critical Coverage report from the UE and triggers SN release. The SN Terminated Split Bearer(s) are converted to MN Terminated MCG Bearer(s).

Typically, this critical coverage SN release occurs only after MCPC has searched for suitable alternative PSCell coverage using A5 Inter-Frequency Candidate measurements and has failed to find any. However, it can also occur in the following cases:

- No valid target NR frequencies exist for MCPC to measure. In this case, the A2 Entering Search Zone measurements are never configured in the UE; only this A2 Critical Coverage measurement is used.

- The UE sends an A2 Entering Search Zone report which indicates that the coverage is below the critical level. In this case, the A5 Inter-Frequency Candidate measurements are not configured in the UE and critical handling is triggered.

Critical coverage SN release is enabled separately per trigger quantity (RSRP, RSRQ and SINR). To enable this functionality for RSRP, for example, set McpcPSCellProfileUeCfg.rsrpCriticalEnabled = true and configure the measurements with the structure attribute McpcPSCellProfileUeCfg.rsrpCritical . See Section 11.2.9.3 for details of the parameter settings and trigger level formulas.

The A2 Critical Coverage threshold must be set below the B1 SN addition threshold (Section 11.2.2).  If not, SN addition could be immediately followed by critical release, or critical release could be immediately followed by another SN addition.

### 6.3.5 NR Radio Link Failure - NSA

NR Radio Link Failure (RLF) can be detected by either the UE or the gNodeB.

<!-- page: 110 -->

̶

If the UE detects NR RLF, via one of the following conditions, then the eNodeB initiates SN release:

- Random access during SN addition procedure fails ( GNBDUFunction.Rrc.t304 expires)

- RLC UL delivery failure. The number of UL RLC retransmissions exceeds DrbRlcUeCfg.ulMaxRetxThreshold

- Out of synchronization (t310-Expiry). The UE is configured to monitor the SSB for Radio Link Monitoring purposes and counts 'in - synch' and 'out -ofsynch' indications.

̶

- GNBDUFunction.Rrc.n310 consecutive 'out -ofsynch' indications starts timer T310 (set by GNBDUFunction.Rrc.t310 )

̶

- GNBDUFunction.Rrc.n311 consecutive 'in - synch' indication stops timer T310

- RLF occurs when T310 expires

If the gNodeB detects NR RLF, via the following condition, then the gNodeB initiates SN release:

- RLC DL delivery failure. The number of DL RLC retransmissions exceeds DrbRlcUeCfg.dlMaxRetxThreshold

### 6.3.6 NR Intra-Frequency SCell Change - NSA

NR intra-frequency SCell Change in FR1 is triggered by the gNodeB when an NR A6 report is received from the UE (forwarded by the eNodeB). The procedure is shown in Figure 6-20.

<!-- page: 111 -->

̶

̶

![Figure on page 111](5G_Mobility_and_Traffic_Management_Guideline_images/page_111_image_002.png)

Figure 6-20 - NSA Intra-frequency SCell Change

**Notes for Figure 6-20:**

- Serving SN receives (via the eNodeB) an Event A6 report for NR SCell B from the UE

- A6 measurements are configured in the UE only if betterSCellReportConfigMode is set to ALWAYS , or if it is set to CONDITIONAL and there is more than one SCell candidate on the frequency.

- Serving SN deconfigures NR SCell A and configures and activates NR SCell B For the SCell change to be performed the following must be fulfilled:

- The triggering conditions (described in Section 11.2.7.3) must be met.

- The target cell must be configured in the serving SN ( NRCellCU or ExternalNRCellCU with a matching nRPCI )

- An NRCellRelation between the NR PSCell and NR SCell B with:

̶

- NRCellRelation.sCellCandidate = ALLOWED

- The read-only attribute NRCellRelation.caStatusActive is true when using the feature NR DL Carrier Aggregation for Coverage Extension for FDD / TDD carrier aggregation.

- NRCellRelation.coverageIndicator does not impact SCell change.

All NR neighbor relations for carrier aggregation must be manually configured.

<!-- page: 112 -->

## 6.4 VoLTE Procedures - NSA

In the current NR NSA solution, VoLTE continues to be carried over the LTE network only.

VoLTE uses two bearers with the following QoS Class Identifier (QCI) values:

- A signaling bearer (QCI5)

- A voice data bearer (QCI1)

The eNodeB prevents the QCI1 bearer from being configured as an EN-DC split bearer, as 3GPP standards do not allow it.

Other bearers, such as QCI9, may still be configured as split bearers, even when VoLTE is present. However, the recommended configuration is to disallow split bearers when the UE has a VoLTE connection, to ensure VoLTE performance is maintained. This is best achieved with the following settings:

**· Disallow Split Bearers with VoLTE**

Assign EndcProfilePredefined = 3 to QCIs used for VoIP services (e.g. QCI1 and QCI2). This predefined profile has the following settings:

̶

- meNbS1TermReqArpLev = 15 The VoLTE bearer cannot have an ARP greater than 15, so this setting disallows

split for the VoLTE bearer.

̶

- splitNotAllowedUeArpLev

- = 15

The VoLTE bearer cannot have an ARP greater than 15, so this setting disallows split for all bearers.

Note that the ARP scale is reversed: a low priority bearer has a high ARP value.

**· Inhibit SN Addition During MO Voice Setup**

Set ENodeBFunction.endcSplitAllowedMoVoice = false . This introduces an additional mechanism to inhibit SN addition while a mobile originated voice call is being set up from idle mode. It does not cover mobile terminated voice calls.

**·**

Inhibit SN Addition After VoLTE Release Set UeMeasControl.endcInhibitTime > 0. This prevents SN addition for endcInhibitTime after VoLTE release. Specifically, it inhibits B1 measurement configuration for SN addition and EN-DC triggered handover, and buffer monitoring for buffer-based EN-DC setup. This functionality is useful when repeated VoLTE calls are made during benchmarking, because it ensures that the next VoLTE setup attempt does not collide with an SN addition process. Without this inhibition, a collision with SN addition causes the VoLTE setup to be delayed (if endcS1OverlapMode = true ) or rejected (if endcS1OverlapMode = false ). The setting can be overridden per subscriber group with EndcUserProfile.endcInhibitTimeOverride .

The above settings are a subset of the criteria considered for SN addition, which are fully described in Section 6.2.3.1.

<!-- page: 113 -->

### 6.4.1 VoLTE Setup from Idle Mode - NSA

The procedure for setting up VoLTE from idle mode is unchanged by the deployment of EN-DC. Both of the VoLTE bearers (QCI1 and QCI5) and the data bearer (for example QCI9) are set up as MN Terminated MCG Bearers, as shown in Figure 6-21.

![Figure on page 113](5G_Mobility_and_Traffic_Management_Guideline_images/page_113_image_001.png)

Figure 6-21 - VoLTE Setup from Idle Mode

For mobile originated voice calls, there is a mechanism to inhibit SN addition for a configurable guard time while the call is set up; see Section 6.2.3.1 for details.

### 6.4.2 Setup in Connected Mode - NSA

The procedure for setting up VoLTE from connected mode depends on the pre-existing data bearers. Three examples are provided here, assuming a pre-existing default data bearer of one of the following types:

- MN Terminated MCG Bearer

- SN Terminated Split Bearer

- SN Terminated MCG Bearer

#### 6.4.2.1 VoLTE Setup with Pre-Existing MN Terminated MCG Bearer

This procedure is unchanged from the legacy LTE procedure. The VoLTE bearer for voice data (QCI1) is set up as an MN Terminated MCG Bearer, as shown in Figure 6-22.

<!-- page: 114 -->

![Figure on page 114](5G_Mobility_and_Traffic_Management_Guideline_images/page_114_image_001.png)

Figure 6-22 - VoLTE Setup with MN Terminated MCG Bearer

If B1 measurements for SN addition are ongoing when the VoLTE bearer is set up, and split bearer is not allowed for VoLTE, then the measurements are removed.

#### 6.4.2.2 VoLTE Setup with Pre-Existing SN Terminated Split Bearer

The procedure for adding VoLTE to an existing SN Terminated Split Bearer depends on whether a split bearer is allowed for the UE when a VoLTE bearer is present, as detailed in Section 6.4. The recommended configuration is disallowed, to ensure VoLTE performance is maintained.

**Split Bearers with VoLTE Not Allowed**

If split bearers with VoLTE are not allowed, then VoLTE call setup is handled as shown in Figure 6-23. The VoLTE setup triggers the removal of the SCG for the QCI9 bearer but the PDCP layer remains in the secondary node and the bearer becomes an SN Terminated MCG Bearer. At the next mobility event the PDCP layer is moved to the master node, and the bearer becomes an MN Terminated MCG Bearer.

In this context, the 'next mobility event' is one of the following:

- LTE intra or inter-frequency handover

- LTE intra-cell handover that is performed by EN-DC capable UEs when one of the following events occurs:

̶

- TTI bundling activation or deactivation

̶

- E-RAB setup when there are no available DRB IDs on the same security key

̶

- Security key change

<!-- page: 115 -->

![Figure on page 115](5G_Mobility_and_Traffic_Management_Guideline_images/page_115_image_002.png)

Figure 6-23 - VoLTE Setup with Split Bearer Not Allowed

**Split Bearers with VoLTE Allowed**

If split bearers with VoLTE are allowed, then the VoLTE QCI1 bearer is set up as normal MN Terminated MCG Bearer and the QCI9 split bearer is not impacted, as shown in Figure 6-24.

![Figure on page 115](5G_Mobility_and_Traffic_Management_Guideline_images/page_115_image_003.png)

Figure 6-24 - VoLTE Setup with Split Bearer Allowed

#### 6.4.2.3 VoLTE Setup with Pre-Existing SN Terminated MCG Bearer

This case can only arise when the UE has an SN terminated MCG bearer (see Section 6.4.2.2) and then the VoLTE connection is released and set up again. In this case the QCI1 bearer is simply added, leaving the other bearers unchanged as shown in Figure 6-25.

<!-- page: 116 -->

![Figure on page 116](5G_Mobility_and_Traffic_Management_Guideline_images/page_116_image_001.png)

Figure 6-25 - VoLTE Setup with SN Terminated MCG Bearer

### 6.4.3 VoLTE Release - NSA

When a VoLTE connection is released, the overall procedure depends on which bearers are being used at the time. Three examples are provided here:

- VoLTE with MN Terminated MCG Bearer

- VoLTE with SN Terminated MCG Bearer

- VoLTE with SN Terminated Split Bearer

Note that after a VoLTE bearer is released, EN-DC setup can be inhibited for a configurable period of time, using endcInhibitTime .  Refer to Section 6.4 for details.

**VoLTE Release with MN Terminated MCG Bearer**

This is the most likely case. The QCI1 bearer is removed and, assuming split bearer is allowed for the UE (see Section 6.3.6), a B1 measurement is configured in the UE.

Upon reception of a B1 report, the MN Terminated MCG Bearer is reconfigured as a split bearer. This is shown in Figure 6-26.

![Figure on page 116](5G_Mobility_and_Traffic_Management_Guideline_images/page_116_image_002.png)

Figure 6-26 - VoLTE Release with MN Terminated MCG Bearer

<!-- page: 117 -->

**VoLTE Release with SN Terminated MCG Bearer**

This case is similar to the case of the MN Terminated MCG Bearer. The QCI1 bearer is removed and, assuming split bearer is allowed for the UE (see Section 6.3.6), a B1 measurement is configured in the UE.

Upon reception of a B1 report, the SN Terminated MCG Bearer is reconfigured as a split bearer. This is shown in Figure 6-27.

![Figure on page 117](5G_Mobility_and_Traffic_Management_Guideline_images/page_117_image_001.png)

Figure 6-27 - VoLTE Release with SN Terminated MCG Bearer

If a new bearer is set up while an SN Terminated MCG Bearer is already configured (as shown in the middle configuration above), then the new bearer is set up as an MN Terminated MCG Bearer. When a B1 report is received, then the existing SN Terminated MCG Bearer is converted to an SN Terminated Split Bearer as shown in the right-hand side of Figure 6-27. The new bearer, however, remains as an MN Terminated MCG Bearer, even if split bearer is allowed for this new bearer.

**VoLTE Release with SN Terminated Split Bearer**

This case can only arise if split bearer is allowed with VoLTE. The QCI1 bearer is removed, leaving the SN Terminated Split Bearer. This is shown in Figure 6-28 .

![Figure on page 117](5G_Mobility_and_Traffic_Management_Guideline_images/page_117_image_002.png)

Figure 6-28 - VoLTE Release with SN Terminated Split Bearer

<!-- page: 118 -->

### 6.4.4 VoLTE Single Radio Voice Call Continuity (SRVCC) - NSA

The procedure for SRVCC depends on whether the UE is configured with an SN terminated bearer or not. If it is not, then the procedure is identical to that for legacy LTE. If it is, then the SN terminated bearer is released at SRVCC.

## 6.5 CS Fallback Procedures - NSA

This section describes procedures that are initiated by a CS fallback event from LTE to WCDMA or GSM.

### 6.5.1 CS Fallback from Idle Mode - NSA

When CSFB is triggered from idle mode, both measurement-based and configurationbased SN addition are prevented.

### 6.5.2 CS Fallback from Connected Mode - NSA

The procedure for CS fallback from connected mode depends on whether the UE is configured with an SN terminated bearer or not.

- If it is, then the SN terminated bearer is released at RRC connection release (in the case of CS fallback based on release-with-redirect) or at outgoing IRAT handover (in the case of PSHO-Based CS Fallback to UTRAN ).

- If not, then the procedure is identical to that for legacy LTE.

If measurement-based CS Fallback is activated, the NR B1 measurements are stopped (if ongoing). Otherwise, the procedure is identical to that for legacy LTE.

## 6.6 LTE Coverage-Triggered Mobility Procedures - NSA

This section describes procedures that are triggered by changes in LTE coverage, including intra-frequency, inter-frequency and inter-RAT handover, connection re-establishment and radio link failure. In the current release, all LTE handover cases trigger MN initiated SN release as part of the handover procedure.

### 6.6.1 Intra-LTE Handover - NSA

The procedure for intra-LTE handover depends on the data bearers that are being used when the handover is triggered. Three examples are provided here, assuming the following bearers:

- MN Terminated MCG Bearer

- SN Terminated Split Bearer

<!-- page: 119 -->

- SN Terminated MCG Bearer with VoLTE

The procedures cover both intra and inter-frequency handover within LTE.

NR measurement reports that arrive during an LTE handover can cause problems. To prevent such problems set EUtranCellFDD / TDD . nrMeasRepBlockedDuringHO = true . This prevents the eNodeB from forwarding NR measurements to the gNodeB during LTE handover.

#### 6.6.1.1 Intra-LTE Handover with MN Terminated MCG Bearer

The procedure for intra-LTE handover with an MN Terminated MCG Bearer is shown in Figure 6-29. This case can arise, for example, if the serving LTE cell (A in this case) is not capable of EN-DC. The first part of the procedure, the LTE handover itself, is identical to that for legacy LTE. The second part of the procedure shows the case where SN addition occurs on the target cell. Possible alternatives are that SN addition does not occur (for example because the target cell is not capable of EN-DC) or that EN-DC triggered handover occurs (for example because an LTE cell on another frequency is better suited to provide EN-DC).

![Figure on page 119](5G_Mobility_and_Traffic_Management_Guideline_images/page_119_image_001.png)

Figure 6-29 - Intra-LTE Handover with MN Terminated MCG Bearer without VoLTE

Notes for Figure 6-29:

- eNodeB receives Event A3 or Event A5 report from the UE

<!-- page: 120 -->

- eNodeB initiates intra-frequency or inter-frequency handover on LTE

- If Cell B is EN-DC capable and split bearer is allowed for the UE, then the eNodeB (for Cell B) configures B1 measurement report in the UE

- eNodeB receives Event B1 report from the UE

- eNodeB initiates secondary node addition and secondary cell group addition

The above procedure assumes that the target cell uses measurement-based SN addition. If the target cell uses configuration-based SN addition, then after the handover in Step 2 the target eNodeB attempts to set up EN-DC on the configured NR cell, without measurements.

#### 6.6.1.2 Intra-LTE Handover with SN Terminated Split Bearer

The procedure for intra-LTE handover with an SN Terminated Split Bearer is shown in Figure 6-30. This example shows the case where the NR cell can be used as a PSCell by both the source and target LTE cells. In this case no change of PSCell or SN is required.

The procedure happens without the need for a B1 measurement, and the PDCP context is retained in the SN throughout the procedure. This requires that the involved eNodeB(s) and gNodeB have the required SW level and the LTE handover can be completed over X2 (not S1).

![Figure on page 120](5G_Mobility_and_Traffic_Management_Guideline_images/page_120_image_002.png)

Figure 6-30 - Intra-LTE Handover with SN Terminated Split Bearer, keeping PSCell

Notes for Figure 6-30:

- eNodeB receives Event A3 or Event A5 report from the UE

<!-- page: 121 -->

- eNodeB initiates intra-frequency or inter-frequency handover on LTE and initiates SN Addition in the target LTE cell and SN Release from the source LTE cell

If the NR cell cannot be used as a PSCell by both the source and target LTE cells (or another prerequisite condition is not met) then the procedure shown in Figure 6-31 applies. The difference is that the PDCP context must be relocated to the MN and a B1 measurement is required to find the new PSCell. Note that the example shown assumes that the LTE handover is triggered before an attempt to change PSCell on NR occurs, and that NR Cell B is the best cell in the B1 report after the LTE handover.

![Figure on page 121](5G_Mobility_and_Traffic_Management_Guideline_images/page_121_image_002.png)

Figure 6-31 - Intra-LTE Handover with SN Terminated Split Bearer, changing PSCell

#### 6.6.1.3 Intra-LTE Handover with SN Terminated MCG Bearer & VoLTE

An intra-LTE handover with an SN Terminated MCG Bearer with VoLTE arises from the following sequence of events:

- An SN Terminated Split Bearer is set up

<!-- page: 122 -->

- VoLTE call is setup, but split bearer is not allowed with VoLTE (default configuration). This causes the SN Terminated Split Bearer to be reconfigured as an SN Terminated MCG Bearer.

- The next mobility event is an LTE Event A3 or A5

Assuming this sequence occurs, the resulting handover procedure is shown in Figure 6-32.

![Figure on page 122](5G_Mobility_and_Traffic_Management_Guideline_images/page_122_image_002.png)

Figure 6-32 - Intra-LTE Handover with SN Terminated MCG Bearer

Notes for Figure 6-32:

- eNodeB receives Event A3 or Event A5 report from the UE

- eNodeB initiates SN release

- eNodeB initiates intra or inter-frequency handover on LTE

Note that after Step 3, the presence of the VoLTE bearer prevents the eNodeB from configuring the UE with an Event B1 to detect NR coverage. The B1 is configured only when the VoLTE connection is released.

### 6.6.2 IRAT Handover - NSA

If an IRAT handover is triggered, the procedure is the same as for IRAT handover in legacy LTE, with the exception that the Secondary Node is released, including any Secondary Cell Group resources.

<!-- page: 123 -->

### 6.6.3 LTE Radio Link Failure - NSA

If an LTE Radio Link Failure is triggered, the procedure is the same as for legacy LTE, with the addition that if a split bearer is configured then the Secondary Node is released, including any Secondary Cell Group resources.

### 6.6.4 LTE RRC Connection Re-establishment - NSA

If an LTE connection re-establishment is triggered, the procedure is the same as for legacy LTE, with the addition that if a split bearer is configured then the Secondary Node is released, including any Secondary Cell Group resources.

After a successful connection re-establishment, if all the prerequisites for SN addition are fulfilled then the eNodeB sets up an Event B1 measurement in the UE to facilitate SN addition. Measurement-based SN addition is always used, even if the cell is configured for configuration-based SN addition.

## 6.7 LTE Load-Triggered Mobility Procedures - NSA

The eNodeB has a number of load-triggered features which can move UEs between frequencies in connected mode for the purpose of controlling load distribution. These features may result in an EN-DC capable UE being moved to a frequency that is less appropriate for use as an EN-DC anchor. For this reason, it is possible to disable loadtriggered mobility for EN-DC capable UEs, using the attribute lbActionForEndcUe in the EUtranCellFDD and EUtranCellTDD MOs, as shown in Table 6-3.

Table 6-3 - Disabling Load-Triggered Mobility for EN-DC Capable UEs

| lbActionForEndcUe           | Status of Load-Triggered Mobility for EN-DC Capable UEs   | Status of Load-Triggered Mobility for EN-DC Capable UEs   |
|-----------------------------|-----------------------------------------------------------|-----------------------------------------------------------|
|                             | UEs without SN terminated DRBs                            | UEs with SN terminated DRBs                               |
| NOT_ALLOWED                 | Disabled                                                  | Disabled                                                  |
| ENDC_CAPABLE_NOT_CONFIGURED | Enabled                                                   | Disabled                                                  |
| ENDC_CAPABLE_ALL            | Enabled                                                   | Enabled                                                   |

Table 6-3 - Disabling Load-Triggered Mobility for EN-DC Capable UEs

The attribute lbActionForEndcUe applies to the load balancing and offload features, but it does not apply to the features Load-Based Distribution at Release (LBDAR) or Evolved Load-Based Distribution at Release (ELBDAR). LBDAR and ELBDAR can, however, be overridden for EN-DC capable UEs by the feature Capability-Aware Idle Mode Control (Section 10.2.10). UEs that are not capable of EN-DC are unaffected by the setting of lbActionForEndcUe .

Once triggered, load-triggered handovers follow similar procedures to coverage-triggered handovers; as described in Section 6.6.1 for inter-frequency handovers, and Section 6.6.2 for IRAT handovers.

<!-- page: 124 -->

# 7 Connectivity and Bearers - SA

This section describes how UEs connect to a 5G SA network using SA. Figure 7-1 illustrates the terminology used for describing connectivity. This terminology applies to both NR SA (single connectivity) and NR-DC (dual connectivity).

![Figure on page 124](5G_Mobility_and_Traffic_Management_Guideline_images/page_124_image_001.png)

Figure 7-1 - Connectivity Terminology

**· PDU Session**

A PDU session provides user data connectivity between the UE and an Access Point in the core network. A UE can have up to multiple PDU sessions. PDU sessions are requested by the UE after it registers on the network. Smartphones typically request two PDU sessions, one for IMS services (e.g. voice) and one for MBB. These PDU sessions remain established as the UE changes back and forth between RRC_CONNECTED, RRC_INACTIVE and RRC_IDLE states. When requesting a session, the UE can optionally include a flag to request that the PDU session is ' always o n' , meaning user plane resources (DRB) are established whenever the UE moves from RRC_IDLE to RRC_CONNECTED state. However, the Ericsson core does not configure 'always on' PDU sessions, which allows radio resources to be added and removed as needed. A PDU session always belongs to a single slice within the network.

**· QoS Flow**

One PDU session carries from one to four QoS flows. All QoS flows of a certain PDU session are sent over the same NG-U tunnel. A QoS flow is the finest granularity at which QoS parameters can be set. Each packet (both uplink and downlink) is mapped to a QoS flow, and all packets belonging to the same QoS flow use the same 5G Quality of Service Indicator (5QI). Typically, an IMS PDU session contains an ongoing QoS flow for IMS signaling (5QI5), while QoS flows for VoNR (5QI1) and ViNR (5QI2) are added and removed as needed.

<!-- page: 125 -->

**· Radio Bearer**

Radio bearers carry data to and from the UE over the air interface (Uu) when the UE is in RRC_CONNECTED state. They are added and removed as needed, unlike in LTE where DRBs for the default EPS bearers are added whenever the UE enters RRC_CONNECTED state.

DRBs are used for two purposes:

̶

**Data Radio Bearer (DRB)**

DRBs carry user data. Each DRB carries a single QoS flow in the Ericsson implementation. In RRC_CONNECTED state the UE has one or more DRBs.

̶

- Signaling Radio Bearer (SRB)

The SRB carries Layer 3 signaling. The SRB is carried over FR1 via the Master Node.

In the context of NR-DC, a DRB is described by two characteristics:

- The node which terminates the NG-U interface from the core:

̶

- Master Node (MN), which is always on FR1

̶

- Secondary Node (SN), which is always on FR2

- The cell groups which provide the resources for the DRB over the air interface:

̶

- Master Cell Group (MCG), which is always on FR1.

In NR-DC, the MCG has one Primary Cell (PCell) and, if carrier aggregation is configured, one or more Secondary Cells (SCells) in the downlink.

̶

- Secondary Cell Group (SCG), which is always on FR2.

- In NR-DC, the SCG has one Primary Secondary Cell (PSCell) and, if carrier aggregation is configured, one or more Secondary Cells (SCells) in the DL and zero or more in the UL.

For NR-DC, there are two types of DRB, which are described using the above terminology:

- MN Terminated MCG DRB

The NG-U interface is terminated on the MN and the air interface resources are provided by the MCG.

**·**

- SN Terminated Split DRB

The NG-U interface is terminated on the SN and the air interface resources are provided by both the MCG and the SCG.

These two DRB types are shown in Figure 7-2. A UE can have more than one DRB configured at a given time, and the DRBs can be of the same type or different types. For a UE to be considered as 'connected using NR - DC' it must have at least one SN Terminated Split DRB, otherwise it is simply connected using NR SA (no dual connectivity).

<!-- page: 126 -->

![Figure on page 126](5G_Mobility_and_Traffic_Management_Guideline_images/page_126_image_001.png)

Figure 7-2 - NR-DC DRB Types

## 7.1 Split Bearer User Plane Functions - NR-DC

This section describes the PDCP layer functions which control the flow of user data over an SN Terminated Split Bearer. The functions used for EN-DC are reused for NR-DC, and are:

**· Uplink / Downlink Decoupling**

The basic feature Uplink-Downlink Decoupling enables uplink and downlink user data transmissions to be sent independently over FR1 or FR2. For example, the downlink can use FR2 while the uplink uses FR1.

**· Downlink User Plane Switching**

This function enables fast switching of downlink user data between MCG (FR1) and SCG (FR2) resources in response to varying FR2 radio quality.

**· Uplink User Plane Switching**

This function enables fast switching of uplink user data between MCG (FR1) and SCG (FR2) resources in response to varying FR2 radio quality.

**· Downlink User Plane Aggregation**

This function enables simultaneous use of both MCG and SCG resources for downlink user data when required by the data flow and allowed by FR2 radio quality.

**· Uplink User Plane Aggregation**

This function enables simultaneous use of both MCG and SCG resources for uplink user data when required by the data flow.

**· Flow Control**

This function controls the flow of user data over MCG and SCG resources to manage the latencies and minimize packet reordering during aggregation.

<!-- page: 127 -->

These functions are further described, for EN-DC, in Section 5.3. These sections assume that GNBCUUPFunction.altDepHServAdapUPProfEnabled = true , and therefore user plane functions are controlled with the new MO classes rather than the old MO classes which are being deprecated. Refer to the Network Impact Report in CPI for more detail on this deprecation handling.

Additionally, the new MO classes allow different settings for EN-DC and NR-DC for User Plane Switching and Aggregation and, if the relevant service-adaptive features are active, UE group level control is also possible.

To enable different settings for EN-DC and NR-DC, a number of licensed service-adaptive features are required; refer to the relevant feature descriptions in Features and Capacities in CPI.

In addition to the downlink and uplink user plane aggregation described above, an NR-DC connection can also use carrier aggregation on the SCG (FR2). Carrier aggregation is further described in Section 4.6.

<!-- page: 128 -->

# 8 Mobility and Connectivity Procedures - SA

This section describes mobility and connectivity procedures for SA. The SA procedures are simpler than the NSA procedures as they involve only one Radio Access Technology (RAT).

## 8.1 Idle Mode Procedures - SA

Procedures performed by UEs in idle mode include:

- PLMN Selection

- System information acquisition

- Cell selection and reselection (intra-frequency, inter-frequency and inter-RAT)

- Tracking area updates and paging

This section focuses on cell selection and reselection, as these are most relevant for mobility and traffic management. The following simplifying assumptions are made:

- Higher priority PLMN offsets do not apply,

- The UE is capable of the maximum transmit power allowed in the cell and

- Speed dependent scaling does not apply.

These assumptions typically apply in most cases.

### 8.1.1 Cell Selection - SA

Cell selection is the idle mode procedure performed by the UE to find a suitable cell on which to camp, after PLMN selection or after return from connected mode to idle mode or RRC_INACTIVE state. UEs which are capable of both LTE and NR SA can select cells on either LTE or NR SA. UEs which are capable only of SA can select cells only on SA.

The UE can select an NR SA cell when:

SS_RSRPNR > (gNB) NRCellDU.qRxLevMin

and

SS_RSRQNR > (gNB) NRCellDU.qQualMin

For LTE, similar conditions apply; see Section 11.1.1. for details.

<!-- page: 129 -->

### 8.1.2 Cell Reselection - SA

Cell reselection is the procedure used by an idle or RRC_INACTIVE UE to change the cell on which it is camped, when it finds a better cell. It is performed autonomously by the UE, using the parameters broadcast in the system information messages of the cell on which it is camped. Cell reselection can be intra-frequency, inter-frequency, or inter-RAT if the UE is capable of both RATs, for example LTE and NR SA.

To perform cell reselection, the UE measures the serving cell and other cells on the same frequency, and potentially also cells on other frequencies on the same RAT or other RATs. The frequencies to be measured, the conditions under which to measure them and the criteria for reselection are communicated to the UE in system information.

If the UE is not close to cell edge and/or has low mobility, then the measurements required for cell reselection can be performed less frequently, to conserve battery life. This functionality is enabled by the feature Relaxed Radio Resource Management Measurements , which is described in Section 10.3.31.

A detailed description of the parameters governing idle mode selection is provided in Section 11.1.

#### 8.1.2.1 Criteria to Conduct Measurements for Intra-Frequency Cell Reselection

Before the UE can reselect between cells on the same frequency, it must be measuring the cells.

If camped on NR SA, the UE must perform intra-frequency measurements when:

SS_RSRPNR < (gNB) NRCellDU.qRxLevMin + (gNB) NRFreqRelation.sIntraSearchP or SS_RSRQNR < (gNB) NRCellDU.qQualMin + (gNB) NRFreqRelation.sIntraSearchQ

If the above conditions are not met, then the UE may choose not to perform intrafrequency measurements.

If sIntraSearchQ is empty, then the UE applies the default value of 0 dB, disabling the SS_RSRQ criteria.

If camped on LTE, similar criteria are applied; see Section 11.1.2 for details.

#### 8.1.2.2 Intra-Frequency Cell Reselection

Given that the UE is camping on NR SA and the intra-frequency measurements are being performed, intra-frequency cell reselection occurs when:

SS_RSRPtarget - SS_RSRPsource > (gNB) NRCellCU. qHyst

<!-- page: 130 -->

and

SS_RSRPtarget > (gNB) NRFreqRelation.qRxLevMin

and

for a time of (gNB) NRFreqRelation. tReselectionNR , (default 2 s)

Additionally, to stay on the new cell, the cell selection criteria listed in Section 8.1.1 must be satisfied.

To decrease the risk of immediate handover after RRC connection setup, align the idle and connected mode cell sizes as follows:

- As RSRP is used as the trigger quantity for idle mode intra-frequency mobility, use RSRP also for connected mode intra-frequency mobility, by setting IntraFreqMCCellProfileUeCfg.betterSpCellTriggerQuantity = RSRP

- To achieve equivalent cell size, set qHyst equal to the connected mode handover margin, which is determined by the parameters offset and hysteresis in the structure IntraFreqMCCellProfileUeCfg.rsrpBetterSpCell (see Section 11.2.4). Typically, qHyst is set to 4 dB. Note that the current software revision does not provide cell relation level offsets for idle mode reselection.

Figure 8-1 illustrates intra-frequency reselection behavior. The heavy black lines in the diagram represent decreasing signal strength measured by the UE. The blue arrows show the mobility behavior of the UE in response to the configured thresholds: diagonal as it moves within a cell from good to poor coverage, and then vertical as it reselects to a different cell.

![Figure on page 130](5G_Mobility_and_Traffic_Management_Guideline_images/page_130_image_001.png)

Figure 8-1 - Idle Mode Intra-frequency NR SA Cell Reselection

If the UE is camped on LTE, similar criteria apply; see Section 11.1.2 for details.

#### 8.1.2.3 Cell Reselection Priorities

To control reselection between cells on different frequencies and RATs in idle mode and RRC_INACTIVE state, absolute priorities are used.

<!-- page: 131 -->

The absolute priorities are broadcast to all UEs in System Information Broadcast (SIB) messages. Which SIB messages are used depends on the RAT of the serving cell:

- NR cells use SIB2 and SIB4 for the NR frequencies and SIB5 for the LTE frequencies

- LTE use SIB24 for the NR frequencies and SIB3 and SIB5 for LTE frequencies

The broadcasted priorities can be overridden by dedicated priorities that are sent directly to the UE when it moves from connected mode to idle mode. This enables certain features to customize cell reselection behavior for a subset of UEs. Examples of features which use this overriding mechanism are Traffic Steering Cell Reselection Priority at UE Release and Idle Mode Steering and in NR, and Capability-Aware Idle Mode Control (CAIMC) in LTE.

- In NR, the dedicated priorities are sent to the UE in the cellReselectionPriorities information element of the RRCRelease message.

- In LTE the dedicated priorities are sent to the UE in the Idle Mode Mobility Control (IMMCI) information element in the RRCConnectionRelease message.

The broadcasted absolute priority always has an integer part, and optionally also a fractional part (known as the sub-priority). These are set by attributes at the frequency relation level, as follows:

- cellReselectionPriority

This attribute sets the integer part of the absolute priority to a value in the range 0-7 . It is used on all types of frequency relations. On some types of frequency relations, the attribute can also be set to -1 or empty. This makes the frequency unavailable for reselection, by excluding it from being broadcast in the SIB and from the dedicated messages used to override the SIB priorities. Refer to Section 11.1.4 for more detail on making frequencies unavailable for reselection.

**· cellReselectionSubPriority**

This attribute determines the fractional part of the absolute priority (the sub-priority) and is available only on some frequency relation types (see Table 8-2). The sub-priority is added to the cellReselectionPriority to obtain the priority. It can be set to 2 , 4 , 6 or 8 , corresponding to sub-priorities of 0.2, 0.4, 0.6 and 0.8 respectively. Additionally, depending on the relation, it can be set to either empty or 0 , both of which correspond to a sub-priority of 0, or no sub-priority. The sub-priority setting has no impact if the cellReselectionPriority is set to -1. The sub-priorities allow more absolute priority levels to be defined overall, enabling finer control of the cell reselection strategy in networks with a large number of layers.

Table 8-1 shows how the cellReselectionPriority and cellReselectionSubPriority are added to obtain the absolute priority. The higher the value, the higher the absolute priority. UEs which do not support sub-priorities ignore them and use only the cellReselectionPriority values.

<!-- page: 132 -->

Table 8-1 - Determining the Absolute Priority

| Absolute Priority       | cellReselectionSubPriority                 | cellReselectionSubPriority                 | cellReselectionSubPriority                 | cellReselectionSubPriority                 | cellReselectionSubPriority                 |
|-------------------------|--------------------------------------------|--------------------------------------------|--------------------------------------------|--------------------------------------------|--------------------------------------------|
| cellReselectionPriority | 0 or empty                                 | 2                                          | 4                                          | 6                                          | 8                                          |
| -1                      | Frequency is not available for reselection | Frequency is not available for reselection | Frequency is not available for reselection | Frequency is not available for reselection | Frequency is not available for reselection |
| 0                       | 0                                          | 0.2                                        | 0.4                                        | 0.6                                        | 0.8                                        |
| 1                       | 1                                          | 1.2                                        | 1.4                                        | 1.6                                        | 1.8                                        |
| 2                       | 2                                          | 2.2                                        | 2.4                                        | 2.6                                        | 2.8                                        |
| 3                       | 3                                          | 3.2                                        | 3.4                                        | 3.6                                        | 3.8                                        |
| 4                       | 4                                          | 4.2                                        | 4.4                                        | 4.6                                        | 4.8                                        |
| 5                       | 5                                          | 5.2                                        | 5.4                                        | 5.6                                        | 5.8                                        |
| 6                       | 6                                          | 6.2                                        | 6.4                                        | 6.6                                        | 6.8                                        |
| 7                       | 7                                          | 7.2                                        | 7.4                                        | 7.6                                        | 7.8                                        |

Table 8-1 - Determining the Absolute Priority

Table 8-2 shows which priority settings are supported on the different types of frequency relations.

Table 8-2 - Supported Priority Settings

| Relation Type   | Cell MO Relation MO                      | cellReselectionPriority   | cellReselectionSubPriority   |
|-----------------|------------------------------------------|---------------------------|------------------------------|
| NR to NR        | NRCellCU NRFreqRelation                  | -1, 0 to 7                | empty, 2, 4, 6, 8            |
| NR to LTE       | NRCellCU EUtranFreqRelation              | empty, 0 to 7             | empty, 2, 4, 6, 8            |
| LTE to NR       | EUtranCellFDD/TDD GUtranFreqRelation     | -1, 0 to 7                | 0, 2, 4, 6, 8                |
| LTE to LTE      | EUtranCellFDD/TDD EUtranFreqRelation     | -1, 0 to 7                | Not supported                |
| LTE to WCDMA    | EUtranCellFDD/TDD UtranFreqRelation      | 0 to 7                    | Not supported                |
| LTE to GSM      | EUtranCellFDD/TDD GeranFreqGroupRelation | 0 to 7                    | Not supported                |

Table 8-2 - Supported Priority Settings

On a given cell, frequency relations to different RATs must not be assigned the same absolute priority, because 3GPP have intentionally made IRAT comparisons with equal absolute priorities non-valid. On an LTE cell, frequency relations to GSM, WCDMA and LTE must therefore be assigned different cellReselectionPriority values. Frequency relations to NR SA can be differentiated either by using different cellReselectionPriority values or different cellReselectionSubPriority values.

Figure 8-2 illustrates how sub-priorities can be used to obtain additional priority levels for the NR layers, in a network where the other RATs use all the priorities except one. In this example the settings are identical from LTE and NR perspectives (with the exception of the WCDMA and GSM layers which are not visible from NR). This example does not show sub-priorities on the LTE layers, noting that sub-priorities are supported on NR to LTE relations, but not on LTE to LTE relations.

<!-- page: 133 -->

![Figure on page 133](5G_Mobility_and_Traffic_Management_Guideline_images/page_133_image_001.png)

Figure 8-2 - Using Sub-Priorities to Obtain Additional Priority Levels for NR SA

When using a feature that overrides the broadcast priorities with dedicated priorities, the overriding priorities are determined in different ways, depending on the feature. Some features determine the priority values dynamically, and others use values that are set with attributes. Not all overriding features support sub-priorities. The feature Capability-Aware Idle Mode Control has various options for handling SA priorities, as described in Section 10.2.10.6. On the other hand, the feature Subscriber-Triggered Mobility (STM) does not support sub-priorities in the current release, so any sub-priorities that are set on NR ( GUtranFreqRelation ) will not be considered in the dedicated priorities sent by STM. Refer to the CPI feature description of the overriding feature for more information.

The priorities described above are used to govern inter-frequency and inter-RAT measurements and cell reselection. Specifically, the priority values are used to determine whether the neighboring frequency has a priority which is lower than, equal to or higher than the serving frequency. The outcome (lower, equal, or higher) then determines the measurement and reselection behavior, as described in the following sections.

<!-- page: 134 -->

#### 8.1.2.4 Criteria to Conduct Measurements for Inter-Frequency and Inter-RAT Cell Reselection

In idle mode and RRC_INACTIVE state, the UE must always measure frequencies with higher priority than the serving frequency.

If camped on NR SA, the UE must measure frequencies with priority equal to or lower than the current frequency when:

or

If sNonIntraSearchP is empty or -1, then the UE applies the default value of infinity, always measure.

If sNonIntraSearchQ is empty, then the UE applies the default value of 0 dB, disabling the SS_RSRQNR criteria.

If the above conditions are not met, then the UE can choose not to measure equal or lower priority frequencies.

Similar criteria apply when the UE is camped on LTE; see Section 11.1.8 for details.

#### 8.1.2.5 Inter-Frequency and Inter-RAT Cell Reselection

The criteria for cell reselection between NR SA and LTE depend on whether NR SA has a higher or lower priority than LTE; they cannot have the same priority. Typically, NR SA would be assigned a higher priority if it is expected to outperform LTE. Otherwise, if for example NR SA has limited bandwidth, then the operator may choose to assign NR SA a lower priority than LTE.

This section presents the case where NR SA has a higher priority than LTE. Other cases (for example where NR SA has a lower priority, or the case of inter-frequency reselection) are similar; refer to Sections 11.1.6 to 11.1.9 for details.

Given that NR SA has a higher cellReselectionPriority than LTE, reselection from NR SA to LTE occurs when:

SS_RSRPNR < (gNB) NRCellDU. qRxLevMin + (gNB) NRCellCU. threshServingLowP and

RSRPLTE > (gNB) EUtranFreqRelation. qRxLevMin + (gNB) EUtranFreqRelation. threshXLowP

<!-- page: 135 -->

for a time of (gNB) EUtranFreqRelation. tReselectionEUtra (default 2 s).

Additionally, to stay on the new cell, the cell selection criteria listed in Section 11.1.1 must be satisfied.

**Reselection from LTE to NR SA occurs when:**

SS_RSRPNR > (eNB) GUtranFreqRelation. qRxLevMin + (eNB) GUtranFreqRelation. threshXHigh

for a time of (eNB) EUtranCellFDD.systemInformationBlock24. tReselectionNR (default 2 s).

Additionally, to stay on the new cell, the cell selection criteria listed in Section 8.1.1 must be satisfied.

Idle mode reselection from LTE to NR SA is enabled by information broadcast to UEs in SIB24. SIB24 does not include NR frequencies with GUtranFreqRelation. cellReselectionPriority = -1.

Although up to 16 GUtranFreqRelation instances can be defined in an EUtranCellFDD/TDD , a maximum of 8 can be broadcast in SIB24. If more than 8 are defined, then the 8 with the highest priority ( cellReselectionPriority + cellReselectionSubPriority/10) are chosen for broadcast. In the case of equal priorities, the time of creation of GUtranSyncSignalFrequency is used to prioritize; those created earliest are chosen for broadcast.

Note that some UEs misbehave when SIB24 is broadcast; refer to Section 8.1.2.6 for how to handle this problem.

The above formulas assume that reselection is based on RSRP. This is the case if threshServingLowQ is not included in system information. If it is included, then reselection is based on RSRQ; see Sections 11.1.6 to 11.1.9 for details.

The above reselection criteria are illustrated by Figure 8-3. The heavy black lines in the diagram represent decreasing signal strength measured by the UE. The blue arrows show the mobility behavior of the UE in response to the configured thresholds: diagonal as it moves within a cell from good to poor coverage, and then vertical as it reselects to a different cell.

<!-- page: 136 -->

![Figure on page 136](5G_Mobility_and_Traffic_Management_Guideline_images/page_136_image_002.png)

Figure 8-3 - Cell Reselection Between NR SA and LTE (assuming NR has higher priority)

The criteria for inter-frequency reselection are similar to those for inter-RAT reselection, except that equal priorities are allowed for two frequencies on the same RAT; see Section 11.1.5 to 11.1.7 for more information.

This section assumes that the UE uses the cell reselection priorities that are broadcast system information. However, the network can instead give the UE dedicated priorities at release, as described in Sections 8.2.7 and 10.2.2.

#### 8.1.2.6 Handling SIB24 with Misbehaving UEs

Idle mode reselection from LTE to NR SA is enabled the eNodeB feature NR CoverageTriggered NR Session Continuity . This feature provides the broadcast of SIB24, which contains the relevant frequencies, priorities and thresholds required for reselection. However, when SIB24 is broadcast, some UEs, which are not capable of SA and are not compliant to 3GPP, misbehave. The problem lies not with SIB24 itself, but instead occurs when these non-compliant UEs attempt to decode the information element in SIB1 that provides scheduling information for SIB19 and higher, including SIB24. The problem causes these non-compliant UEs to consider the LTE cell as barred.

To solve this problem, 3GPP introduced an alternative scheduling format. The choice between the alternative and legacy formats is controlled using the attribute EUtranCellFDD/TDD.sib1AltSchInfo as follows:

- Legacy Scheduling

̶

- If sib1AltSchInfo = false , SIB24 (specifically SIB19 and higher) are mapped in the SIB1 Scheduling Info List using the legacy format. UEs then behave as follows:

- Non SA capable, 3GPP compliant UEs decode the SIB1 correctly, ignore SIB24 and camp normally on the LTE cell.

<!-- page: 137 -->

- Non SA capable, non 3GPP compliant UEs fail to decode the SIB1 and consider the LTE cell barred.

- SA capable UEs decode the SIB1 and SIB24 correctly and use it to govern reselection from LTE to NR SA.

- Alternative Scheduling - (This is the Ericsson recommended approach)

̶

- If sib1AltSchInfo = true , SIB24 (specifically SIB19 and higher) are mapped in the SIB1 Scheduling Info List using the alternative late non-critical extensions. UEs then behave as follows:

- All non SA capable UEs (both 3GPP compliant and non-compliant) decode SIB1 correctly, ignore the late non-critical extensions for SIB24 and camp normally on the LTE cell.

- SA capable UEs which support the late non-critical extensions camp normally on the cell and use the SIB24 information to govern reselection to NR SA.

- SA capable UEs which do not support the late non-critical extensions camp normally on the LTE cell but cannot decode SIB24 and therefore cannot perform idle mode reselection to NR SA. They can, however, be moved from LTE to NR SA in connected mode, using the feature NR Coverage-Triggered NR Session Continuity.

## 8.2 Data Bearer Setup and Release Procedures - SA

This section describes the procedures used to establish and release a data bearer for transferring MBB data. VoNR procedures are covered in Section 8.3.13.1.

### 8.2.1 UE Capability Enquiry - SA

To handle the UE in an optimal way, the gNodeB needs to know the UE capabilities. The gNodeB obtains the UE capability information from the MME if available. If not, or if the information received from the MME does not cover all of the frequency bands configured in the gNodeB, then the gNodeB sends a UE Capability Enquiry message to the UE to discover the unknown capabilities, and the UE responds with a UE Capability Information message.

The attribute robustUeCapEnquiryMode controls how the UE Capability Enquiry is sent to the UE. It takes the following values:

- COMBINED_ONLY - The gNodeB sends a single UE Capability Enquiry message to the UE, requesting both NR and EUTRA capabilities. If case of any failure, the UE is released.

- SPLIT_ONLY - The gNodeB splits the UE Capability Enquiry into two separate messages, the first for NR capabilities and the second for EUTRA capabilities. If only NR or only EUTRA capabilities are required, a single message is sent. In case of any failure, the UE is released.

<!-- page: 138 -->

- COMBINED_THEN_SPLIT - The gNodeB first sends a single UE Capability Enquiry message to the UE, requesting both the NR and EUTRA capabilities. If the request fails with a PDCP integrity check, then the gNodeB splits the UE Capability Enquiry into two further messages, the first for NR capabilities and the second for EUTRA capabilities. If the split enquiry also results in a PDCP integrity check failure, or if the entire process fails for any other reason, then the UE is released.

The default setting is COMBINED_THEN_SPLIT , as this yields the highest overall enquiry success rate.

UEs that support UL segmentation (introduced in 3GPP Release 16) can divide the UE capability information into up to six segments, to avoid truncation of a large UE capability message. The gNodeB counter NRCellCU.pmUeCapabilityInfoSegmented is stepped for each successful assembly of a segmented RRC UeCapabilityInformation message.

If the gNodeB is configured with a frequency that belongs to more than one frequency band, then by default the gNodeB will request the UE capabilities related to all of these bands. However, if the attribute NRFrequency.bandListManual is used to specify support for only a subset of the possible bands, then the gNodeB will request the UE capabilities for only that subset. This can reduce the size of the UE capability response and improve success rates.

When the gNodeB receives the UE capability information, it performs a capability check. UEs that do not support minimum required capabilities fail the check. An example is a UE that does not support ESS attempting to access an ESS cell.

If the UE capability check fails, the UE is released-with-redirect to the lowest LTE frequency that has UeMCEUtranFreqRelProfileUeCfg.blindRwrAllowed = true . If no frequencies have blindRwrAllowed = true , then the UE is released to idle mode. To prevent the UE from returning to the ESS frequency in idle mode, the release message includes the IE deprioritisationReq (30 min) and the NR frequency.

A capability check is also performed at handover. If the check fails, then the handover is rejected, and the UE is kept in the serving cell.

### 8.2.2 Choice of Connectivity Option

When a UE connects to a standalone 5G network from RRC_IDLE or RRC_INACTIVE state, it initially connects using only a single cell, the PCell. Once connected, the gNodeB evaluates whether it is possible to improve the data rate available to the UE by altering the connectivity. If the function Dynamic Cell Set Change during Mobility is activated ( mlcPeriodicEnabled = true ), then the connectivity is also evaluated periodically as described in Section 10.3.5.4.

The possible outcomes of the evaluation are:

- Set up carrier aggregation (CA), by adding secondary cells (SCells) on FR1. This is described in Section 4.6.

<!-- page: 139 -->

- Set up NR-DC, by adding a primary secondary cell (PSCell) and potentially also secondary cells (SCells) on FR2. This is described in Section 8.2.3.

- Change the PCell frequency or the SCells to allow access to a higher estimated downlink data rate. This is enabled by the Multi-Layer Coordination (MLC), described in Section 8.3.9.

- Move the connection to LTE:

̶

- If the bandwidth currently available to the UE on NR SA is below a threshold, then Bandwidth-Triggered Inter-System Handover (BWTISHO), described in Section 8.3.10 can move the UE to LTE.

̶

- If the throughput or RLC buffer status indicates low performance, then NR DataAware Mobility (DAM), described in Section 10.3.26, can move the UE to LTE.

### 8.2.3 SN Addition NR-DC

Secondary Node (SN) addition is the process by which a UE establishes an NR-DC connection using a secondary node. As part of the process, any PDU sessions that are allowed to be SN terminated are moved to the secondary node. These sessions then have access to resources provided by both the master node (namely Master Cell Group (MCG) resources) and the secondary node (namely Secondary Cell Group (SCG) resources). The MCG always uses FR1 frequencies, and the SCG always uses FR2 frequencies.

SN addition is illustrated in Figure 8-4, for the case of a UE which has one session containing a single QoS flow that is not allowed to be SN terminated, and one session containing two QoS flows which are allowed to be SN terminated.

<!-- page: 140 -->

![Figure on page 140](5G_Mobility_and_Traffic_Management_Guideline_images/page_140_image_002.png)

Figure 8-4 - SN Addition Example for NR-DC, including CA

**Notes for Figure 8-4:**

- To determine whether the UE has suitable coverage from an FR2 cell to set up NRDC, the MN sets up A4 measurements in the UE. To set up A4 measurements, the instance of NrdcMnCellProfileUeCfg selected for the PCell must have nrdcEnabled = True . Up to nrdcMaxMeasFreqA4 frequencies can be measured.

- When the UE finds an FR2 cell that satisfies the A4 measurement criteria, the UE sends an A4 measurement report to the MN. The parameters and trigger-level formulas for the A4 measurements are provided in Section 11.2.12.

- The MN evaluates the reported cell to determine whether it is a valid candidate for setting up NR-DC. If the reported cell is suitable, then the MN initiates SN addition and reconfigures any DRBs that are allowed to be SN terminated, from MN terminated MCG DRBs to SN terminated split DRBs. SCells are added on FR2 if supported. On FR1, SCells remain configured for DL CA but are deconfigured for UL CA, as UL CA in FR1 is not supported with NR-DC. DRBs that are not allowed to be SN terminated remain as MN terminated MCG DRBs.

To avoid setting up NR-DC for sessions which are unlikely to benefit from it, downlink and uplink buffer-based NR-DC can be used. This inhibits the configuration of A4 measurements until there is sufficient traffic in the DL RLC SDU buffer or in the UE UL buffer, as described in Section 10.3.2.1.

The A4 measurement for NR-DC SN addition is triggered by:

- Initial Context Setup

<!-- page: 141 -->

- PDU session resource setup or modify

- Incoming handover to the MN

- SN release

When the MN receives the A4 report, SN addition is triggered if all of the following criteria are met:

- At least one PDU session is allowed to be SN terminated, meaning all its QoS flows are allowed to be SN terminated. This is determined by the setting of NrdcSnTerminationUeCfg.nrdcSnTermAllowed for the relevant 5QI and ARP.

- The reported PCI matches an ExternalNRCellCU on the measured frequency, and the PCell has an NRCellRelation to the candidate PSCell.

- Xn connection exists to the gNodeB hosting the candidate PSCell, with TermPointToGNodeB unlocked and enabled.

Full details of the SN addition procedure are provided in the CPI feature description for NRNR Dual Connectivity .

### 8.2.4 Release Due to Inactivity - SA

UE release from connected mode to idle mode is triggered by either the AMF or the gNodeB. Reasons for the gNodeB to trigger a release are inactivity or NR Radio Link Failure.

For inactivity, the procedure depends on the bearers in use by the UE. There are two cases:

- UE with only Master Node (MN) terminated bearers

- UE with one or more Secondary Node (SN) terminated bearers (NR-DC)

In both cases the release decision is taken by the MN. However, when the UE has an SN terminated bearer, the MN obtains assistance from the SN. The following sections provide more detail on these two cases.

#### 8.2.4.1 Inactivity Release - UE with only MN terminated bearers

A UE using only MN terminated bearers is released due to inactivity if the following conditions are fulfilled:

- All DRBs have been inactive in both the uplink and the downlink for a period of at least InactivityProfileUeCfg.tInactivityTimer (default 10 sec)

**· There has been NAS inactivity for a period of at least**

InactivityProfileUeCfg.nasInactivityTime (default 5 sec)

<!-- page: 142 -->

The UE is released either to idle mode or to RRC_INACTIVE state. The release is to RRC_INACTIVE state only if all of the following conditions are met:

- The RRC Inactive State feature is enabled

- The UE supports RRC_INACTIVE state

- The Core Network Assistance Information (CNAI) is stored in the UE context

- The UE is not configured with NR-DC

- The UE is not in limited-service mode

- The RrcInactiveProfileUeCfg.rrcInactiveStateSupport = true for the UE.

#### 8.2.4.2 Inactivity Release - UE with SN terminated bearers

When the UE has one or more SN terminated bearer (NR-DC), release is always to idle, never inactive state. Both the MN and the SN monitor UE activity. The monitoring is performed at the PDCP layer. The MN monitors the activity of any MN terminated DRBs. The SN monitors the activity of SN terminated DRBs and informs the MN of the results over the Xn-AP interface.

The node responsible for actually releasing a UE due to inactivity is the MN. It releases the UE when all DRBs (both MN and SN terminated) have been inactive for a specific period of time and no NAS message has been sent or received for at least a specific period of time.

- MN terminated DRBs: InactivityProfileUeCfg.tInactivityTimer (default 10 sec)

- SN terminated DRBs: InactivityProfileUeCfg.tInactivityTimerNrdcSn (default 10 sec)

- NAS message: InactivityProfileUeCfg.nasInactivityTime (default 5 sec)

To achieve this, the following processes are followed.

**SN Inactivity Monitoring**

The SN considers a UE inactive if all SN terminated DRBs have been inactive in both the uplink and the downlink for a period of at least

InactivityProfileUeCfg.tInactivityTimerNrdcSn (default 10 sec). The SN informs the MN of the UE inactivity by sending the notification XnAP Activity Notification (inactive) over the Xn-AP interface.

The SN considers a UE active if any SN terminated DRB has any activity in either the uplink or downlink. The SN informs the MN of the UE activity by sending the notification XnAP Activity Notification (active) to the MN over the Xn-AP interface.

<!-- page: 143 -->

The SN does not initiate release based on inactivity. It simply notifies the MN of the state (inactive or active), and the MN determines when to release the UE.

**MN Inactivity Monitoring**

The UE is released when the MN decides that the DRBs (both MN and SN terminated) are inactive, and NAS signaling has not occurred for at least

InactivityProfileUeCfg.nasInactivityTime seconds.

The master node uses the following rules to decide whether a DRB is inactive:

- Any MN terminated DRB is considered inactive by the MN when no data has been transmitted in either the uplink or the downlink on that DRB for at least InactivityProfileUeCfg.tInactivityTimer .

- All SN terminated DRBs are considered inactive by the MN when the notification XnAP Activity Notification (inactive) is received by the MN.

Figure 8-5 summarizes the procedure for release due to inactivity for a UE with both an MN terminated MCG DRB and an SN terminated split DRB.

![Figure on page 143](5G_Mobility_and_Traffic_Management_Guideline_images/page_143_image_002.png)

Figure 8-5 - Release due to Inactivity - Split Bearer Example

<!-- page: 144 -->

### 8.2.5 UE Initiated Release

If the feature UE-Assisted RRC State Preference is enabled, the UE can request release to either idle mode or inactive state. This is described in Section 10.3.28.

### 8.2.6 Release Due to Radio Link Failure

When a UE is connected to the network, the radio link is always supervised and either the UE or the gNodeB can detect NR Radio Link Failure (RLF).

The UE detects NR RLF via one of the following conditions:

- Random access fails during SN addition procedure ( GNBDUFunction.Rrc.t304 expires)

- RLC UL delivery fails (the number of UL RLC retransmissions exceeds DrbRlcUeCfg.ulMaxRetxThreshold )

- Out of synchronization (t310-Expiry) occurs. The UE is configured to monitor the SSB for and counts 'in - synch' and 'out -ofsynch' indications.

̶

- Rrc.n310 consecutive 'out -ofsynch' indications starts timer T310 (set by Rrc.t310 )

̶

- Rrc.n311 consecutive 'in - synch' indication stops timer T310

̶

- RLF occurs when T310 expires

For an NR-DC connection, these parameters are set in the MN for the MCG, and in the SN for the SCG.

The gNodeB detects NR RLF via the following condition:

- RLC DL delivery fails (the number of DL RLC retransmissions exceeds DrbRlcUeCfg.dlMaxRetxThreshold )

If RLF is detected on the MN, the UE is released to idle mode, and attempts RRC connection re-establishment if possible (see Section 8.3.15).

If RLF is detected on the SN, then the SN is released, any SN terminated bearers are reconfigured to MN terminated bearers.

### 8.2.7 Cell Reselection Priorities At Release

As detailed in Section 8.1, UEs use cell reselection priorities to govern reselection between frequencies and RATs in idle mode and inactive mode. Typically, the UE reads these priorities from the system information messages, which are broadcast by the serving cell. However, these broadcast values can be overridden by values that are sent to the UE in a dedicated message when the UE is released from RRC connected mode. This enables different UEs to be selectively steered towards different frequencies.

<!-- page: 145 -->

Whether dedicated priorities are sent to the UE at release or not, is controlled per UE group with the attribute TrStSaCellProfileUeCfg.actionAtRelease . It takes the following values:

- 0 (DISABLED) - The UE uses the priorities that are broadcast in system information.

- 1 (CA_CONF) - The function Traffic Steering Cell Reselection Priority at UE Release determines whether dedicated priorities are used. See Section 10.3.5.2.

- 2 (PRIORITY_LIST) - The function Idle Mode Steering determines whether dedicated priorities are used. See Section 10.3.4.6.

- 3 (CRP_MLC_CONDITIONAL) - The function Traffic Steering Cell Reselection Priority at UE Release determines whether dedicated priorities are used. See Section 10.3.5.2.

- 4 ( RANDOM_REDIRECT ) - This value can be used only on SA high-band (FR2) cells when multiple PCells are configured in a sector. It enables load distribution at release between the PCells in the sector.

## 8.3 Connected Mode Procedures - SA

### 8.3.1 Release-With-Redirect from LTE to NR SA

This procedure is enabled by the eNodeB feature NR Coverage-Triggered NR Session Continuit y (FAJ 121 4983), Section 10.2.2.

Release-with-redirect provides a mechanism to move UEs in connected mode from LTE to NR SA. It is triggered at RRC connection setup; that is after initial connection setup, incoming handover or RRC re-establishment, at EN-DC release, and at release of last voice bearer. To check for NR SA coverage the eNodeB configures Event B1 measurements in the UE. If coverage is found, the UE sends an Event B1 report to the eNodeB, which triggers a release-with-redirect to the reported NR frequency.

#### 8.3.1.1 Prerequisites for RwR from LTE to NR SA

For a UE to be configured with an Event B1 measurement, for the purpose of release-withredirect, the following must be fulfilled:

- The license for NR Coverage-Triggered NR Session Continuity is enabled

- The attribute UeMeasControl.nrB1MeasEnabled = true

- The UE does not have a voice bearer (serviceType: VOIP, PTT or MC_SIGNALING)

̶

- UEs with a voice bearer are handled by the feature Outgoing NR IRAT Handover , refer to Section 8.3.2.

<!-- page: 146 -->

- If the UE is configured with EN-DC, then UeMeasControl.nrB1MeasAtEndcEnabled = true

.

- The UE supports NR SA on at least one of the NR frequencies with connectedModeMobilityPrio not equal to -1. The UE indicates its support by including frequencies in the capability SupportedbandListNR-SA in UE-EUTRACapability IE.

- The UE does not have the value NRrestrictedin5GS in the NR restriction in 5GS IE in its Handover Restriction List (HRL).

- At least one of the serving or any equivalent PLMNs in the UE's HRL matches any PLMN in the GUtranFreqRelation.allowedPlmnList and at least one of these matching PLMNs does not have the value 5GCForbidden in the Core Network Type Restrictions IE in the HRL. This check is not applied if GUtranFreqRelation.allowedPlmnList is empty.

- The UE does not have an interest in MBMS that blocks NR SA measurements.

- If the feature LTE Service-Triggered Outgoing NR IRAT Mobility is active, then additional QCI or SPID criteria apply; see Section 10.2.23.

#### 8.3.1.2 Choice of Frequencies for RwR from LTE to NR SA

The number of B1 measurements configured in the UE for mobility to NR SA is limited to UeMeasControl.maxMeasNR (the default is 5). The priority for including NR frequencies is set with the attribute GUtranFreqRelation.connectedModeMobilityPrio , from 7 (highest) to 0 (lowest). The value -1 means the frequency is excluded; set this value on NR frequencies which are capable of NSA only. Frequencies with the same connectedModeMobilityPrio are ordered by lowest arfcn first when constructing the RRC reconfiguration message that is sent to the UE to set up measurements.

The GUtranFreqRelation.connectedModeMobilityPrio (and voicePrio ) values can be overridden per subscriber group (SPID) using the feature Subscriber Triggered Mobility (see Section 10.2.4). The overriding values are set using the RATFreqPrio MO, as shown in the example of Figure 8-6, where subscribers with SPID = 8 are given overriding priorities on three frequencies. The value -1000 means the priority set in the GUtranFreqRelation is not overridden.

<!-- page: 147 -->

![Figure on page 147](5G_Mobility_and_Traffic_Management_Guideline_images/page_147_image_002.png)

Figure 8-6 - Example of using SPID to override priorities for RwR and HO from LTE to SA

To prevent a UE from returning to an NR SA frequency after Bandwidth-Triggered InterSystem Handover has sent the UE from NR SA to LTE, use the attribute mobilityBackToNrFreqDisabled as described in Section 10.2.2.

The parameters used to control trigger levels of Event B1 are provided in Section 11.2.3.

#### 8.3.1.3 Measurement Sequences for RwR from LTE to NR SA

There are three possibilities for configuring the sequence of B1 measurements: measure periodically, measure forever and measure once. All three sequences begin when the UE sets up an RRC connection and are shown in Figure 8-7.

- Measurements are performed forever if UeMeasControl.nrB1MobilityTimerLessTtt

= -1, or if not then,

- Measurements are performed only once if UeMeasControl.waitForResumeNRMeas = -1, or if not then,

- Measurements are performed periodically, because in this case UeMeasControl.nrB1MobilityTimerLessTtt not equal to -1 and UeMeasControl.waitForResumeNRMeas not equal to -1.

<!-- page: 148 -->

![Figure on page 148](5G_Mobility_and_Traffic_Management_Guideline_images/page_148_image_002.png)

Figure 8-7 - Event B1 Measurement Sequence for RwR and handover to NR SA

**Notes for Figure 8-7:**

- For 'Measure once then stop' and 'Measure periodically', the measurements are performed for a maximum time as follows:

̶

- Measurement Time = UeMeasControl.nrB1MobilityTimerLessTtt + max( ReportConfigB1NR.timeToTriggerB1 , GUtranFreqRelation.timeToTriggerNrB1B2Override )

̶

- The max() function includes all frequencies that are configured for measurement and have timeToTriggerNrB1B2Override not equal to -1000.  If no frequencies have an override value set, then timeToTriggerB1 is used.

These B1 measurements are stopped if any of the following occurs:

- A voice bearer is set up

̶

- However, if the feature Outgoing NR IRAT Handover is enabled, then B1 measurements are not stopped but rather are reconfigured for QCI1 voice handover instead, if allowed, see Section 8.3.2.

- EN-DC is set up and UeMeasControl . nrB1MeasAtEndcEnabled = false

̶

- If nrB1MeasAtEndcEnabled = true , then measurements are not stopped when EN-DC is set up, and it becomes possible to trigger a release-with-redirect from LTE to NR SA even when the UE has an EN-DC connection.

<!-- page: 149 -->

The default value for waitForStartNRMeas is 6000 (6 second). If both NSA and SA are deployed, this allows time for EN-DC measurements to complete before starting measurements for release-with-redirect to NR SA. More specifically, starting NR SA measurements immediately after RRC connection setup would have limited value for the following reasons:

- If SA has the highest priority in idle mode, then UEs are pushed to NR SA in idle mode via the cell reselection priority settings. So, if the UE performs an RRC connection setup on LTE, then it is likely that NR SA coverage is not available. It is therefore reasonable to allow some time for the UE radio conditions to change before starting measurements. Also, if NR NSA is deployed in addition to NR SA, then waiting for this time allows EN-DC measurements to complete first.

- If LTE has the highest priority in idle mode (for example because NSA is preferred to SA), then any EN-DC measurement setup process should preferably complete before starting measurements for NR SA. To ensure this happens, set waitForStartNRMeas to the longest expected time to complete B1 EN-DC measurements, according to Section 10.2.1.1.

Note that waitForStartNRMeas is not applied if the feature LTE Service-Triggered Outgoing NR IRAT Mobility applies; refer to Section 10.2.23.

#### 8.3.1.4 Measurement Report Priority Handling for RwR from LTE to NR SA

If a measurement reconfiguration message contains two or more NR frequencies with different GUtranFreqRelation.connectedModeMobilityPrio or RATFreqPrio.FreqPrioNR.connModeMobilityPrio values (e.g. 7 and 6) then the eNodeB has additional control to increase the probability that the higher priority frequency is used. Specifically, if the first received B1 report is from the lower priority frequency, then the eNodeB waits for nrB1MeasWindow for a B1 report containing the higher priority frequency. If it is received before this time expires, then RwR or HO to SA using the higher priority frequency occurs. Otherwise, when the timer expires, RwR or HO using the lower priority frequency occurs. Note that HO also requires the feature Outgoing NR IRAT Handover, as described in Section 8.3.2.

This is illustrated in Figure 8-8, for the case of a measurement reconfiguration message which contains frequencies of priority 7 and 6.

<!-- page: 150 -->

![Figure on page 150](5G_Mobility_and_Traffic_Management_Guideline_images/page_150_image_002.png)

Figure 8-8 - Handling Simultaneous Measurement of Multiple priority values

**Notes for Figure 8-8 :**

- Case 1 :  If a B1 report for a valid priority 7 cell is received first, then the eNodeB initiates mobility to SA immediately.

- Case 2 :  If a B1 report for a valid priority 6 cell is received first and a B1 report for a valid priority 7 cell is received within nrB1MeasWindow , then the eNodeB initiates mobility to SA using the priority 7 cell.

- Case 3 : If a B1 report for a valid priority 6 cell is received first and then nrB1MeasWindow expires, the eNodeB initiates mobility to SA using the stored priority 6 cell.

- Case 4 : If a B1 report for a valid priority 6 cell is received first and then Measurement Time expires, the eNodeB initiates mobility to SA using the stored priority 6 cell.

<!-- page: 151 -->

#### 8.3.1.5 Fast Return to NR SA after Release-With-Redirect

To enable fast return to NR SA after voice call fallback, the eNodeB also configures the B1 measurements when a voice bearer is released. The measurement is configured immediately; waitForStartNRMeas is not applied. When the B1 measurement report is received, it triggers RwR to SA.

For emergency voice calls, fast return to NR SA can be overridden with the feature LTE Emergency Call Handling with NR Standalone. This feature keeps the UE in LTE for a configurable time when an emergency call is released. Refer to Section 10.2.19 for details.

#### 8.3.1.6 MOs and Attributes for Configuring RwR from LTE to NR SA

The key MOs and attributes required to configure release-with-redirect from LTE to NR SA are shown in Figure 8-9. This figure also includes attributes for handover to NR SA, which is described in the next section.

![Figure on page 151](5G_Mobility_and_Traffic_Management_Guideline_images/page_151_image_001.png)

Figure 8-9 - Key MOs and Attributes for RwR and Handover from LTE to NR SA

<!-- page: 152 -->

### 8.3.2 Handover from LTE to NR SA (including voice)

This procedure is enabled by the eNodeB feature Outgoing NR IRAT Handover , Section 10.2.3.

This feature extends the feature NR Coverage-Triggered NR Session Continuity , by adding the ability to perform IRAT handover (HO) to NR SA rather than release-with-redirect (RwR). It also enables handover of a VoNR capable UE with a QCI1 voice bearer.

To enable the handover, the target gNodeB must have the feature NR Mobility activated and, for voice connections, also the feature Voice over NR .

The handover can be triggered in one of two ways, depending on whether the UE is in good or poor LTE coverage:

- If the UE is in good LTE coverage, then the feature NR Coverage-Triggered NR Session Continuity tries to push the UE to NR, using a B1 measurement to detect suitable NR coverage.

- If the UE is in poor LTE coverage, then the feature Mobility Control at Poor Coverage* tries to find suitable alternative coverage on another carrier, either LTE or another RAT. In this case, a B2 measurement is used to search for suitable NR coverage.

* This document assumes that the feature Mobility Control at Poor Coverage is enabled in the eNodeB.

These two cases are further described in the sections below.

When IratNrRobustness . nrMobilityRobustEnabled is true, the eNodeB monitors the number of failed handover attempts to NR SA for each UE. If the total number of failures exceeds nrMobilityRobustThreshold , then nrMobilityRobustAction determines the action, as follows:

- NO_ACTION - the eNodeB continues handover attempts without change

- RWR_ONLY - the eNodeB attempts to perform RwR instead of LTE to NR handover, until timer nrMobilityRobustOffDuration expires, LTE handover occurs, or the UE is released

- BLOCK_NR_MOBILITY - the eNodeB prohibits LTE to NR mobility until timer nrMobilityRobustOffDuration expires, LTE handover occurs, or the UE is released.

This functionality is enabled and configured at the node level and can additionally be controlled at the SPID level using IratNrRobustnessProfile .

<!-- page: 153 -->

̶

#### 8.3.2.1 HO from Good LTE Coverage to NR SA (using Event B1)

The eNodeB considers the UE to be in good LTE coverage when the UE has reported the measurement Event A1 - Leaving Search Zone.

In this case the feature NR Coverage-Triggered NR Session Continuity tries to push the UE to NR using RwR, if the prerequisite conditions described in Section 8.3.1.1 are satisfied.

To perform a HO rather than a RwR, the following additional prerequisites must be satisfied:

- If the UE has a voice bearer:

̶

- ENodeBFunction.voiceMobilityToNrEnabled = true

- The UE is capable of VoNR

̶

- The voice bearer is QCI1 (not MCPTT i.e. QCI65, QCI66 or QCI69)

̶

- The voice bearer is not an emergency call

̶

- The emergency inactivity timer extension is not running

- At least one candidate frequency exists, with GUtranFreqRelation.voicePrio not equal to -1.

̶

- Service or Priority-Triggered Inter-Frequency Handover (SPIFHO) measurements are not configured.

̶

- If the UE does not have a voice bearer:

̶

- Service or Priority-Triggered Inter-Frequency Handover (SPIFHO) measurements are not configured.

If a voice bearer (QCI=1) is added to an MBB-only connection, then any ongoing measurements are reconfigured using voicePrio . Conversely, if a voice bearer is removed to leave an MBB-only connection, then any ongoing measurements are reconfigured using connectedModeMobilityPrio .

When the eNodeB receives a B1 measurement report, other measurement quantities (besides the triggering quantity) can be checked too. See Section 11.2.3.1 for the formulas defining the trigger levels and additional checks.

The eNodeB uses the process shown in Figure 8-10 to determine what action to take: handover (HO), release-with-redirect (RwR), or wait for another report.

Handover to a reported PCI is possible if:

- The conditions for the Release Inactive UE at High Load Handover feature are not fulfilled

- There is an N26 interface between MME and 5GC AMF

<!-- page: 154 -->

- The feature license for Outgoing NR IRAT Handover is activated

- The UE supports IRAT handover to the target NR frequency

- The reported cell is not included in the denylist in the eNodeB (see Section 10.2.1.3)

- An ExternalGUtranCell exists for the reported PCI and frequency, with a defined nRTAC .

- The target NR cell doesn't belong to a PLMN that is restricted in the Handover Restriction List.

- A GUtranCellRelation exists from the source cell to the reported cell, with handover allowed. This means:

̶

- For an MBB-only connection, isHoAllowed = true

̶

- For a voice connection, isVoiceHoAllowed = true

![Figure on page 154](5G_Mobility_and_Traffic_Management_Guideline_images/page_154_image_001.png)

Figure 8-10 - Handover from LTE to NR SA - B1 Report Handling

Notes for Figure 8-10:

<!-- page: 155 -->

- The eNodeB takes only one action per B1 measurement report, namely HO, RwR or wait for next B1 report. So HO is attempted to at most one PCI in a particular B1 report. If the HO fails, then the eNodeB takes no further action on any other PCIs that may be in the B1 report. Note that a given B1 report contains PCIs from only one frequency.

- If a B1 report has only one PCI in the report, and that PCI corresponds to a cell that is valid for HO, then the eNodeB attempts HO to the cell, regardless of how many times HO to this cell has been attempted before.

- If a B1 report contains multiple PCIs, all of which have reached minBestCellHoAttempts

attempts, then the eNodeB attempts HO to the strongest.

The key MOs and attributes required to configure handover from LTE to NR SA are shown in Figure 8-9 (previous section).

The parameters and trigger level formulas for the B1 measurements are provided in Section 11.2.3.1.

#### 8.3.2.2 HO from Poor LTE Coverage to NR SA (using Event B2)

The eNodeB considers the UE to be in poor LTE coverage when the UE reports the measurement Event A2 - Entering Search Zone.

In this case, the feature Mobility Control at Poor Coverage tries to find suitable alternative coverage, either on another LTE frequency or an IRAT frequency (NR SA, WCDMA or GSM), depending on the configuration. For more information on the eNodeB feature Mobility Control at Poor Coverage , refer to the LTE Mobility and Traffic Management Guideline in CPI.

NR SA frequencies are included as candidates if the following criteria are met (in addition to those already described in Section 8.3.1.1):

- B2 NR measurements are enabled: UeMeasControl.ueMeasurementsActiveNR = true

- The UE supports Event B triggered NR measurements

- The UE has reported poor LTE coverage with Event A2

̶

- However, if the Event A2 is triggered by RSRQ and inhibitB2RsrqConfig = true , then the eNodeB does not configure RSRQ measurements for Event B2

- For voice (QCI=1), the UE is capable of VoNR and ENodeBFunction.voiceMobilityToNrEnabled =

true

- For MCPTT (QCI=65, 66 or 69), the UE is capable of MCPTT and ENodeBFunction.voiceMobilityToNrEnabled = true and ENodeBFunction . nrMobilityForMcPttDisabled = false

<!-- page: 156 -->

̶

- If the feature LTE Emergency Call Handling with NR Standalone is enabled, then the UE must not have an emergency call and the emergency inactivity timer extension must not be running. If the feature is disabled, then handover of an emergency call in poor coverage is permitted.

- Service or Priority-triggered Inter-Frequency Handover (SPIFHO) measurements are not configured

- At least one candidate frequency exists that is valid for connected mode mobility:

̶

- If the UE has a voice or MCPTT bearer, then voicePrio does not equal -1

- If the UE does not have a voice or MCPTT bearer (MBB only), then connectedModeMobilityPrio or connModeMobilityPrio (whichever applies) does not equal -1

- If the feature LTE Service-Triggered Outgoing NR IRAT Mobility is active, then additional QCI or SPID criteria apply; see Section 10.2.23.

The maximum number of NR frequencies that the UE can be configured to measure is set by UeMeasControl.maxMeasNR . If there are more candidate NR frequencies than maxMeasNR , then the frequencies with the lowest priority ( connectedModeMobilityPrio or voicePrio ) are excluded.

In LTE, MCPC can be configured with inner and outer search zones. In this case, NR frequencies with a priority higher than or equal to lowPrioMeasThresh are measured in both the inner and outer search zones, whereas those with a lower priority are measured only in the outer search zone.

B2 measurements are stopped if any of the following conditions occur:

- The UE moves into good LTE coverage (UE reports A1 Leaving Search Zone)

- A voice call (QCI1) is set up, and voiceMobilityToNrEnabled = false

- An MCPTT call is set up, and nrMobilityForMcPttDisabled = true

- The a5B2MobilityTimer is set to a value greater than zero, and it expires. For QCI1 or MCPTT users, the timer is always restarted and B2 measurements continue.

The parameters and trigger level formulas for the B2 measurements are provided in Section 11.2.3.2.

When a B2 report is received from the UE, other measurement quantities (besides the triggering quantity) can be checked too. See Section 11.2.3.2 for the formulas defining the trigger levels and additional checks.

The eNodeB handles the report as follows (assuming GUtranFreqRelation.mobilityAction = HANDOVER ):

- If one of the reported cells is a valid target (starting with the strongest reported PCI), then initiate handover. A valid target is defined in Section 8.3.2.1.

<!-- page: 157 -->

- If none of the reported cells is a valid target (e.g. isHoAllowed or isVoiceHoAllowed = false ), then:

̶

- Initiate RwR to the reported frequency if EUtranCellFDD/TDD.rwrSearchZoneAllowed = true

- If the UE has an active voice bearer, then release-with-redirect is initiated only if UeMeasControl.allowReleaseQci1 = true and the UE does not have an ongoing emergency call

- If no action can be initiated, the connection is kept and the eNodeB waits for another measurement report from the UE

̶

If an A2 Critical report is received, it is handled as follows:

- The eNodeB evaluates whether blind handover is possible:

̶

- If a frequency has been measured for longer than UeMeasControl.searchEffortTime , then it is considered to be a non-feasible target, since no measurement report was triggered. All such frequencies are removed from the list, unless this leaves the list empty, in which case the list is left unmodified by this step.

̶

- Blind handover is possible if the remaining frequency with the highest priority has GUtranFreqRelation.mobilityAction = HANDOVER and it has at least one cell with GUtranCellRelation.coverageIndicator = COVERS

- If blind handover is not possible, the eNodeB evaluates whether RwR is possible to the remaining frequency with the highest priority (as determined above):

̶

- RwR is possible if rwrCriticalZoneAllowed = true

- If the UE has an active voice or MCPTT bearer, then RwR is possible only if UeMeasControl.allowReleaseQci1 = true and the UE does not have an ongoing emergency call.

### 8.3.3 Intra-Frequency PCell Handover - SA

This procedure is enabled by the gNodeB feature NR Mobility (FAJ 121 5041), Section 10.3.4.4. It is possible only when the PCell is in FR1. When the PCell is in FR2, there is support for fixed wireless access applications only, without mobility.

NR intra-frequency PCell handover is triggered by the gNodeB when an NR A3 report is received from the UE.

The parameters and trigger level formulas are provided in Section 11.2.4.

If the UE has CA configured when the handover is triggered, then the SCells are removed as part of the handover, and added depending on the CA capability on the target cell.

<!-- page: 158 -->

![Figure on page 158](5G_Mobility_and_Traffic_Management_Guideline_images/page_158_image_002.png)

Figure 8-11 - Intra-frequency PCell Handover with SN Terminated Split DRB (NR-DC)

**Notes for Figure 8-11:**

- Master node receives PCell extended Event A3 report from the UE

- Master node initiates intra-frequency PCell handover and immediately establishes a new NR-DC cell set if the extended A3 report includes a PSCell with an RSRP better than the A4 SN addition threshold.

̶

- If no such PSCell is included, then the SN is released and new A4 measurements are started if the new PCell is capable of NR-DC. If the handover causes the selected NrdcMnCellProfileUeCfg instance to change to one that has nrdcEnabled = False , then the MN triggers SN release.

̶

- The number of configured SCells may change, if Cell A and Cell B have different CA capabilities

For NR-DC configured UEs, inter-gNodeB PCell handover is always NG-based.

### 8.3.4 Intra-Frequency Intra-gNodeB LTM Cell Switch - SA

L1/L2 Triggered Mobility (LTM) is an intra-frequency PCell mobility procedure that reduces the mobility interruption time, which is particularly important for critical IoT services.

<!-- page: 159 -->

̶

LTM uses an A3 RSRP measurement (set up in the UE via L3 signaling) to trigger an intrafrequency cell switch. The command to perform the cell switch is signaled to the UE via an L2 (MAC layer) control element (in contrast to a standard handover, which uses L3 signaling). The UE must support the LTM capabilities defined in 3GPP Release 18.

The LTM procedure is illustrated in Figure 8-12 and the following notes.

![Figure on page 159](5G_Mobility_and_Traffic_Management_Guideline_images/page_159_image_002.png)

Figure 8-12 - LTM Cell Switch Procedure

Notes for Figure 8-12:

- When the LTM-capable UE enters connected mode, the gNodeB configures it with an intra-frequency A3 measurement for LTM, in addition to the standard A3 measurement used for L3 HO-based mobility.

̶

- If the UE is configured with NR-DC or if EPS fallback measurements are started, then LTM measurements are stopped (or not started).

- The serving gNodeB receives an Event A3 (LTM) report from the UE.

̶

- The first event A3 report received by the gNodeB determines the mobility procedure, either LTM or standard handover.

̶

- To help ensure that the LTM A3 report is received first, configure LTM with a smaller offset plus hysteresis and/or a shorter time-to-trigger. See the following sections for the parameters and trigger level formulas:

- Standard (L3-based) handover:  Section 11.2.4

- LTM (L2-based) cell switch:  Section 11.2.17

- If the reported cell is not in the same gNodeB as the PCell, or is from an unknown PCI, the report is ignored

- The serving gNodeB initiates LTM preparation, including:

<!-- page: 160 -->

̶

- Preparing the candidate cell and the UE for the LTM procedure, including early synchronization in the downlink and optionally the uplink, while user plane transmissions continue in the source cell.

- The gNodeB sends the cell switch command to the UE using a MAC control element, and the UE performs the cell switch.

Further details on LTM can be found in the following feature descriptions in CPI:

- Low Latency Mobility for Public RAN (FAJ 121 5784), and

- Low Latency Mobility for Dedicated RAN (FAJ 121 5785)

### 8.3.5 Intra-Frequency PSCell Change - SA

This procedure is enabled by the gNodeB feature NR-NR Dual Connectivity (FAJ 121 5380).

An A3 measurement is used to detect the need for a PSCell change. If the PCI reported by the A3 measurement corresponds to a known neighbor (with a matching nRPCI ), then the PSCell change is initiated. If not, the A3 report is ignored.

The parameters and trigger level formulas are provided in Section 11.2.4.

<!-- page: 161 -->

![Figure on page 161](5G_Mobility_and_Traffic_Management_Guideline_images/page_161_image_001.png)

Figure 8-13 - Intra-frequency PSCell Change via A3 Measurement Report

Notes for Figure 8-13:

- Serving SN receives (via the master gNodeB) an PSCell Event A3 report from the UE

- Serving SN initiates a PSCell change. Any FR2 SCells are deconfigured at the PSCell change and reconfigured after the PSCell change (see Section 4.6 for further information on CA configuration and activation). The number of configured SCells may change along with the PSCell change. The SCell on FR1 remains configured throughout the procedure.

### 8.3.6 Intra-Frequency SCell Change - SA

NR intra-frequency SCell change is triggered by the gNodeB when an NR A6 report is received from the UE. The procedure only applies to MN terminated MCG bearers in FR1 and is shown in Figure 8-14. The relevant MOs are shown in Figure 6-16. Refer to Section 11.2.7.3 for the parameters and trigger level formulas.

<!-- page: 162 -->

![Figure on page 162](5G_Mobility_and_Traffic_Management_Guideline_images/page_162_image_001.png)

Figure 8-14 - SA Intra-frequency SCell Change

Notes for Figure 8-14:

- gNodeB receives an Event A6 report for SCell B from the UE. A6 measurements are configured in the UE only if betterSCellReportConfigMode is set to ALWAYS , or if it is set to CONDITIONAL and there is more than one SCell candidate on the frequency.

- gNodeB deconfigures SCell A and configures and activates SCell B

For the SCell change to be performed, the following must be fulfilled:

- The target cell must be configured in the serving gNodeB (as an NRCellCU or ExternalNRCellCU with a matching nRPCI )

- An NRCellRelation between the PCell and SCell B exists, with:

̶

- NRCellRelation.sCellCandidate = ALLOWED

- The read-only attribute NRCellRelation.caStatusActive is true when using the feature NR DL Carrier Aggregation for Coverage Extension for FDD / TDD carrier aggregation.

̶

All neighbor relations for NR carrier aggregation must be configured manually.

Refer to Section 11.2.7.3 for the parameters and trigger level formulas.

### 8.3.7 Inter-Frequency PCell Handover - SA

SA inter-frequency handover is triggered by the Mobility Control at Poor Coverage (Section 10.3.4.5) when the UE encounters poor serving PCell coverage, and by Multi-Layer Coordination (Section 10.3.5.1) to move the to a cell set that offers a higher data rate.

The procedure for MCPC is illustrated in Figure 8-15.

<!-- page: 163 -->

![Figure on page 163](5G_Mobility_and_Traffic_Management_Guideline_images/page_163_image_001.png)

Figure 8-15 - SA Inter-frequency PCell Handover

Notes for Figure 8-15:

- Serving gNodeB receives an Event A2 Entering Search Zone and configures an Event A5 or A3 measurement (set per frequency relation) in the UE to search for a suitable inter-frequency target.

- Serving gNodeB receives an Event A5 or A3 Inter-Frequency Candidate from the UE and performs inter-frequency handover to NR PCell B if the reported cell is high priority. If the reported cell is low priority, the report is stored for possible later use; see Section 10.3.4.5 for details.

If the UE has CA configured when the handover is triggered, then the SCells are removed and added as part of the handover, depending on the CA capability on the target cell.

If the UE is configured with NR-DC when the inter-frequency PCell handover is triggered, then immediate NR-DC establishment in the new cell is attempted. If a PSCell with better RSRP than the A4 SN addition RSRP threshold is reported in the extended A5 or A3 report for the same PSCell frequency as before the handover, then it is immediately setup as PSCell. If not, then the SN is released and the target PCell sets up A4 measurements to search for a new PSCell.

For NR-DC configured UEs, inter-gNodeB PCell handover is always NG-based.

For the PCell handover to be attempted the following must be fulfilled:

- The target cell is configured in the serving gNodeB (that is, an NRCellCU or ExternalNRCellCU whose nRPCI matches the reported PCI exists)

- A neighbor relation exists between the serving and reported cell either a manuallycreated NRCellRelation with isHoAllowed = true , or an ANR-created lwNeighborRel (which always allows handover).

<!-- page: 164 -->

̶

- The UE Mobility Restriction List (MRL) contains at least one PLMN supported by the target cell, and the TAC used in the target cell is not forbidden by the MRL.

̶

- If the MRL is not provided by the core network, then the used PLMN in the source cell must also be supported by the target cell.

- If the feature RAN Slicing Framework is active, the target cell:

̶

- Belongs to the same PLMN as the serving cell and

- Support at least one S-NSSAI used by the UE in the serving cell

If the reported PCI does not have a corresponding neighbor relation, then ANR is triggered as described in Section 10.3.16.

If the reported PCI has a corresponding neighbor relation but the NRCellRelation . isHoAllowed = false , or the UE is not capable inter-frequency handover, then a release-with-redirect is initiated to the reported NR frequency.

Inter-frequency NR neighbor cell relations can be created either manually or automatically by ANR. Manually created relations are represented by an instance of NRCellRelation and ANR-created relations are represented by an entry in the read-only attribute lwNeighborRel . Figure 8-16 shows the managed objects involved.

![Figure on page 164](5G_Mobility_and_Traffic_Management_Guideline_images/page_164_image_002.png)

Figure 8-16 - Key Managed Objects for NR Neighbor Relations and SA MCPC

**Notes for Figure 8-16:**

- This solid line indicates that the NRCellRelation MO is a child of the NRCellCU MO.

- This dashed line indicates an intra -gNodeB relation. For example, a relation from NRCellCUA to NRCellCUB consists of an NRCellRelation which is a child of NRCellCUA and contains an nRCellRef attribute pointing to NRCellCUB .

- This dashed line indicates an inter -gNodeB relation. For example, a relation from NRCellCUA to ExternalNRCellCUC consists of an NRCellRelation which is a child of NRCellCUA and contains an nRCellRef attribute pointing to ExternalNRCellCUC .

<!-- page: 165 -->

- ANR-created neighbor relations are represented by entries in the read-only attribute lwNeighborRel . These can be either intra-gNodeB or inter-gNodeB.

If the handover preparation attempt fails for any reason, then the UE stays in the search zone and waits for a new measurement report. If the failure cause is cell-not-available, the PCI is added to the deny list and is not attempted again during the UE connection.

### 8.3.8 Critical Coverage SN Release - NR-DC

Critical coverage-triggered SN release, shown in Figure 8-17, is enabled by the gNodeB feature NR-NR Dual Connectivity , described in Section 10.3.2.4.

![Figure on page 165](5G_Mobility_and_Traffic_Management_Guideline_images/page_165_image_002.png)

Figure 8-17 - Critical Coverage SN Release - NR-DC

Notes for Figure 8-17:

- The SN gNodeB receives (via the master gNodeB) an Event A2 Critical Coverage report from the UE, indicating critical PSCell coverage. This triggers SN release, and the SN Terminated Split Bearer(s) are converted to MN Terminated MCG Bearer(s).

Critical coverage SN release is enabled per trigger quantity (RSRP, RSRQ and SINR). To enable this functionality for RSRP, for example, set

McpcNrdcPSCellProfileUeCfg.mcpcA2Quantity = 1 (RSRP) and configure the measurements with the structure attribute

McpcNrdcPSCellProfileUeCfg . rsrpCritical . See Section 11.2.16 for details of the parameter settings and trigger level formulas.

With this configuration, the Event A2 Critical Coverage measurements are configured in the UE for the PSCell in NR-DC.

<!-- page: 166 -->

### 8.3.9 Multi-Layer Coordination - SA

Multi-Layer Coordination (MLC) is a function within the NR Traffic Steering feature (Section 10.3.5.1). Its purpose is to evaluate whether the UE has coverage from an alternative cell set that offers a higher estimated downlink data rate and, if so, initiate handover or SCell reselection. If NR Advanced Multi-Layer Coordination is active, then MLC evaluations consider the downlink cell load when estimating the downlink data rate; see Section 10.3.6 for details. If Uplink-Aware Advanced Multi-Layer Coordination is active, then MLC evaluations consider the uplink cell load when estimating the uplink data rate; see Section 10.3.7 for details.

MLC operates when the UE connects from RRC_IDLE or RRC_INACTIVE state. Additionally, if periodic traffic steering is enabled ( mlcPeriodicEnabled = true , see Section 10.3.5.4), then MLC evaluation also occurs periodically.

Figure 8-18 shows examples of where MLC is triggered by connection setup, and CaCellProfileUeCfg . servingCellSelectionPolicy = PRIORITIZE_DL_THP . For simplicity, the examples assume that the estimated downlink data rate is proportional to the bandwidth, with no load impact.

<!-- page: 167 -->

![Figure on page 167](5G_Mobility_and_Traffic_Management_Guideline_images/page_167_image_001.png)

![Figure on page 167](5G_Mobility_and_Traffic_Management_Guideline_images/page_167_image_003.png)

![Figure on page 167](5G_Mobility_and_Traffic_Management_Guideline_images/page_167_image_004.png)

Figure 8-18 - Multi-Layer Coordination

Notes for Figure 8-18:

- In Example 1, the UE connects on the lower bandwidth FDD carrier and supports downlink CA with either TDD or FDD as PCell. However, if the PCell is moved from FDD to TDD, then the uplink will have access to the higher TDD bandwidth. MLC therefore configures an A5 measurement in the UE to detect coverage from the TDD cell. If coverage is found, MLC instructs the UE to change PCell to TDD and set up CA with the SCell.

![Figure on page 167](5G_Mobility_and_Traffic_Management_Guideline_images/page_167_image_005.png)

<!-- page: 168 -->

- In Example 2, the UE connects on the lower bandwidth FDD cell. In this case the UE is not capable of CA using the FDD and TDD band combination, so it does not have access to the higher bandwidth of TDD. MLC therefore configures an A5 measurement in the UE to detect coverage from the TDD cell. If coverage is found, MLC instructs the UE to change PCell to TDD, which provides a higher estimated downlink data rate.

- In Example 3, the UE connects on the higher bandwidth TDD carrier, but it does not have access to CA with FDD because it does not support CA with TDD as PCell. The UE does, however, support CA with FDD as PCell. MLC estimates that the DL data rate would be higher if the PCell were moved to one of the FDD layers. It therefore configures A5 measurements in the UE to detect coverage from the FDD1 and FDD2 cells. If coverage is found for both cells, MLC instructs the UE to change PCell to FDD2 (which gives the highest estimated PCell data rate) and set up CA with the SCells on TDD and FDD1.

- In Example 4, the UE connects on the higher bandwidth FDD2 cell. The gNodeB blindly configures an SCell on TDD, but the UE does not have coverage from the SCell so it is deactivated. MLC therefore configures an A5 measurement in the UE to detect if there is SCell coverage from the FDD1 cell. If coverage is found, MLC instructs the UE to change SCell to FDD1, which provides a higher estimated downlink data rate.

### 8.3.10 Bandwidth-Triggered Inter-System Handover - SA

Bandwidth-Triggered Inter-System Handover (BWTISHO) is a function within the NR Traffic Steering feature (Section 10.3.5.3).

BWTISHO is triggered when the UE connects from RRC_IDLE or RRC_INACTIVE, or when the DCSC periodic timer elapses. Its purpose is to move UEs from NR SA to LTE when the total NR bandwidth available with the current cell set is less than or equal to a configurable threshold, namely aggregatedBwThreshold . The current cell set consists of the PCell and any SCells within coverage (an A1 report has been received for the SCell).

If the available bandwidth is less than or equal to aggregatedBwThreshold , B2 measurements are started in the UE to find a suitable LTE cell.  However, if the feature NR Data-Aware Mobility is enabled in combination with BWTISHO, then additional conditions must be fulfilled to trigger IRAT HO; refer to Section 10.3.26 for more details.

If the UE reports a suitable cell, then the gNodeB triggers an inter-RAT handover. If the UE does not support inter-RAT handover (HO) or if EUtranCellRelation.isHoAllowed = false , then the gNodeB triggers a release-with-redirect (RwR) to the reported frequency.

To prevent a UE from returning to an NR SA frequency after BWTISHO has sent the UE from NR SA to LTE, use the attribute mobilityBackToNrFreqDisabled as described in Section 10.2.2.

The feature does not consider the available LTE bandwidth for the target LTE PCell and possible SCells. Therefore, the operator must carefully consider the LTE bandwidth and load when choosing the NR bandwidth threshold.

<!-- page: 169 -->

Figure 8-19 shows how BWTISHO operates, given two UEs (one CA capable and one not) in four different locations (A to D). In each case, the available NR SA bandwidth is shown, with green indicating a value above the 50 MHz threshold and red below.

![Figure on page 169](5G_Mobility_and_Traffic_Management_Guideline_images/page_169_image_002.png)

Figure 8-19 - Bandwidth-Triggered Inter-System Handover

Notes for Figure 8-19:

- In Location A, both UEs are camped on NR F2 with an available bandwidth greater than the 50 MHz threshold, so BWTISHO takes no action.

- In Location B, both UEs are camped on NR F1. The non-CA capable UE has only 20 MHz available, which is less than the 50 MHz threshold. So BWTISHO configures a B2 measurement in that UE, LTE coverage is found, and HO or RwR occurs. The CA capable UE has 120 MHz available, more than the 50 MHz threshold, so BWTISHO takes no action for that UE.

- In Location C, both UEs are camped on NR F1 and, because they don't have coverage from NR F2, they have only 20 MHz of FR1 available. As this is less than the 50 MHz threshold, BWTISHO configures B2 measurements in both UEs, LTE coverage is found, and HO or RwR occurs for both.

- Location D is similar to Location C, except that no LTE coverage is available. So, although BWTISHO configures B2 measurements in both UEs, neither finds LTE coverage before the measurement timer expires, and they both remain on NR F1.

For further details see the feature summary for BWTISHO in Section 10.3.5.3.

### 8.3.11 Coverage-Triggered Inter-RAT Handover from NR SA to LTE

Coverage-triggered inter-RAT handover from NR SA to LTE is triggered by the Mobility Control at Poor Coverage functionality within the NR Mobility feature when the UE encounters poor serving PCell coverage. See Section 10.3.4.5 for a description of the functionality and parameters.

<!-- page: 170 -->

The procedure is illustrated in Figure 8-20.

![Figure on page 170](5G_Mobility_and_Traffic_Management_Guideline_images/page_170_image_001.png)

Figure 8-20 - Inter-RAT Handover from NR SA to LTE

- gNodeB receives an Event A2 Entering Search Zone and configures an Event B2 EUTRAN Candidate measurement in the UE to search for a suitable IRAT target LTE cell.

- gNodeB receives an Event B2 EUTRAN Candidate from the UE and performs IRAT handover to LTE if the reported cell is high priority. If the reported cell is low priority, the report is stored for possible later use; see Section 10.3.4.5 for details.

For the IRAT handover to be performed the following must be fulfilled (not a complete list):

- The target cell is configured in the serving gNodeB (that is, an ExternalEUtranCell whose PCI matches the reported PCI exists)

- An EUtranCellRelation between the serving and reported cell exists, with isHoAllowed = true

- The UE Mobility Restriction List (MRL) contains at least one PLMN supported by the target cell and does not restrict the target RAT for this PLMN.

̶

- If gNodeB does not have an MRL for the UE, then any PLMN configured for the reported cell is allowed.

If the handover preparation attempt fails for any reason, then the UE stays in the search zone and waits for a new measurement report.

If the reported PCI has a corresponding EUtranCellRelation with isHoAllowed = false , or the UE is not capable inter-RAT handover, then a release-with-redirect is initiated to the reported LTE frequency.

When choosing the thresholds for triggering IRAT handover, care must be taken to avoid configurations which cause UEs to toggle back and forth between LTE and NR SA. See Section 8.4 for more detail.

<!-- page: 171 -->

If the UE has NR-DC configured when the IRAT handover is triggered, the SN is released before the handover.

Direct packet forwarding is initiated during IRAT handover from SA to LTE.

### 8.3.12 Release-With-Redirect from NR SA to LTE

Release-with-redirect from NR SA to LTE can be triggered by the following features and functions:

- Bandwidth Triggered Inter-System Handover (Section 10.3.5.3)

- NR Data Aware Mobility (Section 10.3.26)

- NR Traffic Offload (Section 10.3.27)

- NR Remote Interference Management (Section 10.3.22)

- Mobility Control At Poor Coverage (Section 10.3.4.5)

- EPS Fallback for IMS Voice (Section 10.3.10)

- NR Emergency Fallback to LTE (Section 10.3.12)

If the UE has NR-DC configured when the release is triggered, then the SN is released as part of the procedure.

To avoid ping-pong mobility between NR SA and LTE, UEs can be discouraged from returning to NR in idle mode after certain RWR triggers from SA to LTE, specifically 1 to 4 above. This is achieved by including a deprioritisation IE in the release message to the UE. The IE is controlled with the value of the attribute deprioritisationModeAtRwr as follows:

- 0 ( NONE) , the deprioritisationReq IE is not included in the redirection message, and normal reselection handling applies.

- 1 ( FREQUENCY) , the RRCRelease message includes deprioritisationReq IE with deprioritisationType set to frequency . This causes the UE to deprioritise the NR frequency below all others for reselection.

- 2 ( NR) , the RRCRelease message includes deprioritisationReq IE with deprioritisationType set to nr . This causes the UE to deprioritise all NR frequencies below all others for reselection.

The deprioritisation applies for a time set by deprioritisationTimer (which is handled by the UE as T325). The deprioritisation survives transition to and from connected mode in LTE and NR and overrides any cell reselection priorities that the UE may read from system information or receive in IMMCI. If additional mobility causes further frequencies to be deprioritised while T325 is still running, then T325 is restarted (and applies to all deprioritised frequencies). The deprioritisation has no impact on connected mode mobility.

<!-- page: 172 -->

The attributes deprioritisationModeAtRwr and deprioritisationTimer exist in two MO classes, as follows:

- TrStSaCellProfileUeCfg

This class applies when the release-with-redirect is triggered by Bandwidth-Triggered Inter-System Handover or NR Data-Aware Mobility .

- OffloadCellProfileUeCfg

This class applies when the release-with-redirect is triggered by NR Traffic Offload or NR Remote Interference Management .

### 8.3.13 Voice Call - SA

A voice call can be handled in two different ways in NR SA:

- Voice over NR (VoNR):  Set up the call on NR SA

- EPS Fallback to LTE:  Move the UE to LTE, to set up the voice call there.

These options are described in the following sections.

#### 8.3.13.1 Voice over NR (VoNR)

VoNR is enabled by the gNodeB feature Basic Voice over NR (Section 10.3.11). This feature provides the functionality to establish, maintain, and release VoNR calls, for UEs that are capable of VoNR. UEs that are not capable of VoNR perform EPS fallback to LTE.

When a VoNR call is made, the gNodeB sets up a 5QI5 DRB for IMS signaling and a 5QI1 DRB to carry the voice packets. These DRBs can be added without reconfiguring any existing DRBs.

Figure 8-21 shows an example of setting up a VoNR call, when the UE already has a 5QI9 SN terminated split DRB configured (in other words, it is connected using NR-DC).

![Figure on page 172](5G_Mobility_and_Traffic_Management_Guideline_images/page_172_image_002.png)

Figure 8-21 - VoNR Call Setup

<!-- page: 173 -->

This example assumes that NR-DC is enabled for connections with a VoNR bearer. However, if VoNR setup causes the selected UE group to change, and this in turn causes the selected NrdcMnCellProfileUeCfg instance to change to one that has nrdcEnabled = False , then the MN triggers SN release.

Using the UE Grouping Framework feature, it is possible to create a UE group for UEs that are capable (or not capable) of VoNR, so that they can be treated differently (e.g. for mobility). VoNR capability is represented by the voNrUe variable in the selectionCriteria of the relevant UE group definition. For further information, refer to the feature description for UE Grouping Framework in CPI.

If the feature NR High Load Handling for VoNR is active in the NR cell, it can trigger an EPS fallback blind release-with-redirect to LTE if the 5QI setup is rejected by the feature NR Service Admission Control .

#### 8.3.13.2 Voice Fallback from NR SA to LTE

There are three mechanisms to move UEs in connected mode from NR SA to LTE when a voice call is requested:

- Blind release-with-redirect (RwR) to LTE (without measurement)

- Measurement-based release-with-redirect to LTE

This mechanism requires that the UE supports measurement of LTE frequencies, as indicated by the 3GPP UE capability IE, eventB-MeasAndReport . If the capability is not supported, blind RwR is triggered instead.

- Measurement-based handover to LTE

This mechanism requires that the UE supports both measurement of LTE frequencies and handover to LTE. If the UE supports neither, then blind release-with-redirect is triggered. If the UE supports measurement but not handover, then release-with-redirect with measurements is triggered.

The mechanism is chosen and configured by settings in the gNodeB feature EPS Fallback for IMS Voice , described in Section 10.3.10. Refer to Section 11.2.5 for the parameters and trigger level formulas.

### 8.3.14 Emergency Voice Call - SA

An emergency voice call can be handled in three different ways in NR SA:

- UE reselection to other frequency or RAT :

This case occurs when the 5GC supports neither emergency calls nor emergency fallback. The UE is made aware of this lack of support via the emergency support indication in the NAS Registration Accept message. As a result, it autonomously reselects to another frequency or RAT which supports emergency calls and sets up the call there.

<!-- page: 174 -->

- Voice over NR (VoNR) :

If both the 5GC and RAN support emergency calls, then the UE can set up the emergency call over NR SA, as VoNR.

- Fallback to LTE :

If the 5GC supports either emergency calls or emergency fallback, then the network can trigger emergency call fallback, using release-with-redirect or handover to LTE.

The two last mechanisms are described in the following sections.

#### 8.3.14.1 Emergency Voice Call over NR

This procedure is enabled by the gNodeB feature NR Emergency Procedures (Section 10.3.13).

The feature provides the ability to detect and handle emergency voice calls on NR SA for UEs that are capable of VoNR, instead of performing emergency fallback to LTE.

If the feature NR High Load Handling for VoNR is active in the NR cell, it can trigger an EPS fallback blind release-with-redirect to LTE if the 5QI setup is rejected by the feature NR Service Admission Control .

#### 8.3.14.2 Emergency Voice Call Fallback from SA to LTE

This procedure is enabled by the gNodeB feature NR Emergency Fallback to LTE (Section 10.3.12).

As with a normal voice call, there are three mechanisms to move emergency calls in NR SA to LTE. They are described in Section 8.3.13.2.

Refer to Section 11.2.5 for the parameters and trigger level formulas.

### 8.3.15 RRC Connection Re-establishment - SA

RRC connection re-establishment allows the reestablishment of the UE context when a UE loses its connection to the serving cell. The functionality is enabled by the feature NR RRC Connection Re-Establishment .

It is initiated when the UE detects any of the following issues:

- Radio Link Failure (RLF)

- Reconfiguration with synch failure

- Mobility from NR failure

- Integrity check failure

- RRC connection reconfiguration failure

<!-- page: 175 -->

If the gNodeB detects the RLF before the UE, then it waits for RrcUeCfg.tWaitForRrcReestRequest before starting the UE context release procedure. This allows time for the UE to trigger the RRCReestablishmentRequest message. If the timer expires before the gNodeB receives the RRCReestablishmentRequest message from the UE, then the gNodeB releases the UE. The timer can be set differently for different UE groups.

**The functionality is enabled with the attribute**

GNBCUCPFunction.rrcReestSupportType , which can be set to: NO_RRE_SUPPORT , INTRA_GNB_RRE or INTRA_INTER_GNB_RRE .

In the case of inter-gNodeB RRC re-establishment, packets are forwarded between the gNodeBs.

## 8.4 Interworking Between LTE and NR SA

Typically, NR SA is deployed as an overlay to an established LTE network. It is therefore important to consider the interworking between the two technologies. Although the existing LTE network is likely to have multiple layers, the interworking functionality can be illustrated with the simple two-layer network shown in Figure 8-22.

![Figure on page 175](5G_Mobility_and_Traffic_Management_Guideline_images/page_175_image_002.png)

Figure 8-22 - Simple Two-Layer Network with LTE and NR SA

To ensure stable behavior, the idle and connected mode thresholds for IRAT mobility between NR SA and LTE must be coordinated with each other. Figure 8-23 shows the relevant thresholds when RSRP triggering is used, assuming that NR SA has a higher cellReselectionPriority than LTE. The circled numbers refer to regions of signal strength on NR SA and LTE; see the notes following the figure. Note that this is a simplified view that does not show hysteresis values.

<!-- page: 176 -->

![Figure on page 176](5G_Mobility_and_Traffic_Management_Guideline_images/page_176_image_002.png)

Figure 8-23 - IRAT Mobility between LTE and NR SA - RSRP Threshold Parameters

**Notes for Figure 8-23:**

- In this region NR SA performance is good and UEs are actively pushed towards NR SA from LTE, both in idle mode (by reselection to a higher priority carrier) and connected mode (by handover or release-with-redirect).

- In this region NR SA performance is still reasonable; not good enough to actively push UEs from LTE to NR SA and not poor enough to move UEs back to LTE. This region provides a buffer between arriving in NR SA from LTE (1) and being pushed back to LTE (3), and so ensures that UEs do not toggle back and forth between LTE and NR SA. In this example, the idle and connected mode thresholds at the lower end of this region are aligned. This makes the idle and connected cell sizes are the same. It is not advised to set sNonIntraSearchP or threshServingLowP lower than rsrpSearchZone.threshold and rsrpCandidateB2.threshold1 , because this would create an area where UEs can idle on NR SA, but are pushed to LTE upon entering connected mode.

<!-- page: 177 -->

- In this region NR SA performance is poor. Provided LTE signal strength is reasonable, UEs are pushed to LTE in idle mode, and also in connected mode by MCPC. The poorest end of this region is critical coverage, where UEs are pushed to LTE via handover or release-with-redirect, regardless of LTE signal strength if a valid LTE frequency exists. Otherwise, the UE is released to idle mode.

In this example, the idle and connected mode boundaries of region 3 are aligned. However, the connected mode boundaries can be set slightly lower than the corresponding idle mode ones, so that small fluctuations in signal strength do not result in coverage-triggered mobility immediately after the UE enters connected mode.

- In this region NR SA is effectively unusable. UEs cannot camp on the NR SA cell.

- In this region LTE performance is good. UEs can be pushed to this region in both idle and connected modes when NR SA performance is poor.

- In this region LTE performance is adequate.  UEs are not pushed to LTE here but may remain if already on the cell.

- In this region LTE is usable, but performance is poor. UEs only camp in this region if they cannot camp on NR SA.

- In this region LTE is effectively unusable. UEs cannot camp on the LTE cell.

The boundaries between these regions in Figure 8-23 are set by the parameters shown. While the figure shows the purpose of the parameters, and the relationship between them, it does not provide recommended values. The best values depend on several factors such as: the number of layers in each RAT, the bandwidth of the layers, the carrier aggregation possibilities, and the cell edge performance. Ideally, the thresholds are set so that UEs leave NR when LTE performance is likely to be better. Recommended parameter values are provided for common deployment cases in the CPI document RAN Parameter Recommendations.

<!-- page: 178 -->

# 9 LTE Anchor Carrier Management - NSA

The Ericsson implementation for NSA allows any LTE carrier to be used as an anchor for EN-DC. In a given network deployment, however, some carriers may be unsuitable for use as anchors. Criteria for choosing suitable anchor carriers are provided in Section 9.1.

If EN-DC is not deployed on all LTE carriers or if UEs do not support EN-DC on all the deployed band combinations, then a UE may find itself on an LTE carrier which cannot provide it with EN-DC service. To obtain EN-DC service, the UE must be moved to an appropriate LTE anchor carrier. If the existing mobility and traffic management strategy does not accomplish this, then the strategy needs to be changed when 5G is deployed. Section 9.2 explains how it can be changed to steer EN-DC capable UEs towards an appropriate anchor carrier. Subsequent sections provide additional information configuring anchor management solutions.

## 9.1 Choosing Suitable Anchor Carriers - NSA

The following sections present criteria for determining whether an LTE carrier is suitable for use as an anchor for EN-DC.

### 9.1.1 Standardized EN-DC Band Combinations

The allowed band combinations for EN-DC operation are specified in 3GPP TS 38.101-3.

If an LTE carrier has no allowed band combinations with any of the deployed NR bands, then it cannot be used as an anchor carrier with those carriers.

Note, however, that some bands overlap, and a physical frequency can be contained in more than one band. With the feature Multiple Frequency Band Indicator , additional band combinations can become available, and if one of those supports EN-DC then the LTE carrier can be used as an anchor accordingly (refer to Section 10.2.1.4).

### 9.1.2 UE support of EN-DC Band Combinations

The UE reports its supported list of EN-DC band combinations in the IE UE-MRDC-Capability as specified in 3GPP TS 38.331. Refer to Section 6.2.1 for how the eNodeB requests this information.

Many UEs do not support EN-DC inter-band combinations that share the same UE power amplifier, due to RF limitations when transmitting on both UL carrier frequencies for the PCell and PSCell.

A typical UE implementation is expected to share the same power amplifier for bands within each one of the following band groups:

- FDD bands below 1 GHz

- FDD bands above 1 GHz

<!-- page: 179 -->

- TDD bands below 6 GHz

EN-DC inter-band combinations that fall within one of these band groups are unlikely to be supported by all UEs. For example, UEs are unlikely to support an EN-DC combination where both the NR and LTE carriers are below 1 GHz.

Note that intra-band EN-DC is allowed in 3GPP TS 38.101-3 for specific bands, for example within Band 41.

An LTE carrier is unsuitable as an anchor carrier if it has no EN-DC band combinations that are likely to be supported by UEs.

### 9.1.3 UE Support of Simultaneous Reception and Transmission

UE support for simultaneous reception and transmission is a pre-requisite for setting up EN-DC on that band combination.

If a UE supports a band combination, then it typically also supports simultaneous reception and transmission on that band combination.

The UE indicates its support of simultaneous reception and transmission ( simultaneousRxTxInterBandENDC ) on each EN-DC band combination using the IE MRDC-Parameters , as specified in 3GPP TS 38.331.

An LTE carrier is unsuitable as an anchor carrier if it has no EN-DC band combinations for which UEs are likely to support simultaneous reception and transmission.

### 9.1.4 Potential IM Interference and Single UL Allowed

UEs that transmit simultaneously on two different frequencies (for example an LTE and an NR frequency) may generate 2 nd  and 3 rd  order intermodulation (IM) products. If these IM products fall within a receive band being used by the UE, then they can interfere with the reception of the downlink. If the interference is strong enough, then it could impact performance. Similar interference can be caused by harmonics of a single uplink frequency.

This problem can occur on some EN-DC band combinations, where the simultaneous transmission on LTE and NR frequencies may cause IM products that fall within the LTE downlink receive band, causing interference.

Such IM interference can be avoided by not transmitting on both frequencies at the same time. 3GPP has therefore provided a mechanism by which a UE can request single uplink transmission on potentially problematic EN-DC band combinations. Such potentially problematic combinations are marked as 'Single UL Allowed' in 3GPP 38.101 -3. UEs request single uplink transmission on a particular EN-DC combination using the IE MRDCParameters ( singleUL-Transmission ), as specified in 3GPP TS 38.331.

<!-- page: 180 -->

However, i t is important to note that the NW is not mandated to follow the UE's indication and use single UL TX, whereas the UE is mandated to support dual UL TX even for Single UL Allowed combinations. In current release, the Ericsson EN-DC implementation does not consider the request for single UL TX and does not perform any coordination between LTE and NR UL scheduling. Using single UL TX would inevitably impact performance compared to dual UL TX, since LTE and NR UL transmissions would be divided in time.

An ENDC combination that is marked as 'Single UL Allowed' is only potentially problematic. Whether it actually presents a risk in a given network deployment depends on exactly which frequencies are used by the operator and whether their IM products fall on the DL carrier in use.

Take the example of LTE Band 3 and NR Band 78. Figure 9-1 shows a potentially problematic case, where the IM products fall across the used LTE downlink. Figure 9-2 shows a non-problematic case, where the IM products fall into unused spectrum. Furthermore, for IM interference to be a potential problem, the NR UL, the LTE UL and the LTE DL all need to be transmitting at the same time. The probability of this happening may be low. Finally, if interference ends up impacting performance, then MAC layer link adaption works to mitigate the impact.

![Figure on page 180](5G_Mobility_and_Traffic_Management_Guideline_images/page_180_image_002.png)

Figure 9-1 - Example of Frequencies with Potentially Problematic IM Interference

![Figure on page 180](5G_Mobility_and_Traffic_Management_Guideline_images/page_180_image_003.png)

Figure 9-2 - Example of Frequencies with Non-Problematic IM

In summary, even if the IM risk is low, the operator may wish to avoid EN-DC combinations that are marked as Single UL Allowed. If this avoidance results in the exclusion of all the valid EN-DC combinations for a particular LTE carrier, then that carrier should not be used as an anchor carrier.

<!-- page: 181 -->

### 9.1.5 Baseband Support for EN-DC

EN-DC requires that the LTE carrier is deployed using baseband hardware that supports EN-DC, namely a baseband unit of the Ericsson Radio System (ERS) family (for example 5212, 5216, 6318, 6620, 6630). Older baseband units (for example DUS41) should be upgraded to ERS or, where there is a mix of old and new baseband, the LTE anchor carriers can be hosted by the ERS baseband nodes and the non-anchor carriers by the older baseband.

### 9.1.6 Ericsson Spectrum Sharing (ESS)

With ESS, the LTE spectrum is dynamically shared with NR NSA and/or NR SA. However, an LTE cell cannot be used as an anchor for an NR cell on the same frequency. This excludes the ESS carrier from being used as an anchor for itself. The anchor cell must be on another LTE frequency.

The ESS carrier can, however, be used as an anchor for some other NR carrier, for example a mid-band NR carrier. If doing so, consider the limitations of an ESS carrier, for example, an ESS LTE carrier has a lower capacity than a dedicated LTE carrier of the same bandwidth.

These limitations impact the overall performance for the legacy LTE, EN-DC and NR SA users on ESS carriers. If alternative anchor carriers are available, better overall performance may be obtained by steering LTE traffic away from the ESS carrier. Doing so is easier if the ESS carrier is not used as an anchor, because both EN-DC Triggered Handover and Capability-Aware Idle Mode Control are more effective at moving traffic from a non-anchor to an anchor than from one anchor to a better anchor.

For these reasons, even when the ESS carrier can be used as an anchor for another NR NSA carrier, the operator may choose not to do so.

### 9.1.7 Other Considerations for Anchor Carrier Selection

In multi-layer LTE networks, the following points can also be considered when deciding whether to allow a particular carrier to be used as an anchor.

- Load : To ensure the best possible performance for EN-DC users, it may be desirable to use a more lightly loaded LTE carrier as an EN-DC anchor, rather than a more heavily loaded one.

- Coverage : To minimize reconfigurations due to LTE intra-frequency or inter-frequency handovers, avoid using carriers that do not have contiguous coverage as anchor carriers.

- UL capacity : To improve uplink performance, use carriers with a larger bandwidth (for example 20 MHz rather than 5 MHz) as anchors

<!-- page: 182 -->

## 9.2 Steering 5G UEs to an Anchor Carrier - NSA

If EN-DC is not deployed on all LTE carriers or if UEs do not support EN-DC on all the deployed band combinations, then UEs may be served by LTE carriers which cannot provide them with EN-DC service. To give these UEs access to EN-DC they must be steered to an appropriate anchor carrier. This steering is best done selectively, so that UEs that are not capable of EN-DC are not impacted. This section describes a strategy to achieve this.

The strategy has five components, which can be implemented in various combinations, depending on the required control. For example, it is possible to implement only those components that control idle mode mobility, leaving connected mode mobility unchanged.

The components of the strategy are listed below, and illustrated in Figure 9-3:

| 5G_Idle_Go   | Push 5G UEs from non-anchor to anchor in idle mode                                                  |
|--------------|-----------------------------------------------------------------------------------------------------|
| 5G_Idle_Stay | Discourage 5G UEs moving from anchor to non-anchor in idle mode                                     |
| 5G_HO_Go     | Encourage 5G UEs to perform a handover from non-anchor to anchor, or from anchor to a better anchor |
| 5G_Cov_Stay  | Prevent or discourage 5G UEs from performing coverage-triggered handover from anchor to non-anchor  |
| 5G_LB_Stay   | Prevent or discourage 5G UEs from performing IFLB-triggered handover from anchor to non-anchor      |

![Figure on page 182](5G_Mobility_and_Traffic_Management_Guideline_images/page_182_image_001.png)

Figure 9-3 - Strategy Components for Steering 5G UEs

All of these strategy components require a way to differentiate 5G UEs from non-5G UEs.

The differentiation technique can be based on automatically retrieving UE capabilities and/or on manually configuring attributes per subscriber in the core network, as follows:

UE Capability In this approach the UE informs the eNodeB of its EN-DC capabilities and this, together with NR subscription information, is used to impact mobility behavior.

<!-- page: 183 -->

**SPID In this approach, UEs are differentiated according to the Subscriber Profile ID (SPID).**

The SPID is a number from 1 to 256 which is set per subscriber in the HSS. It is sent from the HSS to the MME and from there to the eNodeB where it can be used to impact mobility behavior. One or more SPID values can be used to differentiate 5G subscribers from non-5G subscribers.

**QCI In this approach, UEs are differentiated according to the Quality of Service Class Indicator, (QCI)**

The QCI is a number from 1 to 255 which is set per subscriber and APN in the HSS (by means of an additional ContextId per APN). It is sent from the HSS to the MME and from there to the eNodeB where it can be used to impact mobility behavior. One or more QCI values can be used to differentiate 5G subscribers from non-5G subscribers. The QCI can also be altered by features in the eNodeB itself, using the UE capability or SPID as input. This makes it possible to implement a QCI-based solution which uses UE Capability or SPID as the primary differentiator, and QCI to alter the mobility behavior.

In the strategies presented here, these differentiation techniques are used together with one or more of the following eNodeB features to control mobility behavior:

**BIC Basic Intelligent Connectivity**

This feature provides the basic functionality needed for EN-DC. It allows control of load-triggered mobility based on whether the UE is EN-DC capable or not, and it allows the downlink A2 threshold for EN-DC capable UEs to be set differently from the threshold for non EN-DC capable UEs.

**CAIMC Capability-Aware Idle Mode Control**

Inter-Vendor Capability-Aware Idle Mode Control

These features encourage UEs to camp on frequencies which are EN-DC capable. They do so by altering the idle mode reselection priorities at RRC connection release, using the Idle Mode Mobility Control Information (IMMCI).

**ENDCHO EN-DC Triggered Handover During Setup**

EN-DC Triggered Handover During Connected Mode Mobility

These features provide the functionality to move a connected mode UE to a cell that is suited, or better suited, to provide it with EN-DC.

NUTB NR UE Throughput Booster This feature, in conjunction with ASGH Framework (Advanced Subscriber Group Handling), allows predefined QCIs to be re-mapped into new operator defined QCIs. The new QCIs are automatically assigned to UEs according to their EN-DC capability, NR restriction status and EN-DC connection status. Combining NUTB with MLSTM allows the mobility thresholds for the 5G UEs to be modified.

<!-- page: 184 -->

| ASGH   | Advanced Subscriber Group Handling Framework The feature allows subscribers (UEs) to be classified into groups, depending on a number of triggering conditions. The subscribers within a group can then be treated differently, for example they can be given a new QCI value, which allows other features to modify their mobility behavior.   |
|--------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| STM    | Subscriber Triggered Mobility This feature enables mobility behavior to be adapted based on the SPID value. Multi-Layer Subscriber-Based Mobility (MLSBM) is an enhancement to STM that enables more flexible SPID-based mobility control.                                                                                                      |
| MLSTM  | Multi-Layer Service-Triggered Mobility This feature enables coverage-triggered mobility thresholds to be adapted at the QCI and frequency relation level.                                                                                                                                                                                       |
| SSLM   | Service Specific Load Management This feature enables load-triggered mobility behavior to be adapted based on the QCI value.                                                                                                                                                                                                                    |
| MCPC   | Mobility Control At Poor Coverage This feature enables more flexible control of coverage-triggered mobility, using inner and outer search zones.                                                                                                                                                                                                |

Table 9-1 describes how each strategy component (green) can be achieved with one or more solutions (blue) using the given differentiation mechanisms (red). Each solution is represented by a solution number and a list of the features used.

Table 9-1 - Solutions for Steering 5G UEs

| Strategy Component        | Mechanism for Differentiating 5G UEs   | Mechanism for Differentiating 5G UEs   | Mechanism for Differentiating 5G UEs   |
|---------------------------|----------------------------------------|----------------------------------------|----------------------------------------|
| Strategy Component        | UE Capability                          | SPID                                   | QCI                                    |
| 5G_Idle_Go & 5G_Idle_Stay | 1a) CAIMC                              | 2a) STM 3a) MLSBM                      | -                                      |
| 5G_Cov_Stay               | 1b) BIC 2b) NUTB + ASGH + MLSTM        | 3b) STM 4b) MLSBM 5b) STM + MCPC       | 6b) MLSTM                              |
| 5G_HO_Go                  | 1c) ENDCHO 2c) NUTB + ASGH + MLSTM     | 3c) STM + MCPC                         | 4c) MLSTM                              |
| 5G_LB_Stay                | 1d) BIC 2d) NUTB + ASGH +SSLM          | 3d) STM                                | 4d) SSLM                               |

Table 9-1 - Solutions for Steering 5G UEs

Each of the possible solutions in Table 9-1 is described in detail in the following sections. Solution descriptions that involve SPID or QCI assume that unique SPID or QCI values are assigned for 5G subscribers. Details on how to do so are provided in Sections 9.5 and 9.6.

<!-- page: 185 -->

### 9.2.1 Anchor Control Strategy - 5G_Idle_Go and 5G_Idle_Stay

This section presents solutions for the 5G_Idle_Go and 5G_Idle_Stay strategies. Their purpose is to push 5G UEs from a non-anchor to an anchor in idle mode (5G_Idle_Go), and to discourage 5G UEs from moving from an anchor carrier to a non-anchor carrier in idle mode (5G_Idle_Stay).

These two strategies are implemented together in a single 5G_Idle strategy. Two solutions for the 5G_Idle strategy are described here, as shown in Table 9-2. Both solutions impact only 5G UEs.

Table 9-2 - Solutions for 5G\_Idle

| Solution Number   | Mechanism for Differentiating 5G Subscribers   | Features Used                                    | Comments                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
|-------------------|------------------------------------------------|--------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1a                | UE Capability                                  | CAIMC                                            | This is the simplest solution and the easiest to implement. It uses the Capability-Aware Idle Mode Control features in the eNodeB to modify the idle mode cell reselection priorities for 5G subscribers. The modified priorities consider the pre-existing priorities, the EN-DC capabilities of the UE, the available frequencies, and the configuration of the CAIMC features themselves (a number of prioritization modes are possible). This makes CAIMC a good solution when some UEs do not support all deployed band combinations or when the priority order of LTE EN-DC capable layers is to be controlled. Also, since CAIMC differentiates 5G subscribers based on UE capability, it is not necessary to configure subscriber differentiation information in the core network. |
| 2a and 3a         | SPID                                           | STM (optionally including the MLSBM enhancement) | This solution uses the Subscriber Triggered Mobility feature in the eNodeB to modify the idle mode reselection priorities for 5G subscribers. The modified priorities are configured manually, giving increased control compared with Solution 1a. 5G subscribers are differentiated using SPID, which must be manually defined in the core network. UE EN-DC capability is not considered by this solution, so it may not be appropriate.                                                                                                                                                                                                                                                                                                                                                 |

Table 9-2 - Solutions for 5G_Idle

Both CAIMC and STM work by overriding the idle mode reselection priorities sent in the SIB messages. However, these features do not override the thresholds associated with priority-based reselection. For both solutions, it is therefore important to check that the following thresholds have appropriate settings:

- EUtranCellFDD/TDD.systemInformationBlock3.sNonIntraSearch - serving cell threshold for starting measurements on a lower priority frequency

- EUtranCellFDD/TDD.threshServingLow - serving cell threshold for reselection towards a lower priority frequency.

- EUtranFreqRelation.threshXLow - target cell threshold for reselection to a lower priority frequency.

<!-- page: 186 -->

- EUtranFreqRelation.threshXHigh - neighbor cell threshold for reselecting towards a higher priority frequency

#### 9.2.1.1 5G_Idle Solution based on UE Capability, using CAIMC (Solution 1a)

The Capability-Aware Idle Mode Control (CAIMC) features encourage EN-DC capable UEs to camp on a frequency which they can use for EN-DC. They do so by altering the cell reselection priorities used by the UE to reselect between frequencies in idle mode. These features can therefore be used to provide a solution for the 5G_Idle_Go and 5G_Idle_Stay strategies. This section describes how.

The solution described here focuses primarily on the feature Capability-Aware Idle Mode Control , which provides the full CAIMC functionality and is available in baseband nodes (see Section 10.2.10 for the feature summary).

The first step when considering an anchor carrier management solution is to assess whether a solution is actually required. Consider the example in Figure 9-4. While it may not reflect the network being considered, this example introduces conceptual tools which can be applied to other cases.

![Figure on page 186](5G_Mobility_and_Traffic_Management_Guideline_images/page_186_image_002.png)

Figure 9-4 - EN-DC Service Availability Given Various Anchor Configurations

In this example, there are two LTE coverage layers on low band frequencies (LLow1 and LLow2) and an LTE capacity layer on a higher band frequency (LHi). The two coverage layers have equal cell reselection priority (6), and the capacity layer has a higher priority (7). This 'priority carrier configuration' is explained in the LTE Mobility and Traffic Management Guideline; it pushes UEs towards the capacity layer in idle mode. UEs which are within the coverage of LHi (A and B) will camp on it, while UEs that are not (C, D, E and F) will be distributed between LLow1 and LLow2 according to signal strength and load balance.

The example shows four possibilities for anchor carrier configuration, and for each configuration it shows where the existing priority carrier configuration places the UEs. Two types of UEs are shown; the orange UEs support ENDC and the grey UEs don't. In this example, the mobility configuration does not differentiate between them.

<!-- page: 187 -->

**· High-Band Anchor**

The only UE which is both capable of EN-DC and within coverage of the EN-DC anchor carrier is UE A. As it is already placed on LHi by the existing priority settings, an anchor management solution is not needed.

**· Low-Band Anchor**

UEs A, C and E are all EN-DC capable and are within coverage of the EN-DC anchor carrier. However, only UE E has access to EN-DC with the existing priority settings. UEs A and C are camped on carriers which do not support EN-DC. In this case an anchor management solution is needed.

**· Low- and High-Band Anchors**

UEs A, C and E are all EN-DC capable and are within coverage of an EN-DC anchor carrier. However, UE C is camped on LLow2 and so does not have access to EN-DC. Once again, an anchor management solution is needed.

**· All Anchors**

In this case EN-DC capable UEs always have access to EN-DC and no anchor management solution is needed, assuming that all the UEs support a relevant band combination on all LTE carriers. If this assumption is not appropriate, then a solution is needed.

Where a solution is needed, it can be implemented in either idle mode (5G_Idle), or connected mode (e.g. 5G_HO_Go) or both. This section describes the 5G_Idle solution using CAIMC.

The impact of the CAIMC solution on the ' Low Band Anchor ' case is shown in Figure 9-5. CAIMC has moved UEs A and C to LLow1, where they can obtain EN-DC service. Non EN-DC capable UEs (B, D and F) have not been impacted.

<!-- page: 188 -->

![Figure on page 188](5G_Mobility_and_Traffic_Management_Guideline_images/page_188_image_002.png)

Figure 9-5 - CAIMC Solution for Low Band Anchor Case

The impact of the CAIMC solution on the ' Low and High Band Anchors ' case is shown in Figure 9-6, below. In this figure an additional aspect is shown, namely the EN-DC band combinations supported by the UE. Three cases are considered: support for only LLow1 + NR1 (orange), support for only LHi + NR2 (purple), and support for both (orange and purple). UEs which do not support EN-DC are not shown in this figure.

Without CAIMC, UEs C, D, E, F and J end up on carriers which they cannot use for ENDC. With CAIMC, UEs C, D and F are moved to carriers which they can use for EN-DC. UEs E and J remain without EN-DC because they are not within coverage of LHi, which is the only EN-DC anchor they support.

UE A is shown on LHi. However, it is capable of EN-DC on both LHi and LLow1, so CAIMC could place it on either frequency, depending on which is higher prioritized. The priority is decided by CAIMC based on different configurable criteria, as described in 10.2.10.

<!-- page: 189 -->

![Figure on page 189](5G_Mobility_and_Traffic_Management_Guideline_images/page_189_image_002.png)

Figure 9-6 - CAIMC Solution for Low and High Band Anchor Case

These examples show that anchor carrier management is a complex and multi-dimensional problem, impacted by the network capability and configuration, feature configuration, UE capability, and coverage.

To handle this complexity and allow a tailored solution, CAIMC has four different methods for prioritizing the EN-DC capable frequencies; Configuration-Based, UE Capability-Based, Hit Rate-Based and Cell Number-Based.  The method is selected by the attributes UePolicyOptimization.endcAwareImc and

UePolicyOptimization.coverageAwareImc as follows:

- Configuration-Based Prioritization If endcAwareImc = 1 ( MODE_1 ), then CAIMC uses the attribute EUtranFreqRelation.endcAwareIdleModePriority , in a relative way, to rank the EN-DC capable frequencies; a bigger value leads to a higher priority in IMMCI.

**· UE Capability-Based Prioritization**

If endcAwareImc = 2 ( MODE_2 ), then CAIMC assigns the highest priority to the LTE frequencies that support the highest number of NR bands. If multiple LTE frequencies support the same number of NR bands, then CAIMC uses

EUtranFreqRelation.endcAwareIdleModePriority to prioritize between them.

<!-- page: 190 -->

**· Hit Rate-Based Prioritization**

If endcAwareImc = 0 ( DEACTIVATED ) and coverageAwareImc = true , and at least one of the features Best Neighbor Relations for Intra-LTE Load Management (BNR) or Cell Sleep Mode (CSM) is active, then CAIMC bases the priorities on the hit rates measured by one of those features, as described in Section 10.2.10. If neither feature is active, Cell Number-Based Prioritization is used.

**· Cell Number-Based Prioritization**

If endcAwareImc = 0 ( DEACTIVATED ) and coverageAwareImc = false , then CAIMC bases the priorities on the number of EN-DC capable cells, as described in Section 10.2.10.

The first two methods (Configuration-Based and UE Capability-Based) are more flexible and allow more explicit control over the priorities, so one of them is likely to the best choice in most cases. Their impact on idle mode behavior is shown in Figure 9-7, which compares three cases:

- CAIMC disabled

- Configuration-Based CAIMC, endcAwareImc = 1 ( MODE_1 )

- UE Capability-Based CAIMC, endcAwareImc = 2 ( MODE_2 )

This example is more complex than the previous examples, because it additionally considers the settings for endcAwareIdleModePriority and the number of NR bands supported by the UE for each LTE carrier.

![Figure on page 190](5G_Mobility_and_Traffic_Management_Guideline_images/page_190_image_001.png)

Figure 9-7 - CAIMC Solution with Different Prioritization Methods

Notes for Figure 9-7:

<!-- page: 191 -->

- Without CAIMC (left pane), the UEs camp on the frequencies with highest cellReselectionPriority that provide coverage. As a result, many of the UEs camp on layers where they cannot access EN-DC (and would therefore need to be moved in connected mode, for example by a 5G_HO_Go solution, to access EN-DC).

- When endcAwareImc = MODE_1 (central pane), the valid anchor layers are prioritized according to endcAwareIdleModePriority . CAIMC therefore assigns the highest priority to LHi (purple) for all UEs that support this layer as anchor for at least one of the NR bands. Similarly, LMid1 (blue) is preferred over LLow (orange) for all UE supporting this layer as anchor. UE ' H ' , ' M ' and ' N ' remain without EN-DC, because they do not have coverage from the LTE frequencies which they support for NR.

- When endcAwareImc = MODE_2 (right pane), higher importance is given to the maximum number of NR bands that can be activated. So, despite the higher value of endcAwareIdleModePriority for LHi (purple), the UE ' E ' is pushed from LHi (purple) to LLow (orange) since from this layer it can activate both NR1 and NR2. The same happens to UEs 'F' and ' L ' , which move from layer LMid1 (blue) to LLow (orange) where they can activate two NR bands instead of one.

After the prioritization process described above, CAIMC can optionally perform an additional prioritization step which considers load. This is enabled by setting UePolicyOptimization.loadAwareImc = true . CAIMC then reduces the priority of EN-DC capable frequencies that are highly loaded.

CAIMC considers an EN-DC capable frequency to be highly loaded if at least one cell on the frequency meets the following conditions:

- The cell has an EUtranCellRelation from the serving cell, with loadBalancing = ALLOWED or IFO_AND_IFLB

- The cell's subscription ratio equals or exceeds its setting of EUtranCellFDD/TDD.subscriptionRatioHighThresh

If CAIMC considers one or more frequencies to be highly loaded, then it divides the EN-DC capable frequencies into two groups and attempts to give the highly loaded frequency(s) lower priority than the other frequencies, while maintaining the priority order within each group. See Section 10.2.10.5 for further details.

This load-aware functionality can be tuned in two main ways:

- subscriptionRatioHighThresh can be adjusted, at the cell level, to ensure that cells are considered highly loaded only when the load is high enough to risk poor performance.

<!-- page: 192 -->

- loadBalancing can be used to control which neighboring cells are considered when assessing the load on each potential target frequency. To prevent a cell from being considered, set loadBalancing = NOT_ALLOWED . This setting can be used to ensure that distant cells, with little chance of being selected by the UE, are excluded from the load assessment. Note that this also disables inter-frequency load balancing to that cell. To help automate the setting of loadBalancing , the eNodeB feature Best Neighbor Relations for Intra-LTE Load Management (BNR) can be used. It automatically sets the value of loadBalancing , according to the measured hit rate (which is a proxy for the coverage overlap). It can therefore be used to prevent CAIMC from considering the load on relations whose hit rate is lower than a configurable threshold.

Note that CAIMC does not consider NR coverage when evaluating band combinations, and UEs do not consider NR coverage when reselecting between LTE carriers in idle mode. It is therefore possible that CAIMC pushes a UE to a layer where not all the intended NR bands can actually be used. CAIMC can even move UEs that do not have coverage from any NR layer. This complicates the choice of prioritization method. Consider, for example, UEs ' F ' and ' L ' . If coverage from NR1 is not available but coverage from NR2 is available, then MODE_2 is preferable, as it enables these two UEs to obtain EN-DC. However, if coverage from neither NR1 nor NR2 is available, then MODE_1 may be preferred, because it leaves those UEs on LMid1, which may have higher bandwidth and deliver better performance than LLow without EN-DC.

Given the above challenges, CAIMC can be complemented by EN-DC Triggered Handover (ENDCHO), which does measure NR coverage and can be used to create a solution for 5G_HO_Go, as described in Section 9.2.3.1. The best strategy for a given network situation may be to use a combination of the two features, or even to disable CAIMC and use only ENDCHO.

#### 9.2.1.2 5G_Idle Solution based on SPID, using STM (Solution 2a)

This solution uses the feature Subscriber Triggered Mobility (STM) to implement the 5G_Idle_Go and 5G_Idle_Stay strategies. In this solution, 5G UEs are differentiated from non-5G users by their SPID value. Only the 5G UEs are impacted by this solution.

The feature Subscriber Triggered Mobility enables the configuration of special cell reselection priority values for each SPID, which override the values that are broadcast in System Information. When a UE transits from connected to idle mode, STM checks whether the cell reselection priorities for the UE's SPID differ from the priorities broadcast in system information. If they differ, the RRCConnectionRelease message from the eNodeB to the UE includes a list of dedicated cell reselection priorities. These dedicated priorities override the priorities broadcast in the system information for a time set by the attribute RATFreqPrio.t320 .

Note that the cell reselection priorities are configured differently in system information versus STM:

- In system information the priorities are configured per EUtranFreqRelation , which means they can be set differently for each combination of source cell and target frequency.

<!-- page: 193 -->

̶

- In STM the priorities are configured per frequency, for the entire eNodeB. This means that all the relations pointing to a given frequency, from all cells in the eNodeB, have the same priority. With STM, it is therefore not possible to configure a 'relative' cell reselection strategy, where the priorities depend on the cell on which the UE is camped. On example of a configuration which cannot be achieved with STM is the 'Sticky Carrier' configuration described in the LTE Mobility and Traffic Management Guideline .

Furthermore 3GPP 36.304 states that 'If priorities are provided in dedicated signaling, the UE shall ignore all the priorities provided in system information'.

To ensure complete control over prioritization, configure STM with cellReselectionPriority values for all frequencies on all RATs (NR, LTE, WCDMA and GSM) that the UE should consider for cell reselection. This is done with the structures underlying freqPrioListEUTRA , freqPrioListUTRA , and freqGroupPrioListGERAN and the MO FreqPrioNR .

Even when STM is used, reselection from one frequency to another still requires an EUtranFreqRelation to be present between the source cell and the target frequency. If, in a given network deployment, some relations have not been defined (for example to control mobility paths or to reduce complexity) then reselection cannot occur. For any desired reselection paths, relations must therefore be created if missing.

To illustrate this solution, consider the following network example:

- The operator has two different types of 5G subscribers, and these are identified by SPID values 5 and 20

- Three LTE frequencies:

̶

- earfcn: 1350, the preferred anchor frequency

- earfcn: 6300, the secondary anchor frequency

- earfcn: 3750, non-anchor frequency to be selected only if the anchor frequencies are not good enough

̶

- One UTRAN frequency:

̶

- arfcn: 10638, with lower priority than the LTE layers

The solution can be implemented with the following configuration steps:

- Assign a SPID value for 5G subscribers in the HSS (see Section 9.5). In this example, the two 5G subscriber groups are assigned SPID=5 and SPID=20.

- Create a RATFreqPrio object in the MO SubscriberProfileID [0 to 8]. In this example RATFreqPrio[0] is created.

- Include the 5G SPID values (for example SPID=5 and 20) in the RATFreqPrio.spidList [0 to 20] attribute. A given SPID value can only be included in one RATFreqPrio MO.

<!-- page: 194 -->

- Set the timer RATFreqPrio.t320 = 180 (180 minutes, the maximum). The dedicated frequency prioritization is valid for 180 minutes after the UE switches from connected to idle mode. Given the frequent connection establishments triggered by typical UEs, this is more than enough to guarantee a stable prioritization.

- Configure the structure attribute RATFreqPrio.freqPrioListEUTRA [0 to 24]. For each frequency it is possible to define several attributes to control different mobility rules (idle mode, connected mode, load balancing, etc.) This solution involves only two of these attributes: arfcnValueEUtranDl which identifies the frequency and cellReselectionPriority which sets the priority.

Assign the highest priority to the preferred anchor layer:

freqPrioListEUTRA[0].arfcnValueEUtranDl = 1350 freqPrioListEUTRA[0].cellReselectionPriority

= 7 Assign a lower priority to the secondary anchor frequency: freqPrioListEUTRA[1].arfcnValueEUtranDl = 6300 freqPrioListEUTRA[1].cellReselectionPriority = 6 Assign an even lower priority to the non-anchor frequency: freqPrioListEUTRA[2].arfcnValueEUtranDl = 3750 freqPrioListEUTRA[2].cellReselectionPriority = 5

- Configure the structure attribute RATFreqPrio.freqPrioListUTRA [0 to 64] to define the priority of UTRAN layers. It is possible to configure up to 65 frequencies. Assign priority 3, lower than the LTE layers, to the UTRAN frequency:

freqPrioListUTRA[0].arfcnValueUtranDl = 10638 freqPrioListUTRA[0].cellReselectionPriority = 3

This example is illustrated in Figure 9-8.

![Figure on page 194](5G_Mobility_and_Traffic_Management_Guideline_images/page_194_image_002.png)

Figure 9-8 - 5G_Idle Solution based on SPID, using STM

<!-- page: 195 -->

#### 9.2.1.3 5G_Idle Solution based on SPID, using MLSBM (Solution 3a)

This solution is similar to Solution 2a, but it uses the Multi-Layer Subscriber Based Mobility (MLSBM) enhancement of STM. Like STM, MLSBM allows the broadcasted cell reselection priority values to be overridden by dedicated values, which are sent to the UE at release. However, MLSBM offers better flexibility because the dedicated values can be controlled per cell per frequency relation rather than per node per frequency. This allows a 'relative' cell reselection strategy, where the priorities depend on the serving cell. Furthermore, MLSBM introduces UeProfileFilter instances, which map SPID values to parameter sets, further increasing the configuration flexibility.

Figure 9-9 illustrates the solution applied to Cell B only.

![Figure on page 195](5G_Mobility_and_Traffic_Management_Guideline_images/page_195_image_002.png)

Figure 9-9 - 5G_Idle Solution based on SPID, using MLSBM

### 9.2.2 Anchor Control Strategy - 5G_Cov_Stay

This section presents solutions for the 5G_Cov_Stay strategy. Its purpose is to prevent or discourage 5G UEs from performing coverage-triggered handovers from an anchor carrier to a non-anchor carrier.

Five possible solutions are described here, as shown in Table 9-3.

<!-- page: 196 -->

Table 9-3 - Solutions for 5G\_Cov\_Stay

| Solution Number   | Mechanism for Differentiating 5G Subscribers   | Features Used                                | Comments                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
|-------------------|------------------------------------------------|----------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1b                | UE Capability                                  | BIC                                          | This solution uses the feature Basic Intelligent Connectivity to identify EN-DC capable UEs and lower their A2 threshold (poor serving cell coverage) to delay the start of the search for a better cell on another frequency or RAT. As the delay impacts all potential target carriers, this solution is most suited for networks that have only a single anchor layer.                                                                                                                                                                                                                                                   |
| 2b                | UE Capability                                  | NUTB + ASGH + MLSTM                          | This solution uses the features NR UE Throughput Booster and ASGH Framework to identify EN-DC capable UEs and remap the QCIs of those UEs to new operator-defined values. The feature Multi-Layer Service-Triggered Mobility uses the re-mapped QCIs to apply offsets to the mobility event thresholds for EN- DC capable UEs. This solution enables different offsets to be applied on different frequencies. It can therefore be used to delay or disable handover selectively, for example only towards non-anchor frequencies. This makes it a useful solution for networks with multiple anchor and non-anchor layers. |
| 3b, 4b            | SPID                                           | STM (optionally including MLSBM enhancement) | This SPID-based solution uses the feature Subscriber Triggered Mobility to completely prevent coverage- triggered handover from anchor carriers to non-anchor carriers. It is a simple solution, but it is not suitable for anchor carriers which have coverage holes. It also requires SPID to be defined manually in the core network.                                                                                                                                                                                                                                                                                    |
| 5b                | SPID                                           | STM + MCPC                                   | This SPID-based solution uses the feature Mobility Control at Poor Coverage to create two search zones. In the inner search zone, UEs search for suitable coverage from anchor carriers only. In the outer search zone UEs search for suitable coverage from all carriers. This two-stage search helps UEs to remain on an anchor carrier. This solution does not completely prevent handover to non-anchor carriers, so it can be used even on anchor carriers with coverage holes. However, it is more complex than Solution 3b.                                                                                          |
| 6b                | QCI                                            | MLSTM                                        | This QCI-based solution is similar to Solution 2b, except that the QCI values are set manually in the core network, rather than automatically based on EN-DC capability.                                                                                                                                                                                                                                                                                                                                                                                                                                                    |

Table 9-3 - Solutions for 5G_Cov_Stay

In all five solutions, only 5G UEs are impacted. The mobility of non-5G UEs is not impacted.

#### 9.2.2.1 5G_Cov_Stay solution based on UE Capability, using BIC (Solution 1b)

The A2 threshold is used in LTE to identify poor serving cell coverage and trigger the search for a better inter-frequency or inter-RAT cell. By applying a negative offset to the A2 threshold, it is possible to delay the search for inter-frequency or inter-RAT handovers and keep the UE in the serving cell longer.

<!-- page: 197 -->

The feature Basic Intelligent Connectivity (BIC) allows the A2 threshold to be set differently for 5G UEs. Specifically, in this solution the BIC functionality is used to apply an additional (negative) offset for EN-DC capable UEs when served by EN-DC capable cells, therefore delaying the coverage-triggered search for a better LTE carrier or another RAT. Note that the delay applies to all potential target carriers; it cannot be applied selectively, for example, only to non-anchor carriers. This solution is therefore suitable when only one LTE carrier can be used as an anchor and all other carriers cannot. If more than one carrier can be used as an anchor, then Solution 2b is more suitable.

The additional offsets for EN-DC capable UEs can be applied to only the inner search zone (separately per QCI) or to both the inner and the outer search zones (the outer search zone offset is not settable per QCI). The offsets can be set for RSRP or RSRQ or both. The search offsets are applied to both Event A2 (entering poor coverage) and Event A1 (re-entering good coverage). For more details on these offsets, refer to the feature summary in Section 10.2.1.6 and the trigger level formulas for MCPC in the LTE Mobility and Traffic Management Guideline in CPI.

Figure 9-10 provides an example where both the inner and outer search zone RSRP thresholds are lowered by 5 dB for EN-DC capable UEs. The inner search zone offset is applied to QCI 9, assuming that this is the default QCI used for data. The RSRQ offset is not applied in this example.

![Figure on page 197](5G_Mobility_and_Traffic_Management_Guideline_images/page_197_image_002.png)

Figure 9-10 - 5G_Cov_Stay Solution based on UE Capability, using BIC (discourage handover)

#### 9.2.2.2 5G_Cov_Stay Solution based on UE Capability, using NUTB, ASGH and MLSTM (Solution 2b)

This is a more complex solution than Solution 1b, as it involves the use of three features: NR UE Throughput Booster (NUTB), ASGH Framework and Multi-Layer Service-Triggered Mobility (MLSTM). However, it is a more flexible solution, because it enables the mobility offsets to be modified selectively for different target carriers. For example, handover to a non-anchor carrier can be delayed, while handover to an anchor carrier remains unchanged.

<!-- page: 198 -->

̶

In this solution, NUTB and ASGH are used to alter the QCI values of EN-DC capable UEs. The new QCI values are then used by MLSTM to identify those UEs and selectively delay their coverage-triggered handover from anchor carriers to non-anchor carriers.

To illustrate this solution, consider the following example:

- The network has three LTE layers:

̶

- Band 1, earfcndl = 100, anchor

- Band 3, earfcndl = 1300, non-anchor

̶

- Band 20, earfcndl = 6300, anchor

- The objectives of the solution are:

̶

- Delay by 3dB the coverage-triggered handover (based on RSRP) of EN-DC capable UEs from Band 1 to Band 3

̶

- Do not change handover of EN-DC capable UEs from Band 1 to Band 20

̶

- Do not change handover for non EN-DC capable UEs

The solution is shown in Figure 9-11.

- The top part of the figure illustrates how NUTB and ASGH are used to remap the QCI from 9 (assumed to be the QCI used for data) to 30 (the new value for EN-DC capable UEs).  A more detailed description of these settings is provided in Section 9.6.3.

- The lower part of the figure illustrates how MLSTM is used to lower by 3dB the A5 threshold 1 (RSRP), used for coverage-triggered inter-frequency handover. This delays the handover until the serving cell coverage has fallen by an additional 3dB compared to the original setting. Note that the offset ( a5Thr1RsrpFreqQciOffset ) is applied only to QCI 30 and only to the EUtranFreqRelation for Band 3 (1300).

- In this example, the A5 threshold 2, which specifies the required target cell signal strength, is left unchanged ( a5Thr2RsrpFreqQciOffset = 0). However, a positive value could be set to increase the requirement on the target cell coverage, to compensate somewhat for the fact that the target is not EN-DC capable.

<!-- page: 199 -->

![Figure on page 199](5G_Mobility_and_Traffic_Management_Guideline_images/page_199_image_002.png)

Figure 9-11 - 5G_Cov_Stay Solution based on UE Capability, using NUTB, ASGH and MLSTM (Delay Handover)

#### 9.2.2.3 5G_Cov_Stay Solutions based on SPID, using STM (Solutions 3b, 4b and 5b)

This section presents solutions for the 5G_Cov_Stay strategy, based on the feature Subscriber Triggered Mobility (STM). They use SPID to differentiate 5G from non-5G subscribers.

STM enables the connected mode frequency priorities ( connectedModeMobilityPrio and voicePrio ) to be modified per frequency based on SPID, using the MO RATFreqPrio . The values in RATFreqPrio override the values in EUtranFreqRelation , which are normally used. This functionality can be used to modify the coverage-triggered inter-frequency handover behavior to provide two possible solutions; two which prevent handover of 5G UEs completely (Solution 3b and 4b below), and another which discourages it (Solution 5b below).

In a similar way MLSBM allows the connected mode frequency priorities ( connectedModeMobilityPrio and voicePrio ) to be modified per cell per frequency relation based on SPID, using the children of the UeProfile MO .

<!-- page: 200 -->

**Solution 3b with STM - Prevent Handover**

Coverage-triggered handover to non-anchor carriers is completely prevented for data-only connections by setting freqPrioListEUTRA.connectedModeMobilityPrio = -1 on the non-anchor frequencies. Optionally, handover is also completely prevented for VoLTE connections, by setting freqPrioListEUTRA.voicePrio = -1. Handover to the anchor frequencies is left unaffected, by leaving these two attributes at their default values of -1000 for the anchor frequencies. This means these attributes are ignored, and the values in EUtranFreqRelation are used, as normal.

To prevent this solution from impacting idle mode mobility, set cellReselectionPriority = -1000 in all freqPrioListEUTRA , freqPrioListUTRA and freqGroupPrioListGERAN structures.

These settings are summarized in Figure 9-12, for the same example as used in 9.2.1.1.

![Figure on page 200](5G_Mobility_and_Traffic_Management_Guideline_images/page_200_image_001.png)

Figure 9-12 - 5G_Cov_Stay Solution based on SPID (Prevent Handover with STM)

Configuration for this 5G_Cov_Stay solution is very simple if the 5G_Idle_Go and 5G_Idle_Stay solutions (described in Section 9.2.1.1) are already implemented. The only additional change is to set connectedModeMobilityPrio = -1 on the non-anchor frequencies.

This solution is not recommended for anchor carriers which have coverage holes; that is if the coverage-triggered handover from anchor to non-anchor is required to maintain service. In this case Solution 2b or 5b is recommended.

**Solution 4b with MLSBM - Prevent Handover**

This solution uses the MLSBM enhancement to STM to achieve the same outcome as in Solution 3b. However, with MLSBM the solution can be applied at the cell level rather than node level. As shown in Figure 9-13, SPID-based control is applied only for Cell B. Cell A uses the connectedModeMobilityPrio settings in the EUtranFreqRelation .

<!-- page: 201 -->

![Figure on page 201](5G_Mobility_and_Traffic_Management_Guideline_images/page_201_image_002.png)

Figure 9-13 - 5G_Cov_Stay Solution based on SPID (Prevent Handover with MLSBM)

**Solution 5b - Discourage Handover**

This solution is similar to Solution 3b and 4b, except that coverage-triggered handover to non-anchor carriers is discouraged rather than prevented. This solution is preferable if on anchor carriers with coverage holes.

In this solution, the feature Mobility Control at Poor Coverage is used to create two search zones in anchor cells; an inner and an outer search zone. The outer search zone is equivalent to the pre-existing single search zone. The inner search zone is a new search area, which is used only by 5G UEs to search for better coverage from other anchor carriers.

The search zones of the anchor cells are shown in Figure 9-14. Referring to the diagram on the right, as 5G UEs move out of good coverage (green) they first enter the inner search zone (yellow), where they search for coverage from anchor carriers only. If suitable coverage is not found amongst the anchor carriers, then the 5G UEs eventually enter the outer search zone (red) where they search for coverage from all LTE carriers and from other RATs. Non-5G UEs are not impacted by this solution; they search for coverage from all carriers in the outer search zone only.

<!-- page: 202 -->

![Figure on page 202](5G_Mobility_and_Traffic_Management_Guideline_images/page_202_image_002.png)

Figure 9-14 - 5G_Cov_Stay Solution based on SPID (Discourage Handover)

Inner and outer search zones are created for RSRP by setting the attribute a2OuterSearchThrRsrpOffset to a value lower than 0. For example, setting this attribute to -3 dB creates an outer search zone which begins 3 dB below the inner search zone, which is set by a1a2SearchThresholdRsrp . RSRP is the recommended trigger quantity, for the reasons outlined in the LTE Mobility and Traffic Management Guideline . However, RSRQ can also be used, in which case the search zones for RSRP and RSRQ function independently.

To determine which frequencies are searched in the inner and outer search zones the attribute lowPrioMeasThresh is used. This attribute is compared with connectedModeMobilityPrio and voicePrio as follows:

- ·

- For UEs with only data connections: search zones.

If connectedModeMobilityPrio < lowPrioMeasThresh then the frequency is

- searched in the outer search zone only; otherwise the frequency is searched in both

- For UEs with VoLTE connections:

If voicePrio < lowPrioMeasThresh then the frequency is searched in the outer search zone only; otherwise the frequency is searched in both search zones.

To set the connectedModeMobilityPrio and voicePrio values differently for 5G users and non-5G users, the feature Subscriber Triggered Mobility is used:

<!-- page: 203 -->

- Non-5G subscribers, use the values that are set in the normal way in the MO EUtranFreqRelation

- 5G subscribers use the values that are set per frequency using the feature Subscriber Triggered Mobility , in the MO RATFreqPrio .

Example settings for this solution are provided in Table 9-4 and Figure 9-15; building on the example given for the idle mode solution in 9.2.1.1.

Table 9-4 - Settings for SPID-Based Solution for 5G\_Cov\_Stay (Discourage Handover)

| MO                 | Attribute                  |   Value | Comment                                                                                                               |
|--------------------|----------------------------|---------|-----------------------------------------------------------------------------------------------------------------------|
| ReportConfigSearch | a1a2SearchThresholdRsrp    |    -115 | Assuming previous value was -118 dBm, raise the value by 3dB to allow the inner search zone to begin 3 dB earlier.    |
| ReportConfigSearch | a2OuterSearchThrRsrpOffset |      -3 | Set outer search zone boundary 3dB below inner search zone boundary (at the previous search zone level of - 118 dBm). |
| UeMeasControl      | lowPrioMeasThresh          |       5 | Frequencies with a priority less than this value are searched in the outer search zone only.                          |
| EUtranFreqRelation | connectedModeMobilityPrio  |       4 | For non-5G UEs, all LTE frequencies are searched in the outer search zone only.                                       |
| EUtranFreqRelation | voicePrio                  |       4 | For non-5G UEs, all LTE frequencies are searched in the outer search zone only.                                       |
| UtranFreqRelation  | connectedModeMobilityPrio  |       3 | For non-5G UEs, all UTRAN frequencies are searched in the outer search zone only.                                     |
| UtranFreqRelation  | voicePrio                  |       3 | For non-5G UEs, all UTRAN frequencies are searched in the outer search zone only.                                     |

Table 9-4 - Settings for SPID-Based Solution for 5G_Cov_Stay (Discourage Handover)

<!-- page: 204 -->

![Figure on page 204](5G_Mobility_and_Traffic_Management_Guideline_images/page_204_image_002.png)

Figure 9-15 - 5G_Cov_Stay Solution based on SPID - SPID Settings

The solution presented above assumes that there is more than one anchor carrier in the network. If there is only a single anchor carrier, then a different solution is needed. The solution is then to delay the handover from the anchor carrier to the non-anchor carrier(s) by setting the outer search zone lower than the pre-existing search zone. This is shown in Figure 9-16; once again, these search zones are implemented in anchor cells only.

<!-- page: 205 -->

![Figure on page 205](5G_Mobility_and_Traffic_Management_Guideline_images/page_205_image_001.png)

Figure 9-16 - SPID Based Solution for 5G_Cov_Stay (Single Anchor Case)

The same solution, excluding the UTRA layers, can be achieved by Multi-Layer Subscriber Based Mobility . In this case the connectedModeMobilityPrio attributes to be modified are the ones included in the UEProfile MOs as shown in Figure 9-17.

<!-- page: 206 -->

![Figure on page 206](5G_Mobility_and_Traffic_Management_Guideline_images/page_206_image_002.png)

Figure 9-17 - 5G_Cov_Stay Solution based on MLSBM

The solutions presented here assume that the pre-existing mobility strategy uses only a single search zone. If the pre-existing mobility strategy already uses inner and outer search zones, then the solutions presented here need to be adapted to suit.

#### 9.2.2.4 5G_Cov_Stay Solution based on QCI, using MLSTM (Solution 6b)

The solution is similar to Solution 2b, except that the QCIs which differentiate 5G UEs from non-5G UEs are not automatically assigned according to the UE capability (using NUTB). Instead, the QCIs must be either manually configured in the core (as described in Section 9.6.1) network or remapped from manually assigned SPID using ASGH (as described in Section 9.6.2). Apart from this, this solution has the same advantages and disadvantages as Solution 2b.

The configuration of this solution in the eNodeB is therefore the same as for Solution 2b (Section 9.2.2.2), except that there is no need to configure NUTB and ASGH.

### 9.2.3 Anchor Control Strategy - 5G_HO_Go

The section presents solutions for the 5G_HO_Go strategy. The purpose of this strategy is to encourage 5G UEs to move from a non-anchor carrier to an anchor carrier, or from an anchor to a better anchor, in connected mode. This strategy is not always required because UEs can be pushed to an anchor carrier with the 5G_Idle_Go strategy described in Section 9.2.1. However, for some specific traffic cases (long data sessions, benchmarking surveys, demos, etc.) this connected mode strategy can be useful to speed up the movement of UEs to the anchor carrier.

<!-- page: 207 -->

Four solutions are available, as shown in Table 9-5.

Table 9-5 - Solutions for 5G\_HO\_Go

| Solution Number   | Mechanism for Differentiating 5G Subscribers   | Features Used                                           | Comments                                                                                                                                                                                                                                                                                                                                                                                                                                         |
|-------------------|------------------------------------------------|---------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1c                | UE Capability                                  | ENDCHO                                                  | This solution uses the EN-DC Triggered Handover features to move the UE to an LTE cell that is better suited to provide it with EN- DC. It is the only solution which considers UE EN-DC band combination support. It is also the simplest solution as it does not require SPID or QCI configuration.                                                                                                                                            |
| 2c                | UE Capability                                  | NUTB + ASGH + MLSTM                                     | This solution uses the features NR UE Throughput Booster and ASGH Framework to identify EN-DC capable UEs and remap the QCIs of those UEs to new operator- defined values. The feature Multi-Layer Service-Triggered Mobility uses the re- mapped QCIs to apply offsets to the mobility event thresholds for EN-DC capable UEs. These offsets encourage UEs to move from non-anchor carriers to anchor carriers.                                 |
| 3c                | SPID                                           | STM (optionally including the MLSBM enhancement) + MCPC | This SPID-based solution uses the feature Subscriber Triggered Mobility to identify 5G subscribers via their SPID and adjust the connected mode mobility priorities for these UEs. The feature Mobility Control at Poor Coverage is then used to create two search zones. The inner search zone is used to push 5G UEs from non-anchor to anchor carriers. The outer search zone is used for normal coverage-triggered handovers for non-5G UEs. |
| 4c                | QCI                                            | MLSTM                                                   | This solution is similar to Solution 2c, except that the QCI values used to differentiate 5G subscribers are set manually in the core network, rather than being set automatically by NUTB and ASGH.                                                                                                                                                                                                                                             |

Table 9-5 - Solutions for 5G_HO_Go

#### 9.2.3.1 5G_HO_Go Solution based on UE Capability, using ENDCHO (Solution 1c)

This section presents a solution for the 5G_HO_Go strategy, based on the EN-DC triggered handover (ENDCHO) features. ENDCHO is used to move a connected-mode UE to a cell which is better suited to provide it with EN-DC; that is an anchor or a better anchor.

The functioning and configuration of ENDCHO are described in detail in Section 10.2.13. In addition to the information in that section, note the following points for configuring the 5G-HO-Go strategy:

- Ensure a GUtranFreqRelation exists for each NR frequency to be measured by ENDCHO and set endcB1MeasPriority to indicate the priorities for measurement.

<!-- page: 208 -->

̶

- For example, to ensure that the UE searches for frequency NR1 before frequency NR2, set endcB1MeasPriority to 7 for NR1 and 5 for NR2 (not 6, because 6 and 7 are in the same priority group and are therefore measured together). This ensures that NR1 is sent in the first RRC reconfiguration message, and NR2 in the second.

- Set maxMeasB1Endc to control the number of NR frequencies to be included in each RRC reconfiguration message. The default value is 3.

- Depending on the pre-existing mobility strategy and the use of ANR, some or all of the required LTE relations may already be defined. However, confirm that EUtranFreqRelation and EUtranCellRelation MOs are defined for any potential targets.

- Set EUtranFreqRelation.endcHoFreqPriority to indicate the measurement priority for the LTE frequencies. This determines which LTE frequencies are included in the RRC reconfiguration messages if not all can be included. Setting to -1 prevents ENDCHO to the frequency.

- To control which LTE frequencies can be used as an anchor for a particular NR frequency, use GUtranFreqRelation.endcNotAllowedEUtranFreqRef . This attribute creates a list of LTE frequencies that are not allowed for EN-DC for that NR frequency. It can therefore be used to prevent EN-DC on the serving cell, or to prevent ENDCHO to other LTE frequencies. Refer to Section 6.2.3.10 for more detail.

- Set UeMeasControl.endcMeasTime and ReportConfigB1GUtra.timeToTriggerB1 (or timeToTriggerB1Override obtain the desired measurement time for each LTE priority group.

) to

- Set UeMeasControl.endcMeasRestartTime to control if periodical B1 measurement periods should be used.

- To set up the A5 measurement, ENDCHO uses the parameters described in Section 11.2.6.

#### 9.2.3.2 5G_HO_Go Solution based on UE Capability, using NUTB, ASGH and MLSTM (Solution 2c)

This section presents a solution for the 5G_HO_Go strategy, based on the features NR UE Throughput Booster (NUTB), ASGH Framework and Multi-Layer Service-Triggered Mobility (MLSTM).

Coverage-triggered inter-frequency handover is normally used to handle poor serving cell coverage. However, in this solution it is used to proactively push 5G UEs from a nonanchor frequency to an anchor frequency, even when serving cell coverage is good. This is achieved using the feature MLSTM to offset the A2 and A5 thresholds for the QCIs corresponding to 5G users. The offsets cause the inter-frequency measurements and handovers to be triggered earlier.

This solution requires that 5G UEs are assigned with dedicated QCI values. This is achieved using the features NUTB and ASGH Framework , which together automatically detect EN-DC capable UEs and map their QCIs into new values which can then be used by MLSTM.

<!-- page: 209 -->

For example, assume 5G UEs are mapped by NUTB and ASGH into QCI 30, and handover from non-anchor to anchor carriers is advanced by 100 dB (the maximum possible). This is achieved using the configuration shown in Figure 9-18 . The a1a2ThrRsrpQciOffset ensures that measurements are started even when in good serving cell coverage, and the a5Thr1RsrpFreqQciOffset ensures that the handover is triggered even when in good serving cell coverage.

![Figure on page 209](5G_Mobility_and_Traffic_Management_Guideline_images/page_209_image_002.png)

Figure 9-18 - 5G_HO_Go Solution based on UE Capability, using NUTB, ASGH and MLSTM

Note that the A5 Threshold 2, which specifies the required target cell signal strength, is not modified by this solution. Assuming that this threshold is already set to an appropriate value, it ensures that handover occurs only when the target cell signal strength is acceptable. This solution can therefore be used even when the anchor carrier has coverage holes.

#### 9.2.3.3 5G_HO_Go Solution based on SPID, using STM and MCPC (Solution 3c)

This section presents a solution for the 5G_HO_Go strategy, based on the features Subscriber Triggered Mobility (STM) and Mobility Control at Poor Coverage (MCPC). It uses SPID to differentiate 5G from non-5G subscribers.

<!-- page: 210 -->

This solution is similar to Solution 3b and 4b the SPID-based solution for 5G_Cov_Stay (presented in Section 9.2.2.3). Both solutions use MCPC to create inner and outer search zones, which are used differently by 5G and non-5G subscribers. Furthermore, both solutions use STM (or MLSBM), to differentiate 5G and non-5G subscribers based on SPID. The difference between the two solutions is how the search zones are used.

The search zones in this solution are implemented in the non-anchor cells, as shown in Figure 9-19. Referring to the diagram on the right, the good coverage zone (green) is configured to be extremely small, so that all UEs are either in the inner search zone (yellow) or outer search zone (red). In the inner search zone, 5G UEs search for coverage from anchor frequencies but non-5G UEs do not search. In the outer search zone, all UEs search for coverage from all potential target carriers (LTE and other RATs).

![Figure on page 210](5G_Mobility_and_Traffic_Management_Guideline_images/page_210_image_002.png)

Figure 9-19 - 5G_HO_Go Solution based on SPID, using STM and MCPC

The boundary between the good coverage zone and the inner search zone is determined by the attribute a1a2SearchThresholdRsrp , which is set to its maximum value of -44 dBm in this solution (to make the good coverage zone extremely small). The boundary between the inner search zone and the outer search zone is aligned with the pre-existing search zone boundary, for example -118 dBm. This is achieved by the following settings:

Inner-Outer Search Zone Boundary

= a1a2SearchThresholdRsrp + a2OuterSearchThrRsrpOffset

= -44 dBm + (-74) dBm = -118 dBm To ensure that handovers can be triggered in both inner and outer search zones, ReportConfigA5.a5Threshold1Rsrp is set equal to ReportConfigSearch.a1a2SearchThresholdRsrp , namely -44 dBm. This high setting ensures that the source cell threshold for A5 triggering is always satisfied, so that the UE sends the A5 report as soon as the target cell threshold ( a5Threshold2Rsrp ) is met. The target cell threshold is left at the pre-existing value.

<!-- page: 211 -->

Apart from these parameters, the configuration of 5G_HO_Go is identical to that of 5G_Cov_Stay; refer to Table 9-4 and Figure 9-15 for details.

#### 9.2.3.4 5G_HO_Go Solution based on QCI, using MLSTM (Solution 4c)

The solution is similar to Solution 2c, except that the QCIs which differentiate 5G from non5G UEs are not automatically assigned according to the UE capability (using NUTB). Instead, the QCIs must be either manually configured in the core (as described in Section 9.6.1) network or remapped from manually assigned SPID using ASGH (as described in Section 9.6.2). Apart from this, this solution has the same advantages and disadvantages as Solution 2c.

Figure 9-20 gives an example solution, which assumes that 5G UEs are configured with QCI 25 and handover from non-anchor to anchor carriers is to be advanced by 100 dB (the maximum possible). It is similar to that shown in Figure 9-18, except that the NUTB settings for QCI modification are not required.

![Figure on page 211](5G_Mobility_and_Traffic_Management_Guideline_images/page_211_image_002.png)

Figure 9-20 - 5G_HO_Go Solution based on QCI, using MLSTM

<!-- page: 212 -->

### 9.2.4 Anchor Control Strategy - 5G_LB_Stay

This section presents solutions for the 5G_LB_Stay strategy. The purpose of this strategy is to prevent 5G UEs from performing load-triggered handover from an anchor carrier to a non-anchor carrier. This has two benefits:

- It helps to ensure 5G UEs remain on a carrier which offers EN-DC capability.

- It limits the number of inter-frequency handovers performed by 5G UEs. This is beneficial because, in the current release, LTE handovers can result in the temporary release of NR resources, even handovers where both the source and the target are anchor carriers (refer to Section 6.6).

Four solutions are available, using different differentiation mechanisms and features, as shown in Table 9-6.

Table 9-6 - Solutions for 5G\_LB\_Stay

| Solution Number   | Mechanism for Differentiating 5G UEs   | Features Used                                    | Comments                                                                                                                                                                                                                                                                                                                                                                                        |
|-------------------|----------------------------------------|--------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1d                | UE Capability                          | BIC                                              | This solution uses the attribute lbActionForEndcUe in the feature Basic Intelligent Connectivity to prevent all load- triggered handovers for EN-DC capable UEs.                                                                                                                                                                                                                                |
| 2d                | UE Capability                          | NUTB + ASGH + SSLM                               | This solution uses the features NR UE Throughput Booster and ASGH Framework to modify the QCI of EN-DC capable UEs. The modified QCI is then used by the feature Service Specific Load Management to prevent or discourage load-triggered handovers at the frequency relation level, for example allowing handovers to anchor carriers and preventing or discouraging handovers to non-anchors. |
| 3d                | SPID                                   | STM (optionally including the MLSBM enhancement) | This SPID-based solution uses the feature Subscriber Triggered Mobility to prevent load-triggered handovers from anchor to non-anchor carriers, or even between anchor carriers.                                                                                                                                                                                                                |
| 4d                | QCI                                    | SSLM                                             | This solution is similar to Solution 2d, but the QCI is assigned manually, rather than automatically.                                                                                                                                                                                                                                                                                           |

Table 9-6 - Solutions for 5G_LB_Stay

#### 9.2.4.1 5G_LB_Stay Solution based on UE Capability, using BIC (Solution 1d)

This section presents a solution for the 5G_LB_Stay strategy, based on the attribute lbActionForEndcUe in the EUtranCellFDD and EUtranCellTDD MOs. This attribute is provided by the feature Basic Intelligent Connectivity (BIC).

<!-- page: 213 -->

By setting lbActionForEndcUe = NOT_ALLOWED , inter-frequency load balancing and IRAT offload, are prevented for EN-DC capable UEs, regardless of whether they have an SN terminated DRB configured or not.

This solution is best when the number of 5G UEs is low compared with the number of non5G UEs, so that 5G UEs can be safely ignored for the purposes of load management, without risking congestion.

#### 9.2.4.2 5G_LB_Stay Solution based on UE Capability, using NUTB, ASGH and SSLM (Solution 2d)

This section presents a solution for the 5G_LB_Stay strategy, using the features NR UE Throughput Booster (NUTB), ASGH Framework and Service Specific Load Management (SSLM).

NUTB and ASCH are used to replace the QCI for the EN-DC capable UEs with an operator defined QCI.

The modified QCI is then used by SSLM to differentiate EN-DC from non-EN-DC UEs and modify the behavior of the features Inter-Frequency Load Balancing , Inter-RAT Offload to WCDMA and Inter-Frequency Offload .

Specifically, with SSLM it is possible to:

- Disable load-triggered mobility to a given frequency completely, using the attribute lbQciProfileHandling

- Discourage load-triggered mobility to a given frequency, by raising the target cell handover threshold (using the attributes lbA5Threshold2RsrpOffset and/or lbA5Threshold2RsrqOffset ), which makes it more difficult for the target cell to qualify.

As this control is applied at the frequency level, it is possible to allow IFLB towards anchor carriers, but disallow or discourage it towards non-anchors. It is also possible to adjust the target threshold differently per target frequency (anchor or non-anchor) based on the level considered necessary for good performance.

Furthermore, because the differentiation is based on the modified QCI, this solution can consider not just the EN-DC capability but the active services as well.

This solution is therefore the most flexible solution for 5G_LB_Stay, with the other solutions having the following limitations:

- Solution 1d - disables load triggered mobility completely, regardless of whether the target frequency is an anchor or not

- Solution 3d - does not consider the active service, is not able to discourage handover (only prevent it completely) and requires manual configuration of SPID in the core network

- Solution 4d - requires manual configuration of QCI in the core network

<!-- page: 214 -->

The MOs and attributes used for implementing this solution are presented in Figure 9-21, assuming the QCI to be modified is QCI 30.

![Figure on page 214](5G_Mobility_and_Traffic_Management_Guideline_images/page_214_image_002.png)

Figure 9-21 - 5G_LB_Stay Solution Based on UE Capability, using NUTB, ASGH and SSLM

#### 9.2.4.3 5G_LB_Stay Solution based on SPID, using STM or MLSBM  (Solution 3d)

This section presents a solution for the 5G_LB_Stay strategy, using the feature Subscriber Triggered Mobility (STM).

STM allows load-triggered handover for 5G UEs to be disabled independently for each target frequency, using SPID to differentiate between 5G and non-5G UEs. The SPID must be manually defined in the core network.

This solution is more flexible than Solution 1d (using BIC), which does not allow loadtriggered handover to be disabled independently per target frequency. However, it is not as flexible as Solution 2d (using NUTB), which allows load-triggered handover to be delayed (not just prevented) and uses an automatic mechanism to identify 5G UEs.

Figure 9-22 shows an example where load-triggered mobility for 5G UEs is disabled towards non-anchor frequencies only, using STM and setting loadBalancingAllowed = false on the relevant freqPrioListEUTRA

<!-- page: 215 -->

![Figure on page 215](5G_Mobility_and_Traffic_Management_Guideline_images/page_215_image_002.png)

Figure 9-22 - 5G_LB_Stay Solution Based on SPID, using STM

**The same result can be achieved using MLSBM, by setting**

EUtraFreqRelProfile . loadBalancingAllowed as described in Figure 9-23. This allows the load balancing policy to be set separately for each cell. In this case the SPIDbased solution has been applied only to Cell A.

![Figure on page 215](5G_Mobility_and_Traffic_Management_Guideline_images/page_215_image_003.png)

Figure 9-23 5G_LB_Stay Solution using MLSBM

Note that the allowed values for loadBalancingAllowed in EUtraFreqRelProfile differ from those in freqPrioListEUTRA ; refer to CPI for details.

<!-- page: 216 -->

#### 9.2.4.4 5G_LB_Stay Solution based on QCI, using SSLM (Solution 4d)

The solution is similar to Solution 2d, except that the QCIs which differentiate 5G from non5G UEs are not automatically assigned according to the UE capability (using NUTB). Instead, the QCIs must be either manually configured in the core (as described in Section 9.6.1) network or remapped from manually assigned SPID using ASGH (as described in Section 9.6.2). Apart from this, this solution has the same advantages and disadvantages as Solution 2d.

The MOs and attributes used for implementing this solution are presented in the example of Figure 9-24. The difference from Solution 2d is that the parameters for configuring NUTB and ASGH are not required in this solution.

![Figure on page 216](5G_Mobility_and_Traffic_Management_Guideline_images/page_216_image_002.png)

Figure 9-24 - 5G_LB_Stay Solution Based on QCI, using SSLM

### 9.2.5 Overall Anchor Carrier Management Example

The previous sections presented solutions for each individual anchor control strategy, using a variety of differentiation mechanisms and features.

This section presents an overall solution which is based on the UE capability aware features only, namely Basic Intelligent Connectivity (BIC), the EN-DC triggered handover features (ENDCHO) and Capability-Aware Idle Mode Control (CAIMC). Solutions which use the UE capability aware features are recommended because the alternative solutions involving SPID or QCI are more complex to configure. In addition, capability aware solutions adjust to individual UE capabilities or changes in the deployed NSA network, rather than being statically configured for a particular UE subscription.

The overall solution is as follows:

- 5G_Idle_Go The feature CAIMC is used to push 5G UEs from a non-anchor to an anchor in idle mode and to prioritize the list of potential anchor layers

- 5G_Idle_Stay The feature CAIMC is used to discourage 5G UEs moving from an anchor to a non-anchor in idle mode

- 5G_Ho_Go The ENDCHO features are used to move 5G UEs in connected mode from a non-anchor to an anchor, or from an anchor to better anchor

<!-- page: 217 -->

- 5G_LB_Stay The feature BIC is used to prevent 5G UEs from performing IFLB-triggered handover from an anchor to a non-anchor.

The interaction between the features BIC, ENDCHO and CAIMC is shown at a high level in Figure 9-25.

![Figure on page 217](5G_Mobility_and_Traffic_Management_Guideline_images/page_217_image_002.png)

Figure 9-25 - Interaction between UE Capability-Aware Features

**Notes for Figure 9-25:**

- When a connection is first set up, BIC and ENDCHO work in parallel to determine whether to perform SN addition on the serving cell, perform handover to another LTE cell which can provide EN-DC, or use LTE only.

- If ENDCHO is performed (5G-HO-Go), the source eNodeB forwards all the reported cells in the valid B1 measurement reports to the target eNodeB, which then initiates SN addition on the corresponding NR cell if both the target eNodeB and NR cell are configured for EN-DC.

- BIC is also responsible for inhibiting load-triggered handover for EN-DC capable UEs (5G-LB-Stay), which means the UE stays on the serving cell until coverage-triggered intra-frequency or inter-frequency handover occurs.

- When the data transfer finishes and the inactivity timers expire (see Section 6.2.6), CAIMC decides whether to override the cell reselection priorities provided in system information with new, dedicated priorities when it releases the UE to idle mode (5GIdle-Stay and 5G-Idle-Go).

<!-- page: 218 -->

̶

#### 9.2.5.1 UE Capability Aware Features - Selection of Frequencies

The features BIC, ENDCHO and CAIMC all contain functionality to select frequencies, considering the UE capability. However, they use somewhat different criteria. This section summarizes the main differences.

- BIC: configures B1 measurements for SN addition on the serving cell.

̶

- The key criteria for selecting NR frequencies are:

- The NR frequency belongs to a band combination that is supported by the UE for EN-DC

- GUtranFreqRelation . endcB1MeasPriority not equal to -1

- The combination of the NR and LTE frequencies is not disallowed by GUtranFreqRelation.endcNotAllowedEUtranFreqRef

- The priority for measuring an NR frequency is determined by GUtranFreqRelation.endcB1MeasPriority .

- ENDCHO: configures both B1 and A5 to facilitate LTE handover to a cell the UE can use for EN-DC.

̶

- The key criteria for selecting NR and LTE frequency combinations are:

- The NR frequency cannot be used for EN-DC on the serving LTE cell (because the UE does not support the required band combination)

- The LTE and NR band combination is supported by the UE for EN-DC

- The combination of the NR and LTE frequencies is not disallowed by GUtranFreqRelation.endcNotAllowedEUtranFreqRef

- GUtranFreqRelation . endcB1MeasPriority not equal to -1

- EUtranFreqRelation . endcHoFreqPriority not equal to -1

- The priority for including NR frequencies in the RRC message(s) is determined by endcB1MeasPriority . The priority for including LTE frequencies, if not all relevant frequencies can be included, is determined by endcHoFreqPriority .

̶

- CAIMC: provides the UE with the IMMCI at connection release, to indicate the frequencies and priorities for idle mode reselection.

̶

- The key criteria for selecting frequencies are:

- The UE supports at least one valid EN-DC band combination with the LTE frequency. For the band combination to be valid, the LTE serving cell must have a GUtranFreqRelation to an NR frequency in the NR band.

<!-- page: 219 -->

̶

- The serving cell has an EUtranFreqRelation defined to the frequency, with cellReselectionPriority  -1

- The LTE frequency has at least one EN-DC capable cell

- CAIMC prioritizes in the following order:  EN-DC capable LTE frequencies first, then non EN-DC capable LTE frequencies, then other RATs (WCDMA and GSM).

- If UePolicyOptimization.zzzTemporary1 = 2 or 3 then NR SA frequencies are included in the IMMCI for SA capable UEs

## 9.3 Managing the Impact of LTE Mobility Features on EN-DC

Some LTE features are typically used to steer traffic to particular frequencies to optimize the performance of pure LTE connections. However, this can sometimes result in negative impacts on the performance of EN-DC connections, for two reasons:

- The target LTE cell/frequency does not support EN-DC.

- The target LTE cell/frequency supports less attractive EN-DC band combinations.

It may therefore be necessary to limit the action of these features on EN-DC traffic. The following sections explain how to do this for three features.

### 9.3.1 Uplink-Traffic-Triggered Mobility for EN-DC UEs

The purpose of the feature Uplink-Traffic-Triggered Mobility is to move UEs with heavy uplink traffic to cells with higher uplink capacity. It uses A5 measurements to search for suitable cells and, if one is found, the feature triggers handover.

For EN-DC capable UEs, the feature is controlled with the attribute EUtranCellFDD/EUtranCellTDD.uttmCtrlForEndcUe , as follows:

- ENABLED_FOR_ALL_ENDC_UE : The feature is enabled for EN-DC-capable UEs.

- DISABLED_FOR_ENDC_ALLOWED_UE : The feature is disabled for EN-DC-capable UEs that are allowed to enter the EN-DC setup or the EN-DC-triggered handover process.

- DISABLED_FOR_ENDC_CONFIG_UE : The feature is disabled for EN-DC-configured UEs.

### 9.3.2 Inter-frequency Load Balancing for EN-DC UEs

The purpose of the feature Inter-frequency Load Balancing (IFLB) is to balance traffic load between LTE carriers with overlapping coverage, leading to a better and more consistent user experience overall. It uses inter-frequency handovers to move UEs from more heavily loaded carriers to more lightly loaded carriers.

<!-- page: 220 -->

For EN-DC capable UEs, the feature is controlled with the attribute

EUtranCellFDD/EUtranCellTDD.lbActionForEndcUe , as follows:

- NOT_ALLOWED : Load management actions are not allowed on EN-DC-capable UEs.

- ENDC_CAPABLE_NOT_CONFIGURED : Load management actions are allowed only on EN-DC-capable UEs without SN terminated bearers.

- ENDC_CAPABLE_ALL : Load management actions are allowed on all EN-DC-capable UEs.

Section 9.2.4 describes several solutions for controlling the impact of load management on EN-DC capable UEs, including use of the above attribute.

### 9.3.3 LTE Inter-Frequency Handover to Higher Priority for EN-DC UEs

The purpose of the feature LTE Inter-Frequency Handover to Higher Priority is to move UEs in good coverage to frequencies that are configured with a higher priority. The feature uses A5 measurements to search for suitable cells and, if one is found, the feature triggers handover.

The functionality can be enabled or disabled for EN-DC-connected UEs as follows:

- If EUtranCellFDD/TDD.interFreqHoHigherPrioEndc = false , then handover to higher priority is disabled for EN-DC connected UEs using this cell as the PCell

- If interFreqHoHigherPrioEndc = true , then the handover to higher priority for EN-DC connected UEs is controlled at the frequency relation level using interFreqHoHigherPrioControl as follows:

̶

- interFreqHoHigherPrioControl = PRIO_ENDC Handover occurs only if the target cell is EN-DC capable and supports EN-DC in combination with the serving NR frequency, and if endcHoFreqPriority ≠ -1

̶

- interFreqHoHigherPrioControl = PRIO_LTE Handover occurs. If the target cell does not support EN-DC, then the SN is released, and the connection reverts to LTE only.

The attributes interFreqHoHigherPrioControl and endcHoFreqPriority are available in the following MO classes:

- EUtranFreqRelation - to control the functionality at the frequency relation level, for all UEs.

- FreqPrioEUtra and EUtraFreqRelProfile - to override the frequency relation level functionality per subscriber group (SPID) using the feature Subscriber Triggered Mobility feature, as described in chapter 10.2.4.

Additionally, the release of the SCG radio resources can be enabled as a trigger for the handover procedure by setting interFreqHoHigherPrioSnRel = true .

<!-- page: 221 -->

For more information, refer to the feature description in CPI.

## 9.4 Steering non-5G UEs away from an Anchor Carrier

Steering non-5G UEs away from an LTE anchor carrier, is not normally necessary because an anchor carrier may be used by both 5G capable and non-5G capable UEs. So, in most cases, the pre-existing mobility strategy can be retained, and it continues to govern the behavior of non-5G UEs and of 5G UEs not covered by one of the 5G strategy components in Section 9.2.

However, there are valid reasons for steering non-5G UEs when EN-DC is deployed, for example to prevent a low bandwidth anchor carrier from becoming overloaded. In this case the baseline mobility configuration (the strategy used for LTE, without considering 5G specific requirements) is used to steer the non-5G UEs as required. To prevent 5G UEs being impacted, the baseline strategy can be overridden with the desired 5G strategy components in Section 9.2, namely: 5G_Idle_Stay, 5G_Cov_Stay and 5G_LB_Stay.

## 9.5 Configuring SPID for 5G Users

Some of the solutions for anchor carrier control involve using the Subscriber Profile ID for RAT/Frequency Priority (SPID) to differentiate between 5G and non-5G users. The SPID is a number from 1 to 256 which is set per subscriber in the HSS. It is sent from the HSS to the MME and from there to the eNodeB where it can be used to impact mobility behavior. One or more SPID values can be used to differentiate 5G subscribers from non-5G subscribers.

To use SPID, it must be configured in the HSS, the MME and the eNodeB. This section explains how to do so.

### 9.5.1 Configuring SPID in the HSS

The HSS ESM Profile object contains information about the ESM User data.

The SPID associated with a subscriber profile is specified via the attribute hss-EsmRatFreqSelPriorId within the c class.

To use SPID to differentiate 5G subscribers from non-5G subscribers, they must be assigned different SPID values. If SPID is already in use for other purposes, then to retain full differentiation a new 5G SPID value must be created for every existing SPID value. An example is given in Figure 9-26.

<!-- page: 222 -->

Figure 9-26 - Duplicating SPID Values for 5G Introduction

Figure 9-26 - Duplicating SPID Values for 5G Introduction

For further information on this feature refer to the HSS Feature Description EPS Subscriber Data Handling in ESM .

### 9.5.2 Configuring SPID in the MME

The MME receives SPID information from the HSS and forwards it to the eNodeB during connection setup and S1 handover. The MME can overwrite the SPID values assigned by the HSS, for specific IMSI number series. This is the recommended way to set the SPID for incoming roamers, overwriting the values from their own HSS.

### 9.5.3 Configuring SPID in the eNodeB

The eNodeB receives the SPID for a UE from the MME during connection setup, or from another eNodeB during handover. The SPID is then available to a number of features to impact mobility, resource allocation and flexible counter functions.

The feature Subscriber Triggered Mobility (STM), described in Section 10.2.4, enables individual control of mobility characteristics for a User Equipment (UE) based on SPID.

The feature Flexible Counters , described in Section 10.2.9, allows the filtering of certain counters per SPID, to monitor their performance separately.

## 9.6 Configuring QCI for 5G Users

Some of the solutions for anchor carrier control involve using the Quality of Service Class Identifier (QCI) to differentiate between 5G and non-5G users. There are three options for assigning QCI values for 5G users:

- Assign 5G users specific QCI values in the HSS

- Assign 5G users specific SPID values in the HSS and use the feature ASGH Framework to remap the QCIs of those SPIDs to new QCIs values.

- Use combination of the ASGH Framework feature and the NR UE Throughput Booster feature to identify 5G users and remap their QCIs to new values.

<!-- page: 223 -->

If remapping QCIs, the eNodeB feature Operator Defined QCI is also required.

### 9.6.1 Assign QCI in the HSS

In this option, the QCI associated with 5G subscribers is specified in the HSS using an additional ContextId of the current APN configuration.

### 9.6.2 Remap QCI Using ASGH Framework (without NR UE Throughput Booster)

In this option, rather than assigning 5G subscribers specific QCI values in the HSS, they are instead assigned specific SPID values in the HSS. The Advanced Subscriber Group Handling (ASGH) Framework in the eNodeB then uses the SPID values to offset the QCI values for 5G users. Finally, these remapped QCI values can be used to modify mobility behavior for 5G subscribers. This makes both SPID and QCI available for differentiating 5G users and improves the flexibility for adapting mobility behavior.

The first step is to create a new operator-defined QCI profile, corresponding to the remapped QCI value.

The second step is to configure ASGH to assign 5G UEs (identified by their SPID values) to one or more subscriber groups. This is fully described in Section 10.2.5.

The third step is to re-map the QCI(s) into operator defined QCI value(s). This is controlled by four SubscriberGroupProfile attributes:

- qciOffsetForQCI6 = 0 [0, 4..250]

- qciOffsetForQCI7 = 0 [0, 3..249]

- qciOffsetForQCI8 = 0 [0, 2..248]

- qciOffsetForQCI9 = 0 [0, 1..247]

These three steps are illustrated in Figure 9-27 and Figure 9-28.

First, create an operator-defined QCI corresponding to the planned new QCI. In this example, QCI 9 is remapped to QCI 20, so 20 is the new QCI. Copy the attribute values from the old QCI to the new one, updating any values that need to be changed.

<!-- page: 224 -->

![Figure on page 224](5G_Mobility_and_Traffic_Management_Guideline_images/page_224_image_001.png)

Figure 9-27 - Defining an Additional QCI Profile

Second, create a subscriber group profile which captures the 5G SPID values. In this example, 5G subscribers are assigned SPID values 5 and 20 in the HSS. Third, remap QCI 9 to QCI 20 by applying an offset of 11.

![Figure on page 224](5G_Mobility_and_Traffic_Management_Guideline_images/page_224_image_002.png)

Figure 9-28 - Remapping QCI using SPID

### 9.6.3 Remap QCI Using ASGH Framework and NR UE Throughput Booster

The feature NR UE Throughput Booster (NUTB) extends the ASGH Framework feature by implementing an additional custom trigger type which can identify NR UEs. Using this trigger type, ASGH subscriber group(s) can be created that automatically include UEs according to their 5G capability or EN-DC connection state. The feature supports both ENDC-capable UEs and NR SA-capable UEs.

- The first step is to create an operator-defined QCI corresponding to the planned new QCI as already described in Section 9.6.2.

- The second step is to assign 5G UEs to one or more subscriber groups, using both the ASGH Framework feature and the NR UE Throughput Booster feature, as described fully in Section 10.2.5.2.

- The third step is to remap the QCI for those groups, using ASGH Framework and NR UE Throughput Booster .

The second and third steps are both shown in each of the examples in Figure 9-29 and Figure 9-30.

<!-- page: 225 -->

In Figure 9-29, EN-DC capable UEs without an NR restriction for EPC are re-mapped from QCI 9 to QCI 30.

![Figure on page 225](5G_Mobility_and_Traffic_Management_Guideline_images/page_225_image_002.png)

Figure 9-29  Remapping QCI using NR UE Throughput Booster

In Figure 9-30, EN-DC capable UEs without an NR restriction for EPC are mapped differently, depending on their SPID: those with SPID = 25 are re-mapped from QCI 9 to QCI 30 and with SPID = 28 are remapped from QCI 9 to QCI 31.

![Figure on page 225](5G_Mobility_and_Traffic_Management_Guideline_images/page_225_image_003.png)

Figure 9-30 Combining SPID and NUTB to create two EN-DC subgroups

<!-- page: 226 -->

# 10 Appendix 1 - Feature Summaries

This section provides summaries for the key features referred to in this guideline. For more information on each feature, refer to the full feature descriptions in CPI.

## 10.1 Software Value Packages and Features

A Software Value Package consists of a number of FAJ features that are bundled and offered together. An overview of the features referred to in this guideline, is provided for eNodeB features in Table 10-1 and gNodeB features in Table 10-2. Note, however, that CPI documentation sometimes includes eNodeB functionality in gNodeB feature descriptions (and vice versa) to provide a more complete understanding.

Table 10-1 - RAN Features and Software Value Packages for eNodeB

| Node Type   | Value Package                           | Feature name                                                   | Licensed   |
|-------------|-----------------------------------------|----------------------------------------------------------------|------------|
| eNodeB      | LTE Base Package (FAJ 801 0400)         | Mobility Control at Poor Coverage (FAJ 121 3013)               | Yes        |
| eNodeB      | LTE Base Package (FAJ 801 0400)         | Subscriber Triggered Mobility (FAJ 121 1788)                   | Yes        |
| eNodeB      | LTE Base Package (FAJ 801 0400)         | ASGH Framework (FAJ 121 4795)                                  | No         |
| eNodeB      | LTE Base Package (FAJ 801 0400)         | Flexible Counters (FAJ 121 4669)                               | No         |
| eNodeB      | LTE Base Package (FAJ 801 0400)         | Multiple Frequency Band Indicators (FAJ 121 3054)              | Yes        |
| eNodeB      | Service-Based Mobility (FAJ 801 0433)   | Multi-Layer Service-Triggered Mobility (FAJ 121 4124)          | Yes        |
| eNodeB      | Service-Based Mobility (FAJ 801 0433)   | Service Specific Load Management (FAJ 121 3047)                | Yes        |
| eNodeB      | Service-Based Mobility (FAJ 801 0433)   | LTE Service-Triggered Outgoing NR IRAT Mobility (FAJ 121 5744) | Yes        |
| eNodeB      | VoLTE (FAJ 801 0443)                    | LTE Emergency Call Handling with NR Standalone (FAJ 121 5375)  | Yes        |
| eNodeB      | Self-Organizing Networks (FAJ 801 0435) | Automated Neighbor Relations (FAJ 121 0497)                    | Yes        |
| eNodeB      | Self-Organizing Networks (FAJ 801 0435) | PCI Conflict Reporting (FAJ 121 1898)                          | Yes        |
| eNodeB      | Intelligent Connectivity (FAJ 801 1013) | Basic Intelligent Connectivity (FAJ 121 4843)                  | Yes        |
| eNodeB      | Intelligent Connectivity (FAJ 801 1013) | Capability-Aware Idle Mode Control (FAJ 121 5073)              | Yes        |
| eNodeB      | Intelligent Connectivity (FAJ 801 1013) | EN-DC Triggered Handover During Setup (FAJ 121 5097)           | Yes        |

Table 10-1 - RAN Features and Software Value Packages for eNodeB

<!-- page: 227 -->

| Node Type   | Value Package                                  | Feature name                                                           | Licensed   |
|-------------|------------------------------------------------|------------------------------------------------------------------------|------------|
| eNodeB      | Intelligent Connectivity (FAJ 801 1013)        | EN-DC Triggered Handover During Connected Mode Mobility (FAJ 121 5243) | Yes        |
| eNodeB      | Intelligent Connectivity (FAJ 801 1013)        | Enhanced NR Restriction (FAJ 121 5212)                                 | Yes        |
| eNodeB      | Intelligent Connectivity (FAJ 801 1013)        | Optimized UE Distribution for EN-DC (FAJ 121 5657)                     | Yes        |
| eNodeB      | Basic NR Mobility Support (FAJ 801 1018)       | Incoming NR IRAT Handover (FAJ 121 5118)                               | Yes        |
| eNodeB      | Basic NR Mobility Support (FAJ 801 1018)       | NR Coverage-Triggered NR Session Continuity (FAJ 121 4983)             | Yes        |
| eNodeB      | Basic NR Mobility Support (FAJ 801 1018)       | Outgoing NR IRAT Handover (FAJ 121 5377)                               | Yes        |
| eNodeB      | Inter-Vendor Load Management (FAJ 801 0416)    | Inter-Vendor Capability-Aware Idle Mode Control (FAJ 121 5160)         | Yes        |
| eNodeB      | Multi-carrier Load Management (FAJ 801 0427)   | Inter-Frequency Load Balancing (FAJ 121 3009)                          | Yes        |
| eNodeB      | Multi-carrier Load Management (FAJ 801 0427)   | TM9 Capability-Aware Idle Mode Control (FAJ 121 5153)                  | Yes        |
| eNodeB      | Differentiated Mobile Broadband (FAJ 801 0409) | NR UE Throughput Booster (FAJ 121 5242)                                | Yes        |
| eNodeB      | Differentiated Mobile Broadband (FAJ 801 0409) | Operator Defined QCI (FAJ 121 1892)                                    | Yes        |

Table 10-2 - RAN Features and Software Value Packages for gNodeB

| Node Type   | Value Package                                              | Feature name                                          | Licensed   |
|-------------|------------------------------------------------------------|-------------------------------------------------------|------------|
| gNodeB      | Critical IoT for Public RAN Base Package (FAJ 801 1700)    | Low Latency Mobility for Public RAN (FAJ 121 5784)    | Yes        |
| gNodeB      | Critical IoT for Dedicated RAN Base Package (FAJ 801 1701) | Low Latency Mobility for Dedicated RAN (FAJ 121 5785) | Yes        |
| gNodeB      | NR Base Package (FAJ 801 4002)                             | LTE-NR Dual Connectivity (FAJ 121 4908)               | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)                             | Uplink-Downlink Decoupling (FAJ 121 4909)             | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)                             | NR Mobility (FAJ 121 5041)                            | No         |

Table 10-2 - RAN Features and Software Value Packages for gNodeB

<!-- page: 228 -->

| Node Type   | Value Package                      | Feature name                                              | Licensed   |
|-------------|------------------------------------|-----------------------------------------------------------|------------|
| gNodeB      | NR Base Package (FAJ 801 4002)     | EPS Fallback for IMS Voice (FAJ 121 5059)                 | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)     | NR Standalone (FAJ 121 5060)                              | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)     | NR Emergency Fallback to LTE (FAJ 121 5166)               | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)     | RAN Slicing Framework (FAJ 121 5095)                      | Yes        |
| gNodeB      | NR Base Package (FAJ 801 4002)     | CQI-Based UE Energy Efficiency Enhancement (FAJ 121 5215) | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)     | NR Automated Neighbor Relations (FAJ 121 5218)            | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)     | Measurement GAP-Aware NR Scheduling (FAJ 121 5295)        | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)     | UE Grouping Framework (FAJ 121 5314)                      | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)     | Data-Aware Carrier Management (FAJ 121 5410)              | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)     | Multiple PSCells High Band (FAJ 121 5341)                 | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)     | NR RRC Connection Re- establishment (FAJ 121 5346)        | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)     | EBS Counter Enabler (FAJ 121 5409)                        | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)     | NR Traffic Steering (FAJ 121 5458)                        | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)     | NR UE-Assisted Overheating Mitigation (FAJ 121 5449)      | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)     | NR Cell Soft Lock (FAJ 121 5575)                          | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)     | NR PCI Conflict Reporting (FAJ 121 5621)                  | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)     | Ericsson Reduced Capability Enabler (FAJ 121 5661)        | Yes        |
| gNodeB      | NR Base Package (FAJ 801 4002)     | NR Traffic Offload (FAJ 121 5680)                         | No         |
| gNodeB      | NR Base Package (FAJ 801 4002)     | NR Preemptive Mobility Management (FAJ 121 5893)          | No         |
| gNodeB      | Peak Rate Evolution (FAJ 801 4005) | LTE-NR Downlink Aggregation (FAJ 121 4912)                | Yes        |
| gNodeB      | Peak Rate Evolution (FAJ 801 4005) | LTE-NR Uplink Aggregation (FAJ 121 5091)                  | Yes        |
| gNodeB      | Peak Rate Evolution (FAJ 801 4005) | Dynamic Component Carrier Management (FAJ 121 5045)       | Yes        |

<!-- page: 229 -->

| Node Type   | Value Package                                              | Feature name                                                             | Licensed   |
|-------------|------------------------------------------------------------|--------------------------------------------------------------------------|------------|
| gNodeB      | Peak Rate Evolution (FAJ 801 4005)                         | Mixed Bandwidth Support for Carrier Aggregation High-Band (FAJ 121 5272) | No         |
| gNodeB      | Peak Rate Evolution (FAJ 801 4005)                         | TDD PCell Support for DL Carrier Aggregation Low/Mid-Band (FAJ 121 5363) | Yes        |
| gNodeB      | Peak Rate Evolution (FAJ 801 4005)                         | NR-NR Dual Connectivity (FAJ 121 5380)                                   | Yes        |
| gNodeB      | Peak Rate Evolution (FAJ 801 4005)                         | NR Switched Uplink for Throughput Boost (FAJ 121 5772)                   | Yes        |
| gNodeB      | Peak Rate Evolution (FAJ 801 4005)                         | NR Automated Neighbor Relations for NR-DC (FAJ 121 5871)                 | Yes        |
| gNodeB      | Voice over NR (FAJ 801 4017)                               | Basic Voice over NR (FAJ 121 5219)                                       | No         |
| gNodeB      | Voice over NR (FAJ 801 4017)                               | NR Emergency Procedures (FAJ 121 5298)                                   | Yes        |
| gNodeB      | Voice over NR (FAJ 801 4017)                               | NR Limited Service Mode Emergency Call Support (FAJ 121 5302)            | Yes        |
| gNodeB      | Performance Boost (FAJ 801 4021)                           | NR Service-Adaptive Inactivity Timer (FAJ 121 5326)                      | Yes        |
| gNodeB      | Performance Boost (FAJ 801 4021)                           | NR Remote Interference Management (FAJ 121 5514)                         | Yes        |
| gNodeB      | Intelligent Traffic Management and Mobility (FAJ 801 4022) | PSCell Change to Higher Priority (FAJ 121 5334)                          | Yes        |
| gNodeB      | Intelligent Traffic Management and Mobility (FAJ 801 4022) | RRC Inactive State (FAJ 121 5328)                                        | Yes        |
| gNodeB      | Intelligent Traffic Management and Mobility (FAJ 801 4022) | User- and Service-Specific Mobility (FAJ 121 5399)                       | Yes        |
| gNodeB      | Intelligent Traffic Management and Mobility (FAJ 801 4022) | NR Advanced Multi-Layer Coordination (FAJ 121 5584)                      | Yes        |
| gNodeB      | Intelligent Traffic Management and Mobility (FAJ 801 4022) | NR Data-Aware Mobility (FAJ 121 5696)                                    | Yes        |
| gNodeB      | 5G Advanced Macro Positioning (FAJ 801 4028)               | Positioning of UEs without PDU Session Overview (FAJ 121 5821)           | Yes        |
| gNodeB      | 5G Advanced Performance Boost (FAJ 801 4029)               | Uplink-Aware Advanced Multi-Layer Coordination (FAJ 121 5780)            | Yes        |

<!-- page: 230 -->

| Node Type   | Value Package                                         | Feature name                                                  | Licensed   |
|-------------|-------------------------------------------------------|---------------------------------------------------------------|------------|
| gNodeB      | 5G Advanced Device Battery Performance (FAJ 801 4031) | UE-Assisted RRC State Preference (FAJ 121 5714)               | Yes        |
| gNodeB      | 5G Advanced Device Battery Performance (FAJ 801 4031) | Relaxed Radio Resource Management Measurements (FAJ 121 5824) | Yes        |
| gNodeB      | 5G Advanced Mission Critical Services (FAJ 801 4032)  | Load-Based Prioritized UE Handling (FAJ 121 5895)             | Yes        |

## 10.2 eNodeB Features

This section summarizes features implemented in the eNodeB that are important for 5G Mobility & Traffic Management. For further information, refer to the relevant feature description in CPI.

### 10.2.1 Basic Intelligent Connectivity (FAJ 121 4843) - NSA

This is a licensed eNodeB feature in the value package Intelligent Connectivity (FAJ 801 1013).

The Basic Intelligent Connectivity feature (BIC) introduces the basic support for EN-DC in the eNodeB, enabling a non-standalone 5G deployment. The corresponding feature on the gNodeB side is LTE-NR Dual Connectivity (FAJ 121 4908).

The feature covers the fundamental interaction between LTE and NR in the EN-DC context; for example, configuring the UE with B1 measurements for measurement-based SN addition, setting up and releasing SN terminated bearers and providing the upper layer indication for NR services.

#### 10.2.1.1 Configuring the eNodeB for SN Addition

The key MOs and attributes required for SN addition are shown in Figure 10-1.

<!-- page: 231 -->

̶

![Figure on page 231](5G_Mobility_and_Traffic_Management_Guideline_images/page_231_image_002.png)

Figure 10-1 - Key MOs and Attributes for SN Addition

**Notes for Figure 10-1:**

- A GUtranFreqRelation MO must be defined for each NR frequency that is to be measured for SN addition; namely those frequencies which can be used for the PSCell.

̶

- If a GUtranFreqRelation MO is defined to an NR frequency which cannot be used for the PSCell, then endcB1MeasPriority must be set to -1 on that relation. This prevents the frequency being measured for SN addition. This applies to frequencies which are used only for NSA secondary cells (SCells) and frequencies used only for SA.

̶

- Additionally, it is possible to prevent SN addition using a particular NR frequency. To do this, include a reference to the LTE serving cell frequency in the attribute GUtranFreqRelation.endcNotAllowedEUtranFreqRef of the relevant NR frequency. That NR frequency can then only be used for EN-DC via an ENDCHO to another LTE cell.

- For SN addition to succeed, the serving LTE cell must have a GUtranCellRelation to the reported NR cell.

̶

- Although a GUtranCellRelation is not required for configuration-based SN addition, some procedures always use measurement-based SN addition, so a GUtranCellRelation should still be defined even when using configurationbased SN addition.

̶

- Set GUtranCellRelation.isEndcAllowed = true , otherwise measurementbased SN addition using the related cell is blocked.

- In High-Band (HB), the following PSCell configurations are possible:

<!-- page: 232 -->

̶

- Without the feature Multiple PSCells High-Band , a single PSCell can be configured in each sector, where a sector is defined as the cells that are linked to the same SectorEquipmentFunction instance. When configuring EN-DC in the eNodeB, define GUtranCellRelation MOs towards the carrier with the lowest ARFCN among the UL capable carriers

( NRSectorCarrier.txDirection = DL_AND_UL) .

- With the feature Multiple PSCells High-Band , two PSCells can be configured in each sector. When configuring EN-DC in the eNodeB, define GUtranCellRelation MOs towards the carriers with the lowest and highest ARFCNs among the UL capable carriers ( NRSectorCarrier.txDirection = DL_AND_UL) . To balance the number of users over the two PSCell frequencies, assign them the same value of GUtranFreqRelation.endcB1MeasPriority , so they are selected and ordered randomly when configuring B1 measurements.

- To facilitate PSCell change, it is recommended that all high-band PSCells use the same frequency. If PSCells on neighbor sites or sectors are configured with different frequencies, the network must be configured to support NSA interfrequency PSCell change using the Mobility Control at Poor Coverage functionality.

- To prevent all EN-DC on a cell (including incoming EN-DC triggered handover) but still allow outgoing EN-DC triggered handover, use the following configuration:

̶

- Configure an empty endcAllowedPlmnList on the cell

- Define GUtranFreqRelation MOs to the NR frequencies on which EN-DC triggered handover is required and set endcB1MeasPriority to a value other than -1.

̶

#### 10.2.1.2 B1 Measurements for SN Addition

This section describes the rules used for configuring B1 measurements for SN addition, including determining which NR frequency(s) are measured, in what order, for how long and with what measurement gap configuration (if needed).

If EN-DC triggered handover is active, then it configures measurements in parallel with the SN addition measurements described here; see Section 10.2.13 for more detail on how the two interwork.

**Prerequisites for Measurement-Based SN Addition**

To configure B1 measurements for SN addition, the prerequisites for SN addition, listed in Section 6.2.3.1, must be met. In addition, if Buffer-Based EN-DC Setup is active, then the conditions described in Section 10.2.1.8 must be met.

<!-- page: 233 -->

**Selection of NR Frequencies and B1 Measurement Configuration**

This section describes how NR frequencies are selected and prioritized when the feature Optimized UE Distribution for EN-DC is not active. For information on how that feature modifies NR frequency prioritization, refer to Section 10.2.22.

The priority for including frequencies in B1 is determined by GUtranFreqRelation . endcB1MeasPriority , which can be set from -1 to 7. The highest priority is 7, the lowest is 0, and -1 means the frequency is not measured.

Combinations of NR frequencies and LTE frequencies can be disallowed for EN-DC, using the attribute GUtranFreqRelation.endcNotAllowedEUtranFreqRef . If this results in no suitable frequency combinations using a particular NR frequency for a particular UE, then that frequency is not measured.

NR frequencies are also not measured if the GUtranFreqRelation.allowedPlmnList does not contain either the PLMN ID of the UE or an equivalent PLMN from the HRL for the UE, or if the frequency is disallowed (see Section 6.2.3.5). An empty allowedPlmnList implies that the frequency has no PLMN restrictions.

Frequencies with the same endcB1MeasPriority are selected randomly and are ordered randomly when constructing the RRC reconfiguration message that is sent to the UE to set up measurements.

The value of endcB1MeasPriority is used to assign each frequency to a priority group:

Table 10-3 - Priority Groups for B1 Measurements

| Priority Group   | endcB1MeasPriority   |
|------------------|----------------------|
| 1                | 7, 6                 |
| 2                | 5, 4                 |
| 3                | 3, 2, 1, 0           |
| NA               | -1                   |

Table 10-3 - Priority Groups for B1 Measurements

To configure the measurements in the UE, the eNodeB uses RRC Reconfiguration messages. It sends up to three messages, and it uses the priority group and the endcB1MeasPriority to determine which frequencies to include in each message:

- First Message:  includes up to maxMeasB1Endc frequencies from the highest priority group which is not empty.

- Second Message: includes up to maxMeasB1Endc remaining frequencies from priority groups 1 and 2, or from priority group 3 if there are no remaining frequencies left in groups 1 and 2.

- Third Message: includes up to maxMeasB1Endc remaining frequencies from priority groups 1, 2 and 3.

Table 10-4 gives examples of how frequencies are chosen for inclusion in the three RRC Reconfiguration messages. The examples assume the listed frequencies are EN-DC capable and supported by the UE, and that maxMeasB1Endc = 2 .

<!-- page: 234 -->

Table 10-4 - Selecting Frequencies for EN-DC B1 RRC Reconfiguration Messages

| Example 1   | Example 1        | Example 1   | Example 2   | Example 2        | Example 2   | Example 3   | Example 3        | Example 3   |
|-------------|------------------|-------------|-------------|------------------|-------------|-------------|------------------|-------------|
| Freq        | Priority (Group) | RRC Msg     | Freq        | Priority (Group) | RRC Msg     | Freq        | Priority (Group) | RRC Msg     |
| NR1         | 7 (1)            | 1           | NR1         | 6 (1)            | 2           |             | NR1 4 (2)        | 1           |
| NR2         | 6 (1)            | 1           | NR2         | 6 (1)            | 1           |             | NR2 0 (3)        | 2           |
| NR3         | 5 (2)            | 2           | NR3         | 7 (1)            | 1           |             | NR3 -1 (-)       | -           |
| NR4         | 4 (2)            | 2           | NR4         | 5 (2)            | 2           |             |                  |             |
| NR5         | 3 (3)            | 3           | NR5         | 3 (3)            | 3           |             |                  |             |
| NR6         | 2 (3)            | 3           | NR6         | 0 (3)            | 3           |             |                  |             |
| NR7         | 1 (3)            | -           |             |                  |             |             |                  |             |

Table 10-4 - Selecting Frequencies for EN-DC B1 RRC Reconfiguration Messages

**Notes for Table 10-4:**

- Example 1 :  The first message includes the priority group 1 frequencies, and the second message includes the priority group 2 frequencies. The third message can include only two of the three priority group 3 frequencies.

- Example 2 :  The first message includes the priority 7 frequency and one randomly chosen priority 6 frequency.  The second message includes the remaining priority 6 frequency and the group 2 frequency. Message 3 includes the two remaining group 3 frequencies.

- Example 3 :  The first message includes the only frequency in the highest priority group, which is group 2. The second message includes the group 3 frequency. The frequency with a priority of -1 is not sent.

The sequencing of the RRC Reconfiguration messages is shown in Figure 10-2 .

![Figure on page 234](5G_Mobility_and_Traffic_Management_Guideline_images/page_234_image_002.png)

Figure 10-2 - RRC Reconfiguration Messages Sequence for EN-DC B1

<!-- page: 235 -->

**B1 Measurement Report Processing**

If a measurement reconfiguration message contains two or more NR frequencies with different endcB1MeasPriority values (e.g. 7 and 6) then the eNodeB has additional control to increase the probability that the higher priority frequency is used. Specifically, if the first received B1 report is from the lower priority frequency, then the eNodeB waits for endcB1MeasWindow for a B1 report containing the higher priority frequency. If it is received before this time expires, then SN addition using the higher priority frequency occurs. Otherwise, when the timer expires, SN addition using the lower priority frequency occurs. This is illustrated in Figure 10-3, for the case of a measurement reconfiguration message which contains a priority 7 frequency and a priority 6 frequency.

![Figure on page 235](5G_Mobility_and_Traffic_Management_Guideline_images/page_235_image_001.png)

Figure 10-3 - Handling Simultaneous Measurement of Multiple endcB1MeasPriority Values

Notes for Figure 10-3:

- Case 1 :  If a B1 report for a valid priority 7 cell is received first, then the eNodeB initiates SN addition immediately.

- Case 2 :  If a B1 report for a valid priority 6 cell is received first and a B1 report for a valid priority 7 cell is received within endcB1MeasWindow , then the eNodeB initiates SN addition using the priority 7 cell.

<!-- page: 236 -->

- Case 3 : If a B1 report for a valid priority 6 cell is received first and then endcB1MeasWindow expires, the eNodeB initiates SN addition using the stored priority 6 cell.

- Case 4 : If a B1 report for a valid priority 6 cell is received first and then endcMeasTime + timeToTriggerB1 (or timeToTriggerB1Override ) expires, the eNodeB initiates SN addition using the stored priority 6 cell.

Given the above, there are two ways to prioritize one NR frequency over another:

- Different endcB1MeasPriority , same priority group (e.g. 7 and 6) endcB1MeasWindow to advantage the higher priority frequency.

It improves the setup time for the lower priority frequency, in case coverage from the higher priority frequency is not found. However, if endcB1MeasWindow is running, then any B1 and A5 reports received for ENDCHO are ignored. This is a problem only it. In this case, the ENDCHO can be blocked by a B1 report for a lower priority frequency that can be used for SN addition on the serving cell.

- This option allows the frequencies to be measured simultaneously and uses if the highest prioritized frequency is one which requires ENDCHO for the UE to access

- Different endcB1MeasPriority , different priority groups (e.g. 7 and 5) With this option the two frequencies are measured sequentially; the higher priority frequency is measured for the full endcMeasTime before starting measurements on the lower priority frequency, giving a stronger guarantee on priority. Also, unlike the previous option, a B1 measurement report from a lower priority frequency cannot block the B1 or A5 measurement reports for higher priority ENDCHO frequency.

When the eNodeB receives a B1 measurement report for a given NR frequency, it evaluates all the reported cells and selects the best cell in the report. The best cell is the one with the biggest margin above the cell's B1 threshold, noting that cells on the same NR frequency can be configured with different B1 thresholds using b1ThrRsrpCellOffset . This is illustrated in Figure 10-4.

![Figure on page 236](5G_Mobility_and_Traffic_Management_Guideline_images/page_236_image_002.png)

Figure 10-4 - Determining the Best Cell for SN Addition

<!-- page: 237 -->

These cell level offsets can be used to adjust the B1 threshold when cells on the same frequency have different uplink sensitivities due to different hardware types. However, if cells with different B1 thresholds have overlapping coverage, then it may be necessary to use cellIndividualOffsetNR to tune the mobility boundary in the overlapping area, to avoid poor performance during PSCell change.

**Measurement Repetition Patterns**

There are three possibilities for configuring repetition patterns of the above RRC sequences, namely: measure forever, measure once then stop and measure periodically, as shown in Figure 10-5. The chosen pattern is used for both EN-DC setup and ENDCHO.

- Measure forever: = -1, then only the first RRC Reconfiguration is sent, and this

- ·

If endcMeasTime measurement continues indefinitely.

- Measure once then stop: configured (as previously described). After this, no more B1 measurements are started

- ·

If endcMeasTime is set to a value other than -1 and endcMeasRestartTime = -1 (timer inactive, wait forever), then only one set of up to three RRC measurements is until a new trigger occurs; for example, LTE Handover, NR Radio Link Failure and A2 Critical Coverage SN Release.

- Measure periodically:

If both endcMeasTime and endcMeasRestartTime are set to values other than -1, then measurements are performed periodically, as governed by those timers. Setting endcMeasRestartTime = 0 enables continuous repetitions of the three batches (effectively shrinking the 'Wait' time to zero).

Note that some of the attributes in Figure 10-5 can be overridden by ASGH or by frequency relation level attributes (see Section 11.2.2).

<!-- page: 238 -->

![Figure on page 238](5G_Mobility_and_Traffic_Management_Guideline_images/page_238_image_002.png)

Figure 10-5 - Event B1 Repetition Patterns for EN-DC setup and ENDCHO

These measurements are stopped if:

- EN-DC is set up

- An event occurs which violates the prerequisites for SN addition (Section 6.2.3.1), for example a VoLTE bearer is set up.

The measurement sequence is not stopped if the UE enters poor LTE coverage, for example by triggering the MCPC search zone and sending an A2 report.

If required, a measurement gap is used. The gap is set by the highest priority frequency which requires a gap in each RRC Reconfiguration message. If another frequency requires a gap, then it is measured only if its SSB falls within the configured gap. For more detail on measurement gaps, see Section 4.8.4.

**B1 Measurement Threshold and Time to Trigger**

The threshold, hysteresis, offset and time to trigger values used for the B1 measurements are described in detail in Section 11.2.2.

**Controlling the B1 Measurements at the Subscriber Group Level**

Figure 10-6 shows an example of how B1 measurements can be controlled at the subscriber group level (SPID), using the ASGH Framework feature (Section 11.2.2).

<!-- page: 239 -->

In this example, Fixed Wireless Access (FWA) users are assigned a unique SPID value (e.g. 48), while regular Mobile Broadband (MBB) users are not assigned a SPID. MBB users are configured to measure periodically using the normal B1 threshold. FWA devices, which in this example have a higher transmit power and do not require a measurement gap, are configured to measure forever with lower B1 threshold.

If ASGH is used to selectively lower the B1 threshold, make sure that the modified B1 threshold is higher than the threshold for triggering MCPC on NR. This ensures that SN addition is not immediately followed by an MCPC-triggered handover or release back to LTE. One way to achieve this is to also selectively lower the MCPC threshold, using the UE grouping framework to target the same subscribers.

![Figure on page 239](5G_Mobility_and_Traffic_Management_Guideline_images/page_239_image_002.png)

Figure 10-6 - Configuring Different B1 Measurements for MBB and FWA

#### 10.2.1.3 NR Cell Overload Backoff Timer

This functionality enables the eNodeB to exclude overloaded NR cells from EN-DC and IRAT handover procedures for a configurable time period.

If an EN-DC setup or SCG addition is rejected due to the candidate NR cell being overloaded, then the cell is added to the denylist for a time of ENodeBFunction . nrCellOverloadBackoffTime . Setting the attribute to 0 disables the functionality.

When in the denylist, the NR cell is not used for the following procedures:

- Configuration-based EN-DC setup

- Measurement-based EN-DC setup

- SCG Addition

<!-- page: 240 -->

- EN-DC Triggered Handover

- LTE handover without Secondary Node change

- Outgoing NR IRAT Handover

This prevents repeated failures, reduces signaling and improves end user experience.

#### 10.2.1.4 Multiple Frequency Band Indicator for EN-DC Setup

To enable overlapping LTE bands to be used for EN-DC setup, set ENodeBFunction.endcAwareMfbiIntraCellHo = true . This allows the eNodeB to consider overlapping LTE bands when determining which band combinations are supported by both the UE and eNodeB, and therefore which NR frequencies the UE must measure for SN addition (using B1).

When a B1 report is received from the UE, and the UE does not support EN-DC on this NR frequency combined with the primary LTE band, then the eNodeB triggers an intra-cell handover to an overlapping LTE band which the UE supports for EN-DC, and SN addition proceeds.

If SN release occurs, then the eNodeB moves the UE back to the band it was using before EN-DC setup. For example, consider the case of an LTE intra-frequency handover, when the UE is using EN-DC on an overlapping band. The sequence of events is:

- eNodeB receives the Event A3 report

- SN release and intra-cell handover from overlapping band to previously used band (e.g. primary band)

- Legacy LTE intra-frequency handover

- Intra-cell handover to overlapping band, B1 measurement configuration and SN addition

Note that SCG release (and addition) does not trigger the band change.

Setting endcAwareMfbiIntraCellHo = true also enables using overlapping LTE bands for ENDCHO, see Section 10.2.13.1.

#### 10.2.1.5 Automatic Update of Upper Layer Indication

As described in Section 4.5 - 5G Status Icon on UE, the upper layer indication tells the UE that 5G NSA service is potentially available in the area, so that the UE can display a 5G icon. The upper layer indication can be set either manually or automatically (by BIC) for each PLMN defined in the LTE serving cell as follows:

<!-- page: 241 -->

- To enable automatic update, set EUtranCellFDD/TDD.upperLayerAutoConfEnabled =

̶

- If automatic update is enabled:

- The eNodeB sets the upper layer indication (per PLMN) to true

- The PLMN exists in the EUtranCellFDD/TDD.endcAllowedPlmnList and

- when: ,

- The PLMN exists in ExternalGUtranCell.plmnIdList referenced by GUtranCellRelation

̶

- Otherwise, the eNodeB sets it to false

- The automatically configured values for each PLMN are stored in the read-only attribute EUtranCellFDD/TDD.upperLayerAutoConfIndList . The first listed value corresponds to ENodeBFunction.eNodeBPlmnId , and the subsequent values to the PLMN list contained in

EUtranCellFDD/TDD.additionalPlmnList .

- The automatic process is typically triggered when a GUtranCellRelation is added or removed, but it can also be triggered by other configuration changes. If this process results in a change to a broadcasted upper layer indication value, then a SIB2 update is triggered to advise the UE.

̶

- If automatic update is disabled:

̶

- The upper layer indication is set manually, using the attributes EUtranCellFDD/TDD.primaryUpperLayerInd and EUtranCellFDD/TDD.additionalUpperLayerIndList .

- Note that for both manual and automatic updates, the upper layer indication can be configured only on PLMNs which are allowed in the serving LTE cell, namely those contained in ENodeBFunction.eNodeBPlmnId and

EUtranCellFDD/TDD.additionalPlmnList .

#### 10.2.1.6 Differentiate A2 Threshold for EN-DC Capable UE

In LTE, Event A2 is used to detect poor serving cell coverage and trigger the search for a better LTE carrier or another RAT.

The feature Basic Intelligent Connectivity (BIC) enables the A2 threshold to be set differently for EN-DC capable UEs. Specifically, an additional negative offset can be applied for EN-DC capable UEs when served by EN-DC capable cells. This delays the coverage-triggered search for a better LTE carrier or another RAT, so keeping EN-DC capable UEs on EN-DC capable cells longer. When determining whether to apply the differentiated offset, this feature considers only whether the UE is EN-DC capable or not. It does not consider, for example, EN-DC band combination support or the presence of the NR restriction in the HRL.

̶

̶

true The additional offsets for EN-DC capable UEs can be applied only to the inner search zone or to both the inner and the outer search zones. They can be set for RSRP or RSRQ or both, and triggering occurs independently for the two. The offsets are provided in the MO class ReportConfigA1A2Endc .

<!-- page: 242 -->

**Search Zone Offsets**

The EN-DC specific search zone offsets are set by the following attributes:

- qciA1A2ThrOffsetsEndc . a1a2ThrRsrpQciOffsetEndc

- qciA1A2ThrOffsetsEndc . a1a2ThrRsrqQciOffsetEndc

These offsets are set per cell, per QCI. For EN-DC capable UEs, they are added to the A2 search zone threshold offsets determined by the active LTE Mobility features, for example Mobility Control at Poor Coverage , Multi-Layer Service-Triggered Mobility and/or Service Triggered Mobility . These offsets are negative, so they lower the thresholds for EN-DC capable UEs, delaying the search.

**If the UE uses multiple QCIs, then the QCI with the highest**

UeMeasControl.prioOffsetPerQci.offsetPerQciPrio determines the offset. If more than one QCI has the equal highest priority, then the maximum sum of a1a2ThrRsrpQciOffset + a1a2ThrRsrpQciOffsetEndc or a1a2ThrRsrqQciOffset + a1a2ThrRsrqQciOffsetEndc is selected from those QCIs.

The search zone offsets are applied equally to both the A2 threshold (entering poor coverage) and the A1 threshold (re-entering good coverage) to keep the search zone boundary consistent.

**Outer Search Zone Offsets**

The EN-DC specific outer search zone offsets are set by the following attributes:

- a2OuterSearchThrRsrpOffsetEndc

- a2OuterSearchThrRsrqOffsetEndc

These offsets are set per cell (not per QCI). For EN-DC capable UEs, they replace the A2 outer search zone offsets set by MCPC (namely a2OuterSearchThrRsrpOffset and a2OuterSearchThrRsrqOffset ).

However, the outer search zone offset is applied only if the corresponding EN-DC search offset is non-zero. Specifically, ' corresponding ' means the a1a2ThrRsrpQciOffsetEndc or a1a2ThrRsrqQciOffsetEndc offset for the QCI used for the search zone, as described above. If the corresponding offset is zero, then the legacy outer search zone offset is used for all UEs.

<!-- page: 243 -->

Detailed formulas showing how to calculate the overall trigger levels for the search zone, outer search zone and good coverage zone are provided in the CPI document: LTE Mobility and Traffic Management Guideline.

This functionality requires that at least one of the following two LTE features is enabled in the eNodeB: Service Triggered Mobility or Multi-Layer Service-Triggered Mobility .

#### 10.2.1.7 LTE Handover Without Secondary Node Change

This function decreases EN-DC user plane interruption during LTE handover, by allowing the PDCP context to remain in the SN during the handover, and by removing the need for a B1 measurement.

LTE Handover without secondary node change requires:

- ENodeBFunction . zzzTemporary81 = 1

- The LTE handover can be completed over X2 (not S1)

- The PSCell can be used for EN-DC on the target LTE cell

- The PSCell RSRP, forwarded from the source eNodeB, meets the B1 threshold for SN addition that is set in the target LTE cell (as detailed in Section 11.2.2).

If these conditions are not met, then the SN is released during the handover and new B1 measurements are started after the LTE handover to detect suitable NR coverage.

The function supports packet forwarding for all bearers, both MN and SN terminated.

#### 10.2.1.8 Buffer-Based EN-DC Setup (DL and UL)

When this function is enabled, B1 measurements for SN addition and EN-DC triggered handover (ENDCHO) are started only if the downlink or uplink user plane data exceeds configurable thresholds. Note that if a VoLTE call has just been released, then buffer monitoring does not start until endcInhibitTime has expired, as described in Section 6.4.

Buffer-based EN-DC setup prevents SN addition for short sessions which are unlikely to benefit from it, so avoiding unnecessary B1 measurements, measurement gaps and user plane interruptions, and conserving UE battery power.

To enable DL buffer monitoring set EUtranCellFDD/TDD.endcSetupDlPktVolThr or EUtranCellFDD/TDD.endcSetupDlPktAgeThr to a value other than zero. B1 measurements are then started if:

- The total SDU volume in the DL RLC queue exceeds endcSetupDlPktVolThr , and

- The age of the earliest DL RLC SDU exceeds endcSetupDlPktAgeThr

<!-- page: 244 -->

Setting either of these thresholds to zero removes the corresponding check. Setting both to zero disables DL buffer-based EN-DC setup.

To enable UL buffer monitoring set EUtranCellFDD/TDD.endcSetupUlBsVolThr to a value other than zero. B1 measurements are then started if:

- The uplink data volume per logical channel group in buffer status report from the UE exceeds EUtranCellFDD/TDD.endcSetupUlBsVolThr

If both DL and UL buffer monitoring are enabled, then B1 measurements are started if either the DL or the UL buffer condition is satisfied.

These cell-level settings can be overridden per subscriber group (SPID) using:

- EndcUserProfile . endcSetupDlPktVolThrOverride

- EndcUserProfile . endcSetupDlPktAgeThrOverride

- EndcUserProfile . endcSetupUlBsVolThrOverride

In a similar way, setting these attributes to zero removes the corresponding check.

To monitor the proportion of EN-DC setups which are avoided by Buffer-Based EN-DC Setup, use the formula in Section 12.2.

Buffer-based EN-DC setup can also be applied after LTE RRC reestablishment and incoming S1 or X2 handover, if restartBufMonAtMobility = true . For more details, refer the feature for Basic Intelligent Connectivity in CPI.

#### 10.2.1.9 NR UE-Assisted Overheating Mitigation

This functionality enables the eNodeB to take mitigating action when a UE informs the network that it is overheated. It requires the gNodeB feature NR UE-Assisted Overheating Mitigation .

The functionality is enabled by setting ENodeBFunction.endcOverheatingAssistance = true

When the eNodeB receives a report that the UE is overheated, it takes one of the following actions, depending on the severity of the overheating:

- Deactivate SCells in the NR SCG

- Release the SCG

The eNodeB will not reactivate the SCells or reconfigure the SCG until the UE reports that it is no longer overheated.

SN addition is prevented if the UE is overheated.

The overheating status is cleared when the UE returns to idle mode.

<!-- page: 245 -->

For more information, see CPI for the gNodeB feature NR UE-Assisted Overheating Mitigation .

#### 10.2.1.10 Detection, Prevention, and Handling of Recurring EN-DC Setup Failures

The Detection, Prevention, and Handling of Recurring EN-DC Setup Failures function in feature Basic Intelligent Connectivity allows the eNodeB to block NR frequencies on which a specific UE experiences recurring radio link failures shortly after EN-DC setup.

The types of radio link failures considered are any UE reported failure, and gNodeB detected failures with cause value radioNetwork:radio-connection-with-UE-lost .

If an EN-DC connection is released with one of these failures within loopingEndcShortScgSessTime (default 1500 ms) after the EN-DC setup, then it is considered an 'EN - DC setup failure'.

If there are loopingEndcConsecFailThr (default 5) 'EN - DC setup failures' with less than 100 seconds between them, then the failures are considered recurring. The relevant NR frequency is added to a blocklist and is then blocked for that UE for loopingEndcBackOffDuration (default 100 s).

During this blocked time, the following restrictions are applied to the frequency:

- The frequency is not used for B1 measurements for EN-DC setup or ENDCHO

- The frequency is ignored if it is received in a B1 measurement report

- The frequency is not used for A5 measurements for MCPC NSA or PSCell Change to Higher Priority

- The frequency is excluded when CAIMC evaluates supported band combinations

Blocking the offending frequency prevents repeated failures and increases the chance of successfully setting up EN-DC on another NR frequency, if available.

The function is activated per EUtranCellFDD/TDD by setting loopingEndcProtectionEnabled = true .

If a UE belongs to a subscriber group, then settings can be overridden with the following parameters in the EndcUserProfile class:

- loopingEndcProtectionEnabledOverride

- loopingEndcShortScgSessTimeOverride

- loopingEndcConsecFailThrOverride

- loopingEndcBackOffDurationOverride

<!-- page: 246 -->

### 10.2.2 NR Coverage-Triggered NR Session Continuity (FAJ 121 4983) - SA

This is a licensed eNodeB feature in the value package Intelligent Connectivity (FAJ 801 1013).

It enables mobility of NR Standalone (NR SA) capable UEs from LTE to NR SA when coverage becomes acceptable. The feature enables mobility in both idle mode and connected mode:

- In idle mode, the feature enables the broadcast of NR SA frequencies in SIB24, so that NR SA capable UEs can reselect from LTE to NR SA. See Section 8.1 for more detail.

- In connected mode, the feature allows UEs which are capable of NR SA to be redirected to NR SA, when NR SA coverage becomes acceptable. See Section 8.3.1 for more detail. If the feature Outgoing NR IRAT Handover is enabled, then the UE can be sent to NR SA using inter-RAT handover rather than release-with-redirect; see Section 10.2.3.

To avoid ping-pong mobility between LTE and NR, UEs can be prevented from returning to NR after certain mobility triggers from SA to LTE. The prevention mechanism depends on whether the mobility was a handover or a release-with-redirect.

- After release-with-redirect, mobility back to NR SA can be discouraged as described in Section 8.3.12.

- After handover, mobility back to NR SA is prevented by this feature, as described below.

Mobility back to NR SA can be prevented after a handover to LTE that is triggered by one of the following:

- Bandwidth-Triggered Inter-System Handover

- NR Data-Aware Mobility

- Uplink SINR-triggered MCPC Handover

- NR Traffic Offload (with special handling for UEs with SPID, see below)

**This functionality is controlled with**

ENodeBFunction . mobilityBackToNrFreqDisabled , which takes the following values:

- 0 (NO_RESTRICTION)

Mobility back to the NR SA frequency is not prevented

- 1 (CONNECTED_MODE_MOBILITY)

Mobility back to the NR SA frequency is prevented in connected mode only

- 2 (CONNECTED_IDLE_MODE_MOBILITY)

Mobility back to the NR SA frequency is prevented in connected mode, and possibly also in idle mode (see below for details)

<!-- page: 247 -->

In connected mode, the eNodeB prevents mobility back to NR SA by excluding the NR SA frequency from any B1 or B2 SA measurements. The connected mode exclusion lasts until the PCell is changed or the UE returns to idle mode.

If the UE is released to idle mode while the connected mode exclusion still applies, then the eNodeB sends an IMMCI message to the UE that excludes the NR SA frequency, so that the UE cannot reselect to it after entering idle mode. This exclusion lasts until the relevant t320 timer expires or until the UE reenters connected mode.

If the handover from NR SA to LTE is triggered by NR Traffic Offload , and the UE has a SPID that is captured by the spidList of an instance of RATFreqPrio or UeProfileFilter , then the exclusion handling is modified by the feature Subscriber Triggered Mobility , as described in Section 10.2.4.1.

Additionally, if the feature LTE Service-Triggered Outgoing NR IRAT Mobility is active, then connected mode mobility to NR SA can be restricted based on QCI and SPID; see Section 10.2.23.

Refer to the CPI document NR Coverage-Triggered NR Session Continuity for more information.

### 10.2.3 Outgoing NR IRAT Handover (FAJ 121 5377) - SA

This is a licensed eNodeB feature in the value package Basic NR Mobility Support (FAJ 801 1018).

This feature extends the feature NR Coverage-Triggered NR Session Continuity (Section 10.2.2) by enabling handover from LTE to NR SA, for MBB-only connections and for VoNR capable UEs with a QCI1 bearer or MCPTT users. Using handover reduces service interruption time and minimizes downlink packet loss by introducing support for direct packet forwarding. The conditions to start the B1 measurements, and the measurement patterns used, are the same as described Section 8.3.1 for RwR.

This feature also enables the feature Mobility Control at Poor Coverage , to trigger handover or release-with-redirect to NR SA when the UE is in poor coverage. B2 measurements are used for this.

For further details on the handover procedure, refer to Section 8.3.2.

### 10.2.4 Subscriber Triggered Mobility (FAJ 121 1788) - LTE

Subscriber Triggered Mobility (STM) is a licensed eNodeB feature in the LTE Base Package (FAJ 801 0400). It enables the mobility behavior of a UE to be modified based on its Subscriber Profile ID (SPID) value. The SPID is received by the RBS over the S1 interface and is specific to a UE, applying to all its radio bearers.

In this guideline, STM is used for NSA to steer UEs towards LTE anchor layers, and for SA to control mobility to NR SA frequencies.

STM provides two options for SPID-based control:

<!-- page: 248 -->

**· Legacy STM**

The legacy implementation of STM uses the MOs under the SubscriberProfileID class to override the attributes in the frequency relation MOs for UEs whose SPID is found in the RATFreqPrio.spidList . When legacy STM overrides the settings for a particular frequency, it overrides the settings for all frequency relations in the eNodeB that point to that frequency. Legacy STM therefore provides control at the frequency and SPID level.

- Multi-Layer Subscriber-Based Mobility (MLSBM)

The MLSBM enhancement to STM provides more flexible control of SPID-based mobility. It uses the MOs under the UeProfile class to override the attributes in the frequency relation MOs for UEs whose SPID is found in the UeProfileFilter.spidList . In this case, the settings can be chosen independently for each frequency relation under each cell, using the eUtraFreqRelProfileSetRef attribute. MLSBM therefore provides control at the frequency relation and SPID level.

The MOs associated with the two STM options are shown in Figure 10-7.

- The main EUtranFreqRelation attributes that can be overridden by STM are: arpPrio , cellReselectionPriority , connectedModeMobilityPrio , endcHoFreqPriority, interFreqHoHigherPrioAllowed, interFreqHoHigherPrioControl, loadBalancingAllowed and voicePrio .

- The main GUtranFreqRelation attributes that can be overridden by STM are: cellReselectionPriority (overridden by cellReselectionPrio ), cellReselectionSubPriority (overridden by cellReselectionSubPrio ), connectedModeMobilityPrio (overridden by connModeMobilityPrio ), endcB1MeasPriority and voicePrio .

<!-- page: 249 -->

![Figure on page 249](5G_Mobility_and_Traffic_Management_Guideline_images/page_249_image_002.png)

Figure 10-7 - MOs associated with Subscriber Triggered Mobility

If SPID level control is required for NR or LTE frequencies, then use either legacy STM or MLSBM for those frequencies, not both. Although it is possible to configure both simultaneously in an eNodeB, doing so creates extra complexity with no benefit. The remainder of this section therefore assumes that only one is configured for NR and LTE frequencies; either MLSBM (using the MOs under UeProfile ) or legacy STM (using the MOs under SubscriberProfileID ), not both.

If SPID level control is required for frequencies of other RATs (e.g. WCDMA and GSM), then legacy STM must be used for those frequencies, as MLSBM does not support those RATs.

For a given mobility decision for a particular UE, the eNodeB uses the following process to build a target frequency list:

- Step 1:

<!-- page: 250 -->

̶

- If MLSBM is used for NR and LTE (UeProfile MOs) The eNodeB first attempts to build the target frequency list for NR and LTE using the children of the UeProfile MO. A frequency is included if the source cell has a corresponding frequency relation that references a profile set whose spidList contains the UE SPID, and mobility is allowed by the relevant attribute (e.g. for idle mode mobility, this means cellReselectionPriority ≠ -1). The value for the attribute is taken from the relevant UeProfile child MO if that attribute is not set to -1000, otherwise it is taken from the corresponding frequency relation**.

- If Legacy STM is used for NR and LTE (SubscriberProfileID MOs) The eNodeB attempts to build the target frequency list using the children of the SubscriberProfileID MO. A frequency is included if the source cell has a corresponding frequency relation, and that frequency has an instance of RATFreqPrio or FreqPrioNR whose spidList contains the UE SPID, and mobility is allowed by the relevant attribute. The attribute value is taken from the relevant SubscriberProfileID child MO if that attribute is not set to -1000, otherwise it is taken from the frequency relation**. Note, however, that for attributes cellReselectionPrio and cellReselectionPriority , the value -1000 excludes the frequency from IMMCI and therefore from the target frequency list; it does not indicate that the value in the frequency relation is used.

̶

- Step 2:  Legacy STM for Other RATs (SubscriberProfileID MOs) The eNodeB attempts to build a target frequency list for other RATs (e.g. WCDMA and GSM) using the children of the SubscriberProfileID MO. A frequency is included if the source cell has a corresponding frequency relation, and that frequency has an instance of RATFreqPrio whose spidList contains the UE SPID, and mobility is allowed by the relevant attribute. The attribute value is taken from the relevant SubscriberProfileID child MO if that attribute is not set to -1000, otherwise it is taken from the frequency relation. Note, however, that for attributes cellReselectionPrio and cellReselectionPriority , the value -1000 excludes the frequency from IMMCI and therefore from the target frequency list; it does not indicate that the value in the frequency relation is used.

- Step 3:  Combine Lists or use Baseline Settings (Frequency Relation MOs) If any frequencies were found in Steps 1) or 2), then combine those frequencies to produce the final target frequency list. If both 1) and 2) return empty lists, then the target frequency list is built using the attributes from the cell's frequency relations.

** If MLSBM and legacy STM are used concurrently for NR and LTE (not recommended), for example during migration from legacy STM to MLSBM, then setting the value -1000 in the MLSBM MOs results in different behavior to that described above. Specifically, the eNodeB searches for a match in the spidList (s) of the legacy STM MOs, and if one is found, then the value from that MO is used, otherwise the value from the frequency relation is used.

<!-- page: 251 -->

Regardless of whether MLSBM or legacy STM is used to control mobility for a certain SPID, all desired target frequencies must have both a frequency relation and a matching instance of EUtraFreqRelProfileSet or GUtraFreqRelProfileSet (if MLSBM is used) or RATFreqPrio or FreqPrioNR (if legacy STM is used). If either is missing, the frequency is excluded when building the relevant list. If using MLSBM, this implies that every frequency relation must have a matching profile. However, if SPID-based control is not required for a frequency, then it can use a profile that has all the mobility attributes set to -1000, so that the values in the frequency relation are used instead. This is shown in Figure 10-8.

![Figure on page 251](5G_Mobility_and_Traffic_Management_Guideline_images/page_251_image_002.png)

Figure 10-8 - Example of Creating a Default Profile with MLSBM

To illustrate the difference between using MLSBM and legacy STM, an example case is implemented in two different ways: using MLSBM in Figure 10-9 and legacy STM in Figure 10-10. In these examples, the same settings are applied to both Cell A and Cell B. However, for the MLSBM solution they could be different, as described by the notes in the figure.

![Figure on page 251](5G_Mobility_and_Traffic_Management_Guideline_images/page_251_image_003.png)

Figure 10-9 - Example Configuration with legacy STM

<!-- page: 252 -->

̶

![Figure on page 252](5G_Mobility_and_Traffic_Management_Guideline_images/page_252_image_002.png)

Figure 10-10 - Example Configuration with MLSBM

#### 10.2.4.1 NR Mobility after NR Traffic Offload

If the gNodeB feature NR Traffic Offload triggers handover of a UE from NR SA to LTE due to overload on an NR frequency, then that NR frequency can be excluded for connected and idle mode mobility (as described in Section 10.2.2).

With Subscriber Triggered Mobility , that exclusion can be modified per SPID. Specifically, if the UE has a SPID that is captured by the spidList of an instance of RATFreqPrio or UeProfileFilter , then the exclusion is controlled as follows:

- The exclusion is enabled using:

̶

- RATFreqPrio.mobBackToNrFreqDisabled or

- UeProfileFilter.mobBackToNrFreqDisabled

- In connected mode, the exclusion has a time limit that is set by:

̶

- RATFreqPrio.mobBackToNrFreqDisabledTime or

̶

- UeProfileFilter.mobBackToNrFreqDisabledTime

<!-- page: 253 -->

̶

The exclusion timer is applied per combination of LTE cell, NR frequency and SPID. It is started/restarted every time NR Traffic Offload triggers a handover from that NR frequency to that LTE cell for a UE with that SPID. The exclusion applies to all UEs using that SPID on that cell, not just UEs that have recently been sent from the NR frequency to the LTE frequency.

- If the UE is released to idle mode while the connected mode exclusion still applies, then the eNodeB releases the UE with an IMMCI message that excludes the frequency from idle mode measurements for a time set by:

̶

- RATFreqPrio.t320 or

- UeProfileFilter.t320

### 10.2.5 ASGH Framework (FAJ 121 4795) - LTE

This is an unlicensed eNodeB feature in the LTE Base Package (FAJ 801 0400).

The ASGH framework relies on three separate features:

- An unlicensed feature that provides the framework, allowing the configuration of the detection criteria, QCI remapping and observability

- The licensed feature ASGH Performance Package (FAJ 121 4796), which enables the modification of all UE-level parameters, except for prescheduling parameters

- The licensed feature ASGH-Based Prescheduling (FAJ 121 4797), which enables the modification of prescheduling parameters

In this guideline, ASGH is used to re-map the QCI values of 5G subscribers into different, operator defined QCI values, as described in Sections 9.6.2 and 9.6.3. This facilitates the use of QCI-based features, such as Multi-Layer Service-Triggered Mobility or Service Specific Load Management , in 5G mobility and traffic management solutions.

Subscriber group profiles can be linked to EN-DC user profiles, using the attribute SubscriberGroupProfile.endcUserProfileRef , which connects a particular SubscriberGroupProfile instance with an EndcUserProfile instance. This allows EN-DC functionality to be controlled at the subscriber group level; for example, enabling/disabling EN-DC (see Section 6.2.3.2), or configuring the B1 measurements used for SN addition (see Section 11.2.2).

The following sections describe how to assign UEs to subscriber groups in two ways:

- Using the ASGH Framework feature alone

- Using a combination of ASGH and the NR UE Throughput Booster feature

The advantage of using the NR UE Throughput Booster feature is that it enables 5G users to be automatically identified; they do not need to be identified by specific SPID values.

<!-- page: 254 -->

#### 10.2.5.1 Assigning the UE to a Subscriber Group (without NR UE Throughput Booster)

ASGH maps a connected UE into a specific profile (a subscriber group). It is possible to define up to 10 subscriber groups (MO SubscriberGroupProfile[0..10] ).

The mapping is done using five independent criteria, configured for each SubscriberGroupProfile . A connected UE is mapped into a subscriber group if all the following conditions are met:

- bearerTriggerList - The UE must have at least one combination of ARP and QCI which matches an entry in the bearerTriggerList . The ARP and QCI values are sent by the core network. In the bearerTriggerList , the value 0 indicates a match for all ARP or QCI values. Up to 6 combinations of ARP and QCI can be included in the list.

- spidTriggerList - The SPID of the UE must match one of the SPID values in the spidTriggerList . Up to 6 SPID values can be included in the list. The value 0 in the spidTriggerList matches UEs without any assigned SPID. If the spidTriggerList is empty, the SPID condition is always fulfilled.

- customTriggerList - The UE must match an entry in the customTriggerList if the list is not empty and the list is used. The use of the list is determined by the attribute customTriggerType .  The default value of customTriggerType is TRIGGER_NOT_USED . The other used values of customTriggerType are:

̶

- TRIGGER_TYPE_1 :  The customTriggerList is interpreted as an additional list of QCI values (in addition to bearerTriggerList ).

̶

- TRIGGER_TYPE_2 :  The customTriggerList is used to identify 5G devices and subscriptions for NSA and/or SA. See Section 10.2.5.2 for further details.

- cellTriggerList - The cellId of the PCell must match an entry in the cellTriggerList , or the list must be empty. This is only applicable if the feature Cell Level Scheduler is active.

- plmnTriggerList - The UE serving PLMN ID must match an entry in the plmnTriggerList , or the list must be empty.

If all five lists are empty, all UEs match. If no list is empty, the UE must match at least one value in each list.

Each trigger list is evaluated independently every time the bearer of a subscriber is set up, modified, or released. If a subscriber fulfills more than one SubscriberGroupProfile , only the SubscriberGroupProfile with the highest priority applies. The priority is defined by the attribute SubscriberGroupProfile[x].profilePriority.

<!-- page: 255 -->

̶

#### 10.2.5.2 Assigning the UE to a Subscriber Group (with NR UE Throughput Booster)

The feature NR UE Throughput Booster enables 5G users to be identified and assigned to subscriber group profiles based on the device capability and connectivity status. This allows 5G specific mobility strategies to be implemented even when 5G users are not differentiated by SPID values assigned in the core network.

To use NR UE Throughput Booster in combination with ASGH Framework:

- Activate the feature NR UE Throughput Booster feature by installing the license key and setting the attribute featureState to ACTIVATED in the FeatureState=CXC4012503 MO instance. (The ASGH Framework feature must also be activated.)

- Create a new instance of SubscriberGroupProfile to contain the 5G users, for example SubscriberGroupProfile[1] , with the following settings.

- Set SubscriberGroupProfile.customTriggerType = TRIGGER_TYPE_2 . This attribute specifies how the eNodeB interprets the values set in the customTriggerList array. The value TRIGGER_TYPE_2 indicates that the trigger is used to identify 5G UEs, using the NR UE Throughput Booster feature.

- Set SubscriberGroupProfile.customTriggerList[1] in the range [1..3] to include NSA capable UEs in the group, as follows:

̶

- 0: NSA capability is not used as a trigger condition

- 1: Include UEs which support EN-DC

- 2: Include UEs which support EN-DC and do not have an NR restriction for EPC (see Section 6.2.3.1)

̶

- 3: Include UEs which have an EN-DC connection configured. For this setting, BIC must be enabled.

̶

- Set SubscriberGroupProfile.customTriggerList[2] to 1 or 2 to include SA capable UEs in the group, as follows:

̶

- 0: SA capability is not used as a trigger condition

̶

- 1: Include UEs which support NR SA

̶

- 2: Include UEs which support NR SA and do not have an NR restriction for 5GC

UEs meet the TRIGGER_TYPE_2 criteria if either the customTriggerList[1] (NSA) trigger or the customTriggerList[2] (SA) trigger is met. If both of these triggers are set to 0, then all UEs meet the TRIGGER_TYPE_2 criteria. If only one is set to 0, then the other one determines which UEs meet the TRIGGER_TYPE_2 criteria.

<!-- page: 256 -->

Subscribers (UEs) are included in the group only if all four trigger conditions are met: bearerTriggerList , spidTriggerList , customTriggerList and cellTriggerList , noting that an empty list includes all the UEs.

It is therefore possible to create ASGH groups with a combination of criteria based on 5G UE capability, SPID, QCI and even specific cell lists. For example, if the core network already assigns different SPIDs to 'premium' and 'basic' users, then it straig htforward to create 'premium' and 'basic' groups specifically for EN -DC users, by combining SPID and custom trigger type 2.

### 10.2.6 Mobility Control at Poor Coverage (FAJ 121 3013) - LTE

Mobility Control at Poor Coverage (MCPC) is a licensed eNodeB feature in the LTE Base Package (FAJ 801 0400).

It builds on the legacy Session Continuity features to provide more control over mobility triggered by poor coverage. In this guideline, it is used for some of the anchor carrier management strategies. Refer to the LTE Mobility and Traffic Management Guideline for additional information on using this feature in the mobility strategy.

### 10.2.7 Multi-Layer Service-Triggered Mobility (FAJ 121 4124) - LTE

Multi-Layer Service-Triggered Mobility (MLSTM) is a licensed eNodeB feature in the Service Based Mobility Value Package (FAJ 801 0433).

It allows mobility thresholds to be tailored per frequency and/or per QCI (so per service) by adding offsets. It requires the feature Mobility Control at Poor Coverage to be active, as well as the relevant session continuity feature (for example Coverage-Triggered InterFrequency Session Continuity ). This feature supersedes the feature Service-Triggered Mobility and overrides it if both features are activated. In this guideline, it is used for some of the anchor carrier management strategies. Refer to the LTE Mobility and Traffic Management Guideline for further information on using this feature in the mobility strategy.

### 10.2.8 Service Specific Load Management (FAJ 121 3047) - LTE

Service Specific Load Management is a licensed eNodeB feature in the value package Service Based Mobility (FAJ 801 0433).

This feature provides control over how certain services (for example VoIP) are treated by load balancing and offload. In this guideline, it is used for some of the anchor carrier management strategies. Refer to the LTE Mobility and Traffic Management Guideline for further information on using this feature in the mobility strategy.

<!-- page: 257 -->

### 10.2.9 Flexible Counters (FAJ 121 4669) - LTE

Flexible Counters is an unlicensed eNodeB feature in the LTE Base Package (FAJ 801 0400). It introduces the possibility to apply operator-defined filters on certain counters, so that they peg for only a subset of events. This enables the creation of KPIs which focus on EN-DC users. It is also possible to combine filters, for example EN-DC, QCI and SPID filters, to obtain further differentiation.

Three levels of filtering are available for the EN-DC if endcFilterEnabled = True . The included levels are set by the attribute PmFlexCounterFilter.endcFilterMin . For example, if this attribute is set to 1, then the counter is stepped if the EN-DC state is either ENDC_NR_MATCHED or ENDC_NR_ACTIVE .

- 0 (ENDC_NR_CAPABLE)

The UE is confirmed to be capable of EN-DC.

- 1 (ENDC_NR_MATCHED)

The UE EN-DC capability matches LTE cell configuration (for either SN addition on the serving cell or for EN-DC triggered handover)

- 2 (ENDC_NR_ACTIVE)

EN-DC is active for the UE (SCG resources are configured)

### 10.2.10 Capability-Aware Idle Mode Control (FAJ 121 5073) - NSA

This licensed eNodeB feature is for Baseband Radio Nodes.

This eNodeB feature encourages EN-DC capable UEs to camp on a frequency which they can use for EN-DC. This is achieved by altering the cell reselection priorities used by the UE to reselect between frequencies in idle mode; higher priorities are given to EN-DC capable frequencies. The altered priorities are sent from the eNodeB to EN-DC capable UEs at RRC connection release, in the IdleModeMobilityControlInfo (IMMCI) IE. These priorities override the cell reselection priorities which are broadcast in System Information, for a time of t320 . The value of t320 is taken from the UePolicyOptimization MO if it is defined, and from the Rrc MO if not.

#### 10.2.10.1 UEs that are Impacted by CAIMC

CAIMC applies to UEs which meet the following conditions:

- The UE is EN-DC capable ( en-DC-r15 UE capability IE is set to supported)

- The UE is not prohibited from using EN-DC by the NR restriction (see Section 6.2.3.1)

- The UE is not Category M1

- The UE is not involved with CSFB or RWR

<!-- page: 258 -->

Additionally, whether CAIMC applies to UEs that are also capable of SA is determined by the setting of UePolicyOptimization.zzzTemporary1 , as follows:

- If zzzTemporary1 = 1, 2 or 3 then CAIMC applies to SA capable UEs.

- If zzzTemporary1  1, 2 or 3 then CAIMC does not impact SA capable UEs. They therefore use the cell reselection priority values broadcast in system information, and can reselect to SA in idle mode.

CAIMC considers a UE to be SA capable if it is qualified to be prioritized by the NR Coverage-Triggered NR Session Continuity feature. A UE is qualified if:

- The feature NR Coverage-Triggered Session Continuity is enabled, and

- The UE is SA capable, and

- UE does not have the value NRrestrictedin5GS in the NR restriction in 5GS IE in the UE's HRL, and

- GUtranFreqRelation.allowedPlmnList is empty, or at least one of the serving or any equivalent PLMNs in the UE's HRL matches any PLMN in the GUtranFreqRelation.allowedPlmnList and at least one of these matching PLMNs does not have the value 5GCForbidden in the Core Network Type Restrictions IE in the HRL.

#### 10.2.10.2 Interaction of CAIMC with Other Features that use IMMCI

If the UE has a SPID value assigned to it, then the following additional checks are performed:

- If Subscriber Triggered Mobility (STM) is active and the SPID value is found in the spidList of a RATFreqPrio or UeProfileFilter instance, then the behavior depends on the setting of ueCapPrioAllowed in that RATFreqPrio or UeProfileFilter instance respectively:

̶

- If ueCapPrioAllowed = true, then the IMMCI is determined by CAIMC if it applies to the UE, otherwise by STM

̶

- If ueCapPrioAllowed = false, then the IMMCI is determined by STM

For EN-DC capable UEs, CAIMC overrides the features LBDAR and ELBDAR if either of those features is active.

#### 10.2.10.3 Selection of EN-DC Capable Frequencies

CAIMC considers an LTE frequency to be EN-DC capable for a particular UE if all the following conditions are met:

- The UE supports an EN-DC band combination which uses the LTE frequency. (Section 6.2.1 explains how the eNodeB obtains the UE capability information.)

<!-- page: 259 -->

̶

̶

- NR frequencies which have recurring EN-DC setup failures are excluded when evaluating supported band combinations, if UePolicyOptimization . endcAwareImc = MODE_1 or MODE_2 . Refer to Section

- for more information.

- The serving cell has at least one GUtranFreqRelation defined for a NR frequency that the UE can use for EN-DC in combination with the LTE frequency.

- The serving cell has an EUtranFreqRelation defined for the frequency, with cellReselectionPriority ≠ -1

- If UePolicyOptimization . endcAwareImc = MODE_1 or MODE_2 , then EUtranFreqRelation . endcAwareIdleModePriority ≠ -1

- If the Shared LTE RAN feature is active, then at least one PLMN from EUtranFreqRelation.allowedPlmnList matches a PLMN in the UE's HRL. If the HRL is not available, then this condition is not applied.

- The frequency has at least one EN-DC capable cell that has an EUtranCellRelation defined from the serving cell. An EN-DC capable cell is one where the following conditions are met:

̶

- For an internal cell

- BIC is enabled in the eNodeB

- The endcAllowedPlmnList is not empty

- For an external cell

- A t least one of the serving or equivalent PLMN identities listed in the UE's HRL matches one of the identities configured in the endcAllowedPlmnList of the target cell. If the UE's HRL is not available, the primary PLMN of the target node ( eNodeBPlmnId ) is used for the comparison with the endcAllowedPlmnList .

- To exchange EN-DC cell relation capability over X2, both eNodeBs must be Ericsson. However, if this is not the case, then the feature Inter-Vendor Capability-Aware Idle Mode Control can be used to manage EN-DC capability; refer to Section 10.2.11 for more detail.

If no EN-DC capable frequencies remain after applying the above conditions, then CAIMC does not send IMMCI, and therefore does not impact the UE.

#### 10.2.10.4 Frequency Prioritization

This section describes how CAIMC prioritizes LTE, WCDMA and GSM frequencies. Prioritization of NR SA frequencies is described in Section 10.2.10.6.

<!-- page: 260 -->

For the EN-DC capable group of frequencies, CAIMC has four different methods for determining the IMMCI priorities: Configuration-Based, UE Capability-Based, Hit RateBased and Cell Number-Based. The method is selected by the attributes

UePolicyOptimization.endcAwareImc

UePolicyOptimization.coverageAwareImc

and as follows:

**· Configuration-Based Prioritization**

Obtained by setting: endcAwareImc = 1 ( MODE_1 )

This option gives the operator the most explicit control, as the ranking of the EN-DC capable frequencies is determined solely using the attribute

EUtranFreqRelation.endcAwareIdleModePriority. The values of endcAwareIdleModePriority are not used directly in IMMCI, but instead are used to obtain the relative ranking. A bigger value gives a higher priority. If multiple frequencies have the same value of endcAwareIdleModePriority , then they are given the same priority in IMMCI.

**· UE Capability-Based Prioritization**

Obtained by setting: endcAwareImc = 2 ( MODE_2 )

With this option, CAIMC gives highest priority to the LTE frequencies that support the highest number of NR bands. If multiple LTE frequencies support the same number of NR bands, then CAIMC uses endcAwareIdleModePriority to prioritize between them, giving the same priority to frequencies which also have the same endcAwareIdleModePriority .

**· Hit Rate-Based Prioritization**

Obtained by setting: endcAwareImc = 0 ( DEACTIVATED ) and coverageAwareImc = true

With this method, if at least one of the features Best Neighbor Relations for Intra-LTE Load Management (BNR) or Cell Sleep Mode (CSM) is active, then CAIMC prioritizes EN-DC capable frequencies according to the hit rate statistics, aggregated to the frequency level. A higher hit rate gives a higher priority. If the serving frequency is ENDC capable, then it is given the highest priority. If both features are active, CAIMC uses the hit rates from BNR. If neither is active then Cell Number-Based ranking is used, as described below.

**· Cell Number-Based Prioritization**

Obtained by setting: endcAwareImc = 0 ( DEACTIVATED ) and coverageAwareImc = false

With this method, CAIMC prioritizes EN-DC capable frequencies according to the number of EN-DC neighbor capable cells on the frequency; more EN-DC capable cells gives a higher priority. If the serving frequency is EN-DC capable, then it is given the highest priority.

See Section 9.2.1.1 for more information on how the prioritization method impacts idle mode behavior and how to choose the most appropriate setting.

Regardless of the prioritization method used for EN-DC capable frequencies, all of the ENDC capable frequencies are ranked on top, followed by the non EN-DC capable LTE frequencies and other RAT frequencies (WCDMA and GSM). Frequencies with cellReselectionPriority set to -1 are not included in IMMCI; refer to Section 11.1.4 for more detail.

<!-- page: 261 -->

In summary, CAIMC uses the following high-level process for ranking frequencies in IMMCI:

- EN-DC capable frequencies are ranked on top, according to the prioritization method, starting from Priority 7.

- Next come the non EN-DC capable LTE frequencies. Where possible, the priority order set by EUtranFreqRelation.cellReselectionPriority (SIB priority) is followed. If insufficient priority levels are available, then the lowest available priority level is used for the remaining frequencies.

- WCDMA and/or GSM frequencies are given the very lowest priority; for example, 0 if there is only one other RAT, or 0 and 1 if there are two. Different RATs can never be allocated the same priority. When determining the priorities amongst different RATs, SIB priority order is followed. If a RAT has more than one priority in SIB, then the highest is used to determine priority order.

- SA frequencies are handled by CAIMC as described in 10.2.10.6.

Two examples of how CAIMC assigns cell reselection priorities are provided below.

Table 10-5 shows the case where Configuration-Based Prioritization is used. In this table, the 'EN - DC Capable' column indicates the result after applying all the relevant criteria, including UE capability, network configuration, etc.

Table 10-5 - CAIMC Frequency Ranking - Configuration-Based Prioritization (MODE\_1)

| Frequency            | EN-DC Capable   |   cellReselectionPriority |   endcAwareIdleModePriority | CAIMC Priority   |
|----------------------|-----------------|---------------------------|-----------------------------|------------------|
| LTE 1                | No              |                         7 |                           3 | 4                |
| LTE 2                | Yes             |                         6 |                           2 | 5                |
| LTE 3                | Yes             |                         5 |                           4 | 6                |
| LTE 4                | Yes             |                         4 |                           6 | 7                |
| LTE 5 (Serving Cell) | Yes             |                         3 |                           2 | 5                |
| LTE 6                | No              |                         4 |                           5 | 3                |
| LTE 7                | No              |                         4 |                          -1 | 3                |
| LTE 8                | No              |                        -1 |                           5 | Not included     |

Table 10-5 - CAIMC Frequency Ranking - Configuration-Based Prioritization (MODE_1)

**Notes for Table 10-5**

- Frequencies LTE 2 to LTE 5 are EN-DC capable, and so are ranked on top, according to the endcAwareIdleModePriority . LTE 2 and LTE 5 are allocated the same CAIMC priority as they have the same endcAwareIdleModePriority .

- The non EN-DC frequencies (1, 6 and 7) are ranked in order of cellReselectionPriority , noting that frequency LTE 7 is considered as non ENDC capable because endcAwareIdleModePriority = -1.

- Frequency 8 is excluded from IMMCI as the cellReselectionPriority = -1

Table 10-6 shows the same example using UE Capability-Based Prioritization instead. Note the additional column showing the number of NR bands supported.

<!-- page: 262 -->

Table 10-6 - CAIMC Frequency Ranking - UE Capability-Based Prioritization (MODE\_2)

| Frequency            | EN-DC Capable   | NR Bands Supported   |   cellReselection Priority |   endcAwareIdle ModePriority | CAIMC Priority   |
|----------------------|-----------------|----------------------|----------------------------|------------------------------|------------------|
| LTE 1                | No              | NA                   |                          7 |                            3 | 4                |
| LTE 2                | Yes             | 2                    |                          6 |                            2 | 7                |
| LTE 3                | Yes             | 1                    |                          5 |                            4 | 5                |
| LTE 4                | Yes             | 1                    |                          4 |                            6 | 6                |
| LTE 5 (Serving Cell) | Yes             | 2                    |                          3 |                            2 | 7                |
| LTE 6                | No              | NA                   |                          4 |                            5 | 3                |
| LTE 7                | No              | NA                   |                          4 |                           -1 | 3                |
| LTE 8                | No              | NA                   |                         -1 |                            5 | Not included     |

Table 10-6 - CAIMC Frequency Ranking - UE Capability-Based Prioritization (MODE_2)

**Notes for Table 10-6:**

- Frequencies LTE 2 to LTE 5 are EN-DC capable, and so are ranked on top, according to the number of supported NR bands firstly, and then according to the endcAwareIdleModePriority . Frequencies 2 and 5 are allocated the same priority in IMMCI, as they have the same number of supported NR bands and the same setting for endcAwareIdleModePriority .

- The non EN-DC frequencies (1, 6 and 7) are ranked in order of cellReselectionPriority , noting that frequency LTE 7 is considered as non ENDC capable because endcAwareIdleModePriority = -1.

- Frequency 8 is excluded from IMMCI as the cellReselectionPriority = -1

#### 10.2.10.5 Load-Aware Prioritization

After the prioritization process described above, CAIMC can optionally consider load when prioritizing among the EN-DC capable frequencies. This is enabled by setting UePolicyOptimization.loadAwareImc = true . CAIMC then reduces the priority of EN-DC capable frequencies that are highly loaded.

CAIMC considers an EN-DC capable frequency to be highly loaded if at least one cell on the frequency is highly loaded. A cell is considered highly loaded if it meets the following conditions:

- The cell has an EUtranCellRelation from the serving cell, with loadBalancing = ALLOWED or IFO_AND_IFLB .

- The cell's subscription ratio equals or exceeds its setting of EUtranCellFDD/TDD.subscriptionRatioHighThresh .

**The ranking order then becomes:**

- EN-DC capable frequencies that are not highly loaded

- EN-DC capable frequencies that are highly loaded

<!-- page: 263 -->

- Non EN-DC capable LTE frequencies

- Other RAT frequencies

Within each of these groups, CAIMC attempts to maintain the priority order determined by the previously described mechanism (as determined by endcAwareImc and coverageAwareImc ). If insufficient priority levels are available to do this, then CAIMC merges priority levels together, starting at the lower priority end. However, CAIMC always assigns different priorities to frequencies on different RATs.

Note that a single, highly loaded cell can result in an entire frequency being deprioritized. To ensure that prioritization is appropriate, refer to the guidelines on tuning load aware CAIMC in Section 9.2.1.1.

Figure 10-11 provides an example of load aware CAIMC. The right hand part of the table shows how load-aware CAIMC impacts prioritization, assuming the starting point in the second left column.

![Figure on page 263](5G_Mobility_and_Traffic_Management_Guideline_images/page_263_image_001.png)

Figure 10-11 - Load-Aware CAIMC - Frequency Prioritization Example

The load-aware functionality in CAIMC requires that the eNodeB feature Inter-Frequency Load Balancing is active in the serving and neighboring eNodeBs. This enables the subscription ratio to be calculated, shared between the eNodeBs, and used for CAIMC.

#### 10.2.10.6 CAIMC Prioritization of NR SA Frequencies

After the prioritization of LTE, WCDMA and GSM frequencies (as described in the above sections), CAIMC can optionally include NR SA frequencies.

How NR SA frequencies are handled by CAIMC is determined by the attribute UePolicyOptimization.zzzTemporary1 , as follows:

<!-- page: 264 -->

- If zzzTemporary1  1, 2 or 3

̶

- CAIMC does not apply to SA capable UEs. SA capable UEs therefore use the cell reselection priority values broadcast in system information and can reselect to SA in idle mode. For non-SA capable UEs, NR SA frequencies are not included in IMMCI.

- If zzzTemporary1 = 1

̶

- CAIMC applies to UEs that are capable of both EN-DC and SA, but NR SA frequencies are not included in the IMMCI message that CAIMC sends to the UE. Therefore, if CAIMC sends IMMCI to an SA capable UE, then the UE will not be able to reselect to NR SA in idle mode.

̶

- This setting therefore prioritizes NSA over SA, for UEs which are capable of both.

- If zzzTemporary1 = 2

̶

- CAIMC applies to UEs that are capable of both EN-DC and SA.

̶

- IMMCI includes NR SA frequencies that meet the following conditions:

- GUtranFreqRelation.cellReselectionPriority ≠ -1

- GUtranFreqRelation.cellReselectionSubPriority ≠ 0

- Mobility to the frequency is not blocked due a recent BWTISHO (see Section 10.2.2 for details)

- This setting ensures that SA frequencies never have the same absolute priority as LTE, WCDMA or GSM frequencies in the IMMCI message. This is because the included SA frequencies always have a non-zero sub-priority, whereas the LTE, WCDMA and GSM frequencies do not have a sub-priority (which effectively means it is zero).

̶

- In the IMMCI message, the SA frequencies use the priority values set in the relevant GUtranFreqRelation . This means that the SA frequencies can end up 'interleaved' in priority with the LTE, WCDMA and GSM frequencies (whose priorities are determined as described in the previous sections).

̶

- If zzzTemporary1 = 3

̶

- CAIMC applies to UEs that are capable of both EN-DC and SA.

̶

- IMMCI includes NR SA frequencies that meet the following conditions:

- GUtranFreqRelation.cellReselectionPriority ≠ -1

- Mobility to the frequency is not blocked due a recent BWTISHO (see Section 10.2.2 for details)

<!-- page: 265 -->

̶

- When CAIMC assigns dedicated priorities to NR SA frequencies in IMMCI, it ensures that:

- If the priority settings in the frequency relations give an NR SA frequency a higher priority than an LTE frequency, then CAIMC also gives it a higher priority.

- The algorithms used to choose the dedicated cell reselection priority (CRP) and cell reselection sub-priority (CRSP) for each NR frequency are shown in Figure 10-12.

![Figure on page 265](5G_Mobility_and_Traffic_Management_Guideline_images/page_265_image_002.png)

Figure 10-12 - Algorithm used to determine NR priorities when zzzTemporary1 = 3

An example which illustrates these zzzTemporary1 settings for an SA-capable UE is provided in Figure 10-13 and the following notes .

<!-- page: 266 -->

Figure 10-13 - Example of SA Frequency Handling by CAIMC

Figure 10-13 - Example of SA Frequency Handling by CAIMC

Notes for zzzTemporary1 = 3 in Figure 10-13:

- NR 1 and NR 2 have a higher configured CRP than all of the LTE frequencies, so CAIMC assigns them the highest dedicated CRP of all LTE frequencies, being 7. Additionally, NR 2 retains a higher priority than NR1, via the sub-priorities (8 & 6).

- NR 3 has a higher configured CRP than LTE 6 only, so CAIMC assigns it the dedicated CRP of LTE 6, being 6, and adds a sub-priority of 8 to keep the absolute priorities different.

- NR 4 does not have any LTE frequencies with a lower configured CRP, so CAIMC assigns it the lowest CRP of LTE frequencies minus 1, being 3, and adds the subpriority 8.

If any NR frequencies have been deprioritized during release-with-redirect from NR SA to LTE (as described in Section 8.3.12) then the deprioritisation overrides the priorities assigned by CAIMC for those frequencies.

#### 10.2.10.7 CAIMC and TM9 Interaction

If both the features Capability-Aware Idle Mode Control (CAIMC) and TM9 CapabilityAware Idle Mode Control (TM9 CAIMC) are active, then the attribute UePolicyOptimization.ueCapPrioList determines how frequencies are prioritized. Table 10-7 provides some examples, assuming a UE which is capable of both EN-DC and TM9. This table uses the following terms to describe the frequencies:

- EN-DC(NW + UE) : Frequency is supported for EN-DC by both the network and the UE

- EN-DC(NW) : Frequency is supported for EN-DC by the network but not the UE

- TM9 : Frequency is supported for TM9 by the network and the UE

- Other : All remaining frequencies

<!-- page: 267 -->

Table 10-7 - Example of Frequency Ranking with both CAIMC and TM9 CAIMC Active

| ueCapPrioList         | Frequency Order in IMMCI                                                                                             |
|-----------------------|----------------------------------------------------------------------------------------------------------------------|
| empty                 | Legacy ranking is used (no priority for EN-DC or TM9 capable frequencies)                                            |
| [ENDC]                | EN-DC(NW+UE), EN-DC(NW), Other                                                                                       |
| [TM9]                 | TM9, Other                                                                                                           |
| [TM9, ENDC]           | TM9, EN-DC(NW+UE), EN-DC(NW), Other                                                                                  |
| [ENDC, TM9] (default) | EN-DC(NW+UE), EN-DC(NW), TM9, Other This is also the default behavior if the UePolicyOptimization MO is not defined. |

Table 10-7 - Example of Frequency Ranking with both CAIMC and TM9 CAIMC Active

CAIMC does not trigger as a result of a tracking area update; it triggers when the last DRB is released.

### 10.2.11 Inter-Vendor Capability-Aware Idle Mode Control (FAJ 121 5160) - NSA

Note: This licensed eNodeB feature is for Baseband and DU Radio Nodes.

This feature extends the feature Capability-Aware Idle Mode Control to include EN-DCcapable cells of other vendors.

To indicate whether an external cell is EN-DC capable, the attribute endcAllowedPlmnList in the MOs ExternalEUtranCellFDD/TDD is used. How this attribute is set depends on whether the cell is inter-vendor or not, and how the ExternalEUtranCellFDD/TDD is created. This is described in Table 10-8:

Table 10-8 - Handling of endcAllowedPlmnList

| EN-DC cell capabilities are available over X2?   | ExternalEUtranCell created by?                                                     | Handling of endcAllowedPlmnList                                                                                      |
|--------------------------------------------------|------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------|
| Yes                                              | NA                                                                                 | Set automatically if EN-DC capability information is received through X2                                             |
| No                                               | Operator                                                                           | Must be manually configured                                                                                          |
| No                                               | ANR (the cell must be a permanent cell, created by CGI measurement- triggered ANR) | Set automatically with information from EUtranFrequency.extEndcAllowedPlmnListPolicy for the corresponding frequency |

Table 10-8 - Handling of endcAllowedPlmnList

See the feature description in CPI for further information.

### 10.2.12 TM9 Capability-Aware Idle Mode Control (FAJ 121 5153) - LTE

Note: This licensed eNodeB feature is for Baseband Radio Nodes.

<!-- page: 268 -->

This feature is similar to the feature Capability-Aware Idle Mode Control (CAIMC, Section 10.2.10) but rather than targeting EN-DC capable UEs, it targets TM9 capable UEs.  Its purpose is to encourage TM9 capable UEs to camp on a frequency which they can use for TM9. As with CAIMC, the feature alters the cell reselection priorities used by the UE to reselect between frequencies in idle mode; higher priorities are given to TM9 capable frequencies. Priorities are determined by hit rate statistics if either of the features Best Neighbor Relations for Intra-LTE Load Management or Cell Sleep Mode is active and the attribute UePolicyOptimization.coverageAwareImc = true . If not, priorities are determined by the count of TM9 capable neighbor cells on each frequency.

If both the features Capability-Aware Idle Mode Control and TM9 Capability-Aware Idle Mode Control are active, then the attribute UePolicyOptimization.ueCapPrioList determines whether EN-DC or TM9 is given priority, as described in 10.2.10.

See the feature description in CPI for further information.

### 10.2.13 EN-DC Triggered Handover During Setup (FAJ 121 5097) - NSA

The purpose of EN-DC triggered handover (ENDCHO) is to move the UE to another LTE cell which is better suited to provide it with EN-DC. Another cell is better suited in the following cases:

- The UE cannot use the serving LTE cell for EN-DC, for example because the cell is not capable of EN-DC, or because the UE does not support the EN-DC band combinations available on the cell, or because the combination of LTE and NR frequencies has been manually disallowed on the serving LTE cell. The UE can, however, use another LTE cell for EN-DC.

- The UE can use the serving LTE cell for EN-DC, but the UE does not have coverage from the required NR frequency(s). However, the UE does have coverage from a lower priority NR frequency that the UE can use for EN-DC if it moves to another LTE cell.

- The UE can use the serving LTE cell for EN-DC and the UE has coverage from the required NR frequency(s). However, the UE also has coverage from a higher priority NR frequency that it can use for EN-DC if it moves to another LTE cell.

There are two licensed eNodeB features which provide ENDCHO functionality:

- EN-DC Triggered Handover During Setup - FAJ 121 5097

This feature is for Baseband Radio Nodes. It provides ENDCHO which is triggered at initial context setup. It uses B1 measurements to check for coverage from NR target frequencies and A5 measurements to check for coverage from target LTE frequencies. If coverage from a suitable NR and LTE frequency combination is found, then ENDCHO is performed and all the cells in the valid B1 measurement reports are forwarded to the target cell during the LTE handover.

- EN-DC Triggered Handover During Connected Mode Mobility - FAJ 121 5243

<!-- page: 269 -->

This feature is for Baseband Radio Nodes. It is similar to EN-DC Triggered Handover During Setup , except that it triggers ENDCHO at incoming intra-frequency, interfrequency, inter-RAT handover and at RRC connection re-establishment, rather than at setup. It also uses B1 and A5 measurements to check for coverage. This feature is further described in Section 10.2.15.

The rest of this section describes functionality that is relevant primarily to features 1 and 2 above. It explains how the ENDCHO and Basic Intelligent Connectivity features work together to determine whether to perform SN addition on the serving cell, or perform ENDC triggered handover, or use LTE only. A high-level overview of the interaction is shown in Figure 10-14.

![Figure on page 269](5G_Mobility_and_Traffic_Management_Guideline_images/page_269_image_002.png)

Figure 10-14 - Interaction between SN addition and ENDCHO processes

ENDCHO is allowed if ENodeBFunction.endcAllowed = true or if the UE belongs to a subscriber group that has EndcUserProfile.endcAllowedOverride = true . If so, the serving eNodeB searches for suitable combinations of target LTE and NR frequencies. A combination is considered suitable for ENDCHO if all of the following conditions are met:

- The serving LTE cell must have a GUtranFreqRelation to the target NR frequency, with GUtranFreqRelation.endcB1MeasPriority not equal to -1. This allows the NR frequency to be measured, either for SN addition or for ENDCHO.

<!-- page: 270 -->

̶

- The NR frequency has not been selected by BIC as suitable for SN addition on the serving LTE cell. An NR frequency cannot be selected as a candidate for both SN addition and ENDCHO, it is selected for either one or the other. An NR frequency is suitable for SN addition if:

̶

- endcAllowedPlmnList is not empty and a PLMN match is found with the UE as described in Section 6.2.3.1

̶

- The band combination is supported by the UE

- The serving LTE frequency is not listed in GUtranFreqRelation.endcNotAllowedEUtranFreqRef for the NR frequency.

- The serving LTE cell must have an EUtranFreqRelation to the target LTE frequency, with EUtranFreqRelation.endcHoFreqPriority not equal to -1. This allows the target LTE frequency to be measured.

- The target LTE frequency is not listed in the endcNotAllowedEUtranFreqRef attribute contained in the GUtranFreqRelation from the serving LTE cell to the NR frequency.

- The UE must support EN-DC on a band combination which includes both the target NR and target LTE frequencies.

- The UE is not prohibited from using EN-DC by the NR restriction (see Section 6.2.3.1).

- At least one ' EN-DC capable ' cell must exist on the target LTE frequency. To be considered ' EN-DC capable ' , the cell must support EN-DC on a PLMN which can be used by the UE. More specifically, at least one of the serving or equivalent PLMN identities listed in the UE's HRL must match one of the identities configured in the endcAllowedPlmnList of at least one cell on the target LTE frequency. If the HRL is not available, the ExternalENodeBFunction.eNodeBPlmnId is used instead.

̶

- For cells on the serving eNodeB, the endcAllowedPlmnList contained in the EUtranCellFDD or EUtranCellTDD MO is used.

̶

- For cells on another eNodeB, the endcAllowedPlmnList in the ExternalEUtranCellFDD or ExternalEUtranCellTDD MO is used. This list is populated automatically when the X2 link is configured between the two eNodeBs, provided that the feature Basic Intelligent Connectivity is active in the other LTE cell.

- Note that no check is made to confirm that the 'EN - DC capable' cell is actually configured to support EN-DC with the target NR frequency. The only requirement is the PLMN match, described above.

̶

If no suitable combinations of target LTE and NR frequencies are found, then ENDCHO is not possible. In this case, measurements are configured for SN addition on the current serving cell only (assuming this is possible, as described in Section 10.2.1).

<!-- page: 271 -->

If at least one suitable combination of target LTE and NR frequencies is found, ENDCHO is possible. The eNodeB then configures B1 measurements to detect coverage from NR cells and A5 measurements to detect coverage from the LTE cells. These measurements use the same framework as the measurements for SN addition, described in Section 10.2.1:

- If Buffer-Based EN-DC Setup is active, then the downlink or uplink user plane data must exceed the threshold conditions (described in Section 10.2.1.8) before setting up B1 measurements.

- The B1 and A5 measurements are configured together in the same RRC reconfiguration messages.

̶

- Note that in the current software revision, ENDCHO requires that the feature Dynamic SCell Selection for Carrier Aggregation is active, because the functionality contained in that feature enables the configuration of the A5 measurements.

- The B1 and A5 measurements for ENDCHO are configured in a similar way to the measurements for SN addition on the serving cell. This is described in full detail in Section 10.2.1.2, with particular reference to the RRC reconfiguration sequences (shown in Figure 10-2) and the repetition patterns (shown in Figure 10-5).

- When prioritizing NR frequencies for B1 measurement, no distinction is made between frequencies which have been chosen for ENDCHO and frequencies which have been chosen for SN addition on the serving cell. They are all ranked together using the priorities set in GUtranFreqRelation.endcB1MeasPriority ; 7 is the highest priority, 0 is the lowest priority and -1 means that the frequency is excluded.

- The B1 measurements use the attributes configured in ReportConfigB1GUtra , for example: b1ThresholdRsrp , hysteresisB1 and timeToTriggerB1 , along with any offset configured in GUtranFreqRelation . Some of these attributes can be overridden at the frequency relation level, or at the subscriber group level by the ASGH Framework feature. See Section 10.2.1.2 and 11.2.2 for more detail.

- For the A5 measurements, the priority for including LTE frequencies is determined by the attribute EUtranFreqRelation.endcHoFreqPriority ; 7 is the highest priority, 0 is the lowest priority and -1 means that the frequency is excluded.

- The A5 measurements use the attributes configured in the MO ReportConfigA5EndcHo , for example: a5Threshold1Rsrp , a5Threshold2Rsrp , hysteresisA5 , timeToTriggerA5 . It is possible to use RSRQ for triggering A5, by setting triggerQuantityA5 = RSRQ . However, RSRP is recommended. See Section 11.2.6 for more detail.

Figure 10-15 gives an example of how the eNodeB chooses the frequencies to include in each message. In this example, the serving cell uses frequency LTE2, which is configured for EN-DC with frequency NR2 only.

<!-- page: 272 -->

![Figure on page 272](5G_Mobility_and_Traffic_Management_Guideline_images/page_272_image_002.png)

Figure 10-15 - EN-DC Triggered Handover During Setup - How eNodeB Chooses Frequencies

Notes for Figure 10-15:

- List the NR frequencies which have a GUtranFreqRelation MO configured under the serving LTE cell. Order them by GUtranFreqRelation.endcB1MeasPriority . Include the priority group of each frequency (as explained in Section 10.2.1.1.) and the frequency band.  In this example, frequency NR3 is contained in two NR bands (n77 and n78).

- List the band combinations supported by the UE for EN-DC.

- Eliminate those NR bands which are not supported by the UE for EN-DC, assumed to be n77 and n51 in this example.

- Eliminate those NR frequencies which are not included in any band supported by the UE for EN-DC, namely NR4.

- List the LTE frequencies which have an EUtranFreqRelation MO configured from the serving LTE cell with endcHoFreqPriority not equal to -1.

- Eliminate those LTE bands which are not supported by the UE for EN-DC, namely b28.

- Eliminate those LTE frequencies which are not included in any band supported by the UE for EN-DC, namely LTE5.

- Eliminate any LTE frequencies which have no EN-DC capable cells; assume LTE4 in this example.

- Eliminate the frequency of the serving LTE cell; LTE2 in this example. EN-DC triggered handover is not required for this frequency.

<!-- page: 273 -->

̶

̶

- Remove any combinations of LTE and NR frequencies that are forbidden by GUtranFreqRelation.endcNotAllowedEUtranFreqRef (no examples of this are shown here).

- By combining the tables in steps 1, 2 and 5, list the NR and LTE frequency combinations which remain valid for EN-DC, and the NR frequencies which remain valid for SN addition. For example, looking at the yellow highlighted cells, frequency NR1 is in NR band n260 which the UE can use with LTE bands b1 and b5 for EN-DC, and these bands have EN-DC capable frequencies LTE1 and LTE3 implemented in the network. Note that NR2 is configured for EN-DC on the serving LTE cell, so no matching LTE frequencies are listed against NR2.

- Combine the NR and LTE frequencies into a maximum of three RRC reconfiguration messages to the UE, using the Priority Group rules described in Section 10.2.1.2. In this example, the first message contains the priority group 1 NR frequencies and the matching LTE frequencies. The second message contains the priority group 2 NR frequencies, and the matching LTE frequency. Up to maxMeasB1Endc NR frequencies can be included in each message. The number of LTE frequencies which can be included is more complicated to determine; refer to the LTE Mobility and Traffic Management Guideline for more details. If not all of the LTE frequencies can be included, endcHoFreqPriority is used to prioritize. Note that the same LTE frequency can be included in more than one RRC reconfiguration message.

When the eNodeB receives the B1 and A5 measurement reports, it evaluates them using the following procedure:

- When the eNodeB receives a B1 report, it immediately initiates SN addition if both the UE and serving cell allow EN-DC with the reported frequency.

̶

- If not, the eNodeB stores the B1 report and waits for an A5 report that results in a valid band combination for ENDCHO.

- When the eNodeB receives an A5 report, it determines whether the report contains a valid LTE target cell. To be valid, the following conditions must be met:

̶

- Given that the UE has sent the report, the triggering condition (based on either RSRP or RSRQ, as set by triggerQuantityA5 ) is already satisfied. However, if reportQuantityA5 = BOTH , then the eNodeB also checks that the non-triggering quantity (the quantity that triggerQuantityA5 is not set to) is also satisfied. This is fully described in Section 11.2.6.

̶

- A B1 report for one or more NR frequencies has already been received, within the report interval of NR B1, ReportConfigB1GUtra . reportIntervalB1 (default value 240 ms)

- To allow the B1 to arrive first, set the time to trigger for the A5 longer than that of the B1.

- The UE is capable of an EN-DC band combination which includes the reported LTE frequency and one of the above-mentioned NR frequencies, and the LTE/NR frequency combination is not prohibited for use by GUtranFreqRelation.endcNotAllowedEUtranFreqRef .

<!-- page: 274 -->

̶

̶

̶

̶

̶

- The reported LTE cell is ' EN-DC capable ' ; in other words, at least one of the serving or equivalent PLMN identities listed in the UE's HRL matches one of the identities configured in the target cell's endcAllowedPlmnList . If the HRL is not available, the ExternalENodeBFunction.eNodeBPlmnId is used instead.

- If the reported LTE cell is hosted by the serving eNodeB, then prerequisites for SN addition on the cell must be satisfied. This includes checking that isEndcAllowed = true on the GUtranCellRelation from the reported LTE cell to the relevant NR cell.

- If the reported LTE cell is hosted by another eNodeB, then there is no check to confirm that the reported LTE cell supports EN-DC with the reported NR cell or any cell on the reported NR frequency. If it does not, then it may not be possible to set up EN-DC once the LTE handover has been performed.

- isHoAllowed = true and mobilityStatus . available = true on the EUtranCellRelation

- The HRL of the UE allows a handover to the cell.

̶

- The reported target cell is not blocked due to Cell Soft Lock

- If multiple LTE cells in a measurement report satisfy the above criteria, then the one with the highest RSRP or RSRQ (depending on triggerQuantityA5 ) is selected.

̶

- If a voice bearer is introduced with ARP settings that forbid other bearers being split, and an FR1 B1 measurement is ongoing, then all the B1 and A5 measurements in the corresponding RRC reconfiguration message are removed, for both FR1 and any FR2 measurements which may be present, and the measurements are not reconfigured if the voice bearer is removed.

In addition, the eNodeB checks the following conditions for the UE:

- Multimedia Broadcast Multicast Services (MBMS) interest indication for the UE is not set to the serving frequency.

- The guard timer for mobile originated voice calls is not running for the UE (refer to Section 6.2.3.1)

If a valid LTE target cell is found and the above-listed UE conditions are met, then the eNodeB instructs the UE to perform the EN-DC triggered handover. During the LTE handover, all valid B1 measurement reports (one per NR frequency) are forwarded to target LTE eNodeB. Valid means that less than

ReportConfigB1GUtra . reportIntervalB1 (default value 240 ms) has elapsed since that B1 report was received.

<!-- page: 275 -->

After completion of incoming ENDCHO, the forwarded B1 measurements are used for SN addition, assuming that the relevant prerequisites are met. If the forwarded measurements contain multiple frequencies, then the eNodeB uses endcB1MeasPriority to prioritize amongst them. In the case of equal priorities, a round-robin algorithm is used. The forwarded B1 measurement can be used even if the incoming handover is from another vendor, via X2 or S1.

If SN addition using the forwarded B1 measurement result fails, then the eNodeB starts new B1 measurements following the normal procedure for SN addition.

If configuration-based SN addition is used in the target LTE cell ( EUtranCellFDD/TDD.extGUtranCellRef is set), then the eNodeB does not use the forwarded B1 information. Instead, EN-DC setup is performed using configuration-based SN addition.

#### 10.2.13.1 Multiple Frequency Band Indicator for ENDCHO

**To enable overlapping LTE bands to be used for ENDCHO, set**

ENodeBFunction.endcAwareMfbiIntraCellHo = true on both the source and target eNodeBs. This allows the source eNodeB to consider overlapping LTE bands when determining which band combinations are supported by both the UE and eNodeB, and therefore which LTE and NR frequencies the UE must measure for ENDCHO. For the target eNodeB, which receives the incoming ENDCHO, it allows the eNodeB to consider overlapping bands when using the forwarded B1 report for SN addition.

Figure 10-16 shows two examples of using overlapping bands for ENDCHO. UE A performs an ENDCHO to the primary band, after which the target eNodeB uses the forwarded B1 report to initiate an intra-cell handover to the overlapping band to allow ENDC setup. UE B performs an ENDCHO directly to the overlapping band, and the target eNodeB uses the forwarded B1 report to set up EN-DC.

<!-- page: 276 -->

![Figure on page 276](5G_Mobility_and_Traffic_Management_Guideline_images/page_276_image_002.png)

Figure 10-16 - ENDCHO with Overlapping Frequency Bands

When endcAwareMfbiIntraCellHo = true , overlapping LTE bands are considered for by the following EN-DC triggered handover features:

- EN-DC-Triggered Handover During Setup

- EN-DC-Triggered Handover During Connected Mode Mobility

For consistent behavior, the attribute endcAwareMfbiIntraCellHo should be set to the same value across the network.

#### 10.2.13.2 ENDCHO - Interaction of UE Capability, Priority and Coverage

Figure 10-17 provides examples of how EN-DC behaves in the complex case of a multilayer, multi-priority network, with varying NR coverage and differing UE capabilities.

<!-- page: 277 -->

![Figure on page 277](5G_Mobility_and_Traffic_Management_Guideline_images/page_277_image_002.png)

Figure 10-17 - ENDCHO - Interaction of UE Capability, Priority and Coverage

Notes for Figure 10-17:

- Both LTE cells (LTE1 and LTE2) are configured for EN-DC with both NR cells (NR1 and NR2). NR2 is configured with a higher endcB1MeasPriority (7) than NR1 (5).

- The figure shows four UEs, (A, B, C and D) in different positions (1, 2, 3, and 4). The EN-DC combinations supported by the UEs are indicated by the colors. For example, UE D supports all EN-DC combinations, whereas UE A only supports LTE2 + NR1.

The behavior of each UE is shown in Table 10-9.

Table 10-9 - ENDCHO - Interaction of UE Capability, Priority and Coverage

| UE    | Measurement Order                   | Behavior                                                                                                      |
|-------|-------------------------------------|---------------------------------------------------------------------------------------------------------------|
| UE_A1 | 1) B1 → NR2                         | UE reports NR2 and sets up EN-DC on serving cell.                                                             |
| UE_A2 | 1) B1 → NR2                         | UE has no coverage from NR2, the measurement times out and EN-DC cannot be set up.                            |
| UE_A3 | 1) B1 → NR2 + A5 → LTE2             | UE reports NR2 and LTE2 and performs ENDCHO                                                                   |
| UE_A4 | 1) B1 → NR2 + A5 → LTE2             | UE reports LTE2 but has no coverage from NR2, the B1 measurement times out and EN-DC cannot be set up.        |
| UE_B1 | 1) B1 → NR1 + A5 → LTE1             | UE reports NR1 and LTE1 and performs ENDCHO.                                                                  |
| UE_B2 | 1) B1 → NR1 + A5 → LTE1             | UE reports NR1 and LTE1 and performs ENDCHO.                                                                  |
| UE_B3 | 1) B1 → NR1                         | UE reports NR1 and sets up EN-DC on serving cell.                                                             |
| UE_B4 | 1) B1 → NR1                         | UE reports NR1 and sets up EN-DC on serving cell.                                                             |
| UE_C1 | 1) B1 → NR2 2) B1 → NR1 + A5 → LTE1 | UE reports NR2 and sets up EN-DC on serving cell. Second measurements are never configured.                   |
| UE_C2 | 1) B1 → NR2 2) B1 → NR1 + A5 → LTE1 | UE has no coverage from NR2 and the first measurement times out. UE reports NR1 and LTE1 and performs ENDCHO. |
| UE_C3 | 1) B1 → NR2 + A5 → LTE2 2) B1 → NR1 | UE reports NR2 and LTE2 and performs ENDCHO Second measurement is never configured.                           |

Table 10-9 - ENDCHO - Interaction of UE Capability, Priority and Coverage

<!-- page: 278 -->

| UE    | Measurement Order                   | Behavior                                                                                                                                   |
|-------|-------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------|
| UE_C4 | 1) B1 → NR2 + A5 → LTE2 2) B1 → NR1 | UE reports LTE2 but has no coverage from NR2 and the first B1 measurement times out. UE reports NR1 and sets up EN-DC on the serving cell. |
| UE_D1 | 1) B1 → NR2 2) B1 → NR1             | UE reports NR2 and sets up EN-DC on serving cell. Second measurement is never configured                                                   |
| UE_D2 | 1) B1 → NR2 2) B1 → NR1             | UE has no coverage from NR2 and the first measurement times out. UE reports NR1 and sets up EN-DC on serving cell.                         |
| UE_D3 | 1) B1 → NR2 2) B1 → NR1             | UE reports NR2 and sets up EN-DC on serving cell. Second measurement is never configured.                                                  |
| UE_D4 | 1) B1 → NR2 2) B1 → NR1             | UE has no coverage from NR2 and the first measurement times out. UE reports NR1 and sets up EN-DC on serving cell.                         |

The key takeaways for ENDCHO are:

- For a particular UE, a given NR frequency is considered as a candidate for either ENDCHO or SN addition on the serving cell, never both.

- ENDCHO therefore enables a UE to access EN-DC using an NR frequency that is not a valid candidate for SN addition on the serving cell.

- If all configured NR frequencies are valid candidates for SN addition for a given UE, then ENDCHO will never occur for that UE, regardless of coverage or priority settings.

- The preference among the NR frequencies is determined by the order of the measurements, which is controlled by GUtranFreqRelation.endcB1MeasPriority . The timeouts involved with measuring multiple frequencies can be reduced through the careful choice of priorities, as described in 10.2.1.2.

- To maximize EN-DC availability, ensure that all NR cells which cover the serving LTE cell have a GUtranFreqRelation defined, with endcB1MeasPriority not equal to -1 and a GUtranCellRelation with isEndcAllowed = true .

#### 10.2.13.3 ENDCHO Parameters

The key parameters for this feature are:

Table 10-10 - Parameters for EN-DC Triggered Handover During Setup

| Attribute (RAT)MO                            | Values (default) [unit]   | Description                                                                                                                                                                                                     |
|----------------------------------------------|---------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| endcAwareMfbiIntraCellHo (eNB)ENodeBFunction | true, false (false)       | Whether functionality to support LTE MFBI for EN-DC setup and EN-DC Triggered Handover is activated.                                                                                                            |
| endcB1MeasPriority (eNB) GUtranFreqRelation  | -1, 0 to 7 (4)            | NR frequency priority for EN-DC measurements. Highest priority is 7. Lowest priority is 0. Value -1 means that the frequency is excluded. Frequencies with the same priority are selected and ordered randomly. |

Table 10-10 - Parameters for EN-DC Triggered Handover During Setup

<!-- page: 279 -->

| Attribute (RAT)MO                                     | Values (default) [unit]                                                     | Description                                                                                                                                                                                                                          |
|-------------------------------------------------------|-----------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| endcNotAllowedEUtranFreq Ref (eNB) GUtranFreqRelation | { … }                                                                       | List of references to LTE frequencies that are not allowed for EN-DC in combination with the NR frequency relation. Can be used to disable SN addition or ENDCHO for certain frequency combinations.                                 |
| endcHoFreqPriority (eNB) EUtranFreqRelation           | -1, 0 to 7 (7)                                                              | LTE frequency priority for EN-DC Triggered Handover During Setup . Highest priority is 7. Lowest priority is 0. Value -1 means that the frequency is excluded. Frequencies with the same priority are selected and ordered randomly. |
| endcMeasTime (eNB) UeMeasControl                      | -1, 40 to 120000 (2000) [ms]                                                | Time in which UE performs measurements requested in each RRC reconfiguration message for EN-DC. Value -1 means infinity.                                                                                                             |
| endcMeasRestartTime (eNB) UeMeasControl               | -1, 0 to 240000 (-1) [ms]                                                   | Time to wait for next B1 array (up to three sets of B1 measurement configuration) for EN-DC.                                                                                                                                         |
| a5Threshold1Rsrp (eNB) ReportConfigA5EndcHo           | -140 to -44 (-44) [dBm]                                                     | Serving cell RSRP threshold for A5. Used only if triggerQuantityA5 is set to RSRP.                                                                                                                                                   |
| a5Threshold2Rsrp (eNB) ReportConfigA5EndcHo           | -140 to -44 (-112) [dBm]                                                    | Target cell RSRP threshold for A5. Used only if triggerQuantityA5 is set to RSRP.                                                                                                                                                    |
| a5Threshold1Rsrq (eNB) ReportConfigA5EndcHo           | -195 to -30 (-30) resolution 5 [0.1 dB]                                     | Serving cell RSRQ threshold for A5. Used only if triggerQuantityA5 is set to RSRQ.                                                                                                                                                   |
| a5Threshold2Rsrq (eNB) ReportConfigA5EndcHo           | -195 to -30, resolution 5 [0.1 dB] (-150)                                   | Target cell RSRQ threshold for A5. Used only if triggerQuantityA5 is set to RSRQ.                                                                                                                                                    |
| reportAmountA5 (eNB) ReportConfigA5EndcHo             | 0, 1, 2, 4, 8, 16, 32, 64 (0)                                               | Number of reports for periodical reporting for Event A5 measurement. 0 means that reports are sent as long as the event is fulfilled.                                                                                                |
| reportIntervalA5 (eNB) ReportConfigA5EndcHo           | Various values from 120 ms to 60 min (480 ms)                               | Interval for event-triggered periodical reporting for Event A5 measurement.                                                                                                                                                          |
| triggerQuantityA5 (eNB) ReportConfigA5EndcHo          | RSRP, RSRQ (RSRP)                                                           | Quantity that triggers Event A5 for Event A5 measurement.                                                                                                                                                                            |
| timeToTriggerA5 (eNB) ReportConfigA5EndcHo            | 0,40,64,80,100128,16 0,256, 320,480,512 640,1024,1280,2560, 5120 (100) [ms] | Time-to-trigger value for Event A5. Used for both RSRP and RSRQ.                                                                                                                                                                     |
| hysteresisA5 (eNB) ReportConfigA5EndcHo               | 0 to 150, (10) resolution 5 [0.1 dB]                                        | The hysteresis value for Event A5 measurement.                                                                                                                                                                                       |

### 10.2.14 Enhanced NR Restriction (FAJ 121 5212) - NSA

This licensed eNodeB feature allows access to EN-DC to be controlled per NR frequency range. It modifies how the eNodeB handles the NR Restriction in EPS as Secondary RAT IE in the Handover Restriction List (HRL), as follows:

- If this feature is not active, UEs which have the NR restriction in the HRL are completely prevented from using EN-DC.

<!-- page: 280 -->

- If this feature is active, UEs which have the NR restriction may access EN-DC on FR1 (low-band and mid-band) NR frequencies, but are prevented from accessing EN-DC on FR2 (high-band) NR frequencies. This allows an operator who has both FR1 and FR2 to reserve the FR2 spectrum for 'prioritized' users only; namely users that do not have the NR restriction. To achieve this outcome, the Enhanced NR Restriction feature removes the FR2 bands from the capability enquiry message that it sends to the UE, so the UE 's response cannot include FR2 bands , which makes the UE appear incapable of FR2.

This feature is provided because 3GPP does not currently support EN-DC restriction at the frequency range level.

Note: If ENodeBFunction.zzzTemporary67 = 1 , then the functions NR Restriction and Enhanced NR Restriction are disabled and all EN-DC capable UEs in the eNodeB are treated as not NR restricted.

### 10.2.15 EN-DC Triggered Handover During Connected Mode Mobility (FAJ 121 5243) - NSA

This licensed eNodeB feature is similar to the feature EN-DC Triggered Handover During Setup , but instead triggers EN-DC triggered handover (ENDCHO) at an incoming handover (either IRAT or intra-LTE) and at RRC re-establishment in LTE. Apart from the different trigger, the two features follow the same procedures; refer to Section 10.2.13 for details.

**To enable overlapping LTE bands to be used for ENDCHO, set**

ENodeBFunction.endcAwareMfbiIntraCellHo = true . See Section 10.2.13.1 for more details.

Figure 10-18 gives two examples of EN-DC triggered handover during connected mode mobility. Note that the figure is designed purely to illustrate the functionality; it does not illustrate a recommended configuration.

![Figure on page 280](5G_Mobility_and_Traffic_Management_Guideline_images/page_280_image_002.png)

Figure 10-18 - EN-DC Triggered Handover During Connected Mode Mobility

<!-- page: 281 -->

Consider the two UEs shown in Figure 10-18, A and B. The colors show which band combinations the UEs support for EN-DC; namely LTE1 + NR1 and LTE2 + NR2. It is the limited band combination capability which causes the EN-DC triggered handover.

UE A :    This shows an example where coverage from the highest priority NR frequency runs out, so ENDCHO sends the UE to an LTE cell where it can set up EN-DC with a lower priority NR frequency. The UE starts on the left, where it has EN-DC using LTE2A + NR2A.  As the UE moves out of NR2A coverage, EN-DC is deconfigured due to A2 critical release or radio link failure on the NR leg. Eventually the intra-frequency handover between the LTE2A and LTE2B occurs. After the handover, the UE is configured with a B1 measurement for NR2 (the higher priority NR frequency) for SN addition. However, there is no coverage from NR2, so this measurement times out. The UE is reconfigured with a B1 measurement for NR1 (the lower priority NR frequency) and an A5 measurement for LTE1. The UE finds NR1 and A5 LTE1 and reports both, and an ENDCHO occurs to LTE1 B. The B1 measurement report for NR1 is forwarded to the target LTE1 B, the SN addition is initiated after the LTE Handover.

UE B: This shows an example where ENDCHO does not occur. It does not occur because both the source and target LTE cells can use NR1A as a PSCell, so the LTE handover occurs without relocating the PDCP context from SN to MN (as described in Section 10.2.1.7, LTE Handover Without Secondary Node Change) and this does not trigger ENDCHO. So, in this case, ENDCHO from LTE1A to LTE2A occurs only when the UE enters idle mode and then re-enters connected mode. This triggers ENDCHO at setup to enable EN-DC with the higher priority frequency (NR2).

### 10.2.16 Automated Neighbor Relations (FAJ 121 0497) - NSA and SA

Automated Neighbor Relations (ANR) is a licensed eNodeB feature that enables the automatic creation and removal of the managed objects associated with neighbor relations.

The feature manages relations from LTE to LTE, and LTE to other RATs. This section focusses on the relations from LTE to NR, which are used for both NSA (EN-DC) and SA.

For these neighbor relations, ANR is triggered when the eNodeB receives a B1 report containing an unknown NR PCI. The resulting ANR mechanism can be either PCI-based or NCGI-based. Which option can be used depends on the frequency range and the mobility event which triggers ANR, as summarized in Table 10-11. These cases are described in the following sections.

Table 10-11 - Supported ANR Mechanisms

|             | Triggered by B1 report for …   | Triggered by B1 report for …            |
|-------------|--------------------------------|-----------------------------------------|
|             | ENDC Setup                     | Frequency Band RwR or HO from LTE to SA |
| PCI or NCGI |                                | FR1: Low & Mid NCGI                     |
| PCI         | -                              | FR2: High                               |

Table 10-11 - Supported ANR Mechanisms

The feature is also responsible for neighbor removal.

<!-- page: 282 -->

̶

In addition to these functions, ANR also forwards neighbor relation information to the gNodeB, where it is used by the gNodeB feature ( NR Automated Neighbor Relations ) for creating NR to NR relations, as described in Section 10.3.16.

ANR can sometimes add a GUtranCellRelation to a distant NR cell that has unreliable coverage. To avoid using such a relation:

- Set isEndcAllowed = false to prevent it being used for EN-DC

- Set isHoAllowed and isVoiceHoAllowed = false to prevent it being used for HO from LTE to NR SA

- Set isRemoveAllowed = false to prevent ANR from removing and recreating the relation, which would reset the above attributes to true , their default values. Note that when ANR creates a relation, it sets isRemoveAllowed = true .

#### 10.2.16.1 Enabling ANR for Low-Band and Mid-Band - NSA

For low and mid-band (FR1) EN-DC, ANR can be either PCI-based or NCGI-based (not both).

To enable PCI-based ANR, perform the following:

- In the eNodeB:

̶

- Activate the feature license for Automated Neighbor Relations (FAJ 121 0497)

- Set ANRFunctionNR . anrStateNR = 0 (DEACTIVATED)

̶

- Set ENodeBFunction . zzzTemporary74 = 1

To enable NCGI-based ANR (based on UE NCGI measurements), perform the following:

- In the eNodeB:

̶

- Activate the feature license for Automated Neighbor Relations (FAJ 121 0497)

̶

- Set ANRFunctionNR . anrStateNR = 1 (ACTIVATED)

̶

- Set GUtranFreqRelation.anrMeasOn = true

- Set ENodeBFunction.endcX2IpAddrViaS1Active = true (to allow X2 TNL Address discovery procedure for an unknown gNodeB)

̶

̶

- Set AnrFunctionNR.essNRNeighborCellInfoUsed = true (This allows ESS NR neighbor cell information to be transmitted to neighbor eNodeBs through X2, which in turn allows ANR in the neighbor eNodeB to use the PCI to create a neighbor relation towards an ESS cell, which does not broadcast SIB1.)

- In the gNodeB:

<!-- page: 283 -->

̶

- Set NRCellDU.secondaryCellOnly = false , to enable SIB1 broadcast

- If an ESS cell is using PRB blanking (flexible channel bandwidth), then SIB1 cannot be broadcast and secondaryCellOnly is set to true .

**Additionally, for ANR to function:**

- The MME must support X2 TNL Address Discovery via S1 based on TS 36.413 V15.5.0 or a later revision.

- The UE must support reportCGI-NR-NoEN-DC-r15 in UE-EUTRA-Capability

#### 10.2.16.2 Neighbor Addition for Low-Band and Mid-Band - NSA

With PCI-based ANR enabled, the procedure for neighbor addition for low-band and midband NR cells is as follows:

- The eNodeB receives, from the UE, a B1 report for EN-DC setup in which the strongest PCI does not have a corresponding GUtranCellRelation , and the RSRP or RSRQ of this PCI meets the following criteria:

̶

- If the trigger quantity for the B1 measurement report is RSRP (Section 11.2.2) then RSRP >= AnrFunctionNR.cellAddRsrpThresholdNR or alternately RSRP >= GUtranFreqRelation.cellAddRsrpThrNROverride if it is not set to -1000

̶

- If the trigger quantity for the B1 measurement report is RSRQ (Section 11.2.2) then RSRQ >= AnrFunctionNR.cellAddRsrqThresholdNR or alternately RSRQ >= GUtranFreqRelation.cellAddRsrqThrNROverride if it is not set to -1000

- If no ExternalGUtranCell exists for the reported PCI, then the B1 report is discarded.

- If an ExternalGUtranCell exists for the reported PCI, then the ENodeB creates a corresponding GUtranCellRelation under the EUtranCellFDD/TDD.GUtranFreqRelation

- A new B1 report must be received to trigger EN-DC setup.

- Creation (or removal) of a cell relation can trigger an automatic update of the upper layer indication, as described in Section 10.2.1.5.

With NCGI-based ANR enabled, steps 2 onwards are replaced as follows:

- The eNodeB deconfigures the B1 measurement and configures a measurement in the UE to determine the NR Cell Global Identity (an NCGI measurement)

̶

- However, if the UE has a voice call in progress (namely serviceType = VOIP, PTT or MC_SIGNALING), the NCGI measurement cannot be configured, and the B1 report is discarded.

<!-- page: 284 -->

̶

- If the eNodeB receives an NCGI measurement report that contains the NCGI:

̶

- If the gNodeB is unknown, then the eNodeB creates ExternalGNodeBFunction under GUtraNetwork , and TermPointToGNB under ExternalGNodeBFunction ; which triggers X2 setup.

- To acquire the IP address of the gNodeB, the eNodeB uses the X2 TNL Address Discovery Procedure on the S1 interface to the MME. This procedure requires that at least one EN-DC X2 is already manually defined from another eNodeB to the gNodeB, within the same MME.

- The eNodeB creates the ExternalGNodeBFunction.ExternalGUtranCell and EUtranCellFDD/TDD.GUtranCellRelation

- If the eNodeB receives an NCGI measurement report that does not contain the NCGI, and instead contains the indicator noSIB1 :

̶

- The eNodeB tries to use the reported PCI to find the NR cell in its ExternalGUtranCell MOs or in its stored neighbor information for NR ESS cells.

- The stored neighbor information for NR ESS cells is created as follows: If an NR ESS cell does not transmit SIB1, then its host eNodeB shares information about the cell over X2. This information is then used to create neighbor relations towards the cell. To enable this sharing, set AnrFunctionNR.essNRNeighborCellInfoUsed = true in both the eNodeB containing the ESS cell and the neighboring eNodeBs that receive the information.

- If the cell is found, then any missing neighbor relation MOs are created as described above.

̶

- Creation (or removal) of a cell relation can trigger an automatic update of the upper layer indication, as described in Section 10.2.1.5.

- After NCGI measurements are finished, the eNodeB reconfigures the B1 measurement in the UE to detect NR coverage, as described in Section 10.2.1.2. A new B1 report must be received from the UE to trigger EN-DC setup.

#### 10.2.16.3 Enabling ANR for High-Band - NSA

To enable ANR (PCI-based) for high-band (FR2), perform the following:

- In the eNodeB:

̶

- Activate the feature license for Automated Neighbor Relations (FAJ 121 0497)

̶

- Set ENodeBFunction.zzzTemporary74 = 1 , to enable PCI-based ANR

<!-- page: 285 -->

#### 10.2.16.4 Neighbor Addition for High-Band Cells - NSA

The procedure for neighbor addition by ANR for high-band is different, because some UE vendors do not support the NCGI measurement on high-band. The procedure for PCIbased ANR is as follows:

- The eNodeB receives, from the UE, a B1 report for EN-DC setup in which the strongest PCI does not have a corresponding GUtranCellRelation , and the RSRP or RSRQ of this PCI meets the following criteria:

̶

- If the trigger quantity for the B1 measurement report is RSRP (Section 11.2.2) then RSRP >= AnrFunctionNR.cellAddRsrpThresholdNR or alternately RSRP >= GUtranFreqRelation.cellAddRsrpThrNROverride if it is not set to -1000

̶

- If the trigger quantity for the B1 measurement report is RSRQ (Section 11.2.2) then RSRQ >= AnrFunctionNR.cellAddRsrqThresholdNR or alternately RSRQ >= GUtranFreqRelation.cellAddRsrqThrNROverride if it is not set to -1000

- If no ExternalGUtranCell exists for the reported PCI, then the B1 report is discarded.

- If an ExternalGUtranCell exists for the reported PCI, then the ENodeB creates a corresponding GUtranCellRelation under the EUtranCellFDD/TDD.GUtranFreqRelation

- A new B1 report must be received to trigger EN-DC setup.

- Creation (or removal) of a cell relation can trigger an automatic update of the upper layer indication, as described in Section 10.2.1.5.

#### 10.2.16.5 Enabling ANR for Low-Band and Mid-Band - SA

For low and mid-band (FR1) SA, ANR can be NCGI-based.

To enable NCGI-based ANR, perform the following in the eNodeB:

- Activate the feature license for Automated Neighbor Relations (FAJ 121 0497)

- Set ANRFunctionNR . anrStateNR = 1 ( ACTIVATED )

- Set GUtranFreqRelation . anrMeasOn = true

- ·

- Configure at least one NR frequency with GUtranFreqRelation.connectedModeMobilityPrio not set to = -1

The UE must support reportCGI-NR-EN-DC-r15 or reportCGI-NR-NoEN-DC-r15 in UEEUTRA-Capability.

<!-- page: 286 -->

#### 10.2.16.6 Neighbor Addition for Low-Band and Mid-Band - SA

With NCGI-based ANR enabled for SA, the procedure for neighbor addition for low-band and mid-band NR cells is as follows:

- The eNodeB receives, from the UE, a B1 report for SA mobility in which the strongest PCI does not have a corresponding GUtranCellRelation , and the RSRP or RSRQ of this PCI meets the following criteria:

̶

- If the trigger quantity for the B1 measurement report is RSRP (Section 11.2.2) then RSRP >= AnrFunctionNR.cellAddRsrpThresholdNR or alternately RSRP >= GUtranFreqRelation.cellAddRsrpThrNROverride if it is not set to -1000

̶

- If the trigger quantity for the B1 measurement report is RSRQ (Section 11.2.2) then RSRQ >= AnrFunctionNR.cellAddRsrqThresholdNR or alternately RSRQ >= GUtranFreqRelation.cellAddRsrqThrNROverride if it is not set to -1000

- The eNodeB deconfigures the B1 measurement and configures a measurement in the UE to determine the NR Cell Global Identity (an NCGI measurement)

̶

- However, if the UE has a voice call in progress (namely serviceType = VOIP, PTT or MC_SIGNALING), the NCGI measurement is not configured, and the B1 report is discarded.

- If the eNodeB receives an NCGI measurement report that contains the NCGI:

̶

- If the gNodeB is unknown, then the eNodeB creates ExternalGNodeBFunction under GUtraNetwork.

̶

̶

- If the NR cell is unknown, then the eNodeB creates ExternalGUtranCell under ExternalGNodeBFunction .

- The eNodeB creates the EUtranCellFDD / TDD . GUtranCellRelation

- After NCGI measurements are finished, the eNodeB reconfigures the B1 measurement in the UE to detect NR coverage, as described in Section 10.2.2. A new B1 report must be received from the UE to trigger SA mobility.

#### 10.2.16.7 Neighbor Removal

The procedure for neighbor removal by ANR, for all low-band, mid-band and high-band NR cells is as follows:

ANR auto-removal of cell relations is enabled by ANRFunctionNR.anrStateNR = 1 (ACTIVATED ).

- GUtranCellRelation is removed if:

<!-- page: 287 -->

̶

- GUtranCellRelation . isRemoveAllowed = true

̶

- GUtranCellRelation . essEnabled = false

- The relation has not been used for EN-DC setup or LTE to SA handover for AnrFunction.removeNrelTime (default 7 days)

̶

- ExternalGUtranCell is removed if:

̶

- ExternalGUtranCell . isRemoveAllowed = true

- ExternalGUtranCell is unused for AnrFunction . removeNcellTime (default 30 days)

̶

- Note: ANR cannot create (or re-create) ExternalGUtranCell MOs for NR highband (FR2) cells. Therefore, to prevent their removal by ANR, set isRemoveAllowed = false .

̶

- TermPointToGNB is removed when the last ExternalGUtranCell is removed from the parent ExternalGNodeBFunction

- ExternalGNodeBFunction is removed when no child ExternalGUtranCell exists for AnrFunction . removeNgnbTime (default 7 days)

#### 10.2.16.8 Dynamic Handling of NR Frequency Relations

This function enables ANR to update all of the relevant MOs in the eNodeB when an NR frequency is changed in the gNodeB. This includes the GUtranSyncSignalFrequency , ExternalGUtranCell , GUtranFreqRelation and GUtranCellRelation MOs. Specifically, it removes the need to manually configure the GUtranFreqRelation and GUtranCellRelation MOs. Refer to the eNodeB feature description for Automated Neighbor Relations in CPI for further information.

### 10.2.17 Multiple Frequency Band Indicators (FAJ 121 3054) - LTE

In LTE, frequencies are grouped together into bands, as defined by 3GPP. Some of these bands overlap each other, so a given physical frequency can belong to more than one frequency band. If it does, the frequency is represented by a different EARFCN for each band that it belongs to. When a UE connects to the network, it tells the network which bands and band combinations it supports. In the case of overlapping frequency bands, it is possible that the UE supports only one of the overlapping bands, and not the other(s). If so, the UE cannot use cells on the non-supported band. However, if the feature Multiple Frequency Band Indicators (MFBI) is enabled, then the UE can use the cell on an overlapping band.

<!-- page: 288 -->

Consider the overlapping frequency band example shown in Figure 10-19. The UE is unable to use the cell on the configured EARFCN_X, because the UE does not support Band_X. However, if MFBI is enabled, then the UE can use the cell on EARFCN_Y as a Band_Y cell; it can use an overlapping band. MFBI also allows the use of overlapping bands when configuring UE measurements on other frequencies, when directing a UE to a new target cell and (of particular relevance to this guideline) when setting up EN-DC, as explained in Section 10.2.1.

![Figure on page 288](5G_Mobility_and_Traffic_Management_Guideline_images/page_288_image_002.png)

Figure 10-19 - Overlapping Frequency Bands

### 10.2.18 NR UE Throughput Booster (FAJ 121 5242)

This is a licensed Baseband Radio Node feature in the Differentiated Mobile Broadband value package (FAJ 801 0409).

NR UE Throughput Booster (NUTB) is not a mobility feature, as it does not directly alter any mobility functionality. However, it provides functionality which can detect 5G capable UEs and assign them a specific operator-defined QCI. Other features can then use the modified QCI to differentiate 5G UEs from non-5G UEs, and selectively alter their mobility. For example, Multi-Layer Service-Triggered Mobility can be used to selectively alter the handover thresholds for UEs which are EN-DC capable, to steer them to a suitable anchor carrier.

NUTB works by adding additional triggering conditions in the Advanced Subscriber Group Handling Framework (ASGH) (Section 10.2.5). These additional triggering conditions allow UEs to be assigned to subscriber groups based on the UE's 5G capability or EN -DC configured state. The subscriber group containing the 5G UEs can then be configured to alter the QCI for those assigned UEs. This QCI reassignment is possible only for QCI 6 to 9.

<!-- page: 289 -->

The big advantage of using NUTB is that QCI-based differentiation of 5G UEs is performed automatically, rather than manually in the core network. Furthermore, NUTB can dynamically alter the QCI based on the state of the UE. For example, NUTB can alter the QCI based on whether a UE has an EN-DC connection configured or not. Specific examples on how to use NUTB for anchor carrier control are provided in Sections 9.2.2.2, 9.2.3.2 and 9.2.4.2.

To enable the feature NR UE Throughput Booster , install the license key in the eNodeB and set featureState = ACTIVATED on the FeatureState=CXC4012503 MO instance.

### 10.2.19 LTE Emergency Call Handling with NR Standalone (FAJ 121 5375) - LTE

This is a licensed Baseband Radio Node feature in the VoLTE value package (FAJ 801 0443).

This feature keeps SA capable UEs in LTE for a configurable time when an emergency call is released. The time is set with the attribute Rcs.extendInactEmergency (default 300 sec), which is added to the value of Rcs.tInactivityTimer . This delays the release, which prevents both idle mode reselection to NR SA and handover/release-withredirect to NR SA. The parameter Rcs.extendInactEmMode activates the extension and determines whether the triggering is based on QCI1, QCI5 or both. This feature overrides the feature VoLTE Inactivity Timer Extension and, for emergency calls, replaces any time extension added by that feature. Refer to the feature description in CPI for further information.

### 10.2.20 Incoming NR IRAT Handover (FAJ 121 5118) - SA

This is a licensed eNodeB feature in the value package Basic NR Mobility Support (FAJ 801 1018).

This feature enables incoming IRAT handover from NR SA to LTE. It reduces the packet interruption time and is particularly relevant when the coverage of NR SA is smaller than that of LTE. It requires the N26 interface, which connects the 5G core (5GC) network to the Evolved Packet Core (EPC) network.

See Section 8.3.11 and the CPI document Incoming NR IRAT Handover for more information.

### 10.2.21 PCI Conflict Reporting (FAJ 121 1898)

This licensed eNodeB feature detects PCI conflicts and reports them to the ENM, enabling faster resolution of any conflicts found.

<!-- page: 290 -->

̶

When used together with the gNodeB feature NR PCI Conflict Reporting (Section 10.3.23), PCI conflicts for NR cells can be detected automatically. The automatic detection works by monitoring the random access failure rate during SN addition. If the failure rate exceeds a configurable threshold, then ANR is used to check the identity of the NR cell being accessed. If the identified cell does not have a corresponding ExternalGUtranCell or GUtranCellRelation , then ANR creates the missing instances. If their creation leads to a PCI conflict, then the eNodeB flags the conflict in the ExternalGUtranCell and reports it to ENM. The operator can then take action to resolve the conflict, where feasible.

However, where conflicts remain, the eNodeB attempts to mitigate the problem by handling conflicting PCIs during SN addition as follows:

- If the PCell has a relation to only one cell with a matching PCI, then SN addition proceeds.

- If the reported PCI is unknown (the PCell does not have a relation to a cell with a matching PCI) then the action depends on whether ANR is activated:

̶

- If ANR is activated, ANR attempts to identify the cell using NCGI measurements - refer to Section 10.2.16.

̶

- If ANR is not activated, then the eNodeB takes no action and waits for a new report.

- If the PCell has relations to more than one cell with a matching PCI and at least one of them is a valid EN-DC candidate, then the action depends on whether PCI Conflict Reporting is activated:

̶

- If PCI Conflict Reporting is not activated, then the first matching cell is used for SN addition.

̶

- If PCI Conflict Reporting is activated, pciConflictMitigationNcgiMeas = ENDC_FR1 , GUtranFreqRelation.anrMeasOn = true , and the UE supports NCGI measurements, then a measurement is started to identify the cell. For VoLTE connections, a measurement is started only if pciConflictNcgiVoiceEnabled = true .

- If the reported NCGI matches a cell that the PCell has a relation to, then SN addition proceeds, otherwise ANR creates the required MOs.

- If the NCGI measurement timer expires before the cell is identified, then the eNodeB does not act on the report. The next B1 report with same PCI uses the statistic or manual-based configuration procedure described below.

- If feature PCI Conflict Reporting is activated, and ( pciConflictMitigationNcgiMeas = DISABLED , or GUtranFreqRelation.anrMeasOn = false , or the UE does not support NCGI measurements), then cell selection amongst the matching cells is determined by pciConflictCellSelForEndc as follows:

- OFF - the first cell is used

- AUTO_SELECT - the eNodeB uses:

<!-- page: 291 -->

̶

̶

- the cell with GUtranCellRelation.pciConflictPreferredCellAuto = true , if one exists, otherwise,

- the first identified cell.

- MANUAL_SELECT - the eNodeB uses:

̶

- the first cell with GUtranCellRelation.pciConflictPreferredCellMan = true , if one exists, otherwise,

̶

- the first identified cell.

- AUTO_SELECT_OVER_MANUAL - the eNodeB uses:

̶

- the cell with GUtranCellRelation.pciConflictPreferredCellAuto = true , if one exists, otherwise,

̶

- the first cell with GUtranCellRelation.pciConflictPreferredCellMan = true , if one exists, otherwise,

̶

- the first identified cell.

- MANUAL_SELECT_OVER_AUTO - the eNodeB uses:

̶

- the first cell with GUtranCellRelation.pciConflictPreferredCellMan = true , if one exists, otherwise,

̶

- the cell with GUtranCellRelation.pciConflictPreferredCellAuto = true , if one exists, otherwise,

̶

- the first identified cell.

The eNodeB automatically sets pciConflictPreferredCellAuto based on EN-DC setup statistics.

For more information, refer to the feature description for PCI Conflict Reporting in CPI.

### 10.2.22 Optimized UE Distribution for EN-DC (FAJ 121 5657) - NSA

This licensed eNodeB feature provides a mechanism for distributing EN-DC traffic amongst the available NR carriers, by altering the order in which the NR carriers are measured for the purpose of EN-DC setup, SCG addition and EN-DC triggered handover (ENDCHO).

The operation of the feature depends on the load in the LTE anchor cell. Every 5 seconds, the number EN-DC connected users in the LTE anchor cell is compared with EndcDistrProfile.endcUserThreshold . The result of the comparison determines how the NR carriers are measured during the next 5 seconds, as follows:

<!-- page: 292 -->

- If EN-DC connected users < endcUserThreshold , or if endcUserThreshold = -1, then the order in which the NR carriers are measured remains as described in Section 10.2.1.2. The traffic distribution is therefore unchanged by this feature.

- If EN-DC connected users >= endcUserThreshold , or if endcUserThreshold = 0, then the measurement order is impacted by the settings in the MO EndcDistrProfile , with the purpose of altering the traffic distribution. There are three options: a distribution model, a list of mandatory frequencies, or both. Which option is used depends on how the attributes are set, as shown in Figure 10-20 and further described below.

![Figure on page 292](5G_Mobility_and_Traffic_Management_Guideline_images/page_292_image_002.png)

Figure 10-20 - Three Options for Configuring EndcDistrProfile

**Option 1:  Distribution Model**

With this option, each NR frequency can be assigned a percentage of UEs. This is configured using the attributes EndcDistrProfile.gUtranFreqRef (to specify a list of frequencies) and EndcDistrProfile.gUtranFreqDistribution (to specify the corresponding list of percentages). These lists need not contain all configured frequencies, and the percentages may sum to less than 100%.

When B1 measurements are required for a given UE, a frequency is randomly selected from the list, based on the configured percentages. For example, if frequencies F1 and F2 are configured with percentages 60% and 40% respectively, then there is a 60% chance that F1 is chosen and a 40% chance that F2 is chosen. However, any frequency that is measured for the purpose of ENDCHO is not selected by the distribution model.

The selected frequency is configured for measurement in the first RRC reconfiguration message sent to the UE. Any remaining frequencies (including any that are not in the distribution model list) are configured for measurement in the second and third RRC reconfiguration messages, based on their values of endcB1MeasPriority . This is shown in Table 10-12.

<!-- page: 293 -->

Table 10-12 - B1 Measurement Configuration When Using Distribution Model

|   Message | Contents                                                                                                                                                                                    |
|-----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|         1 | The frequency selected randomly according to the distribution model                                                                                                                         |
|         2 | Up to maxMeasB1Endc of the remaining frequencies with endcB1MeasPriority from 7 to 4. If there are no such frequencies, then any remaining frequencies with endcB1MeasPriority from 3 to 0. |
|         3 | Up to maxMeasB1Endc frequencies, in the following order: • Any leftover frequencies from 2) • Any remaining frequencies with endcB1MeasPriority from 3 to 0                                 |

Table 10-12 - B1 Measurement Configuration When Using Distribution Model

If the distribution model percentages sum to less than 100%, then the remaining percentage becomes the probability of using an unaltered B1 measurement configuration, as described in Section 10.2.1.2.

Frequencies with the same endcB1MeasPriority are randomized in order, per selection step.

After many such selections, the distribution of the randomly selected frequencies will be biased towards the configured percentages. How strongly this impacts the traffic distribution will depend on the coverage from each frequency and the EN-DC band combinations supported by the UE population. Frequencies with poorer coverage or less UE support will take proportionally less traffic and may therefore require higher configured percentages to achieve the desired load.

**Option 2:  Mandatory Frequencies**

With this option, a list of mandatory frequencies is configured using the attributes EndcDistrProfile.mandatoryGUtranFreqRef and EndcDistrProfile.mandatoryHiPrioGUtranFreqRef. These mandatory frequencies are prioritized for measurement before the others, regardless of whether they are being measured for the purpose of EN-DC setup, SCG addition, or ENDCHO. A frequency configured with EndcDistrProfile.mandatoryHiPrioGUtranFreqRef has the highest priority in the mandatory list. This is shown in Table 10-13.

<!-- page: 294 -->

Table 10-13 - B1 Measurement Configuration When Using Mandatory Frequencies

|   Message | Contents                                                                                                                                                                                                                                                          |
|-----------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|         1 | Up to maxMeasB1Endc of the mandatory frequencies, first those listed in mandatoryHiPrioGUtranFreqRef in order of decreasing endcB1MeasPriority, followed by those listed in mandatoryGUtranFreqRef in order of decreasing endcB1MeasPriority.                     |
|         2 | Up to maxMeasB1Endc frequencies, in the following order: • Any leftover frequencies from 1) • Any remaining frequencies with endcB1MeasPriority from 7 to 4 If there are no such frequencies, then any remaining frequencies with endcB1MeasPriority from 3 to 0. |
|         3 | Up to maxMeasB1Endc frequencies, in the following order: • Any leftover frequencies from 2) • Any remaining frequencies with endcB1MeasPriority from 3 to 0.                                                                                                      |

Table 10-13 - B1 Measurement Configuration When Using Mandatory Frequencies

**Option 3:  Combination of Distribution Model and Mandatory Frequencies**

The distribution model and the mandatory frequency list can be used in parallel. This gives the highest priority to frequencies that are both in the mandatory list and are selected by the distribution model, as shown in Table 10-14.

As with Option 1, frequencies that are being measured for the purpose of ENDCHO are not selected by the distribution model. However, as with Option 2, ENDCHO frequencies are still prioritized if they are configured as mandatory frequencies.

<!-- page: 295 -->

Table 10-14 - B1 Measurement Configuration When Using a Combination of Distribution Model and Mandatory Frequencies

|   Message | Contents                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
|-----------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|         1 | Up to maxMeasB1Endc frequencies, in the following order: • The frequencies in mandatoryHiPrioGUtranFreqRef in order of decreasing endcB1MeasPriority. • The frequency selected by the distribution model if it is also in mandatoryGUtranFreqRef but not in mandatoryHiPrioGUtranFreqRef. • Any frequencies in mandatoryGUtranFreqRef and not selected by the distribution model, in order of decreasing endcB1MeasPriority • The frequency selected by the distribution model if it is not in either mandatory list |
|         2 | Up to maxMeasB1Endc frequencies, in the following order: • Any leftover frequencies from 1) • Any remaining frequencies with endcB1MeasPriority from 7 to 4 If there are no such frequencies, then any remaining frequencies with endcB1MeasPriority from 3 to 0.                                                                                                                                                                                                                                                    |
|         3 | Up to maxMeasB1Endc frequencies, in the following order: • Any leftover frequencies from 2) • Any remaining frequencies with endcB1MeasPriority from 3 to 0                                                                                                                                                                                                                                                                                                                                                          |

Table 10-14 - B1 Measurement Configuration When Using a Combination of Distribution Model and Mandatory Frequencies

If the distribution model percentages sum to less than 100%, then the remaining percentage becomes the probability that no frequency is selected by the distribution model. Note that if no frequency is selected by the distribution model, then Table 10-14 effectively becomes the same as Table 10-13 in Option 2.

Figure 10-21 provides examples that compare Options 1, 2 and 3 with the case where Optimized UE Distribution for EN-DC is not used. The examples assume that all frequencies are always measured for the purpose of EN-DC setup. If some frequencies are sometimes measured for ENDCHO, then Option 1 and Option 3 will have different outcomes. In the examples below, maxMeasB1Endc = 3 .

<!-- page: 296 -->

![Figure on page 296](5G_Mobility_and_Traffic_Management_Guideline_images/page_296_image_002.png)

Figure 10-21 - RRC Message Contents using Different Distribution Configurations

Optimized UE distribution not only impacts the order in which frequencies are measured; it can also impact the behavior when the eNodeB receives a B1 measurement report from the UE. Specifically, the eNodeB checks whether the reported cell 's frequency has the highest priority of those configured in that batch of measurements. If not, then the eNodeB waits for a report for a cell on the highest priority frequency before acting on the lower priority report (as described in Section 10.2.1.2). The priorities used for this process reflect the modified priority orders described above.

For example, consider the RRC measurement configuration shown in yellow in Figure 10-21.  If the eNodeB receives a report for an F1 cell in this case, then it waits endcB1MeasWindow for a report for an F2 cell, because F2 is the highest prioritized frequency in this RRC measurement configuration. This contrasts with the RRC configuration shown in green, where a report for an F3 cell results in immediate action, because F3 is the highest prioritized frequency in this case.

<!-- page: 297 -->

̶

For the Option 1 example in Figure 10-21, the frequency F4 (shown in blue) is sent in message 3 because maxMeasB1Endc = 3 in this example, so an RRC message can contain only three frequencies. The lowest prioritized frequency (F4) is therefore sent in RRC message 3 rather than in RRC message 2.

One typical use case for this feature is to protect a high priority, high-band cell from EN-DC overload, by redirecting EN-DC traffic to other NR frequencies when the load in the corresponding LTE anchor cell is high.

When using this feature, keep the following points in mind:

- The optimized distribution applies only when the number of EN-DC connected users satisfies the endcUserThreshold criteria; otherwise the behavior remains as described in Section 10.2.1.2.

- This feature does not impact the frequencies allowed for measurement; it only changes the order in which the allowed frequencies are configured in the UE for measurement.

- This feature does not check how closely the configured distribution is actually achieved. It may be necessary to iteratively tune the distribution percentages to achieve the desired result.

- This feature is not suitable for steering traffic between LTE anchor carriers, for example to move traffic from a heavily loaded LTE layer to a more lightly loaded layer.

- If this feature has altered the B1 measurements for a UE, and EN-DC was set up with any of the highest prioritized frequencies, then interaction with the feature PSCell Change to Higher Priority is decided by

- TrStPSCellProfileUeCfg . hiPrioAllowedForDistUeEnabled as follows:

̶

- If hiPrioAllowedForDistUeEnabled = false , then PSCell Change to Higher Priority is not triggered for the UE.

- If hiPrioAllowedForDistUeEnabled = true , then PSCell Change to Higher Priority can be triggered even if EN-DC was set up with any of the highest priority frequencies.

- The value of endcB1MeasPriority referred to above is taken from GUtranFreqRelation , or alternately from FreqPrioNR or GUtraFreqRelProfile if the Subscriber Triggered Mobility feature applies (see Section 10.2.4).

- When the NR frequencies to be measured for EN-DC are divided across multiple RRC messages, make sure that endcMeasTime is not set to -1. If it is set to -1, only the first group of NR frequencies in the initial RRC message are sent to the UE, while the 2nd and 3rd frequency groups are ignored.

̶

- If continuous measurements across multiple RRC messages are required, set endcMeasRestartTime to zero and set endcMeasTime to a positive value.

<!-- page: 298 -->

### 10.2.23 LTE Service-Triggered Outgoing NR IRAT Mobility (FAJ 121 5744) - SA

This licensed eNodeB feature allows outgoing mobility to NR SA for only those UEs that have a particular service activated, as defined by QCI.

To enable the functionality for an LTE cell, set nrMobilityTriggerQciRef to reference one or more QCI profiles (instances of QciProfilePredefined and/or QciProfileOperatorDefined ).

- Mobility to NR SA is then allowed only for UEs that use a QCI that is listed in the referenced QCI profile(s). These UEs use the B1 measurements configured with NR Coverage-Triggered NR Session Continuity (Section 10.2.2), regardless of whether the UE is in good coverage or poor coverage, and any wait time configured using waitForStartNRMeas is ignored. For the parameters and trigger level formulas refer to Section 11.2.3.1. If the feature Outgoing NR IRAT Handover is active, then the outgoing mobility can use handover (rather than RwR).

- UEs that do not meet the QCI requirement are not configured to measure NR SA, even if in poor coverage.

However, this functionality is disabled for a UE if the feature Subscriber Triggered Mobility (Section 10.2.4) is activated, and the UE SPID is captured by the spidList of a UeProfileFilter or RATFreqPrio instance that has

nrMobilityTrigQciAllAllowed = true . In this case, mobility to NR SA remains governed by the features NR Coverage Triggered NR Session Continuity , Outgoing NR IRAT Handover , and Mobility Control at Poor Coverage , using B1 or B2 measurements as determined by those features.

<!-- page: 299 -->

![Figure on page 299](5G_Mobility_and_Traffic_Management_Guideline_images/page_299_image_002.png)

Figure 10-22 - LTE Service-Triggered Outgoing NR IRAT Mobility

The functionality does not impact idle mode mobility to NR SA. Therefore, to ensure that only those UEs with the required QCI are moved to NR SA, disable idle mobility to NR SA.

## 10.3 gNodeB Features

This section summarizes features implemented in the gNodeB that are important for 5G Mobility & Traffic Management. For further information, refer to the relevant feature description in CPI.

### 10.3.1 LTE-NR Dual Connectivity (FAJ 121 4908) - NSA

This is an unlicensed gNodeB feature in the NR Base Package (FAJ 801 4002).

The LTE-NR Dual Connectivity feature introduces the basic support for EN-DC in the gNodeB used in a non-standalone deployment. The counterpart feature on the eNodeB side is the feature Basic Intelligent Connectivity (FAJ 121 4843).

Refer to the CPI document LTE-NR Dual Connectivity for more information.

<!-- page: 300 -->

### 10.3.2 NR-NR Dual Connectivity (FAJ 121 5380) - SA

This is a licensed gNodeB feature in the Peak Rate Evolution value package (FAJ 801 4005).

The feature introduces support for NR-NR Dual Connectivity (NR-DC) with the 5GC. This allows the UE to be connected to one gNodeB acting as the Master Node (MN) and another gNodeB acting as the Secondary Node (SN).

The following sections describe the configuration of downlink buffer-based NR-DC setup, the A4 measurements for SN addition, and immediate NR-DC setup during MN PCell handover. Other mobility-related functionality is covered elsewhere in this document.

#### 10.3.2.1 Buffer-Based NR-DC - SA

This function prevents SN addition for short sessions that are unlikely to benefit from NR-DC, which avoids unnecessary A4 measurements, measurement gaps and user plane interruptions, and conserves UE battery power.

When buffer-based NR-DC setup is enabled, A4 measurements for SN addition are started only if the downlink or uplink user plane data exceeds configurable thresholds. This applies to all A4 measurements, except those after an incoming handover when the UE previously had NR-DC configured.

With buffer-based NR-DC setup, A4 measurements for SN addition are started only if either the DL or the UL buffer criteria are met:

- DL buffer criteria

̶

- The total DL SDU volume in the RLC queue exceeds NrdcMnCellProfileUeCfg.nrdcSetupDlPktVolThr and

̶

- The age of the oldest DL RLC SDU exceeds

NrdcMnCellProfileUeCfg.nrdcSetupDlPktAgeThr

- UL buffer criteria

̶

- The UL data volume in the buffer status report for any logical channel group exceeds UlBufferMonCfg.ulBsVolThresh

Setting any of these attributes to zero removes the corresponding check.

- Setting both nrdcSetupDlPktVolThr and nrdcSetupDlPktAgeThr to zero (the default value) disables DL buffer-based NR-DC setup

- Setting ulBsVolThresh to zero disables UL buffer-based NR-DC setup

For a more detailed description, refer to the feature description for NR-NR Dual Connectivity in CPI.

<!-- page: 301 -->

#### 10.3.2.2 A4 Measurements for SN Addition - SA

To search for suitable coverage from an FR2 cell that can be used as the PSCell for NRDC, the gNodeB configures A4 measurements in the UE, using RSRP as the trigger quantity. Up to NrdcMnCellProfileUeCfg.nrdcMaxMeasFreqA4 FR2 frequencies can be measured and are listed in randomized order. If more frequencies fulfil the criteria for A4 measurements, then the measured frequencies are selected randomly.

The measurement is started and stopped periodically, which provides a way to limit UE battery consumption and reduce the impact of measurement gaps on throughput. Note, however, that measurement gaps can be turned off, as described in Section 4.8.4.3. The time of each measurement period is the sum of

NrdcMnCellProfileUeCfg.nrdcMeasTime and timeToTrigger of the triggering quantity. The time of each pause in measurements is NrdcMnCellProfileUeCfg.nrdcMeasRestartTime .

Figure 10-23 illustrates the periodic A4 measurement sequence when RSRP is the triggering quantity.

![Figure on page 301](5G_Mobility_and_Traffic_Management_Guideline_images/page_301_image_001.png)

Figure 10-23 - A4 Measurement Sequence for SN addition for NR-DC

The A4 measurement are removed at SN addition and re-started after SN release. The A4 measurement is not started if the UE is already connected with NR-DC, or when the UE performs RRC re-establishment, or when the UE resumes from RRC inactive state.

The A4 event triggering threshold quantity can be either RSRP, RSRQ or SINR.

When RSRP is the triggering quantity, another measurement quantity (RSRQ or SINR) can be used as additional evaluation check of the target cell before initiating an SN addition.

The A4 triggering quantity and additional evaluation check are configured by the attribute NrdcMnCellProfileUeCfg.pSCellTriggerQuantity as follows:

- 0 ( RSRP ) - the trigger quantity is RSRP

- 1 ( RSRQ ) - the trigger quantity is RSRQ

- 2 ( SINR_FALLBACK_RSRP ) - the trigger quantity is SINR, with fallback to RSRP if the UE does not support SINR measurements.

- 3 ( SINR_FALLBACK_RSRQ ) - the trigger quantity is SINR, with fallback to RSRQ if the UE does not support SINR measurements.

<!-- page: 302 -->

- 4 ( RSRP_AND_RSRQ ) - the trigger quantity is RSRP, and the additional evaluation quantity is RSRQ.

- 5 ( RSRP_AND_SINR_FALLBACK_RSRQ ) - the trigger quantity is RSRP, and the additional evaluation quantity is SINR. If the UE does not support SINR measurements, the additional evaluation quantity is RSRQ.

- 6 ( RSRP_AND_SINR_NO_FALLBACK ) - the trigger quantity is RSRP, and the additional evaluation quantity is SINR. If the UE does not support SINR measurements, there is no additional evaluation.

When an additional evaluation check is configured, both criteria must be fulfilled to initiate SN addition. If not, the A4 report is discarded, and gNodeB waits for a new A4 report.

For the parameters and trigger level formulas associated with NR-DC SN addition, refer to Section 11.2.12.

#### 10.3.2.3 Immediate NR-DC Setup during MN PCell Handover - SA

When the UE has an NR-DC connection, the gNodeB uses extended measurements for the A3 and A5 events. With extended measurements, the UE includes the best non-serving (neighbor) cell on each serving PSCell and SCell frequency (FR2) in the A3 or A5 report.

This allows the gNodeB to immediately establish NR-DC after an A3 or A5 triggered handover, using the reported PSCell, as follows:

- If the serving PSCell is the strongest cell in the extended measurement report and it is better than the A4 RSRP threshold, the existing PSCell is retained.

- If a non-serving PSCell neighbor is the strongest cell in the extended measurement report and it is better than the A4 RSRP threshold, the PSCell is changed.

- If no reported cell on the PSCell frequency is better than the Event A4 RSRP threshold, NR-DC is not established. Instead, the SN is released and new A4 measurements are started. If downlink buffer-based NR-DC is activated, those conditions must also be fulfilled before A4 measurements are configured.

In the case of PCell intra-cell handover, NR-DC is immediately re-configured using the same PSCell.

For the parameters and trigger level formulas associated with NR-DC SN addition, refer to Section 11.2.12.

#### 10.3.2.4 A2 Measurement-based Secondary Node Release for NR-DC

UEs connected using NR-DC can be configured with Event A2 Critical Coverage measurements to detect critical PSCell coverage and trigger SN release. This is configured in the secondary gNodeB as follows:

<!-- page: 303 -->

- Set McpcNrdcPSCellProfileUeCfg.mcpcA2Quantity to a value other than NONE , to select the triggering quantity (namely RSRP, RSRQ or SINR, or a combination of these).

- Set triggering conditions for each enabled quantity using the struct attributes rsrpCritical , rsrqCritical and sinrCritical in McpcNrdcPSCellProfileUeCfg.

Event A2 Critical Coverage measurements are then configured in the UE, to monitor the PSCell coverage. When the UE reports the A2, the gNodeB initiates SN release.

For the trigger level formulas, see Section 11.2.16.

### 10.3.3 Uplink-Downlink Decoupling (FAJ 121 4909) - NSA

This is an unlicensed gNodeB feature in the NR Base Package (FAJ 801 4002).

This feature introduces the basic support for configuring the downlink (DL) and uplink (UL) on the MCG and SCG resources independently as well as dynamically switching between them (refer to Sections 5.3.2 and 5.3.3). It is used for both EN-DC and NR-DC. The feature provides, for example, improved NR coverage by using the LTE UL on a lower FDD band, as described in Section 5.3.1.

### 10.3.4 NR Mobility (FAJ 121 5041) - NSA and SA

This is an unlicensed gNodeB feature in the NR Base Package (FAJ 801 4002).

The purpose of the NR Mobility feature is to manage the UE in RRC_CONNECTED mode.

Note: In the current software release, the procedures for NR mobility may depend on the frequency band. Refer to the CPI documents NR Mobility and 5G SW Feature Status for more information.

The feature contains the following functionalities:

#### 10.3.4.1 Intra-Frequency PSCell change - NSA

This functionality allows EN-DC configured UEs with SCG resources to perform intrafrequency Event A3 measurement in RRC_CONNECTED mode. When an Event A3 measurement report is received by the gNodeB, PSCell change is triggered, as described in Section 6.3.1.

<!-- page: 304 -->

#### 10.3.4.2 Mobility Control at Poor Coverage - NSA

Mobility Control at Poor Coverage (MCPC) enables EN-DC connected UEs to search for suitable coverage on another NR frequency if the serving PSCell coverage becomes poor. If a suitable frequency is found a PSCell change is triggered. If the serving cell coverage deteriorates to a critical level, SN release can be triggered. Potential NR target frequencies can be designated as either high or low priority, and high priority frequencies are given preference.

MCPC for NSA considers the EN-DC connected UE to be in one of three PSCell coverage areas: namely good coverage, search zone or critical coverage. To detect when the UE moves between these coverage areas, MCPC configures Event A1 and A2 measurements in the UE. Additionally, when the UE is in the search zone, MCPC configures Event A5 measurements to detect better coverage from cells on other NR frequencies, and Event A2 critical to detect critical serving cell coverage. This is summarized in Figure 10-24.

![Figure on page 304](5G_Mobility_and_Traffic_Management_Guideline_images/page_304_image_001.png)

Figure 10-24 - MCPC Coverage Zones - NSA

MCPC for NSA is enabled by setting NRCellCU.mcpcPSCellEnabled = true . When it is enabled, set (eNB) CarrierAggregationFunction.endcCaPolicy = NR_PREFERRED , to ensure that the eNodeB sends the full list of UE-supported band combinations to the gNodeB, which in turn enables inter-frequency PSCell change to all potential NR target frequencies.

MCPC supports measurements based on RSRP, RSRQ and SINR. The attribute McpcPSCellProfileUeCfg.mcpcQuantityList specifies which measurement quantities are used (up to two), and it takes the following values:

<!-- page: 305 -->

- RSRP

- RSRQ

- SINR_FALLBACK_RSRQ

- SINR_FALLBACK_RSRP

- RSRP + RSRQ

- RSRP + SINR_NO_FALLBACK

- RSRP + SINR_FALLBACK_RSRQ

Note that SINR always includes a fallback option, which is used for UEs that do not support SINR measurements. So, for example, SINR_FALLBACK_RSRP specifies that RSRP measurements are used for those UEs.

When two measurement quantities are configured e.g. RSRP + RSRQ, they run in parallel, independently. So, for example, a UE can be in good coverage for RSRP but in the search zone for RSRQ. In that case it would be configured with an A2 Search RSRP measurement (to detect poor RSRP), along with A5 RSRQ measurement(s) (to find cells with acceptable RSRQ), an A1 RSRQ measurement (to detect return to good RSRQ coverage) and an A2 Critical RSRQ measurement (to detect critical RSRQ).

The following notes describe the operation of MCPC for NSA, with reference to the events shown in Figure 10-24.

**Event A2 - Entering Search Zone**

If MCPC for NSA is enabled, and valid EN-DC NR target frequencies exist for the UE, then MCPC configures A2 Entering Search Zone measurement(s) in the UE when EN-DC is set up. If valid target frequencies do not exist, then these A2 measurements are not configured (and therefore neither are the A1 Leaving Search Zone and A5 Inter-Frequency Candidate measurements).

A2 Entering Search Zone measurements are used to detect poor serving PSCell coverage. The measurements are configured per McpcPSCellProfileUeCfg with the struct attributes rsrpSearchZone , rsrqSearchZone and/or sinrSearchZone , depending on the measurement quantity. These struct attributes all contain the underlying attributes threshold , hysteresis and timeToTrigger . See Section 11.2.9.2 for the trigger level formulas.

When one of these A2 events is triggered for a particular measurement quantity (RSRP, RSRQ or SINR), MCPC removes the A2 measurement and replaces it with the following measurements, using the same measurement quantity:

- Event A1 Leaving Search Zone - to detect a return to good coverage

- Event A2 Critical Coverage - to detect degradation to critical serving PSCell coverage

<!-- page: 306 -->

̶

- Event A5 Inter-Frequency Candidate - to detect suitable coverage on another NR frequency

Additionally, when the UE enters the search zone, MCPC starts the following timers:

- Search Time Restriction Timer

̶

- This timer is set with rsrpSearchTimeRestriction ,

rsrqSearchTimeRestriction or sinrSearchTimeRestriction (depending on the measurement quantity) and it limits the time spent searching for a suitable target frequency. If it expires, the Event A5 Inter-Frequency Candidate measurements for that measurement quantity are removed, and the UE continues to search for good coverage (A1 Leaving Search Zone) or critical coverage (A2 Critical Coverage). Ericsson recommends that this timer is set to a value larger than the Priority Period Timer, see below, to ensure enough time for searching.  If set to -1 (default value), no time restriction applies.

- Priority Period Timer

̶

- The priority period timer is used to ensure high priority target frequencies are given preference over low priority ones. It is not used if all frequencies are low priority or all are high priority.

̶

- The priority period starts when the A5 Inter-Frequency Candidate measurement is configured in the UE. The priority period length is determined automatically, per measurement quantity, and depends on the number of measured frequencies.

For example, assuming RSRP triggers entry into the search zone, the priority period is:

Priority Period for RSRP =  480 + (NFR1 * 200) +  (NFR2 * 200) + McpcPSCellProfileUeCfg.rsrpCandidateA5.timeToTrigger

where

NFR1 = the total number of NR FR1 frequencies measured by the A5 NFR2 = the total number of NR FR2 frequencies measured by the A5

The formulas for RSRQ and SINR are similar but use the timeToTrigger attributes contained in rsrqCandidateA5 and sinrCandidateA5 respectively.

Separate priority period timers are maintained for each trigger quantity (RSRP, RSRQ or SINR).

- NR Frequencies are considered high priority if:

UeMCNrFreqRelProfileUeCfg.connModePrioPSCell >= McpcPSCellProfileUeCfg.lowHighFreqPrioClassification otherwise they are low priority.

- During the priority period (while the timer is running), A5 reports for low priority targets are handled differently to those from high priority targets. The differences are explained below, under the Event A5 - Inter-Frequency Candidate.

(ms)

̶

<!-- page: 307 -->

After configuring these events, MCPC waits for one of the timers to expire (which is handled as described above) or for the UE to send a measurement report, namely A1 Leaving Search Zone, A2 Critical Coverage or A5 Inter-Frequency Candidate. These events are described below.

**Event A1 - Leaving Search Zone**

This event is used to detect when the UE returns to good serving PSCell coverage for a particular measurement quantity. It is configured using the same struct attributes as the A2 event (namely rsrpSearchZone , rsrqSearchZone and/or sinrSearchZone , depending on the measurement quantity). However, the time to trigger for A1 and A2 can be set differently, using timeToTriggerA1 . See Section 11.2.9.1 for the trigger level formulas.

When this event is triggered for a particular measurement quantity, the UE is once again in good coverage for that measurement quantity. MCPC then removes all of the measurements configured when the UE entered the search zone and replaces them with an A2 Entering Search Zone measurement to detect re-entry into search zone.

**Event A5 - Inter-Frequency Candidate**

This event is used to detect a suitable target PSCell on another NR frequency, and it uses the same measurement quantity that triggered entry into the search zone. It is configured only if valid target NR frequencies exist.

The event is configured with the McpcPSCellProfileUeCfg struct attributes rsrpCandidateA5 , rsrqCandidateA5 and sinrCandidateA5 , depending on the measurement quantity. These struct attributes all contain threshold1 , threshold2 , hysteresis and timeToTrigger . The attribute threshold1 is used to confirm that the serving cell is poor enough and threshold2 is used to confirm that the target cell coverage is good enough, so justifying mobility.

When MCPC receives the A5 report, other measurement quantities (besides the triggering quantity) can be checked too, using the following McpcPSCellProfileUeCfg attributes:

- When mcpcQuantityList = RSRP , then an RSRQ or a SINR check can be added for the target cell using rsrpCandidateA5AddTargEval .

- When mcpcQuantityList = RSRQ , then only an RSRP check can be added for the target cell using rsrqCandidateA5AddTargEval .

- When mcpcQuantityList = SINR , then an RSRP and/or an RSRQ check can be added for the target cell using sinrCandidateA5AddTargEval .

For example, if mcpcQuantityList = RSRP and rsrpCandidateA5AddTargEval = SINR_FALLBACK_RSRQ , then MCPC also checks the reported SINR (for UEs that can measure SINR), or the reported RSRQ (for UEs that cannot measure SINR).

If the received A5 report fails any of the additional checks described above, the measurement report is discarded and MCPC waits for a new report to evaluate.

<!-- page: 308 -->

See Section 11.2.9.4 for the trigger level formulas, and the formulas defining the checks of the additional measurement quantities.

An NR frequency is considered as a valid target if:

- The UE is capable of measuring the frequency and supports the frequency for both uplink and downlink for EN-DC in combination with the used LTE frequencies

- The NR frequency is not included in the blocklist. A frequency can be included in the blocklist for example, due to recurring EN-DC setup failures or insufficient UE capabilities.

- McpcPSCellNrFreqRelProfileUeCfg . inhibitMeasForCellCandidate = false for the frequency

- UeMCNrFreqRelProfileUeCfg . connModeAllowedPSCell = true for the frequency

- The PLMN conditions are fulfilled (refer to the feature description for NR Mobility in CPI)

When the event is triggered, the gNodeB determines whether the reported cell is known, is valid for mobility and has an allowed PLMN. If not, the report is discarded, and no mobility action is taken.

If the reported cell is blocked for traffic (due to manual barring, cell soft lock, or cell sleep preparation), PSCell change is not attempted. Refer to Section 10.3.35 for further details.

If the reported cell is inter-gNodeB, the PSCell change is not allowed if a corresponding GUtranCellRelation exists and has isEndcAllowed = false . This check does not apply for an intra-gNodeB target.

If the reported cell is valid and from a high priority frequency, then the gNodeB initiates a PSCell change to the reported cell if NRCellRelation.isHoAllowed = true , regardless of whether the priority period is running or not. If isHoAllowed = false , then no action is taken.

If the reported cell is valid, from a low priority frequency and the priority period is running, then the gNodeB waits for a high priority report and handles the low priority one as follows:

- If Mcpc.endcLowPrioPSCellCandHandling = STORE_LATEST_RECEIVED , then the reported cell is stored (replacing the pre-existing stored report, if one exists)

- If Mcpc.endcLowPrioPSCellCandHandling = STORE_HIGHEST_PRIO , then the reported cell is stored if its priority is equal to or higher than any previously stored cell, otherwise it is discarded.

If the priority period expires before a high priority report is received, then gNodeB initiates a PSCell change to the stored low priority cell, if there is one. If there is no stored cell when the priority period expires, then the gNodeB initiates a PSCell change when the next valid cell is reported, regardless of whether it is low or high priority.

<!-- page: 309 -->

If the PSCell change request is rejected by the target gNodeB due to insufficient UE capabilities or by the eNodeB due to misconfiguration, then the target cell can be blocklisted for the lifetime of the UE connection in the source gNodeB; refer to Section 6.3.2.1 for further details.

**Event A2 - Critical Coverage**

This event is configured in the UE to detect critical serving PSCell coverage.

It is enabled separately for each measurement quantity allowed by mcpcQuantityList , by setting the McpcPSCellProfileUeCfg attributes rsrpCriticalEnabled , rsrqCriticalEnabled and sinrCriticalEnabled to true . It can be enabled even if no valid target NR frequencies exist for MCPC to measure, in which case the A1 Leaving Search Zone, A2 Entering Search Zone and A5 Inter-Frequency Candidate measurements are never configured; only this A2 Critical Coverage measurement is configured.

A2 Critical Coverage is configured with the McpcPSCellProfileUeCfg struct attributes rsrpCritical , rsrqCritical and sinrCritical , using the underlying attributes threshold , hysteresis and timeToTrigger . See Section 11.2.9.3 for the trigger level formulas.

If this event is triggered and a low priority candidate is stored, then the gNodeB initiates PSCell change to the candidate.

If no low priority candidate is stored, then the gNodeB initiates SN release.

**Configuring MCPC for Critical Coverage-Triggered SN Release Only**

MCPC can be configured to perform only the critical coverage-triggered SN release, without first searching for potential PSCell candidates on other frequencies. This avoids the gaps associated with A5 measurements and allows uninterrupted use of the cell until the critical threshold is reached.

To achieve this, use the following configuration:

- Set NRCellCU.mcpcPSCellEnabled = true

- Turn on measurements for the desired trigger quantities, using McpcPSCellProfileUeCfg.mcpcQuantityList

- Depending on the desired trigger quantities, set the following McpcPSCellProfileUeCfg attributes to true : rsrpCriticalEnabled , rsrqCriticalEnabled and/or sinrCriticalEnabled

- Set McpcPSCellNrFreqRelProfileUeCfg . inhibitMeasForCellCandidate = true for any NRFreqRelation children of the source cell. Note that the relations themselves are still required for idle mode mobility and any other connected mode mobility, such as MCPC for SA or PSCell Change to Higher Priority .

<!-- page: 310 -->

With this configuration, only the MCPC Event A2 Critical Coverage measurements are configured in the UE. The other MCPC events (A1 Leaving Search Zone, A2 Entering Search Zone and A5 Inter-Frequency Candidate measurements) are not configured.

When the UE reports Event A2 Critical Coverage, the gNodeB initiates SN release.

#### 10.3.4.3 Idle Mode - SA

This functionality enables broadcast of System Information in NR SA cells, which enables cell selection and reselection in NR SA when the UE is in idle mode or RRC_INACTIVE state, as described in Section 8.1.

#### 10.3.4.4 Intra-frequency Mobility - SA

This functionality enables intra-frequency mobility using Event A3 (neighbor NR cell becomes offset better than the NR serving cell) for UEs connected to an NR SA cell, as described in Section 8.3.3 for the PCell and Section 8.3.5 for the PSCell.

Inter-gNodeB handovers are Xn-based by default if certain conditions are met. However, the attribute GNBCUCPFunction.prefInterGNBHo enables the default to be changed to NG-based. See CPI for NR Mobility for more detail.

#### 10.3.4.5 Mobility Control at Poor Coverage - SA

Mobility Control at Poor Coverage (MCPC) enables SA-connected UEs to search for suitable coverage on another NR frequency (inter-frequency) or LTE frequency (inter-RAT) if the serving cell coverage becomes poor. If a suitable frequency is found, either handover or release-with-redirect is triggered. If the serving cell coverage deteriorates to a critical level, a critical mobility action can be triggered. Potential target frequencies can be designated as either high or low priority, and high priority frequencies are given preference.

MCPC considers the UE to be in one of three coverage areas: good coverage, search zone or critical coverage. To detect when the UE moves between these coverage areas, MCPC configures Event A1 and A2 measurements. Additionally, when the UE is in the search zone, MCPC configures Event A5 or A3 measurements to detect better suitable coverage from other NR frequencies, Event B2 measurements to detect suitable coverage from LTE frequencies, and Event A2 measurements to detect critical serving cell coverage. This is summarized in Figure 10-25.

<!-- page: 311 -->

![Figure on page 311](5G_Mobility_and_Traffic_Management_Guideline_images/page_311_image_002.png)

Figure 10-25 - MCPC Coverage Zones - SA

By default, the MCPC thresholds apply to all UE power classes. However, for high power UEs, the useable NR cell coverage can be extended by adding offsets to the thresholds. A high-power UE is one that has higher power than power class 3 (23 dBm), which is the most common power class. The offset is set per UE power class; a negative value expands the useable NR coverage area. Details of the thresholds and offsets are provided in the trigger level formulas of Section 11.2.8.

MCPC for SA is enabled by setting NRCellCU.mcpcPCellEnabled = true .

MCPC supports measurements based on the following quantities (described more completely in Section 4.7):

- Downlink: RSRP, RSRQ, SINR

̶

- These quantities are used for Event A1, A2, A3, A5 and B2 measurements. The measurements are performed by the UE and are configured and deconfigured as required using RRC messages sent to the UE.

- Uplink:  UL_SINR

̶

- Uplink SINR is used for Event A1 and A2 measurements only. The measurements are performed by the gNodeB and run continually; they are not configured and deconfigured as the UE enters and leaves the search zone.

<!-- page: 312 -->

The attribute McpcPCellProfileUeCfg.mcpcQuantityList specifies which of these measurement quantities are used (up to three), and it takes the following values:

- RSRP

- RSRQ

- SINR_FALLBACK_RSRQ

- SINR_FALLBACK_RSRP

- RSRP + RSRQ

- RSRP + SINR_NO_FALLBACK

- RSRP + SINR_FALLBACK_RSRQ

- UL_SINR

- RSRP + UL_SINR

- RSRQ + UL_SINR

- SINR_FALLBACK_RSRQ + UL_SINR

- SINR_FALLBACK_RSRP + UL_SINR

- RSRP + RSRQ + UL_SINR

- RSRP + SINR_NO_FALLBACK + UL_SINR

- RSRP + SINR_FALLBACK_RSRQ + UL_SINR

Note that downlink SINR always includes a fallback option, which is used for UEs that do not support SINR measurements on NR. So, for example, SINR_FALLBACK_RSRQ specifies that RSRQ measurements are used for those UEs.

In the special case where a UE supports downlink SINR measurements on NR but not on LTE, then SINR is used for the A1, A2, A3 and A5 measurements, but RSRP for the B2 measurement.

When two or three measurement quantities are configured e.g. RSRP + RSRQ, they run in parallel, independently. So, for example, a UE can be in good coverage for RSRP but in the search zone for RSRQ. In that case it would be configured with an A2 Search RSRP measurement (to detect poor RSRP), along with A5 and/or B2 RSRQ measurement(s) (to find cells with acceptable RSRQ), an A1 RSRQ measurement (to detect return to good RSRQ coverage) and an A2 Critical RSRQ measurement (to detect critical RSRQ).

The following notes describe the operation of MCPC, with reference to the events shown in Figure 10-25.

**Event A2 - Entering Search Zone**

If MCPC for SA is enabled, and valid NR and/or LTE target frequencies exists for the UE, then MCPC configures Event A2 Entering Search Zone measurement(s) when the UE connects to the cell.

<!-- page: 313 -->

The A2 Entering Search Zone measurements are used to detect poor serving PCell coverage. The downlink measurements are configured per McpcPCellProfileUeCfg , with the struct attributes rsrpSearchZone , rsrqSearchZone and/or sinrSearchZone (depending on the measurement quantity). The uplink measurements are configured per UlQualMcpcMeasCfg with the struct attribute ulQualSearchZone . These struct attributes all contain the underlying attributes threshold , hysteresis , timeToTrigger and timeToTriggerA1 . See Section 11.2.8.2 for the trigger level formulas.

When an Event A2 is triggered by RSRP, RSRQ or SINR, MCPC removes the A2 measurement and replaces it with the following measurements, using the relevant measurement quantity:

- Event A1 Leaving Search Zone - to detect a return to good coverage

- Event A2 Critical Coverage - to detect degradation to critical serving PCell coverage

- Event A5 or A3 Inter-Frequency Candidate - to detect suitable coverage on another NR frequency (if valid NR target frequencies exist, as described below)

- Event B2 EUTRAN Candidate - to detect suitable coverage on an LTE frequency (if valid LTE target frequencies exist, as described below)

When an Event A2 is triggered by UL_SINR, MCPC configures the following measurements using RSRP:

- Event A5 Inter-Frequency Candidate - to detect suitable coverage on another NR frequency (if valid NR target frequencies exist, as described below)

- Event B2 EUTRAN Candidate - to detect suitable coverage on an LTE frequency (if valid LTE target frequencies exist, as described below)

- The Event A1 and A2 uplink SINR measurements continue in the gNodeB

Additionally, when the UE enters the search zone, MCPC starts the following timers:

- Search Time Restriction Timer

̶

- This timer is set with rsrpSearchTimeRestriction , rsrqSearchTimeRestriction , sinrSearchTimeRestriction or rsrpSearchTimeRestrictionByUl (depending on the measurement quantity) and it limits the time spent searching for a suitable target frequency. If it expires, the A5 Inter-Frequency Candidate and B2 EUTRAN Candidate measurements are removed, and the UE continues to search for good coverage (A1 Leaving Search Zone) or critical coverage (A2 Critical Coverage). Ericsson recommends that this timer is set to a value larger than the Priority Period Timer, see below, to ensure enough time for searching. If set to -1 (default value), no time restriction applies.

- Priority Period Timer

<!-- page: 314 -->

̶

̶

̶

- The priority period timer is used to ensure high priority target frequencies are given preference over low priority ones. It is not used if all candidate frequencies for a UE connection are low priority, or all are high priority.

- The priority period starts when the A3, A5 or B2 measurements are configured in the UE. The priority period length is determined automatically and depends on the number of measured frequencies and the maximum time to trigger quantity being used.

For example, assuming RSRP triggers entry into the search zone, and all three trigger types are configured in the UE (A3, A5 and B2, each on a different frequency), the priority period is:

**Priority Period for RSRP = 480 + N * 200 +**

max( McpcPCellProfileUeCfg.rsrpCandidateA3.timeToTrigger , McpcPCellProfileUeCfg.rsrpCandidateA5.timeToTrigger , McpcPCellProfileUeCfg.rsrpCandidateB2.timeToTrigger ) (ms)

where N = the total number of NR plus LTE frequencies measured by the A3, A5 and B2

The formulas for RSRQ and SINR are similar but use the timeToTrigger attributes contained in rsrqCandidateA5 , rsrqCandidateA3 and rsrqCandidateB2 or sinrCandidateA5 , sinrCandidateA3 and sinrCandidateB2 respectively.

Separate priority period timers are maintained for each trigger quantity (RSRP, RSRQ or SINR).

- NR Frequencies are considered high priority if:

UeMCNrFreqRelProfileUeCfg . connModePrioPCell >= McpcPCellProfileUeCfg . lowHighFreqPrioClassification otherwise they are low priority.

̶

- LTE frequencies are considered high priority if:

UeMCEUtranFreqRelProfileUeCfg . connModePrioPCell >= McpcPCellProfileUeCfg . lowHighFreqPrioClassification otherwise they are low priority.

- During the priority period (while the timer is running), A3, A5 and B2 reports for low priority targets are handled differently to those from high priority targets. The differences are explained below.

̶

After configuring these events, MCPC waits for one of the timers to expire (which is handled as described above) or for another measurement report, namely A1 Leaving Search Zone, A2 Critical Coverage, A3 or A5 Inter-Frequency Candidate or B2 EUTRAN Candidate. These events are described below.

<!-- page: 315 -->

**Event A1 - Leaving Search Zone**

This event is used to detect when the UE returns to good serving PCell coverage. It uses the same measurement quantity (RSRP, RSRQ, SINR or UL_SINR) as the A2 event that triggered entry into the search zone. It is configured using the same struct attributes as the A2 event (namely rsrpSearchZone , rsrqSearchZone , sinrSearchZone and/or ulQualSearchZone depending on the measurement quantity). However, the time to trigger for A1 and A2 can be set differently, using timeToTriggerA1 . See Section 11.2.8.1 for the trigger level formulas.

When an Event A1 is triggered by RSRP, RSRQ or downlink SINR, MCPC takes the following actions for the relevant measurement quantity:

- MCPC removes all of the measurements that were configured when the UE entered the search zone.

- MCPC configures an A2 Entering Search Zone measurement to detect re-entry into search zone.

When an Event A1 is triggered by UL_SINR, MCPC takes the following actions:

- MCPC removes the A5 and/or B2 RSRP measurements that were configured when the UE entered the UL_SINR search zone.

- The Event A1 and A2 UL_SINR measurements continue in the gNodeB.

**Event A5 - Inter-Frequency Candidate**

This event is used in the search zone to detect a suitable target cell on an NR frequency that has McpcPCellNrFreqRelProfileUeCfg . interFreqMeasType = EVENT_A5 . Using A5 (rather than A3) means the measurement is based on the absolute values of the measured quantity (rather than the relative difference between the measured values on the source and target cells).

If entry into the search zone is triggered by RSRP, RSRQ or downlink SINR, then the A5 uses the same measurement quantity. If entry into the search zone is triggered by uplink SINR, then the A5 uses RSRP. It is configured only if valid candidate NR frequencies exist.

The event is configured with the McpcPCellProfileUeCfg struct attributes rsrpCandidateA5 , rsrqCandidateA5 and sinrCandidateA5 , depending on the measurement quantity. These struct attributes all contain threshold1 , threshold2 , hysteresis and timeToTrigger . The attribute threshold1 is used to confirm that the serving cell is poor enough and threshold2 is used to confirm that the target cell coverage is good enough, so justifying mobility.

When MCPC receives the A5 report, other measurement quantities (besides the triggering quantity) can be checked using the following McpcPCellProfileUeCfg attributes:

- When the triggering quantity is RSRP or uplink SINR, then an RSRQ or a downlink SINR check can be added for the target cell using rsrpCandidateA5AddTargEval .

<!-- page: 316 -->

- When the triggering quantity is RSRQ, then only an RSRP check can be added for the target cell using rsrqCandidateA5AddTargEval .

- When the triggering quantity is downlink SINR, then an RSRP and/or an RSRQ check can be added for the target cell using sinrCandidateA5AddTargEval .

For example, if mcpcQuantityList = RSRP and rsrpCandidateA5AddTargEval = SINR_FALLBACK_RSRQ , then MCPC also checks the reported downlink SINR value (for UEs that can measure SINR), or the reported RSRQ value (for UEs that cannot measure SINR).

When uplink SINR triggers entry into the search zone, additional checks are applied on the uplink quality in the target cell as follows:

- Before handover preparation occurs, the source gNodeB checks that uplink-triggered handover to the target gNodeB is allowed. It is allowed if one of the following conditions is met:

̶

- The read-only attribute ExternalGNBCUCPFunction.ulTrigHoSupport = true . This attribute is automatically set to true if there is an Xn connection to the external gNodeB and it supports uplink-triggered MCPC.

̶

- The attribute ExternalGNBCUCPFunction.ulTrigHoAllowed = true . This means that uplink-triggered handover is allowed even if the target gNodeB does not support uplink-triggered handover and therefore cannot check the target cell uplink quality.

- If UeMCCellProfileUeCfg.checkUlQualityIncomingHo = true , then handover preparation includes a check of the estimated uplink SINR on the target cell. The estimate is based on the target cell RSRP in the A5 report (which is forwarded to the target gNodeB in the Handover Request message), and other information available in the target gNodeB, like the average uplink interference plus noise. If the estimated SINR is greater than or equal to or if the RSRP value is

UeMCCellProfileUeCfg.ulQualityThreshIncomingHo not available, then the handover is accepted, otherwise the handover preparation is rejected.

- If UeMCCellProfileUeCfg.checkUlQualityIncomingHo = false , then the target cell uplink SINR check is not performed.

To reduce the risk of ping-pong handover, ensure ulTrigHoAllowed = false (default value) in the source node (so the handover can only occur if the ulTrigHoSupport = true , which means that the target gNodeB can check the SINR) and checkUlQualityIncomingHo = true in the target node (which turns on the incoming HO quality check).

If the received A5 report fails any of the additional checks described above, the measurement report is discarded and MCPC waits for a new report to evaluate.

See Section 11.2.8.4 for the formulas defining the trigger levels and the additional checks.

Measurements are configured only if valid NR candidate frequency(s) exist:

<!-- page: 317 -->

- The UE is capable of measuring the frequency

- McpcPCellNrFreqRelProfileUeCfg . inhibitMeasForCellCandidate = false for the frequency

- UeMCNrFreqRelProfileUeCfg . connModeAllowedPCell = true for the frequency

- The PLMN conditions are fulfilled (refer to the feature description for NR Mobility in CPI)

When the event is triggered, the gNodeB determines whether the reported cell is known, valid for mobility, has an allowed PLMN and has a suitable slicing configuration. If not, the report is discarded, and no mobility action is taken.

If the reported cell is blocked for traffic (due to manual barring, cell soft lock, or cell sleep preparation), handover is not attempted. Refer to Section 10.3.35 for further details.

or if the

If the reported cell is valid and from a high priority frequency, then the gNodeB initiates mobility action to the reported cell, regardless of whether the priority period is running or not. The mobility action is either handover to the reported cell, if NRCellRelation.isHoAllowed = true , or release-with-redirect, if it is false UE does not support handover to this frequency.

If the reported cell is valid, from a low priority frequency and the priority period is running, then the gNodeB waits for a high priority report and handles the low priority one as follows:

- If Mcpc.nrLowPrioPCellCandHandling = STORE_LATEST_RECEIVED , then the reported cell is stored (replacing the pre-existing stored cell if there is one)

- If Mcpc.nrLowPrioPCellCandHandling = STORE_HIGHEST_PRIO , then the reported cell is stored if its priority is equal to or higher than any previously stored cell, otherwise it is discarded.

If the priority period expires before a high priority report is received, then the gNodeB initiates handover or release-with-redirect to the stored low priority cell, if there is one. If there is no stored cell when the priority period expires, then the gNodeB initiates handover or release-with-redirect to the next valid reported cell, regardless of whether it is low or high priority.

**Event A3 - Inter-Frequency Candidate**

This event is used in the search zone to detect a suitable target cell on an NR frequency that has McpcPCellNrFreqRelProfileUeCfg . interFreqMeasType = EVENT_A3 . Using A3 (rather than A5) means the measurement is based on the relative difference between the measured values on the source and target cells (rather than the absolute values).

If entry into the search zone is triggered by RSRP, RSRQ or downlink SINR, then the A3 uses the same measurement quantity.

<!-- page: 318 -->

If entry into the search zone is triggered by uplink SINR, then Event A5 RSRP is used instead of A3.

The event is configured with the McpcPCellProfileUeCfg struct attributes rsrpCandidateA3 , rsrqCandidateA3 and sinrCandidateA3 , depending on the measurement quantity. These struct attributes all contain offset , hysteresis and timeToTrigger .

When MCPC receives the A3 report, other measurement quantities (besides the triggering quantity) can be checked using the following McpcPCellProfileUeCfg attributes:

- When the triggering quantity is RSRP or uplink SINR, then an RSRQ or a downlink SINR check can be added for the target cell using rsrpCandidateA3AddTargEval .

- When the triggering quantity is RSRQ, then only an RSRP check can be added for the target cell using rsrqCandidateA3AddTargEval .

- When the triggering quantity is downlink SINR, then an RSRP and/or an RSRQ check can be added for the target cell using sinrCandidateA3AddTargEval .

For example, if mcpcQuantityList = RSRP and rsrpCandidateA3AddTargEval = SINR_FALLBACK_RSRQ , then MCPC also checks the reported downlink SINR value (for UEs that can measure SINR), or the reported RSRQ value (for UEs that cannot measure SINR).

If the received A3 report fails any of the additional checks described above, the measurement report is discarded and MCPC waits for a new report to evaluate.

See Section 11.2.8.5 for the formulas defining the trigger levels and the additional checks.

Measurements are configured only if valid NR candidate frequency(s) exist:

- The UE is capable of measuring the frequency

- McpcPCellNrFreqRelProfileUeCfg . inhibitMeasForCellCandidate = false for the frequency

- UeMCNrFreqRelProfileUeCfg . connModeAllowedPCell = true for the frequency

- The PLMN conditions are fulfilled (refer to the feature description for NR Mobility in CPI)

When the event is triggered, the gNodeB determines whether the reported cell is known, valid for mobility, has an allowed PLMN and has a suitable slicing configuration. If not, the report is discarded, and no mobility action is taken.

If the reported cell is blocked for traffic (due to manual barring, cell soft lock, or cell sleep preparation), handover is not attempted. Refer to Section 10.3.35 for further details.

<!-- page: 319 -->

or if the

If the reported cell is valid and from a high priority frequency, then the gNodeB initiates mobility action to the reported cell, regardless of whether the priority period is running or not. The mobility action is either handover to the reported cell, if NRCellRelation.isHoAllowed = true , or release-with-redirect, if it is false UE does not support handover to this frequency.

If the reported cell is valid, from a low priority frequency and the priority period is running, then the gNodeB waits for a high priority report and handles the low priority one as follows:

- If Mcpc.nrLowPrioPCellCandHandling = STORE_LATEST_RECEIVED , then the reported cell is stored (replacing the pre-existing stored cell if there is one)

- If Mcpc.nrLowPrioPCellCandHandling = STORE_HIGHEST_PRIO , then the reported cell is stored if its priority is equal to or higher than any previously stored cell, otherwise it is discarded.

If the priority period expires before a high priority report is received, then the gNodeB initiates handover or release-with-redirect to the stored low priority cell, if there is one. If there is no stored cell when the priority period expires, then the gNodeB initiates handover or release-with-redirect to the next valid reported cell, regardless of whether it is low or high priority.

**Event B2 - EUTRAN Candidate**

This event is used in the search zone to detect a suitable target cell on an LTE frequency. If entry into the search zone is triggered by RSRP, RSRQ or SINR, then the B2 uses the same measurement quantity. If entry into the search zone is triggered by UL_SINR, then the B2 uses RSRP. It is configured only if valid candidate LTE frequencies exist.

The event is configured with the McpcPCellProfileUeCfg struct attributes rsrpCandidateB2 , rsrqCandidateB2 and/or sinrCandidateB2 , depending on the measurement quantity. These struct attributes all contain threshold1 , threshold2EUtra , hysteresis and timeToTrigger . The attribute threshold1 is used to confirm that the serving cell is poor enough and threshold2EUtra is used to confirm that the target LTE cell coverage is good enough, so justifying mobility.

When MCPC receives the B2 report, other measurement quantities (besides the triggering quantity) can also be checked, using the following attributes of McpcPCellProfileUeCfg .

- When the triggering quantity is RSRP or uplink SINR, then an RSRQ or a SINR check can be added for the target cell using rsrpCandidateB2AddTargEval .

- When the triggering quantity is RSRQ, then only an RSRP check can be added for the target cell using rsrqCandidateB2AddTargEval .

- When the triggering quantity is downlink SINR, then an RSRP and/or a RSRQ check can be added for the target cell using sinrCandidateB2AddTargEval .

<!-- page: 320 -->

For example, if mcpcQuantityList = RSRP and rsrpCandidateB2AddTargEval = SINR_FALLBACK_RSRQ , then MCPC also checks the reported SINR value (for UEs that can measure SINR), or the reported RSRQ value (for UEs that cannot measure SINR).

If the received B2 report fails any of the additional checks described above, the measurement report is discarded and MCPC waits for a new report to evaluate.

If the triggering quantity is uplink SINR, then handover to LTE is allowed only if ExternalENodeBFunction.ulTrigHoAllowed = True . The uplink quality of the target cell is not checked as part of the handover, so set ulTrigHoAllowed = True only if rsrpCandidateB2.threshold2EUtra is set to a value that ensures both the downlink and uplink quality of the LTE target cell are likely to be satisfactory. If ulTrigHoAllowed = False , handover is not attempted. When an MCPC-triggered HO to LTE is caused by uplink SINR, the eNodeB attribute mobilityBackToNrFreqDisabled can be used to block immediate mobility back to that NR frequency, thereby reducing the risk of ping pong handover.

Some UEs support downlink SINR measurements on NR frequencies but not on LTE frequencies. In this case, if entry into the search zone is triggered by SINR, then the B2 measurement uses RSRP, with threshold 1 set to -29 dBm. The values for threshold2EUtra , timeToTrigger and hysteresis are taken from rsrpCandidateB2 .

See Section 11.2.8.6 for the formulas defining the trigger levels and the additional checks.

An LTE frequency is considered as a valid candidate if:

- The UE is capable of measuring the LTE frequency

- McpcPCellEUtranFreqRelProfileUeCfg . inhibitMeasForCellCandidate = false for the LTE frequency

- UeMCEUtranFreqRelProfileUeCfg . connModeAllowedPCell = true for the LTE frequency

- The PLMN conditions are fulfilled (refer to the feature description for NR Mobility in CPI) and the target RAT is not restricted according to the Mobility Restriction Lis t (MRL)

When the event is triggered, the gNodeB determines whether the reported cell is known, valid for mobility and has a suitable PLMN. If not, the report is discarded, and no mobility action is taken.

If the reported cell is valid and from a high priority frequency, the gNodeB initiates mobility action to the reported cell, regardless of whether the priority period is running or not. The mobility action is handover if EUtranCellRelation.isHoAllowed = true , or releasewith-redirect if it is false or if the UE does not support handover to the frequency.

If the reported cell is valid, from a low priority frequency and the priority period is running, then the gNodeB waits for a high priority report and handles the low priority one as follows:

<!-- page: 321 -->

- If Mcpc.nrLowPrioPCellCandHandling = STORE_LATEST_RECEIVED , then the reported cell is stored (replacing the pre-existing stored cell if there is one)

- If Mcpc.nrLowPrioPCellCandHandling = STORE_HIGHEST_PRIO , then the reported cell is stored if its priority is equal to or higher than any previously stored cell, otherwise it is discarded.

If the priority period expires before a high priority report is received, then the gNodeB initiates handover or release-with-redirect to the stored low priority cell, if there is one. If there is no stored cell when the priority period expires, then the gNodeB initiates handover or release-with-redirect to the next valid reported cell, regardless of whether it is low or high priority.

For handover from NR SA to LTE, the feature Incoming NR IRAT Handover must be activated in the eNodeB. Direct packet forwarding is initiated during the handover.

**Event A2 - Critical Coverage**

This event is configured in the UE to detect critical serving PCell coverage.

It is enabled separately for each measurement quantity allowed by mcpcQuantityList , by setting the McpcPCellProfileUeCfg attributes rsrpCriticalEnabled , rsrqCriticalEnabled , sinrCriticalEnabled and/or ulQualCriticalEnabled to true .

Once enabled, the triggering criteria are configured with the McpcPCellProfileUeCfg struct attributes rsrpCritical , rsrqCritical and sinrCritical , or the UlQualMcpcMeasCfg struct attribute ulQualCritical using the underlying attributes threshold , hysteresis and timeToTrigger . See Section 11.2.8.3 for the trigger level formulas.

If this event is triggered and a low priority candidate is stored, then the gNodeB initiates handover to the candidate if NRCellRelation.isHoAllowed = true (for NR) or EUtranCellRelation.isHoAllowed = true (for LTE). If the stored candidate has isHoAllowed = false , then gNodeB initiates a release-with-redirect to the candidate.

If the triggering quantity is uplink SINR, then the handover is allowed only if the following conditions are met:

- For HO to NR, ExternalGNBCUCPFunction.ulTrigHoSupport = True or ExternalGNBCUCPFunction.ulTrigHoAllowed = True

- For HO to LTE, ExternalENodeBFunction.ulTrigHoAllowed = True

If no low priority candidate is stored but an LTE frequency relation exists that is supported by the UE, then the gNodeB initiates blind release-with-redirect to an LTE frequency. The frequency is selected using UeMCEUtranFreqRelProfileUeCfg.blindRwrAllowed as follows:

<!-- page: 322 -->

̶

- The gNodeB selects the LTE frequency(s) that have blindRwrAllowed = true , are supported by the UE, and are not excluded by the mobility restriction list (MRL). If there are multiple such frequencies, then the gNodeB selects the one with the lowest EARFCN.

- If none of the LTE frequencies allow release-with-redirect, then the UE is released to idle.

Inter-gNodeB handovers are Xn-based by default if certain conditions are met. However, the attribute GNBCUCPFunction.prefInterGNBHo enables the default to be changed to NG-based. See CPI for NR Mobility for more detail.

#### 10.3.4.6 Idle Mode Steering - SA

Idle mode steering enables the cell reselection priorities to be set per UE group, overriding the priorities broadcast in system information. This allows idle mode mobility to be tailored per UE group.

The overriding priorities are sent to UE in the RRC connection release message when the UE is released to RRC_IDLE or RRC_INACTIVE and they apply until TrStSaCellProfileUeCfg.t320 expires or until the UE reenters connected mode.

Idle mode steering is used when the following criteria are met:

- The UE is included in a UE group ( TrStSaCellProfileUeCfg ), with the following configuration:

̶

- TrStSaCellProfileUeCfg.actionAtRelease = 2 ( PRIORITY_LIST )

- At least one of TrStSaCellProfileUeCfg.freqPrioListNR or TrStSaCellProfileUeCfg.freqPrioListEUtran have frequencies and cell reselection priorities defined (not an empty list). Priorities can be specified for up to 8 NR frequencies and/or 8 LTE frequencies. If either the NR or the LTE list is empty, then reselection to that RAT is not possible until t320 expires. If both lists are empty, the UE uses the broadcast priorities.

For a frequency to be included in the RRC release message, the frequency must be configured to allow PCell:

- ·

- NR frequencies:

- ·

UeMCNrFreqRelProfileUeCfg . connModeAllowedPCell = true

- LTE frequencies:

UeMCEUtranFreqRelProfileUeCfg . connModeAllowedPCell = true

#### 10.3.4.7 Cell Barred and Cell Reserved

NR cells can be reserved for operator use only, as follows:

<!-- page: 323 -->

- Set NRCellDU . cellReservedForOperator or AdditionalPLMNInfo.cellReservedForOperator = RESERVED to prevent all UEs except access identities 11 and 15 from accessing the cell from RRC_IDLE and RRC_INACTIVE states. UEs are immediately informed of the cell reserved status via an update to SIB1.

- Additionally, set UeMCCellProfileUeCfg.connModeUeAllowedToResCell = false to prevent incoming handover and PSCell change, and to prevent the cell being used as a PSCell for EN-DC or NR-DC setup.

NR cells can be barred for access for all users, as follows:

- Set NRCellDU.cellBarred = BARRED , to prevent all UEs from accessing the cell from RRC_IDLE and RRC_INACTIVE states. UEs are immediately informed of the cell reserved status via an update to system information MIB. Cells can also be barred by the feature NR Cell Soft Lock , when shutting down, and by the feature NR Booster Carriers Sleep for energy saving.

- Additionally, set UeMCCellProfile.connModeUeAllowedToBarredCellType = NONE to prevent incoming handover and PSCell change, and to prevent the cell being used as a PSCell for EN-DC or NR-DC setup.

#### 10.3.4.8 Prohibited Cell-Triggered Mobility - SA

Prohibited cell-triggered mobility enables the gNodeB to trigger inter-frequency or interRAT mobility when a UE attempts intra-frequency mobility to a prohibited cell on SA. This reduces interference and improves retainability and integrity.

It is enabled using the attribute UeMCCellProfile.prohibitCellTrigMob as follows:

- ENABLED_ALL - Enables mobility to NR and LTE frequencies

- ENABLED_EUTRAN_ONLY - Enables mobility to LTE frequencies only

It is triggered if:

- The UE sends UeMCCellProfile.noOfInvIntraFreqTrigPCSearch consecutive A3 reports for invalid mobility targets (default 1), and the UE is not in the MCPC search zone. LTM A3 reports for invalid mobility targets are not counted.

̶

- Invalid mobility targets can occur, for example, because:

- The cell is barred or reserved for operator use only (Section 10.3.4.7)

- The cell supports only NSA, not SA

- Handover is prevented by NRCellRelation . isHoAllowed = false

The gNodeB then configures measurements on valid candidate frequencies.

A configured NRFreqRelation is a valid candidate if:

<!-- page: 324 -->

- UeMCNrFreqRelProfileUeCfg . connModeAllowedPCell = true

- The UE supports the frequency in DL and UL

- The frequency is not restricted for the UE by MRL or PLMN

A configured EUtranFreqRelation is valid candidate if:

- UeMCEUtranFreqRelProfileUeCfg . connModeAllowedPCell = true

- The UE supports Event B triggered reporting

- The UE supports the frequency in DL and UL

- The frequency is not restricted for the UE by MRL or PLMN

The first valid NR (A5) or LTE (B1) cell that the UE reports is acted upon; there is no priority handling amongst the valid candidate frequencies.

If the cell relation corresponding to the cell reported in the A5 or B1 has isHoAllowed = false , then the gNodeB triggers release-with-redirect to the reported frequency.

For details of the parameters used to configure the A5 and B1 events, see Section 11.2.14.

#### 10.3.4.9 Dedicated SIB1 Delivery at Handover

If RrcUeCfg . dedicatedSib1AtHo = true , (the default is false ), the source gNodeB includes SIB1 information for the target NR cell in the RRCReconfiguration message sent to the UE during handover, reducing the risk of NAS mobility registration failure.

### 10.3.5 NR Traffic Steering (FAJ 121 5458) - SA

This is an unlicensed gNodeB feature in the NR Base Package (FAJ 801 4002).

The purpose of the NR Traffic Steering feature is to manage the UE at setup and release and guide the UE to the most suitable PCell.

The feature contains the following functionalities, described in following sub-sections:

- Multi-Layer Coordination (MLC)

- Traffic Steering Cell Reselection Priority at UE Release

- Bandwidth-Triggered Inter-System Handover (BWTISHO)

- Dynamic Cell Set Change during Mobility (DCSC)

<!-- page: 325 -->

**These functionalities are configured primarily at the UeCfg level (e.g.**

TrStSaCellProfileUeCfg , TrStSaNrFreqRelProfileUeCfg , etc). This allows the features to be configured differently for different UE groups. For example, NR-DC, CA, MLC, DCSC and BWTISHO could all be disabled for UEs that have a VoNR bearer.

For further information see the feature description for NR Traffic Steering and the NR Traffic Steering Solution Guideline in CPI.

#### 10.3.5.1 Multi-Layer Coordination - SA

The purpose of Multi-Layer Coordination (MLC) is to estimate whether the UE could achieve a better downlink or uplink data rate by changing the serving cell set and, if so, attempt to change it.

MLC evaluation is triggered after the UE connects from RRC_IDLE or RRC_INACTIVE state. Additionally, if periodic traffic steering is enabled ( mlcPeriodicEnabled = true , see Section 10.3.5.4), then MLC evaluation also occurs periodically, giving the maximum benefit. This section assumes periodic traffic steering is enabled.

MLC is possible only when the UE is in good coverage in the serving PCell. If the UE enters poor coverage (Event A2 - Entering Search Zone is triggered), then the MLC measurements are stopped and replaced by MCPC measurements to find a better cell.

MLC evaluation occurs if the following criteria are met:

- MLC functionality is enabled. MLC at setup and resume can be enabled independently of periodic MLC, as follows:

̶

- To enable MLC at connection setup and resume, set: (gNB) TrStSaCellProfileUeCfg . mlcEnabled = true

- To enable periodic MLC evaluation (using Mobility ) set:

̶

- Dynamic Cell Set Change During

(gNB) TrStSaCellProfileUeCfg . mlcPeriodicEnabled = true

- NR-DC is not configured or is not possible to configure:

̶

- At connection setup and resume, MLC is possible only if NR-DC is not possible

̶

- At periodic MLC evaluation, MLC is possible only if NR-DC is not configured

̶

- Refer to Figure 10-26 for details.

- The UE is in good coverage (Event A2 - Entering Search Zone has not been triggered)

MLC evaluates the available cell set against potential candidate cell sets .

<!-- page: 326 -->

The available cell set consists of the current PCell and any SCells for which an A1 report has been received. MLC evaluation does not start until the coverage status of any blindly configured SCells is known, meaning that either the corresponding A1 or A2 reports have been received, or the supervision timer has expired (as described in Section 4.6.3.1). After the timer expires, SCells for which no A1 or A2 report is received are treated as having 'unknown' coverage status. These SCells are deactivated but are included in the MLC candidate list.

The following A1 and A2 measurements are used for this purpose:

- When carrier aggregation is configured, A1 and A2 measurements are started on all SCells to trigger their activation and deactivation. These reports are also used by MLC to evaluate coverage for candidate cell set evaluation.

- Additionally, if MLC is enabled and UL CA is configured, A1 (MLC A1UL) and A2 (MLC A2UL) measurements are started on all SCells that are UL CA capable, to detect whether they are suitable for UL and SCell reselection.

The candidate cell set (s), are chosen based on the allowable actions for changing cell sets, as determined by mlcAllowedCellSetChangeAction . The options are:

- 0 (HANDOVER) - The cell set change involves a handover. So the candidate cell set(s) consist of a PCell on a different frequency to the current PCell, and possibly one or more SCells.

- 1 (SCELL_RESELECTION) - The cell set change involves an SCell reselection. So the best candidate cell set(s) consist of the current PCell and one or more SCells that are different to any existing SCells.

- 2 (HO_AND_SCELL_RESELECTION) - The cell set change involves either handover or SCell reselection. So the best candidate cell set(s) are the union of those two options, as described above.

PCell candidates must meet the following conditions:

- The current PCell has an NRCellRelation or a lwNeighborRel to the candidate PCell

- NRCellRelation . isHoAllowed = true for the PCell candidate

- UeMCNrFreqRelProfileUeCfg . connModeAllowedPCell = true for the PCell candidate

- TrStSaNrFreqRelProfileUeCfg . pCellAllowed = true for the frequency relation of the PCell candidate. This attribute can be set to true for multiple frequency relations.

SCell candidates must meet the following conditions:

- The current PCell has an NRCellRelation to the candidate SCell, with NRCellRelation . caStatusActive = true .

<!-- page: 327 -->

̶

- A lwNeighborRel cannot be used as an MLC SCell candidate.

- For DL SCell candidates:

̶

- NRCellRelation . sCellCandidate = ALLOWED or ONLY_ALLOWED_FOR_DL

̶

- An A2 DL SCell report has not been received

- For UL SCell candidates:

̶

- NRCellRelation . sCellCandidate = ALLOWED

̶

- An A2 UL SCell report has not been received

If a candidate cell is blocked for traffic (due to manual barring, cell soft lock, or cell sleep preparation), it is excluded. Refer to Section 10.3.35 for further details.

MLC finds all the possible candidate cell set combinations (based on setting of mlcAllowedCellSetChangeAction , as described above) and estimates the downlink and uplink data rates achievable given the UE capabilities. These estimates are referred to as the downlink and uplink cell set weights. For each cell, the estimations consider the number of PRBs, the number of slots per millisecond, the modulation order, the number of MIMO layers, ESS (for the DL, if configured), the TDD pattern, the cellSelectionWeightFactor and potentially the cell load (depending on whether the optional features described below are active).

The downlink cell weight is calculated as follows:

DL Cell Weight [kbps] = PRBs * SlotsPerMillisecond * ModulationOrder * MimoLayersDL * ESSRatio * PatternRatioDL * 133 * NRCellDU.cellSelectionWeightFactor * dlAvailableCapacityFactor

The modulationOrder is the number of bits for a modulation symbol. For 64QAM, the modulationOrder is 6. For 256QAM, the modulationOrder is 8.

The dlAvailableCapacityFactor allows MLC to consider the downlink load and is calculated using the feature NR Advanced Multi-Layer Coordination , as described in Section 10.3.6. If that feature is not active, then dlAvailableCapacityFactor = 1.

The uplink cell weight is calculated as follows:

UL Cell Weight = PRBs * SlotsPerMillisecond * ModulationOrder * EffectiveMimoLayersUL * UlTxSwitchingGapRatio * PatternRatioUL * 143 * NRCellDU.cellSelectionWeightFactor ulAvailableCapacityFactor

*

<!-- page: 328 -->

The factors EffectiveMimoLayersUL and UlTxSwitchingGapRatio consider the throughput benefit when the UE can be configured with 2-Layer uplink (using UL SU-MIMO or UL TX switching). During initial cell selection, EffectiveMimoLayersUL uses the value set in CaCellProfileUeCfg.effectiveBwImpactUl2Layer .

The ulAvailableCapacityFactor allows MLC to consider the uplink load and is calculated using the feature Uplink-Aware Advanced Multi-Layer Coordination , as described in 10.3.7. If that feature is not active, then ulAvailableCapacityFactor = 1.

To calculate the cell set weights, the individual cell weights are summed.

MLC then selects the best candidate cell set, by ranking them to prioritize either the estimated DL or UL data rate (weight) according to the setting of servingCellSelectionPolicy , as follows:

- 0 (PRIORITIZE_DL_THP)

MLC ranks the cell sets according to the estimated DL cell set weight, then the estimated DL PCell weight.

- 1 (PRIORITIZE_UL_THP) MLC ranks the cell sets according to the estimated UL cell set weight, then the

estimated UL PCell weight.

- 2 (PRIO_DL_THP_THEN_PCELL_UL_THP) MLC ranks the cell sets according to the estimated DL cell set weight, then the

estimated UL PCell weight.

If servingCellSelectionPolicy = PRIORITIZE_DL_THP , then one of the two checks below must be satisfied to conclude that the candidate cell set is better than the available cell set (i.e. the current cell set).

- DL cell set criterion check:

- DL PCell criterion check:

DL WeightcandCellSet DL WeightavailCellSet >= 1, and ( DL WeightcandPCell DL WeightavailPCell - 1) x 100 >= criterionBetterUeConfig , and DL WeightcandPCell - DL WeightavailPCell >= criterionDlAbsoluteOffset x 1,000

If servingCellSelectionPolicy = PRIORITIZE_UL_THP , then one of the two checks below must be satisfied to conclude that the candidate cell set is better than available cell set (i.e. the current cell set):

<!-- page: 329 -->

- UL cell set criterion check:

( WeightavailCellSet , and UL WeightcandCellSet - UL WeightavailCellSet >= criterionUlAbsoluteOffset x 1,000

- UL PCell criterion check:

UL WeightcandCellSet UL WeightavailCellSet >= 1, and ( UL WeightcandPCell UL WeightavailPCell - 1) x 100 >= criterionBetterUeConfig , and UL WeightcandPCell - UL WeightavailPCell >= criterionUlAbsoluteOffset x 1,000

If servingCellSelectionPolicy = PRIO_DL_THP_THEN_PCELL_UL_THP , then one of the two checks below must be satisfied to conclude that the candidate cell set is better than available cell set (i.e. the current cell set):

- DL cell set criterion check:

- UL PCell criterion check:

DL WeightcandCellSet DL WeightavailCellSet >= 1, and ( UL WeightcandPCell UL WeightavailPCell - 1) x 100 >= criterionBetterUeConfig , and UL WeightcandPCell - UL WeightavailPCell >= criterionUlAbsoluteOffset x 1,000

The units of criterionDlAbsoluteOffset and criterionUlAbsoluteOffset are Mbps. If set to zero, the absolute test is disabled.

If mlcAllowedCellSetChangeAction = SCELL_RESELECTION , then the DL and UL PCell criterion checks are not applied.

If mlcAllowedCellSetChangeAction = HO_AND_SCELL_RESELECTION , then MLC evaluation prioritizes SCell reselection over handover when they would result in a similar gain for the UE, thereby reducing the number of handovers performed. To facilitate this, the evaluation process selects the best candidate cell set for handover and the best candidate cell set for SCell reselection, and compares these with the available cell set (i.e. the current cell set) as follows:

<!-- page: 330 -->

- If neither candidate cell set is better than the available cell set according to the criterion checks described above, then the available cell set is retained.

- If only one candidate cell set is better than the available cell set according to the criterion checks described above, then that one is chosen.

- If both candidate cell sets are better than the available cell set according to the criterion checks described above, then the handover candidate is chosen only if the following conditions are met (otherwise the SCell reselection candidate is chosen).

̶

- The handover candidate has a higher cell set weight in the prioritized direction (which is set with servingCellSelectionPolicy ), or

̶

- The handover candidate has an equal cell set weight in the prioritized direction and:

- The handover candidate PCell weight in the prioritized direction is better than the current PCell weight by both the relative and absolute offsets, or

- The handover candidate PCell weight in the prioritized direction is equal to or better than the current PCell weight, and the handover candidate cell set weight in the opposite direction is better than the SCell reselection candidate cell set weight by both the relative and absolute offsets.

If MLC finds a better candidate cell set, then it determines whether measurements are needed to evaluate the coverage of the candidate cells, as follows:

- If moving to the cell set involves a handover, then the gNodeB always configures an A5 measurement on the candidate PCell frequency.

̶

- If the candidate PCell involves UL 2-layer transmission or an UL CA power reduction, then the A5 measurement threshold on the PCell is adjusted accordingly.

̶

- If the handover includes a change of SCell(s), and the coverage of any SCell is not already known (via previous A1, A2 or A5 measurement reports), an A5 measurement is configured for that SCell.

- If the new cell set does not involve a PCell handover, but only SCell reselection, then the gNodeB configures A5 measurements for any SCell with unknown coverage status.

̶

- If the candidate cell set involves UL 2-layer transmission or a power reduction, then the gNodeB configures an A1 measurement to check the coverage of the current PCell.

The trigger quantities used for these measurements are as follows:

- For downlink PCell or SCell candidates, determines the trigger quantity:

TrStSaCellProfileUeCfg . mlcTriggerQuantity RSRP, RSRQ, or SINR and the fallback quantity (RSRP or RSRQ) if the UE does not support SINR.

- For measurements to determine uplink SCell and PCell coverage, RSRP is used.

<!-- page: 331 -->

The gNodeB then waits for the measurement reports from the UE. If the gNodeB receives all the required reports before the maximum measurement time expires, so completing the coverage picture of the best candidate cell set, then it initiates PCell handover or SCell reselection. For PCell handover, MLC includes the SCells in the handover message, and the target gNodeB configures carrier aggregation with those SCells.

The maximum time that the gNodeB waits for the measurement reports is:

Maximum measurement time =  480 + N * 200 + timeToTrigger (ms) where N is the number of frequencies to measure, and timeToTrigger is taken from the relevant trigger quantity, as set by

TrStSaCellProfileUeCfg . mlcTriggerQuantity .

When MLC receives the A5 report for a PCell candidate, other measurement quantities (besides the triggering quantity) can be checked too, using the following TrStSaCellProfileUeCfg attributes:

- When mlcTriggerQuantity = RSRP , then an RSRQ or a SINR check can be added for the target using rsrpPCellCandidateAddTargEval .

- When mlcTriggerQuantity = RSRQ , then only an RSRP check can be added for the target cell using rsrqPCellCandidateAddTargEval .

- When mlcTriggerQuantity = SINR , then an RSRP and/or an RSRQ check can be added for the target cell using sinrPCellCandidateAddTargEval .

For example, if the mlcTriggerQuantity = RSRP and rsrpPCellCandidateAddTargEval = SINR_FALLBACK_RSRQ , then MLC also checks the reported SINR value (for UEs that can measure SINR), or the reported RSRQ value (for UEs that cannot measure SINR).

If the received A5 report fails any of the additional checks described above, the measurement report is discarded.

If the gNodeB does not receive all the needed measurement reports within this maximum measurement time, then MLC evaluates whether any remaining candidate cell sets are better than the current cell set. If so, and if the previously received measurements have not eliminated those cell set(s), then MLC configures new measurements to search for any candidate cells whose coverage is unknown. If no better candidate cell sets are found, then all measurements are removed, and the evaluation stops.

For high power UEs, the useable NR cell coverage can be extended by adding an offset to the RSRP A5 threshold 2 using rsrpPCellCandidatePcOffset . A high-power UE is one that has higher power than power class 3 (23 dBm), which is the most common power class. The offset is set per UE power class; a negative value expands the useable NR coverage area.

If the feature NR Small Cell Traffic Steering is enabled, then MLC allows handover to other vendor cells on frequencies measured by MLC. Refer to Section 10.3.29 for further information.

<!-- page: 332 -->

Details of the triggering thresholds for MLC are provided in the trigger level formulas of Section 11.2.11.

#### 10.3.5.2 Traffic Steering Cell Reselection Priority at UE Release - SA

The purpose of this function is to keep the UE on the frequency chosen by MLC, even after the UE is released to RRC_IDLE or RRC_INACTIVE. This prevents unnecessary MLCtriggered handovers when the UE reenters connected mode.

The UE is kept on the serving frequency by overriding the broadcast cell reselection priorities with dedicated priorities, which give the serving frequency the highest priority.

The dedicated priorities are sent to the UE in the cellReselectionPriorities information element of the RRCRelease message, if the following criteria are met:

- The UE is released due to inactivity

- If TrStSaCellProfileUeCfg.actionAtRelease = CA_CONF *, and CA is configured in the UE being released

- If TrStSaCellProfileUeCfg.actionAtRelease = CRP_MLC_CONDITIONAL *, and MLC has been performed for the UE

* To ensure optimal performance of CRP at release, set actionAtRelease = CRP_MLC_CONDITIONAL rather than CA_CONF . The other possible values for actionAtRelease are described in Section 8.2.7.

The dedicated cell reselection priority and sub-priority values used in the release message are determined as follows:

| Frequency                                | cellReselectionPriorities IE                                                                  | cellReselectionPriorities IE                                                                                  |
|------------------------------------------|-----------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------|
| Frequency                                | cellReselectionPriority                                                                       | cellReselectionSubPriority                                                                                    |
| Current PCell frequency                  | 7 (highest)                                                                                   | .8 (highest)                                                                                                  |
| Current configured SCell frequencies     | 6                                                                                             | Set to .8, .6, .4, .2 or empty prioritized in order of decreasing ARFCN (highest ARFCN gets highest priority) |
| Remaining NR cell frequencies            | 5                                                                                             | Set to .8, .6, .4, .2 or empty prioritized in order of decreasing ARFCN (highest ARFCN gets highest priority) |
| E-UTRAN frequencies of the current PCell | Remapped to 4, 3, 2, 1, 0 based on current PCell EUtranFreqRelation . cellReselectionPriority | Remapped to .8, .6, .4, .2 or empty based on current PCell EUtranFreqRelation . cellReselectionSubPriority    |

The UE uses the modified priorities until it either enters connected mode or until the timer TrStSaCellProfileUeCfg.t320 expires, after which the UE reverts to using the broadcast values (set in NRFreqRelation and EUtranFreqRelation ). UEs that do not support sub-priorities use only the values contained in cellReselectionPriority .

<!-- page: 333 -->

#### 10.3.5.3 Bandwidth-Triggered Inter-System Handover - SA

The purpose of Bandwidth-Triggered Inter-System Handover (BWTISHO) is to move UEs from NR SA to LTE when the total NR bandwidth available with the current cell set is below a configurable threshold.

BWTISHO evaluation occurs when the UE connects from RRC_IDLE or RRC_INACTIVE. Additionally, if periodic traffic steering is enabled ( mlcPeriodicEnabled = true ), then BWTISHO evaluation also occurs periodically, giving the maximum feature benefit. This section assumes periodic traffic steering is enabled.

**Criteria to start measurements**

For BWTISHO to start the measurements required for handover to LTE, the following criteria must be met:

- TrStSaCellProfileUeCfg.bwTrigISHoEnabled = true

- NR-DC is not configured or is not possible to configure, as below:

̶

- At connection setup and resume, BWTISHO is possible only if NR-DC is not possible

̶

- At periodic BWTISHO evaluation, BWTISHO is possible only if NR-DC is not configured

̶

- Refer to Figure 10-26 for details.

- There is at least one LTE frequency with that the

**·**

UeMCEUtranFreqRelProfileUeCfg.connModeAllowedPCell = true UE can use for handover or RwR

- The UE supports Event B2 triggered measurements

- The UE is in good coverage in the serving PCell (not in the MCPC search zone)

**· The total bandwidth of the current cell set is less than or equal to**

TrStSaCellProfileUeCfg.aggregatedBwThreshold

- The current cell set consists of the PCell and any SCells within coverage (an A1 report has been received for the SCell)

̶

- The cell bandwidth is set using the attribute NRSectorCarrier.bSChannelBwDL

- If the feature NR Data-Aware Mobility is enabled, then additional conditions must be fulfilled; refer to Section 10.3.26 for more details

̶

̶

<!-- page: 334 -->

**Measurement configuration**

If these criteria are met, the gNodeB configures an Event B2 measurement to find a valid target cell on the candidate LTE frequencies.

**The trigger quantity used for the B2 measurement is set by**

TrStSaCellProfileUeCfg.bwTrigISHoTriggerQuantity , to RSRP , RSRQ , SINR_FALLBACK_RSRP or SINR_FALLBACK_RSRQ . For the two SINR settings, the fallback quantity is used if the UE does not support SINR measurements. The trigger conditions are configured using the struct attribute for the chosen trigger quantity, namely rsrpPCellCandidateB2 , rsrqPCellCandidateB2 or sinrPCellCandidateB2 . See Section 11.2.13 for the trigger level formulas.

The maximum B2 measurement time is determined automatically and depends on the number of measured frequencies (N). The formula used is:

Maximum B2 measurement time =  480 + N * 200 + timeToTrigger (ms)

The timeToTrigger parameter is taken from rsrpPCellCandidateB2 , rsrqPCellCandidateB2 or sinrPCellCandidateB2 , depending on the trigger quantity.

If a B2 report is not received within this time, then the measurement is removed.

If the UE enters the MCPC search zone while the BWTISHO B2 measurements are ongoing, then the BWTISHO measurements continue and MCPC measurements to find a better cell (A5 and/or B2) are configured in parallel.

**Measurement report handling**

When BWTISHO receives the B2 report, other measurement quantities (besides the triggering quantity) can be checked too, using the following TrStSaCellProfileUeCfg attributes:

- When bwTrigISHoTriggerQuantity = RSRP , then an RSRQ or a SINR check can be added for the target cell using rsrpPCellCandidateB2AddTargEval .

- When bwTrigISHoTriggerQuantity = RSRQ , then only an RSRP check can be added for the target cell using rsrqPCellCandidateB2AddTargEval .

- When bwTrigISHoTriggerQuantity = SINR , then an RSRP and/or an RSRQ check can be added for the target cell using sinrPCellCandidateB2AddTargEval .

For example, if bwTrigISHoTriggerQuantity = RSRP and rsrpPCellCandidateB2AddTargEval = SINR_FALLBACK_RSRQ , then BWTISHO also checks the reported SINR value (for UEs that can measure LTE SINR), or the reported RSRQ value (for UEs that cannot measure LTE SINR).

<!-- page: 335 -->

If any configured additional check is failed, the B2 report is discarded. Otherwise, the gNodeB uses the following process to decide whether to initiate a handover (if the UE supports it and EUtranCellRelation . isHoAllowed = true ) or a release-with-redirect (RwR) to the reported cell 's frequency . The process ensures that the target LTE frequencies with the highest priorities are given preference over lower priority ones.

- If the reported cell has the highest priority frequency among the measured frequencies, then the gNodeB triggers handover to the reported cell or RwR to the reported cell 's LTE frequency immediately. The priority of an LTE frequency is set using the attribute UeMCEUtranFreqRelProfileUeCfg.connModePrioPCell .

- If the reported cell does not have the highest priority, then it is stored for later use. If there is already a stored report, then it is replaced if the new report has an equal or higher priority, otherwise the new report is discarded. The gNodeB then waits for another report.

- If a report for the highest priority frequency is not received before the maximum B2 measurement time expires, then the gNodeB initiates handover to the stored cell or RwR to the stored cell 's LTE frequency.

**Handover handling**

Direct packet forwarding is initiated during handover from SA to LTE.

After BWTISHO triggers mobility to LTE, the UE can be discouraged from returning to the NR SA frequency as follows:

- If the mobility was handover, the eNodeB can prevent return in both connected and idle mode, as described in Section 10.2.2.

- If the mobility was a release-with-redirect, the gNodeB can discourage return in idle mode, as described in Section 8.3.12.

#### 10.3.5.4 Dynamic Cell Set Change During Mobility - SA

Dynamic Cell Set Change During Mobility (DCSC) provides periodic opportunities for the following functions to be triggered (in addition to when the UE connects from RRC_IDLE or RRC_INACTIVE state):

- Multi-Layer Coordination (MLC) and NR Small Cell Traffic Steering (SCTS)

- Bandwidth-Triggered Inter-System Handover (BWTISHO)

- NR Data-Aware Mobility (DAM)

These functions evaluate the current connectivity and coverage, and potentially trigger a change to more suitable connectivity.

**DCSC (periodic traffic steering) is enabled by setting**

(gNB) TrStSaCellProfileUeCfg . mlcPeriodicEnabled = true .

<!-- page: 336 -->

The periodicity is set with TrStSaCellProfileUeCfg.mlcPeriodicInterval (default 15 s).

The evaluation takes place as shown, at a high level, in Figure 10 - 26 and the following notes. The figure assumes evaluation occurs both at setup and periodically, which requires that both mlcEnabled and mlcPeriodicEnabled are set to true . A more detailed flow chart is provided in the NR Traffic Steering feature description in CPI.

![Figure on page 336](5G_Mobility_and_Traffic_Management_Guideline_images/page_336_image_002.png)

Figure 10-26 - Traffic Steering Overview

Notes for Figure 10 - 26 :

- When MLC, SCTS, BWTISHO and DAM are evaluated, MLC and SCTS evaluations occur first, followed by BWTISHO and DAM evaluation

- If a coverage-triggered handover occurs, then the periodic timer is started in the destination cell (assuming DCSC is activated)

- Setting up NR-DC is a higher priority than MLC, SCTS, BWTISHO and DAM. Therefore, when the UE connects from idle or inactive state, if NR-DC is possible (meaning the UE and cell are capable of NR-DC) then the gNodeB waits for the DCSC timer to expire before attempting MLC, SCTS, BWTISHO and DAM.

Figure 10-27 shows periodic evaluation by DCSC and servingCellSelectionPolicy = PRIORITIZE_DL_THP as the UE moves into progressively better coverage from carriers that are ranked higher by MLC. In this example, the UE is DL 2CC capable and can use either FDD or TDD as PCell.

<!-- page: 337 -->

![Figure on page 337](5G_Mobility_and_Traffic_Management_Guideline_images/page_337_image_002.png)

Figure 10-27 - Operation of MLC as UE moves into better coverage

Notes for Figure 10-27:

- The UE sets up from RRC_IDLE or RRC_INACTIVE on FDD1. The gNodeB performs blind SCell selection and configures the SCell on TDD, which has the largest estimated downlink data rate in this example. MLC cannot find coverage from any candidate cell set, and the DCSC periodic timer is started.

- The UE moves into suitable PCell coverage from FDD2, the periodic timer elapses and MLC evaluation is performed. A5 measurements are configured to detect coverage from FDD2, noting that the gNodeB already knows there is no coverage from TDD as it did not receive an A1 report for the configured TDD SCell. FDD2 coverage is found, the UE sends an A5 report, MLC performs a PCell handover to FDD2, and FDD1 is configured as an SCell.

- The UE moves into suitable SCell coverage from TDD, the periodic timer elapses and MLC evaluation is performed. A5 measurements are configured to detect coverage from TDD. TDD coverage is found, the UE sends an A5 report, MLC performs SCell reselection, replacing the FDD1 with TDD.

- The UE moves into suitable PCell coverage from TDD, the periodic timer elapses and MLC evaluation is performed. A5 measurements are configured to detect suitable PCell coverage from TDD. TDD coverage is found, the UE sends an A5 report, MLC performs a PCell handover to TDD, and FDD2 is configured as an SCell.

**Figure 10-28 shows the operation of MLC, DAM and MCPC using**

servingCellSelectionPolicy = PRIORITIZE_DL_THP as the UE moves into progressively poorer coverage from the cells that are ranked higher by MLC. The UE is DL 2CC capable and can use either FDD or TDD as PCell. This example assumes that DAM is activated on the FDD1 carrier and BWTISHO is not activated.

<!-- page: 338 -->

![Figure on page 338](5G_Mobility_and_Traffic_Management_Guideline_images/page_338_image_002.png)

Figure 10-28 - Operation of MLC, MCPC and DAM as UE moves into poorer coverage

Notes for Figure 10-28:

- The UE sets up from RRC_IDLE or RRC_INACTIVE on TDD, the gNodeB performs blind SCell selection and configures the SCell on FDD2, as it has the highest estimated downlink data rate in this example. MLC cannot find a better candidate cell set, and DCSC starts the periodic timer.

- As the UE approaches the edge of suitable TDD PCell coverage, MCPC triggers a handover to FDD2. The target gNodeB blindly configures an SCell on TDD. DCSC starts the periodic timer.

- As the UE moves into progressively poorer TDD coverage, the UE sends an A2 report for the TDD SCell and the gNodeB deactivates the SCell. When the periodic DCSC timer elapses, MLC evaluation is performed, and A5 measurements are configured to detect coverage from FDD1. The UE finds coverage, it sends the A5 report, and MLC performs SCell reselection to FDD1. DCSC restarts the periodic timer.

- As the UE approaches the edge of FDD2 coverage, MCPC triggers a handover to FDD1. The target gNodeB blindly configures an SCell on TDD. DCSC starts the periodic timer.

- The DCSC periodic timer elapses and MLC evaluation is performed. MLC does not find a better candidate cell set. DAM evaluation is then performed, the current throughput is below the DAM threshold, and B2 measurements are configured to detect coverage from LTE. The UE finds coverage, sends the B2 report and DAM triggers an IRAT handover or RwR (in case the UE does not support inter-RAT handover or target cell has EUtranCellRelation . isHoAllowed = false ) to LTE.

### 10.3.6 NR Advanced Multi-Layer Coordination (FAJ 121 5584) - SA

This licensed gNodeB feature allows cell load to be considered by Multi-Layer Coordination (MLC), Dynamic Cell Set Change During Mobility (DCSC), and initial SCell selection. This allows these functions to better distribute traffic across carriers and improves the user throughput.

<!-- page: 339 -->

**When NR Advanced Multi-Layer Coordination (A-MLC) is activated and**

GNBCUCPFunction.resourceStatusReportF1Enabled = true , the gNodeB calculates the downlink available capacity factor and exchanges this with neighboring gNodeBs using a subscription process. It also enables exchange of the uplink available capacity factor, if the feature Uplink-Aware Advanced Multi-Layer Coordination is active.

The downlink available capacity factor is calculated as follows:

dlAvailableCapacityFactor  = 1 / (1 + dlActiveUEs)

where dlActiveUEs is the filtered number of UEs that are active in the downlink, including UEs that use the cell as a PCell, a PSCell or an SCell.

Setting TrafficSteering.dlCellLoadAware = true allows MLC to use the downlink available capacity factor when calculating the downlink cell weight, as described in Section 10.3.5.1.

### 10.3.7 Uplink-Aware Advanced Multi-Layer Coordination (FAJ 121 5780) - SA

This licensed gNodeB feature allows the uplink cell load to be considered by Multi-Layer Coordination (MLC), Dynamic Cell Set Change During Mobility (DCSC), and initial SCell selection. This allows these functions to better distribute traffic across carriers and improves the uplink user throughput.

**To enable this functionality, activate the feature and set**

TrafficSteering.ulCellLoadAwareEnabled = true . The gNodeB then calculates the uplink available capacity factor for each cell, as follows, and exchanges this information with neighboring gNodeBs:

ulAvailableCapacityFactor  = 1 / (1 + ulActiveUEs)

where ulActiveUEs is the filtered number of UEs that are active in the uplink, including UEs that use the cell as a PCell, a PSCell and an SCell.

MLC then uses the uplink available capacity factor when calculating the uplink cell weight, as described in Section 10.3.5.1.

The feature Uplink Aware A-MLC is not supported in RAN Compute Group 1, 2 and 3 (RCG123) hardware. However, these nodes can still share uplink available capacity factor information with other nodes (that do support the feature, i.e. RCG456). Refer to the NR Traffic Steering Solution Guideline in CPI for further information.

The feature Advanced Multi-Layer Coordination (A-MLC) is a prerequisite for Uplink-Aware Advanced Multi-Layer Coordination .

### 10.3.8 LTE-NR Downlink Aggregation (FAJ 121 4912) - NSA

This is a licensed gNodeB feature in the gNodeB in the value package Peak Rate Evolution (FAJ 801 4005).

<!-- page: 340 -->

The feature enables transmission of downlink user plane data simultaneously on both the MCG and SCG resources of an SN Terminated Split Bearer, for both EN-DC and NR-DC. Different packets are sent on the two cell groups. The feature improves the end user throughput.

An overview of this feature, and its relation to downlink user plane switching, is provided in Section 5.3.4.

Refer to the CPI document LTE-NR Downlink Aggregation for more information.

### 10.3.9 LTE-NR Uplink Aggregation (FAJ 121 5091) - NSA

This is a licensed gNodeB feature in the value package Peak Rate Evolution (FAJ 801 4005).

The feature enables transmission of uplink user plane data (PDCP layer) simultaneously on both the MCG and SCG resources of an SN Terminated Split Bearer for, both EN-DC and NR-DC. This can improve the end user throughput.

An overview of this feature, and its relation to uplink user plane switching, is provided in Section 5.3.5.

Refer to the CPI document LTE-NR Uplink Aggregation for more information.

### 10.3.10 EPS Fallback for IMS Voice (FAJ 121 5059) - SA

This is an unlicensed gNodeB feature in the NR Base Package (FAJ 801 4002). It enables connected mode fallback from NR SA to LTE when an attempt is made to set up a voice call. The feature requires that the EPC and the 5GC support the N26 interface.

Three fallback mechanisms are supported:

- Blind release-with-redirect

- Release-with-redirect based on B1 measurements

- Handover based on B1 measurements

Whether a voice call uses one of these mechanisms or Voice Over NR (VoNR, described in Section 10.3.11) depends on the setting of

McfbCellProfileUeCfg.epsFallbackOperation , as follows:

|   epsFallbackOperation | epsFallbackOperation   | Voice Call Handling                                                                  |
|------------------------|------------------------|--------------------------------------------------------------------------------------|
|                      0 | INACTIVE               | Always use VoNR.                                                                     |
|                      1 | ACTIVE                 | Use VoNR if the UE supports it, or blind release-with- redirect EPS fallback if not. |
|                      2 | FORCED                 | Always use blind release-with-redirect EPS fallback.                                 |
|                      3 | ACTIVE_MEAS_RWR        | Use VoNR if the UE supports it, or                                                   |

<!-- page: 341 -->

|   epsFallbackOperation | epsFallbackOperation   | Voice Call Handling                                                                      |
|------------------------|------------------------|------------------------------------------------------------------------------------------|
|                        |                        | measurement-based release-with-redirect EPS fallback if not.                             |
|                      4 | ACTIVE_MEAS_IRAT_HO    | Use VoNR if the UE supports it, or measurement- based IRAT handover EPS fallback if not. |
|                      5 | FORCED_MEAS_RWR        | Always use measurement-based release-with-redirect EPS fallback.                         |
|                      6 | FORCED_MEAS_IRAT_HO    | Always use measurement-based IRAT handover EPS fallback.                                 |

**If the 5G network does not support VoNR, then set**

McfbCellProfileUeCfg.epsFallbackOperation so that all UEs use fallback, that is to FORCED , FORCED_MEAS_RWR or FORCED_MEAS_IRAT_HO .

The LTE frequencies are ranked by EUtranFreqRelation.voicePrio. If voicePrio is set to -1 or left empty, the frequency is excluded. The LTE frequency with highest priority, that is supported by the UE, is selected. If more than one frequency has the highest priority, then the mechanism blind release-with-redirect selects the lowest EARFCN, and the measurement-based mechanisms select all frequencies with the highest priority.

Frequencies can be excluded for a particular UE by including either PLMN or RAT restrictions in the Mobility Restriction List , which the gNodeB receives from the 5G core. For this exclusion to work, the EUtranFreqRelation.allowedPlmnList must not be empty.

Direct packet forwarding is initiated during handover from SA to LTE.

If no valid frequency can be found, the UE is released without redirection.

For more information on configuring voice services, refer to the 5G Voice SA RAN Solution Guideline in CPI.

#### 10.3.10.1 Measurement-Based EPS Fallback

When measurement-based mechanisms are chosen, the gNodeB configures the UE with Event B1 measurements to detect suitable LTE frequencies and an Event A2 measurement to detect critical serving NR cell coverage. The gNodeB also deconfigures any other ongoing measurements, including any configured by MCPC. This is why the Event A2 Critical is required; if the NR quality drops to a critical level, then the A2 triggers immediate release-with-redirect to LTE, abandoning the B1 measurement process.

The attributes used for configuring the measurements depend on the chosen trigger quantity, as shown in Table 10-15 (the same trigger quantity is used for B1 and A2).

Table 10-15 - Attributes for EPS fallback measurement configuration

| McfbCellProfileUeCfg. triggerQuantity   | B1 Measurement Report Criteria*   | A2 Measurement Report Criteria**   |
|-----------------------------------------|-----------------------------------|------------------------------------|
| RSRP                                    | rsrpCellCandidate                 | rsrpCriticalCoverage               |
| RSRQ                                    | rsrqCellCandidate                 | rsrqCriticalCoverage               |

Table 10-15 - Attributes for EPS fallback measurement configuration

<!-- page: 342 -->

| McfbCellProfileUeCfg. triggerQuantity   | B1 Measurement Report Criteria*   | A2 Measurement Report Criteria**   |
|-----------------------------------------|-----------------------------------|------------------------------------|
| SINR_FALLBACK_RSRP SINR_FALLBACK_RSRQ   | sinrCellCandidate***              | sinrCriticalCoverage***            |

- Contains the struct attributes threshold , hysteresis and timeToTrigger

- **  Contains the struct attributes threshold , hysteresis , timeToTrigger and timeToTriggerA1

- ***  If the UE does not support SINR, then it is configured to use RSRP or RSRQ, as specified by the trigger quantity.

**If a B1 measurement report is not received before**

McfbCellProfileUeCfg.epsFbTargetSearchTimer expires, then the gNodeB orders the UE to perform a blind release-with-redirect to the unmeasured frequency with the highest priority. If no unmeasured frequency exists, then the measured frequency with the highest priority is used.

If an A2 critical measurement report is received before a B1 measurement report, then the gNodeB orders a blind release-with-redirect to highest priority LTE frequency.

If a B1 measurement report is received and the mechanism is set to measurement-based release-with-redirect, then the gNodeB orders a release-with-redirect to the reported frequency.

If a B1 measurement report is received and the mechanism is set to measurement-based handover, then the gNodeB orders a handover to the reported cell if the cell is configured as a neighbor and the PLMN of the cell is not restricted by the Mobility Restriction List . If a measurement report is received with an unknown PCI, then the reported frequency is saved to be used for release-with-redirect if the timer epsFbTargetSearchTimer expires.

If the eNodeB supports the feature Incoming NR IRAT Handover and the core network supports IRAT handover from NR to LTE, then Ericsson recommends using handover as the selected mechanism. This decreases the PS data session interruption time and enables evaluation of more than one LTE target frequency.

Refer to Section 11.2.5 for more information on the parameters and trigger level formulas.

### 10.3.11 Basic Voice over NR (FAJ 121 5219) - SA

This is a basic gNodeB feature in the value package Voice Over NR (FAJ 801 4017).

This feature provides the functionality for establishing, maintaining, and releasing Voice Over NR (VoNR) calls on NR SA. Without VoNR, EPS fallback to LTE must be used to handle voice calls. Refer to the feature description in CPI for more detail.

Whether VoNR or EPS fallback is used, is determined by the UE capability and the setting of McfbCellProfileUeCfg.epsFallbackOperation , as described in Section 10.3.10. Note that this attribute is set per UE group, and that the UE group selection criteria can include the RRC establishment cause, allowing early detection of a voice call.

<!-- page: 343 -->

̶

UEs that have a VoNR bearer can be given specific settings for various functions, such as DRX, CA, MLC, DCSC, BWTISHO, DAM, MCPC and mobility generally. This is achieved by assigning these UEs to a specific UE group, using the UE Grouping Framework feature, and then applying different configurations to that UE group using UE group-enabled features such as User and Service Specific Mobility and User and Service Specific Carrier Aggregation .

The UE Grouping Framework can also be used to identify UEs that are capable (or not capable) of VoNR so that they can be treated differently (e.g. for mobility). VoNR capability is represented by the voNrUe variable in the selectionCriteria of the relevant UE group definition.

For more information on configuring voice services, refer to the 5G Voice SA RAN Solution Guideline in CPI.

### 10.3.12 NR Emergency Fallback to LTE (FAJ 121 5166) - SA

This is an unlicensed gNodeB feature in the NR Base Package (FAJ 801 4002).

The NR Emergency Fallback to LTE feature enables the 5G RAN network to support fallback to LTE in a controlled way when an emergency call is made.

There are two different mechanisms for triggering emergency fallback depending on whether the 5GC supports emergency call service or not:

**· Service request based emergency fallback**

This mechanism is used if the 5GC does not support emergency calls over NR but supports emergency fallback. In this case the UE (in idle or connected mode) sends a NAS Service Request with the service type emergency services , to indicate an emergency call and request fallback. The 5GC detects this request and the AMF sends an Emergency Fallback indicator IE to the gNodeB, which then triggers fallback to LTE.

**· QoS triggered emergency fallback**

This mechanism is used if the 5GC supports emergency calls over NR but the gNodeB does not, so emergency fallback must be used. In this case, the emergency call can be detected and then triggered in one of two ways:

̶

- If the UE detects that the call is an emergency call, then the UE sends an RRC setup request message with the establishmentCause set to emergency .

- If the UE does not know that the call is an emergency call, then the 5GC can detect that the called number is an emergency number and set the 5QI and ARP values to indicate this. The gNodeB then detects the call as an emergency call by matching the 5QI1 and/or 5QI5 ARP values with the configured attributes

arpPrioEm5qi1List , arpPrioEm5qi5List and pLMNIdList in the MO instance(s) of EmCall .

**How an emergency call is handled, is determined by the setting of**

McfbCellProfileUeCfg.epsFallbackOperationEm as follows:

<!-- page: 344 -->

|   epsFallbackOperationEm | epsFallbackOperationEm   | Emergency Voice Call Handling                                                                                        |
|--------------------------|--------------------------|----------------------------------------------------------------------------------------------------------------------|
|                        0 | ACTIVE                   | Use emergency call over NR if the UE supports it, or blind release-with-redirect EPS fallback if not.                |
|                        1 | FORCED                   | Always use blind release-with-redirect EPS fallback.                                                                 |
|                        2 | ACTIVE_MEAS_RWR          | Use emergency call over NR if the UE supports it, or measurement-based release-with-redirect EPS fallback if not. ## |
|                        3 | ACTIVE_MEAS_IRAT_HO      | Use emergency call over NR if the UE supports it, or measurement-based IRAT handover EPS fallback if not. ##         |
|                        4 | FORCED_MEAS_RWR          | Always use measurement-based release-with-redirect EPS fallback. ##                                                  |
|                        5 | FORCED_MEAS_IRAT_ HO     | Always use measurement-based inter-RAT handover EPS fallback. ##                                                     |

Note, however, that if a UE initiates an emergency call from RRC_IDLE state and the UE is not capable of emergency calls over NR, then the release-with-redirect is always blind. Measurements are not performed, regardless of the fallback configuration of epsFallbackOperationEm .

**If the 5G network does not support VoNR,**

McfbCellProfileUeCfg.epsFallbackOperationEm must be set so that all UEs use fallback, that is, FORCED , FORCED_MEAS_RWR or FORCED_MEAS_IRAT_HO .

The LTE frequencies that are candidates for emergency call fallback are ranked by EUtranFreqRelation.eUtranFallbackPrioEc. If eUtranFallbackPrioEc is set to -1 or empty, the frequency is excluded. The LTE frequency with highest priority, that is supported by the UE, is selected. If more than one frequency has the highest priority, then the mechanism blind release-with-redirect selects the lowest EARFCN, and the measurement-based mechanisms select all frequencies with the highest priority.

Frequencies can be excluded for a particular UE by including either PLMN or RAT restrictions in the Mobility Restriction List , which the gNodeB receives from the 5G core. For this exclusion to work, the EUtranFreqRelation.allowedPlmnList must not be empty.

If no valid frequency can be found for the UE, then the UE is released without redirection and PM counter NRCellCU . pmRwrEutranUeNonPerfEpsfbEm is stepped. The UE must perform an autonomous reselection to any RAT that supports emergency calls (3GPP TS 38.304 and 23.167).

When a measurement-based mechanism is used, the measurement configuration and report handling are identical to those used for non-emergency EPS fallback, as described in Section 10.3.10.1.

Direct packet forwarding is initiated during handover from SA to LTE.

Refer to Section 11.2.5 for more information on the parameters and trigger level formulas.

For more information on configuring voice services, refer to the 5G Voice SA RAN Solution Guideline in CPI.

<!-- page: 345 -->

### 10.3.13 NR Emergency Procedures (FAJ 121 5298) - SA

This is a licensed gNodeB feature in the value package Voice Over NR (FAJ 801 4017).

The NR Emergency Procedures feature provides the ability to detect and handle emergency voice calls on NR SA (VoNR). It requires the features Basic Voice over NR (Section 10.3.11) and NR Emergency Fallback to LTE (Section 10.3.12).

When the 5GC is capable of emergency calls the UE can indicate that a voice call is an emergency call as follows:

- From idle mode, the UE sends an RRC setup request message with the establishmentCause set to emergency

However, if the UE does not indicate the emergency call in the establishment, or UE is in connected mode, then the call can still be identified as an emergency call as follows:

̶

- The 5GC detects that the called number is an emergency number and sets the 5QI and ARP values to indicate this.

̶

- The gNodeB then detects the call as an emergency call by matching the 5QI1 and/or 5QI5 ARP values with the configured attributes arpPrioEm5qi1List , arpPrioEm5qi5List and pLMNIdList in the MO instance(s) of EmCall .

Once identified, the emergency call is handled according to setting of McfbCellProfileUeCfg.epsFallbackOperationEm as described in Section 10.3.12.

This feature also enables both intra and inter-gNodeB handover for emergency calls. The handover of emergency call is allowed when:

- The feature is activated, and the

McfbCellProfileUeCfg.epsFallbackOperationEm is set to ACTIVE , ACTIVE_MEAS_RWR or ACTIVE_MEAS_IRAT_HO , or

- The feature is activated, and the

McfbCellProfileUeCfg.epsFallbackOperationEm is set to FORCED , FORCED_MEAS_RWR or FORCED_MEAS_IRAT_HO and McfbCellProfileUeCfg.rejectVoiceIncHoAtEpsFb is set to false .

To ensure emergency call mobility is not impacted by the Mobility Restriction List (e.g. in a shared network), set EmCall.mobilityRestrictionsApplied = false .

### 10.3.14 NR Limited Service Mode Emergency Call Support (FAJ 121 5302) - SA

This is a licensed gNodeB feature in the value package Voice Over NR (FAJ 801 4017).

The feature enables UE to establish emergency voice calls over NR in limited service mode. A UE in limited service mode is only allowed to make emergency calls.

<!-- page: 346 -->

UEs may find themselves in limited service mode when:

- The UE does not have a SIM card

- The UE cannot register on the PLMN

The feature is enabled at the cell level by setting NRCellDU.imsEmSupportEnabled = true .

When feature is enabled the NR SA cell will broadcast ims-EmergencySupport indicator in SIB1. It indicates that the core network supports emergency calls in limited service state. Note that the 5GC must support Limited Service State to broadcast this indicator in 5GRAN.

UEs in limited service mode can then make an emergency call at initial access and continue an emergency call at incoming handover. The emergency call is either setup in NR (as a VoNR call) or sent to LTE via EPS fallback, depending on the UE capability and the configuration of the gNodeB features NR Emergency Procedures and NR Emergency Fallback to LTE .

If the feature is not activated, an emergency call attempt or handover in limited service mode is rejected.

### 10.3.15 RAN Slicing Framework (FAJ 121 5095) - SA

This is a licensed gNodeB feature in the value package RAN Slicing (FAJ 801 4015).

The feature enables RAN slicing and adds new configurations to the Single-Network Slice Selection Assistance Information (S-NSSAI) list.

The feature also enables the S-NSSAI in PDU sessions and slice-aware Core Network instance selection. Additionally, the feature supports the following functionalities with the RanSlicingFramework license:

- Slice-aware QoS mapping framework

- Slice-aware NG-based handover

Refer to the CPI documents RAN Slicing Framework and NR SA Network Slicing Guidelines for more information.

### 10.3.16 NR Automated Neighbor Relations (FAJ 121 5218) - NSA and SA

This is an unlicensed gNodeB feature in the NR Base Package (FAJ 801 4002). It discovers, creates, and removes neighbor relations for both SA and NSA, for intrafrequency, inter-frequency and IRAT mobility.

In the gNodeB, neighbor relations can be created either manually by the network operator or automatically by ANR.

<!-- page: 347 -->

- Manually-created neighbor relations are represented by instances of the NRCellCU.NRCellRelation MO class (for NR to NR relations) or the NRCellCU.EUtranCellRelation MO class (for NR to LTE relations).

- ANR-created neighbor relations are represented by lightweight neighbor relations. These are entries in the NRCellCU.lwNeighborRel list (for NR to NR relations) or in the NRCellCU.lwNeighborRelEUtran list (for NR to LTE relations). These lists are read-only attributes.

Both types of neighbor relations can be used for both NSA and SA mobility. For example, if a lightweight NR neighbor relation is created by ANR in response to NSA mobility, then it can also be used for SA mobility if the cells are capable of SA. SA capability is indicated by valid nRTAC information on the target cell and gNodeB can maintain nRTAC of external cell for lightweight NR neighbor relation based on the information received from the eNodeB.

To make it easier to work with a combination of lightweight neighbor relations and full relations, a list of both lightweight and full relations (or lightweight only) can be obtained with the NRCellCU actions displayNRCellRelation and displayEUtranCellRelation .

Lightweight neighbor relations cannot be edited or manually deleted. To enable editing or deleting, the lightweight relation must first be converted to a full relation ( NRCellRelation or EUtranCellRelation ). One way to do this is to manually create the full relation, in which case the gNodeB deletes the corresponding lightweight relation. Alternately, the lightweight neighbor relation can be 'promoted' to a full NRCellRelation or EUtranCellRelation , using the NRCellCU actions promoteLwNRCellRelation and promoteLwEUtranCellRelation respectively.

Besides manual promotion, there are also automatic promotion and demotion mechanisms, based on mobility attempts and overall relation counts. In the case of shared networks (MOCN or MORAN), it is possible that the automatic promotion leads to an incorrect PLMNID configuration. The configuration is corrected if an Xn connection is established. For details, refer to the NR Automated Neighbor Relations feature description in CPI.

When ANR creates an NR to NR relation, the process followed, and the features used depend on whether the creation is triggered by NSA mobility or SA mobility.

- When NSA mobility triggers the creation, two features are involved: the gNodeB feature NR Automated Neighbor Relations and the eNodeB feature Automated Neighbor Relations (Section 10.2.16).

- When SA mobility triggers the creation, only the gNodeB feature is involved.

- When removing an NR to NR relation, only the gNodeB feature is involved.

- When ANR creates an NR to LTE relation, only the gNodeB feature is involved.

The following sections provide more detail on these creation and removal cases.

<!-- page: 348 -->

̶

#### 10.3.16.1 NR to NR Neighbor Creation - Triggered by NSA Mobility

To enable ANR to create NR to NR neighbor relations, triggered by NSA mobility:

- In the eNodeB:

̶

- Activate the feature license for Automated Neighbor Relations (FAJ 121 0497)

- Set ANRFunctionNR.anrStateNR = 1 (ACTIVATED), to enable NCGI-based ANR for LTE-to-NR or

̶

- Set ENodeBFunction.zzzTemporary74 = 1 , to enable PCI-based ANR for LTEto-NR

- In the gNodeB:

̶

- Set AnrFunctionNR . anrEndcX2Enabled = true

With ANR for NSA enabled, the gNodeB ANR feature operates together with the eNodeB ANR feature to create NR to NR neighbor relations as follows:

- An LTE to NR relation is created in the eNodeB, either manually, or automatically by the eNodeB ANR feature, as described in Section 10.2.16.

- The eNodeB informs the gNodeB of the LTE to NR neighbor relation that it has created, using the EN-DC CONFIGURATION UPDATE message over the X2 interface.

̶

- The eNodeB informs not only the gNodeB that hosts the NR cell in the relation, but also any other relevant gNodeB(s). A relevant gNodeB is one which hosts one or more NR cells that also has a relation from that LTE cell.

̶

- An example of this is shown in Figure 10-29. The eNodeB ANR feature creates the relation (1) from LTE to NR and informs gNodeB B. It also informs gNodeB A, because gNodeB A hosts NR Cell A3 which has an existing relation (2) from LTE Cell 1. However, gNodeB C is not notified, as it does not host a cell with an existing relation from LTE Cell 1. If the eNodeB ANR feature removes an LTE to NR relation, then it also informs the relevant gNodeB(s).

![Figure on page 348](5G_Mobility_and_Traffic_Management_Guideline_images/page_348_image_002.png)

Figure 10-29 - ANR for NSA

<!-- page: 349 -->

̶

- The notifications from the eNodeB allow the gNodeB to maintain an up-to-date list of LTE to NR cell relations, which includes both the Cell Global Identity (CGI) and the Physical Cell Identity (PCI) of the NR cells. This list is not visible. It is stored internally in the gNodeB and is used for creating NR to NR cell relations, as described in the following steps.

- An EN-DC connected UE sends an intra-frequency PSCell change report (Event A3) or inter-frequency PSCell change report (Event A5) that contains a PCI that does not have a corresponding NR cell relation.

For the A3 report, if the signal level of the reported PCI is below a configurable used is either AnrFunctionNRUeCfg.anrRsrpThreshold,

threshold, then ANR takes no further action, and the report is ignored. The threshold AnrFunctionNRUeCfg.anrRsrqThreshold or AnrFunctionNRUeCfg.anrSinrThreshold depending on the value of IntraFreqMCCellProfileUeCfg.betterSpCellTriggerQuantity .

If the UE does not support NR SINR measurements, then betterSpCellTriggerQuantity determines the fallback quantity, namely RSRP ( SINR_FALLBACK_RSRP ) or RSRQ ( SINR_FALLBACK_RSRQ ).

- The gNodeB ANR feature searches the internal list for an NR cell that has both a matching PCI and a relation from the LTE PCell.

̶

- If the PCI search is unsuccessful, then a neighbor relation cannot be created and the A3 report or A5 report is discarded.

̶

- If the search is successful, then ANR retrieves the CGI for the NR cell, which is the unknown neighbor. ANR then creates a lightweight NR neighbor relation by adding the neighbor cell to the list contained in the read-only attribute NRCellCU.lwNeighborRel . ANR does not create an NRCellRelation MO for the new relation.

- The created lightweight relation can be used for both NSA and SA mobility.

#### 10.3.16.2 NR to NR Neighbor Creation - Triggered by SA Mobility

To enable ANR to create NR to NR neighbor relations, triggered by SA mobility:

- In the gNodeB:

̶

- Set NRFreqRelation.anrMeasOn = true

- To enable ANR for intra-frequency mobility using Event A3 reports, set AnrFunctionNR.anrCgiMeasIntraFreqEnabled = true

̶

- To enable ANR for inter-frequency mobility using Event A5 or A3 reports, set AnrFunctionNR.anrCgiMeasInterFreqMode = FR1 (noting that the current release does not support SA in FR2).

̶

- The UE must be capable of NCGI reporting and long DRX cycle:

<!-- page: 350 -->

̶

- nr-CGI-Reporting in MeasAndMobParameters IE

̶

- longDRX-Cycle in MAC-ParametersXDD-Diff IE

- The UE must meet the following conditions:

̶

- The UE does not have an NR-DC bearer

̶

- The UE does not have a VoNR bearer

̶

- The UE does not have an ongoing NCGI measurement

With ANR for SA enabled, NR to NR relations are created as follows:

- The UE sends the gNodeB an A3 (intra-frequency) or A3 or A5 (inter-frequency) report containing a PCI that does not have a corresponding NRCellRelation or lwNeighborRel .

- ANR configures an NCGI measurement in the UE to discover the NR Cell Global Identity (CGI).

̶

- For the A3 report, if the signal level of the reported PCI is below a configurable threshold, then ANR takes no further action, and the report is ignored. The threshold used is either AnrFunctionNRUeCfg.anrRsrpThreshold, AnrFunctionNRUeCfg.anrRsrqThreshold or AnrFunctionNRUeCfg.anrSinrThreshold depending on the value of IntraFreqMCCellProfileUeCfg.betterSpCellTriggerQuantity . If the UE does not support NR SINR measurements, betterSpCellTriggerQuantity determines the fallback quantity, namely RSRP ( SINR_FALLBACK_RSRP ) or RSRQ ( SINR_FALLBACK_RSRQ ).

̶

- If the UE has a voice call in progress, the NCGI measurement cannot be configured, and the A3 or A5 report with the unknown PCI is discarded.

- The UE sends the gNodeB the report containing the NCGI measurement.

̶

- If the NCGI report contains IE NoSIB1 or does not contain 5G-TAC, then the reported cell is considered as NSA-only. ANR then ignores the report and does not trigger NCGI measurement for the same PCI until the information is reset, which happens every 24 hours.

̶

- If the NCGI report contains a valid SA cell, ANR automatically creates a lightweight NR neighbor relation, by adding the cell to the list contained in the read-only attribute NRCellCU.lwNeighborRel . ANR does not create an NRCellRelation MO for the new relation.

- If the UE does not send a report within 2 seconds, then the gNodeB removes the NCGI measurement and reconfigures the A3 or A5 measurement. The gNodeB does not configure any additional NCGI measurements for that frequency and UE connection.

̶

<!-- page: 351 -->

̶

- The created lightweight relation can be used for PCell SA mobility, PSCell NR-DC mobility, and PSCell NSA mobility if the cells are configured for NSA.

̶

- However, lightweight relations cannot be used for carrier aggregation, or for SCell candidate evaluation by the feature Multi-Layer Coordination (MLC).

#### 10.3.16.3 NR to LTE Neighbor Creation - Triggered by IRAT Mobility

IRAT mobility from NR to LTE can be based on B1 measurements (for EPS fallback) or B2 measurements (for coverage-triggered handover and BWTISHO), and both these IRAT measurements can trigger ANR to create NR to LTE relations.

To enable ANR to create relations triggered by IRAT-based mobility:

- In the gNodeB:

̶

- Set EUtranFreqRelation.anrMeasOn = true

- For ANR using B2 measurements set AnrFunctionEUtran.anrCgiMeasEUtranEnabled = true

- For ANR using B1 measurements, in addition to the above, set AnrFunctionEutranUeCfg.ecgiDuringEpsFbEnabled = true

̶

- The UE must be capable of ECGI reporting and long DRX cycle:

̶

- eutra-CGI-Reporting in MeasAndMobParameters IE

̶

- longDRX-Cycle in MAC-ParametersXDD-Diff IE

- The UE must meet the following conditions:

̶

- The UE does not have a voice or critical service bearer (5QI1, 5QI65, 5QI66, 5QI69)

̶

- The UE does not have an NR-DC bearer

̶

- The UE does not have an ongoing ECGI or NCGI measurement

̶

- The UE is not performing EPS fallback for an emergency call

With ANR for IRAT enabled, NR to LTE relations are created as follows:

- The UE sends the gNodeB a B1 (EPS fallback) or B2 (inter-RAT) report containing an unknown PCI, meaning that the PCI does not have a corresponding EUtranCellRelation or lwNeighborRelEUtran .

- ANR configures an ECGI measurement in the UE to discover the EUTRAN Cell Global Identity (ECGI) of the LTE cell

- UE sends the report containing the ECGI measurement to the gNodeB.

<!-- page: 352 -->

̶

- If the UE does not send a report within 1 second, then the gNodeB removes the ECGI measurement and reconfigures the B1 or B2 measurement. The gNodeB does not configure any additional ECGI measurements for that frequency and UE connection.

- The gNodeB receives the report and creates the required neighbor relation:

̶

- If the ExternalENodeBFunction does not exist, the gNodeB creates it. The created MO is visible to the operator.

̶

- If the ExternalEUtranCell does not exist, the gNodeB creates one in internal memory. The created MO is not visible to the operator.

- The gNodeB creates an internal EUtranCellRelation , which is not visible to the operator. It also creates an entry in the lwNeighborRelEUtran list, which is visible to the operator.

̶

- After the ECGI measurement is finished, the gNodeB reconfigures the B1 or B2 measurement in the UE to detect LTE coverage. A new B1 or B2 report must be received to trigger IRAT handover mobility using the newly created lwNeighborRelEUtran .

#### 10.3.16.4 Neighbor Removal

Neighbor relations are removed automatically by ANR if they are unused for SA, NSA or IRAT to LTE mobility for AnrFunction.removeNrelTime (default 7 days). If removeNrelTime = 1000 , then automatic removal is not performed.

- Automatic removal of manually-created NRCellRelation MO instances is allowed if NRCellRelation.isRemoveAllowed = true

- Automatic removal of manually-created EUtranCellRelation MO instances is allowed if EUtranCellRelation.isRemoveAllowed = true .

- Automatic removal of lightweight neighbors created by ANR is always allowed.

#### 10.3.16.5 Automatic removal of LTE Frequency Relations

This function automatically removes unused EUtranFreqRelation instances. It also removes EUtranFrequency instances (but only those for LTE Band 48), that do not have any references to them. It is enabled by setting

AnrFunction . removeEUtranFreqRelTime to a value between 10 and 9999 minutes. When removeEUtranFreqRelTime = 10000 , automatic removal is disabled.

Refer to the feature description NR Automated Neighbor Relations for further information.

<!-- page: 353 -->

#### 10.3.16.6 gNodeB Blocklist

The gNodeB blocklist can be used to prevent an Xn connection to selected gNodeBs. It is configured using the attribute GNBCUCPFunction.gNBBlockList . Individual gNodeBs can be blocked, or all gNodeBs with a specific PLMN can be blocked.

Blocking a gNodeB results in the following:

- Prevents Xn setup, by both the operator and the system

- Disconnects the existing Xn

- Disables direct packet forwarding (by setting directPacketForwarding = false )

- If gNBBlockList.isNgHoAllowed = false, then incoming and outgoing NG handovers are also prevented.

̶

- In this case, it is recommended to configure mutual blocking in both the source and target gNodeB. This avoids the unnecessary signaling associated with rejecting NG handovers, by preventing the handover attempts in the first place.

Blocking intra-frequency handovers can cause increased interference, as the UE remains connected to the weaker source cell when in the stronger target cell coverage. To manage this case, use the Prohibited Cell-Triggered Mobility function in NR Mobility (FAJ 121 5041) - see Section 10.3.4.8.

### 10.3.17 PSCell Change to Higher Priority (FAJ 121 5334) - NSA

This is a licensed gNodeB feature in the value package Intelligent Traffic Management and Mobility (FAJ 801 4022).

This feature enables a UE in good radio conditions to periodically search for a PSCell on a higher priority NR frequency. If a suitable cell is found, then the feature initiates an inter-frequency PSCell change. The periodic search sequence uses A5 measurements with configurable time periods. Both intra-gNodeB and inter-gNodeB PSCell change are supported. The periodic search is possible in good serving PSCell coverage only. If the UE enters poor coverage (Event A2 - Entering Search Zone is triggered), then the periodic search is stopped and replaced by MCPC measurements to find a better cell.

**PSCell change to a higher priority frequency is enabled by setting**

(gNB) NRCellCU.hiPrioDetEnabled = true . When it is enabled, set (eNB) CarrierAggregationFunction.endcCaPolicy = NR_PREFERRED , to ensure that all potential NR target frequencies are available.

If Optimized UE Distribution for EN-DC alters the B1 measurements for a UE, and EN-DC is subsequently set up with any of the highest prioritized frequencies, then the behavior of PSCell Change to Higher Priority is decided by

TrStPSCellProfileUeCfg . hiPrioAllowedForDistUeEnabled .

- If hiPrioAllowedForDistUeEnabled = false , then PSCell Change to Higher Priority is not triggered for the UE.

<!-- page: 354 -->

- If hiPrioAllowedForDistUeEnabled = true , then PSCell Change to Higher Priority can be triggered even if EN-DC was set up with any of the altered highest priority frequencies.

The periodic search sequence is initiated after SN addition, SCG addition, PSCell change and when entering good coverage (A1 Leaving Search Zone). It is initiated only if the PSCell does not have the highest priority among the valid target frequencies. The periodic search is stopped if the UE enters poor PSCell coverage (A2 Entering Search Zone) or if a PSCell change occurs during the periodic search.

Valid target frequencies are those which meet the following criteria:

- The NR frequency is not included in the blocklist. A frequency can be included in the blocklist for example, due to recurring EN-DC setup failures or insufficient UE capabilities.

- The serving PSCell has a frequency relation to the target frequency: NRCellCU.NRFreqRelation

- Connected mode mobility is allowed to the target frequency: UeMCNrFreqRelProfileUeCfg.connModeAllowedPSCell = true

- The target frequency has a higher priority than the serving frequency:

- target >

- UeMCNrFreqRelProfileUeCfg.connModePrioPSCell UeMCNrFreqRelProfileUeCfg.connModePrioPSCell serving

- The PLMN conditions are fulfilled (refer to the feature description for NR Mobility in CPI)

- The UE supports EN-DC on the target frequency in combination with the LTE PCell frequency.

If no NRFreqRelation fulfills these criteria, then the periodic search is not started.

The periodic search sequence is shown in Figure 10-30.

![Figure on page 354](5G_Mobility_and_Traffic_Management_Guideline_images/page_354_image_002.png)

Figure 10-30 - Periodic A5 measurement pattern for PSCell change to higher priority

Notes for Figure 10-30:

- The sequence is initiated at SN addition, SCG addition, PSCell change and when the UE enters good serving PSCell coverage (A1 - Leaving Search Zone).

<!-- page: 355 -->

- No measurements are configured during the initial wait time, set by: TrStPSCellProfileUeCfg.hiPrioDetStartTime (default 2 seconds).

- When the initial wait time expires, the A5 measurements are configured in the UE for all valid target frequencies. The measurements continue until a PSCell change occurs, or SN release occurs, or the UE enters poor coverage (A2 - Entering Search Zone), or the measurement time expires. The measurement time is set by: TrStPSCellProfileUeCfg.hiPrioDetMeasurementTime (default 5 seconds).

When the measurements are started, a priority period timer is also started. This timer is used to ensure that the highest priority target frequency(s) are given priority over lower priority ones. In this context, lower priority means lower than the highest priority being measured; note that all measured frequencies have a higher priority than the serving frequency.

The priority period length is determined automatically and depends on the number of measured frequencies. The formula used in the current revision is:

Priority Period =  480 + (NFR1 * 200) +  (NFR2 * 200) + timeToTrigger (ms)

where

NFR1 = the number of NR FR1 frequencies measured by the A5

NFR2 = the number of NR FR2 frequencies measured by the A5

The timeToTrigger is taken from rsrpCandidateA5 , rsrqCandidateA5 or sinrCandidateA5 , depending on the trigger quantity.

- When hiPrioDetMeasurementTime expires, the A5 measurements are removed from the UE, and no measurements occur for

TrStPSCellProfileUeCfg.hiPrioDetInactiveTime (default 30 seconds).

- The sequence is repeated periodically until PSCell change, SN release or A2 Entering Search Zone occurs.

The Event A5 measurements are configured with the struct attributes rsrpCandidateA5 , rsrqCandidateA5 and sinrCandidateA5 , depending on the measurement quantity. These struct attributes all contain threshold2 , hysteresis and timeToTrigger . threshold2 is used to confirm that the target cell coverage is good enough to justify mobility. The A5 threshold 1 is fixed to a value that is always fulfilled.

When PSCell Change to Higher Priority receives the A5 report, other measurement quantities (besides the triggering quantity) can also be checked, using the following TrStPSCellProfileUeCfg attributes:

- When candidateA5TriggerQuantity = RSRP , then an RSRQ or a SINR check can be added for the target cell, using rsrpCandidateA5AddTargEval .

- When candidateA5TriggerQuantity = RSRQ , then only an RSRP check can be added for the target cell, using rsrqCandidateA5AddTargEval .

<!-- page: 356 -->

- When candidateA5TriggerQuantity = SINR , then an RSRP and/or a RSRQ check can be added for the target cell, using sinrCandidateA5AddTargEval .

For example, if candidateA5TriggerQuantity = RSRP and rsrpCandidateA5AddTargEval = SINR_FALLBACK_RSRQ , then the gNodeB also checks the reported SINR value (for UEs that can measure SINR), or the reported RSRQ value (for UEs that cannot measure SINR).

If the received A5 report fails any of the additional checks described above, the measurement report is discarded and PSCell Change to Higher Priority waits for a new report to evaluate.

See Section 11.2.10 for the formulas defining the trigger levels and the additional checks.

When the gNodeB receives an A5 report from the UE (via the eNodeB), the gNodeB determines whether the reported cell is known, is valid for mobility and has an allowed PLMN. If not, the report is discarded, and no mobility action is taken.

If the reported cell is blocked for traffic (due to manual barring, cell soft lock, or cell sleep preparation), PSCell change is not attempted. Refer to Section 10.3.35 for further details.

If the reported cell is valid and from the highest priority frequency, then the gNodeB initiates a PSCell change to the reported cell if NRCellRelation.isHoAllowed = true , regardless of whether the priority period is running or not. If isHoAllowed = false , then no action is taken.

If the priority of the reported cell is not the highest among the measured frequencies, and if the priority period is running, then the report is stored (replacing the pre-existing stored report, if one exists) while the gNodeB waits for a highest priority report.

If the priority period expires before a highest priority frequency report is received, then the gNodeB initiates a PSCell change to the stored lower priority cell, if there is one. If there is no stored cell when the priority period expires, then the gNodeB initiates a PSCell change to the next valid reported cell from the UE before hiPrioDetMeasurementTime expires, regardless of its priority.

If the PSCell change request is rejected by the target gNodeB due to insufficient UE capabilities or by the eNodeB due to misconfiguration, then the target cell can be blocklisted for the lifetime of the UE connection in the source gNodeB; refer to Section 6.3.2.1 for further details.

### 10.3.18 EBS Counters Enabler (FAJ 121 5409) - NSA and SA

This is an unlicensed gNodeB feature in the value package NR Base Package (FAJ 801 4002).

<!-- page: 357 -->

̶

This feature enables the creation of off-node PM counters in Event Based Statistics for NR (EBS-N). Specifically, it provides the parameters in the PM event and counter model files that are needed to create the counters. Off-node counters are also called EBS counters. EBS counters have significant advantages, including enabling filters to create customized counters, providing more flexibility and granularity (for example cell relation level counters) and allowing short reporting periods, all of which are important for mobility optimization.

For more information on EBS counters, see Section 12.

### 10.3.19 NR Service-Adaptive Inactivity Timer (FAJ 121 5326) - NSA and SA

This is a licensed gNodeB feature in the value package Performance Boost (FAJ 801 4021).

The feature allows the inactivity time for EN-DC, NR SA and NR-DC to be set per UE group.

**· For EN-DC, the secondary node inactivity time is set by**

InactivityProfileUeCfg.tInactivityTimerEndcSn , which overrides the hard-coded value of 5 seconds.

- For NR SA and NR-DC, the master node inactivity time is set by

InactivityProfileUeCfg.tInactivityTimer . This replaces the attribute GNBCUCPFunction.tInactivityTimer , which is deprecated.

· For NR-DC, the secondary node inactivity time is set by InactivityProfileUeCfg . tInactivityTimerNrdcSn .

Refer to the feature description in CPI for more information.

### 10.3.20 User and Service-Specific Mobility (FAJ 121 5399) - NSA and SA

This is a licensed gNodeB feature in the value package Intelligent Traffic Management and Mobility (FAJ 801 4022).

The feature enables the following features to be configured per UE Mobility Group or UE Service Group using the basic UE Grouping framework:

- NR Mobility, specifically, the impacted functions are:

̶

- Intra-Frequency Mobility Control for EN-DC and NR SA

- MCPC for EN-DC and NR SA

̶

- Idle Mode Steering for NR SA

- NR-NR Dual Connectivity

̶

- Intra-frequency mobility for NR-DC

<!-- page: 358 -->

- Inter-frequency PSCell change to higher priority for EN-DC

- NR DL Carrier Aggregation

̶

- SCell mobility for EN-DC and SA

- NR Traffic Steering, specifically, the impacted functions are:

̶

- MLC and Advanced MLC for NR SA

̶

- Traffic Steering Cell Reselection Priority at UE Release for NR SA

̶

- BWTISHO for NR SA

̶

- DCSC for NR SA

- NR Small Cell Traffic Steering

- EPS Fallback for IMS Voice

- NR Emergency Fallback to LTE

- NR Intelligent SCell Management

- NR Cell Soft Lock

- NR Traffic Offload

- Positioning of UEs without PDU Session

If the feature is not active, then only the base instances of the configuration MOs are used for the above-mentioned features and functions (for example McpcPCellProfileUeCfg , McpcPCellNrFreqRelProfileUeCfg , McpcPCellEUtranFreqRelProfileUeCfg ).

Refer to the feature description in CPI for more information.

### 10.3.21 NR UE-Assisted Overheating Mitigation (FAJ 121 5449) - NSA and SA

This basic gNodeB feature allows the network to take mitigating action when a UE informs the network that it is overheated.

For EN-DC connections, this feature works together with functionality in the eNodeB feature Basic Intelligent Connectivity , as described in Section 10.2.1.9.

For NR-DC and SA connections, the functionality is enabled by setting UaiProfileUeCfg.overheatingAssistanceConfig = true . The gNodeB then configures UEs that support the reporting of overheating assistance information to report their overheating status using the UEAssistanceInformation message.

When the master gNodeB (MN) receives a report that the UE is overheated, it takes one or more of the following actions, depending on the severity of the overheating:

<!-- page: 359 -->

- Deactivate SCells in the NR MCG (FR1)

- Deactivate SCells in the NR SCG (FR2)

- Release the Secondary Node (SN) (FR2)

The gNodeB will not reactivate the SCells or add the SN until the UE reports that it is no longer overheated.

UAI configuration is reset at setup/release/change of SN and at MN handover.

The overheating status is cleared when the UE returns to idle mode.

For more information, see CPI for the gNodeB feature NR UE-Assisted Overheating Mitigation .

### 10.3.22 NR Remote Interference Management (FAJ 121 5514) - SA

This is a licensed gNodeB feature for NR standalone TDD cells.

Certain weather conditions can cause atmospheric ducts, which can cause a downlink slot on a remote cell to interfere with an uplink slot on the serving cell, impacting the uplink performance.

When the feature detects that the cell is affected by remote interference, the following actions are taken:

- The SIB1 broadcasted qRxLevMin is increased, which forces cell edge UEs to reselect to another cell.

- For incoming handovers from NR and LTE, the reported RSRP that is included in the handover request is checked against the one of the following thresholds:

̶

- If OffloadCellProfileUeCfg . rimOffloadIncHoRsrpThresh = <empty>, it is checked against the SIB broadcasted increased qRxLevMin + Pcompensation.

̶

- If OffloadCellProfileUeCfg . rimOffloadIncHoRsrpThresh ≠ <empty>, it is checked against the specified threshold value (dBm) of this attribute.

If the RSRP is not included in the handover request or does not pass the above test, then the handover request is rejected. For intra-NR handovers, this triggers the source gNodeB to blocklist the target cell, thereby preventing further handover attempts. Note that the Ericsson eNodeB does not include the RSRP in the handover request for IRAT handovers to NR.

- UL quality monitoring is started for the UEs in the cell. If ulSinrMax < RimOffloadUeCfg . rimUlCriticalQualThresh for 1 sec for a UE, then the UE is considered to be on the cell edge, and the gNodeB initiates a blind RwR to an NR or LTE frequency. Here ulSinrMax is the maximum achievable SINR when the UE uses the maximum available transmission power and a single resource block.

<!-- page: 360 -->

The frequency selected for the RwR is decided as follows:

- Select the NR frequency with the lowest ARFCN supported by the UE with OffloadNrFreqRelProfileUeCfg . rimOffloadType = BLIND_RWR

- If no NR frequency can be selected, select the LTE frequency with the lowest ARFCN supported by the UE with OffloadEUtranFreqRelProfileUeCfg . rimOffloadType = BLIND_RWR

- If no NR or LTE target frequency can be selected, the UE is released. The UE then reselects another cell if the measured RSRP does not meet the modified qRxLevMin

To activate the feature:

- Set NRCellDU . rimOffloadEnabled = true

- Set NRCellDU . rimDetectionEnabled = true to enable the prerequisite feature RIM Detection

If this feature triggers mobility to LTE, the UE can be discouraged from returning to the NR SA frequency as follows:

- If the mobility was handover, the eNodeB can prevent return in both connected and idle mode, as described in Section 10.2.2.

- If the mobility was a release-with-redirect, the gNodeB can discourage return in idle mode, as described in Section 8.3.12.

For more information, see the feature description for NR Remote Interference Management in CPI.

### 10.3.23 NR PCI Conflict Reporting (FAJ 121 5621) - NSA

This basic gNodeB feature introduces automatic PCI conflict detection and reporting for NR networks. Refer to the feature description in CPI for more information.

### 10.3.24 NR Cell Soft Lock (FAJ 121 5575) - SA

This feature reduces the impact on end-user experience when soft locking an NR cell. The feature hands over SA UEs to other cells and prevents new UEs from accessing the cell via handover or EN-DC. For more information, see the feature description for NR Cell Soft Lock in CPI. For the parameters and trigger level formulas, refer to Section 11.2.14.

### 10.3.25 Ericsson Reduced Capability Enabler (FAJ 121 5661) - SA

This licensed gNodeB feature introduces support for reduced capability (RedCap) UEs in an NR standalone deployment.

<!-- page: 361 -->

̶

To enable RedCap UEs to access a cell, set NRCellDU.redCap1RxEnabled = true and/or NRCellDU.redCap2RxEnabled = true . Setting either of these attributes to true also enables intra-frequency mobility for RedCap UEs.

To enable inter-frequency mobility in idle and connected mode for RedCap UEs, set NRFreqRelation.redCapEnabled = true .

To enable mobility and traffic management features to be configured differently for RedCap UEs, the User- and Service Specific Mobility feature allows RedCap UEs to be included in a UE group using the selectionCriteria variable ' redCapUe == true ' .

The feature also enables some additional control over how 'l ow capability ' (LowCap) UEs are handled, using the attribute lowCapUeHandling .

The NR Reduced UE Bandwidth Support feature must be active to enable RedCap UEs to connect to cells with bandwidths larger than 20 MHz in low-band and mid-band.

For further information, refer to the feature description for Ericsson Reduced Capability Enabler and Ericsson Reduced Capability User Guide in CPI.

### 10.3.26 NR Data-Aware Mobility (FAJ 121 5696) - SA

NR Data-Aware Mobility (DAM) is a licensed gNodeB feature in the Intelligent Traffic Management and Mobility package (FAJ 801 4022). It monitors UE performance and moves UEs that experience low performance from NR SA to LTE. DAM is intended primarily for use on NR coverage layers, but it can also be used on capacity layers.

DAM evaluation starts when MLC evaluation finishes, after the UE enters the cell from idle or inactive state. If Dynamic Cell Set Change During Mobility (Section 10.3.5.4) is enabled, then DAM evaluation also starts when the first periodic MLC finishes, after the UE enters the cell via handover or RRC reestablishment.

DAM evaluation follows these steps:

- DAM first determines whether to monitor the UE performance. Once monitoring starts, it runs constantly (not periodically). DAM monitors the performance of a UE if all the following conditions are fulfilled.

̶

- NR-DC is not configured or is not possible to configure, as below:

- At connection setup and resume, DAM is possible only if NR-DC is not possible

- At periodic BWTISHO evaluation, DAM is possible only if NR-DC is not configured

- Refer to Figure 10 - 26 for details.

**There is at least one LTE frequency with**

UeMCEUtranFreqRelProfileUeCfg.connModeAllowedPCell = true that the UE can use for handover or RwR

<!-- page: 362 -->

̶

- The UE supports Event B2 triggered measurements

̶

- The UE is in good coverage in the serving PCell (not in the MCPC search zone)

̶

- The UE is not configured with any IRAT mobility measurements for traffic steering.

- If BWTISHO is enabled (Section 10.3.5.3), then the bandwidth of the current activated cell set for the UE must be less or equal to TrStSaCellProfileUeCfg.aggregatedBwThreshold .

- At least one type of DAM monitoring applies to the UE, namely downlink RLC buffer monitoring, downlink throughput monitoring or uplink throughput monitoring. Monitoring applies if the relevant threshold is set to greater than zero; see the next step.

- DL RLC buffer monitoring is used either for NR-DC setup or for DAM, not both simultaneously. Therefore, if RLC buffer monitoring is already ongoing for NRDC setup, then RLC buffer monitoring for DAM is not started; as shown in Figure 10-31.

- To ensure that buffer monitoring operates correctly for both NR-DC and DAM, set the DAM thresholds higher than the corresponding thresholds for NR-DC, as shown in Figure 10-31.

- DAM monitors the UE performance and concludes that it is low if any of the following conditions occur.

![Figure on page 362](5G_Mobility_and_Traffic_Management_Guideline_images/page_362_image_001.png)

Figure 10-31 - DL RLC Buffer Monitoring - Interaction Between NR-DC Setup and DAM

̶

- Downlink RLC buffer monitoring condition

̶

̶

<!-- page: 363 -->

̶

- The oldest SDU packet in the RLC queue is greater than TrStSaCellProfileUeCfg.dataAwareMobDlPktAgeThr threshold is set to a value greater than 0 , or:

, and that

- The volume of the packets in the RLC queue is greater than TrStSaCellProfileUeCfg.dataAwareMobDlPktVolThr , and that threshold is set to a value greater than 0 .

- If both thresholds are set to a value greater than 0 , then both conditions must be satisfied for DAM to conclude that the performance is low.

- Downlink throughput monitoring condition

- The downlink filtered throughput is less than TrStSaCellProfileUeCfg.dataAwareMobLowDlThpThr , and that threshold is set to a value greater than 0 . The throughput measurement includes both PCell and SCell volume and focuses on periods when the throughput is limited by the air interface.

̶

- Uplink throughput monitoring condition

**·**

The uplink filtered throughput is less than TrStSaCellProfileUeCfg.dataAwareMobLowUlThpThr , and that threshold is set to a value greater than 0 . The throughput measurement includes both PCell and SCell volume and focuses on periods when the throughput is limited by the air interface.

If the performance is low, DAM attempts to move the UE to LTE. For this, DAM uses the same B2 measurements and measurement procedure to search for coverage on the potential target LTE frequencies as BWTISHO, even when BWTISHO is not activated.

The procedures and parameters that are common to BWTISHO and DAM are described in the following subsections in Section 10.3.5.3:

- Measurement configuration

- Measurement report handling

- Handover handling

The parameters and trigger level conditions for both DAM and BWTISHO are described in Section 11.2.13.

For more information, refer to the feature description for DAM in CPI.

### 10.3.27 NR Traffic Offload (FAJ 121 5680) - SA

This gNodeB feature allows UEs to be moved from NR SA to LTE if the number of connected UEs in the NR cell exceeds a configurable threshold.

<!-- page: 364 -->

The threshold is set at the cell level using maxConnectedUeOffloadISHo , but can be adjusted per UE group using ueOffloadISHoRatio as follows:

**Connected UE Offload Threshold =**

AdmissionLimit.maxConnectedUeOffloadISHo * OffloadCellProfileUeCfg.ueOffloadISHoRatio / 1000

where connected UEs includes UEs that use the cell as a PCell for SA or a PSCell for EN-DC or NR-DC.

The conditions for offload are evaluated at:

- Initial context setup

- RRC resume

- Incoming handover

- RRC reestablishment

When offload is required, the gNodeB configures a B1 measurement in the UE to evaluate potential targets; see Section 11.2.14.2 for the parameters and trigger level formulas.

The functionality can be enabled per UE group using:

OffloadCellProfileUeCfg.offloadISHoEnabled

The allowable target frequencies can be controlled per UE group using:

OffloadEUtranFreqRelProfileUeCfg.offloadISHoAllowed

After NR Traffic Offload triggers mobility to LTE, the UE can be discouraged from returning to the NR SA frequency as follows:

- If the mobility was handover, the eNodeB can prevent return in both connected and idle mode, as described in Section 10.2.2.

- If the mobility was a release-with-redirect, the gNodeB can discourage return in idle mode, as described in Section 8.3.12.

### 10.3.28 UE-Assisted RRC State Preference (FAJ 121 5714) - SA

This licensed gNodeB feature allows the UE to request release from connected mode when it suspects that data transmissions are finished, allowing it to save battery.

The request includes a preference for the target RRC state; either idle or inactive or outOfConnected (which means no preference).

The feature is configured at the UE group level using the following attributes:

<!-- page: 365 -->

- UaiProfileUeCfg.releasePrefConfig Set to True to allow the UE to request release.

- UaiProfileUeCfg.releasePrefOverride Set to IDLE or INACTIVE to override the UE target state preference, or to NO_PREFERENCE to respect it. Note that release to inactive state requires the prerequisite conditions to be met, as detailed in Section 8.2.4.1.

For the functionality to apply to a UE, the UE must support the PowSav-ParametersCommon-r16.releasePreference-r16 UE capability.

For further information, refer to the feature description in CPI.

### 10.3.29 NR Small Cell Traffic Steering (FAJ 121 5778) - SA

This licensed gNodeB feature enables NR Traffic Steering to move UEs to another vendor cell when it is reported during measurements initiated by Multi-Layer Coordination (both at setup and periodically due to DCSC).

The functionality is enabled at the UE group level per frequency relation using the attribute TrStSaNrFreqRelProfileUeCfg.hoToPrioritizedCell . Set this attribute to true to allow UEs to handover to a nother vendor's cell . Set the attribute to false to disable the functionality.

The detection of another vendor 's cells requires a measurement on the relevant frequency. This in turn requires that MLC identifies a valid candidate (an Ericsson cell) and configures measurements on the relevant frequency.

The ability to detect other vendor small cells can be reduced under the following conditions:

- The other vendor cell is overlapped by a high-capacity Ericsson cell on another frequency. In this case, MLC may initially choose to measure the high-capacity frequency rather than the small cell frequency. If that measurement results in MLC triggering handover or SCell reselection, then the small cell frequency will not be measured.

- The feature NR Advanced Multi-Layer Coordination is enabled, and all the Ericsson cells on the other vendor small cell frequency are highly loaded. In this case, MLC may choose not to measure the small cell frequency, because all of the potential MLC candidate cells on that frequency have a poor available capacity factor.

Other vendor's cells are those that belong to a gNodeB identified as another vendor 's during Xn setup.

For further information, refer to the feature description in CPI.

<!-- page: 366 -->

### 10.3.30 Positioning of UEs without PDU Session (FAJ 121 5821)

This licensed gNodeB feature allows the Location Management Function (LMF) to obtain positioning measurements from UEs in idle mode. The positioning request is handled as follows:

- The LMF issues a positioning request which causes the UE to be paged.

- The UE responds to the page and enters connected mode without a PDU session.

- The LMF issues a request for an Enhanced Cell ID (E-CID) measurement

- If the feature is active, the gNodeB configures the UE with the E-CID measurement and forwards the result to the LMF. If the feature is not active, the gNodeB responds to the LMF with a failure message.

**The functionality is enabled at the UE group level using**

UeNoDrbPCellProfileUeCfg.posUeWoPduSessionEnabled . This class also contains attributes to configure A2 and A3 measurements to monitor the connection and release it if a report is received. See Section 11.2.15 for the parameters and trigger level formulas.

### 10.3.31 Relaxed Radio Resource Management Measurements (FAJ 121 5824)

Relaxed Radio Resource Management Measurements is a feature that allows NR UEs and RedCap UEs to reduce or suspend radio measurements in RRC_IDLE or RRC_INACTIVE states under specific conditions. This is primarily to conserve UE battery life, especially when mobility is low, or the environment is stable.

The criteria for relaxed measurements are defined using four scenarios (specified in 3GPP TS 138.304), that characterize the radio environment based on UE measurements. These scenarios are configured using the gNodeB attributes shown in Table 10-16, which are communicated to the UE in SIB2.

Table 10-16 - Attributes for Controlling Relaxed RRM Measurements

| Relaxed Measurements Scenario         | SIB2 Configuration Parameters                   | UE Applicability          |
|---------------------------------------|-------------------------------------------------|---------------------------|
| Low mobility                          | sSearchDeltaP tSearchDeltaP                     | NR UEs and RedCap devices |
| Not at the cell edge                  | sSearchThresholdP sSearchThresholdQ             | NR UEs and RedCap devices |
| Stationary                            | sSearchDeltaPStationary tSearchDeltaPStationary | RedCap devices            |
| Not at the cell edge while stationary | sSearchThresholdP2 sSearchThresholdQ2           | RedCap devices            |

Table 10-16 - Attributes for Controlling Relaxed RRM Measurements

When the relaxed measurement criteria are fulfilled, the UE may choose which relaxation method(s) to apply (as defined in 3GPP TS 138.133) and it may apply different relaxations for different measurement types (intra frequency, inter frequency, IRAT).

<!-- page: 367 -->

Relaxed measurements are illustrated in Figure 10-32 where K is the relaxation factor defined by 3GPP, supporting the values 3, 6, 60 and 240.

![Figure on page 367](5G_Mobility_and_Traffic_Management_Guideline_images/page_367_image_002.png)

Figure 10-32 - Relaxed RRM Measurements

The scenarios are further described below:

**Low Mobility Scenario**

This scenario is configured if RelaxedRrmMeasCellProfile. sSearchDeltaP and RelaxedRrmMeasCellProfile. tSearchDeltaP are not empty.

The UE can enter the Low Mobility scenario only after a time of tSearchDeltaP from the last cell selection/reselection.

The UE enters the Low Mobility scenario when:

SS_RSRPServingCell  never decreases below

SS_RSRPServingCell REF - RelaxedRrmMeasCellProfile. sSearchDeltaP

for a time of RelaxedRrmMeasCellProfile. tSearchDeltaP

as depicted in Figure 10-33.

![Figure on page 367](5G_Mobility_and_Traffic_Management_Guideline_images/page_367_image_003.png)

Figure 10-33 - Relaxed RRM Measurements - Low Mobility Scenario

SS_RSRPServingCell REF is a reference RSRP value used by the UE to calculate the serving cell coverage variation.

The value of SS_RSRPServingCell REF is updated with the current value of SS_RSRPServingCell when:

- A new cell is selected/reselected, or

- The  SS_RSRPServingCell  becomes higher than the last SS_RSRPServingCell REF value, or

<!-- page: 368 -->

- The SS_RSRPServingCell remains below SS_RSRPServingCell REF - RelaxedRrmMeasCellProfile. sSearchDeltaP for a period of tSearchDeltaP

If RelaxedRrmMeasCellProfile. highPriorityMeasRelax = true , then the relaxation triggered by the Low Mobility scenario can apply also to the measurements for higher priority frequencies.

**Not At Cell Edge Scenario**

This scenario is configured if RelaxedRrmMeasCellProfile. sSearchThresholdP is not empty.

The UE enters the Not At Cell Edge scenario when:

SS_RSRPServingCell  > NRCellDU . qRxLevMin + RelaxedRrmMeasCellProfile. sSearchThresholdP

![Figure on page 368](5G_Mobility_and_Traffic_Management_Guideline_images/page_368_image_002.png)

Figure 10-34 - Relaxed RRM Measurements - Not At Cell Edge Scenario

If RelaxedRrmMeasCellProfile. sSearchThresholdQ is not empty, then the additional condition:

SS_RSRQServingCell  > NRCellDU . qQualMin + RelaxedRrmMeasCellProfile. sSearchThresholdQ

is required to trigger the Not At The Cell Edge scenario.

**Combined Not At The Cell Edge & Low Mobility Scenarios**

If criteria for both Not At Cell Edge and Low mobility scenarios are configured, the UE can be requested to apply relaxation only if both scenarios are fulfilled. This is achieved by setting RelaxedRrmMeasCellProfile. combineRelaxedMeasCondition = true . The UE can then apply a largest relaxation degree: intra frequency, inter-frequency and IRAT frequency measurements can be suspended for up to one hour.

If combineRelaxedMeasCondition = false , relaxation, with lower degree, will be applied even when only one scenario is fulfilled.

<!-- page: 369 -->

![Figure on page 369](5G_Mobility_and_Traffic_Management_Guideline_images/page_369_image_002.png)

Figure 10-35 - Relaxed RRM Measurements - Combined Scenarios

Similar scenarios can be defined to be applied to RedCap devices only, as follows.

**Stationary RedCap Scenario**

The Stationary RedCap scenario is configured if RelaxedRrmMeasCellProfile. sSearchDeltaPStationary and RelaxedRrmMeasCellProfile. tSearchDeltaPStationary are not empty.

The prerequisite to enter the Stationary scenario is that the UE has performed normal intrafrequency, NR inter-frequency, or inter-RAT frequency measurements for at least tSearchDeltaPStationary after last cell (re-)selection.

The rules for entering the Stationary RedCap scenario are the same as Low mobility and Figure 10-33 also applies, but with alternative parameters:

- sSearchDeltaPStationary is used instead of sSearchDeltaP

- tSearchDeltaPStationary is used instead of tSearchDeltaP

**Not At Cell Edge While Stationary RedCap Scenario**

The scenario is configured if RelaxedRrmMeasCellProfile. sSearchThresholdP2 is not empty.

The prerequisite to enter the Not At Cell Edge While Stationary scenario is that the UE has performed normal intra-frequency, NR inter-frequency, or inter-RAT frequency measurements for at least tSearchDeltaPStationary after last cell (re-)selection.

The RedCap device enters Not At Cell Edge While Stationary if:

- The criterion to enter Stationary scenario is fulfilled for a period of tSearchDeltaPStationary and

- SS_RSRPServingCell  > NRCellDU. qRxLevMin + RelaxedRrmMeasCellProfile . sSearchThresholdP2

<!-- page: 370 -->

And, if RelaxedRrmMeasCellProfile. sSearchThresholdQ2 is not empty,

- SS_RSRQServingCell  > NRCellDU. qQualMin + RelaxedRrmMeasCellProfile

. sSearchThresholdQ2

The Not At Cell Edge While Stationary allows the largest degree of measurement relaxation for a Redcap device: Intra frequency, inter-frequency and IRAT frequency measurements can be suspended for up to four hours.

If RelaxedRrmMeasCellProfile. combineRelaxedMeasCondition2 = true , then entering the Stationary scenario alone is not enough to activate any measurement relaxation.

**Idle Mode Mobility Parameters Dependencies**

There are some dependencies between the idle mode mobility thresholds and the thresholds used for measurements relaxation:

- NRCellCU. sNonIntraSearchP must be higher than or equal to RelaxedRrmMeasCellProfile. sSearchThresholdP and RelaxedRrmMeasCellProfile. sSearchThresholdP2

- NRCellCU. sNonIntraSearchQ must be higher than or equal to RelaxedRrmMeasCellProfile. sSearchThresholdQ and RelaxedRrmMeasCellProfile. sSearchThresholdQ2

- NRFreqRelation. sIntraSearchP must be higher than or equal to RelaxedRrmMeasCellProfile. sSearchThresholdP and RelaxedRrmMeasCellProfile. sSearchThresholdP2

- NRFreqRelation. sIntraSearchQ must be higher than or equal to RelaxedRrmMeasCellProfile. sSearchThresholdQ and RelaxedRrmMeasCellProfile. sSearchThresholdQ2

### 10.3.32 NR Switched Uplink for Throughput Boost (FAJ 121 5772) - SA

This licensed gNodeB features provides a throughput boost for SA UEs that have only two UL transmitters and are capable of 1TX - 2TX switching (UL TX switching). It allows these UEs to dynamically switch between SU MIMO transmission on a Mid-Band TDD PCell and single layer transmission on an FDD SCell, as shown in Figure 10-36.

<!-- page: 371 -->

![Figure on page 371](5G_Mobility_and_Traffic_Management_Guideline_images/page_371_image_002.png)

Figure 10-36 - Uplink 1TX - 2TX Switching

This gives greater overall throughput than using just SU-MIMO on TDD or just UL CA, without requiring three uplink transmitters in the UE.

The decision on whether to use SU-MIMO, UL CA or 1TX-2TX switching is made at initial selection and periodically via MLC/DCSC.

### 10.3.33 Switched Uplink with FDD and TDD Uplink MIMO (FAJ 121 5846) - SA

This licensed gNodeB features provides a throughput boost for SA UEs that have only two UL transmitters, support UL SU-MIMO on both FDD and TDD, and are capable of 2TX - 2TX switching (UL TX switching). It allows these UEs to dynamically switch between SU MIMO transmission on a Mid-Band TDD PCell and on an FDD SCell, as shown in Figure 10-37.

![Figure on page 371](5G_Mobility_and_Traffic_Management_Guideline_images/page_371_image_003.png)

Figure 10-37 - Uplink 2TX - 2TX Switching

This gives greater overall throughput than using just SU-MIMO on TDD or FDD or just UL CA, without requiring three uplink transmitters in the UE.

The decision on whether to use SU-MIMO, UL CA, 1TX-2TX or 2TX-2TX switching is made at initial selection and periodically via MLC/DCSC.

<!-- page: 372 -->

### 10.3.34 Low Latency Mobility for Dedicated RAN (FAJ 121 5785) and Low Latency Mobility for Public RAN (FAJ 121 5784) - SA

These features enable the L1/L2 Triggered Mobility (LTM) procedure, which provides fast intra-frequency PCell switching between cells in the same gNodeB. LTM allows a reduced interruption time compared to a standard PCell handover and is particularly beneficial for time-critical communication (TCC) services.

For a more detailed description of the LTM procedure, refer to Section 8.3.4.

For the parameters and trigger level formulas, refer to Section 11.2.17.

### 10.3.35 NR Preemptive Mobility Management (FAJ 121 5893) - SA and NSA

This feature blocks requests for handover, EN-DC PSCell change, and carrier aggregation configuration to cells that are automatically blocked for traffic by NR Booster Carrier Sleep or NR Cell Soft Lock .

It can also block requests to cells that are manually barred and, in this case, provides additional flexibility to determine which types of requests are blocked.

The requests are blocked before attempts occur, which reduces rejected handovers and PSCell changes, reduces signaling overhead and improves traffic steering efficiency.

For more information, refer to the feature description in CPI.

### 10.3.36 Load-Based Prioritized UE Handling (FAJ 121 5895) - SA and NSA

This licensed feature improves accessibility and service quality for priority UEs under highload conditions in protected cells.

The feature monitors the number of connected users and the PDCCH load, and dynamically blocks non-priority UEs from incoming handover, EN-DC setup, PSCell change, and/or carrier aggregation when configured thresholds are reached.

It also enables the controlled offload of non-priority UEs to neighbor cells during high load conditions.

For more information, refer to the feature description in CPI.

### 10.3.37 NR Automated Neighbor Relations for NR-DC (FAJ 121 5871) - SA

This licensed gNodeB feature enables PCI-based ANR for NR-DC by allowing the master gNodeB to create lightweight FR1-to-FR2 neighbor cell relations when a UE reports an unknown FR2 cell in an A4 measurement report, reducing the need for manual configuration. The relation is created only if the reported RSRP is greater than or equal to AnrFunctionNRUeCfg.anrA4RsrpThreshold , a matching ExternalNRCellCU for the reported PCI already exists, and the reported cell is PSCell capable.

<!-- page: 373 -->

If the master gNodeB supports EN-DC, then the feature can also trigger automatic Xn setup between the master gNodeB and the secondary gNodeB, with assistance from ANR in the eNodeB.

For further information, refer to the feature descriptions in CPI.

## 10.4 MME Features

This section lists selected MME features implemented that are important for 5G Mobility & Traffic Management.

### 10.4.1 UE Dual Connectivity Support (FAT 102 3381/2116)

This is a licensed MME feature and a pre-requisite for successful Dual Connectivity operation.

The UE Dual Connectivity Support feature allows eNodeB to switch user plane tunnels between LTE and NR for UEs in connected state. This is enabled by the E-RAB Modification Indication procedure between the eNodeB, MME and the SGW.

If the feature is not ACTIVATED, the SGSN-MME handles a received E-RAB Modification Indication message as unknown/unsuccessful and responds with an ERROR Indication message and Cause IE Message Not Compatible With Receiver State .

For further information on this feature refer to the SGSN-MME 5G EPC Feature Description.

### 10.4.2 NR Access Control (FAT 102 3381/2119)

This is a licensed MME feature and a pre-requisite for successful Dual Connectivity operation.

The NR Access Control feature enables NR Capable UEs connected to the EPC, to use NR as a secondary RAT.

Based on the NR Access Control feature state, UE support for NR, HSS subscription data and local SGSN-MME configuration, a decision is made on whether NR access is restricted or not.

NR access is allowed only in the following scenarios:

- The NR Access Control license is enabled and the feature is activated

- The UE supports NR

- The HSS subscription data does not restrict NR

- The MME has no local configuration that restricts NR for the subscriber

<!-- page: 374 -->

The eNodeB receives the information in the NR Restriction in EPS as Secondary RAT IE in the Handover Restriction List IE in the Initial Context Setup Request, Handover Request, and Downlink NAS Transport messages. The NR Restriction in EPS as Secondary RAT IE is included only if NR is restricted for the UE.

The NR base package feature LTE-NR Dual Connectivity (FAJ 121 4908) includes support for NR Access Control (referred to as NR Restriction).

For further information on this feature refer to the SGSN-MME 5G EPC Feature Description.

<!-- page: 375 -->

# 11 Appendix 2 - Mobility Trigger Levels

This section provides formulas for the effective trigger levels of various mobility cases. It focusses on those mobility cases which are new with 5G. Legacy LTE mobility cases are described in the CPI document LTE Mobility and Traffic Management Guideline .

The formulas use the following notation:

For example:

When using these formulas, note the following:

- The formulas show the condition(s) required for the action to be triggered, for example the handover or reselection.

- The formulas refer to the Ericsson attribute values with their sign as set in the node. For example, if offset = -30 (-3dB) then use the value -30 in the formula. The formula includes the appropriate conversion, so that the results are in dBm (RSRP) or dB (RSRQ, SINR, UL_SINR or RSRP delta). Any exceptions to this are noted (e.g. sIntraSearch = 1000 , which means not sent).

- For connected mode transitions, the event is triggered when the entry level is satisfied for the relevant time-to-trigger; for more information see Section 4.8.5.

- In general, this section covers only the triggering levels themselves, not the criteria which determine when a particular trigger applies. For more details on triggering criteria refer to the relevant sections in this document or the feature descriptions in CPI.

- For LTE, the formulas shown here are for LTE FDD cells. The formulas for TDD can be obtained by replacing EUtranCellFDD with EUtranCellTDD .

- This section assumes that the UE is capable of LTE, NR NSA and NR SA.

- The attribute qOffsetFreq impacts both idle and connected mode triggering. However, note that it is used with a different sign in idle and connected modes.

- For RSRP formulas, the term on the left of the formula (e.g. SS_RSRPtarget) is the RSRP measured directly by the UE.

̶

- If cell individual offset applies to the event and it is set to a non-zero value for the measured cell, then the UE adds the offset to the measured RSRP before comparing with the threshold and hysteresis configured for the measurement event.

̶

- However, in the formulas in this document, the cell individual offset is subtracted on the right-hand side rather than added on the left-hand side. The two are mathematically identical, but the former is easier to read and understand.

<!-- page: 376 -->

- The final measurement event threshold and hysteresis are sent to the UE separately from any cell individual offset values (as they may be different for different target cells). The UE combines them as required to determine whether the event triggering conditions are satisfied.

- The parameters used for setting the cell individual offset are cellIndividualOffset (for LTE cells) and cellIndividualOffsetNR (for NR cells). If the offset is set to zero, then it is not sent to the UE.

- Cell individual offset is not supported by the lightweight neighbor relations ( lwNeighborRel ) created by NR Automated Neighbor Relations .

## 11.1 Idle Mode

The idle mode formulas presented in the following sections assume the following:

- Higher priority PLMN offsets do not apply (which is normally the case). More specifically this means:

̶

- The 3GPP parameter Qrxlevminoffset = 0, which occurs if qRxLevMinOffset = 1000 (in LTE) or empty (in NR), or the cell is not being evaluated as a result of a search for a higher priority PLMN, and

̶

- The 3GPP parameter Qqualminoffset = 0, which occurs if either qQualMinOffset = 0 (in LTE) or empty (in NR), or the cell is not being evaluated as a result of a search for a higher priority PLMN.

- The UE is capable of the maximum transmit power allowed in the cell (which is normally the case). More specifically this means:

̶

- For the serving cell, the 3GPP parameter Pcompensation = 0, which occurs if either EUtranCellFDD/TDD.pMaxServingCell = 1000 in LTE or NRCellDU.pMax = empty or 1000 in NR, or if the UE is capable of the maximum power.

̶

- For a neighbor cell, the 3GPP parameter Pcompensation = 0, which occurs if either pMax = 1000 or empty in the frequency relation, or if the UE is capable of the maximum power indicated in the frequency relation.

(Aside:  Note that the default value of NRCellDU.pMax is 23 dBm, but the default value of GUtranFreqRelation.pMaxNr is 33 dBm. With these non-matching default values, a 23 dBm UE that camps on LTE and measures NR will penalize the NR cells by 10 dB when evaluating the qRxLevMin criteria for cell selection, because it sees itself as having a 10 dB power shortfall. To avoid this problem, set the two attributes to the same value.)

- Speed dependent scaling does not apply.

- The UE is capable of both NR SA and LTE.

For SA, the idle mode trigger levels apply to UEs in both idle mode and in RRC_INACTIVE state.

<!-- page: 377 -->

### 11.1.1 Cell Selection

Given the simplifying assumptions in Section 11.1, cell selection is performed as follows.

The UE can select an NR SA cell when:

SS_RSRPNR > (gNB) NRCellDU. qRxLevMin and SS_RSRQNR > (gNB) NRCellDU. qQualMin

The UE can select an LTE cell when:

RSRPLTE > (eNB) EUtranCellFDD. qRxLevMin

and, if the UE is capable of RSRQ based evaluation (mandatory in 3GPP Release 9),

RSRQLTE > (eNB) EUtranCellFDD. qQualMin

### 11.1.2 Criteria to Conduct Measurements for Intra-Frequency Cell Reselection

Given the simplifying assumptions for idle mode in Section 11.1, measurements for cell reselection are performed as follows.

If camped on NR SA, the UE must perform intra-frequency measurements when:

SS_RSRPServingCell <= (gNB) NRCellDU. qRxLevMin + (gNB) NRFreqRelation. sIntraSearchP or SS_RSRQServingCell <= (gNB) NRCellDU. qQualMin + (gNB) NRFreqRelation. sIntraSearchQ

If camped on LTE, the UE must perform intra-frequency measurements when:

RSRPServingCell <= (eNB) EUtranCellFDD. qRxLevMin + (eNB) EUtranCellFDD.systemInformationBlock3. sIntraSearch

or alternately (if sIntraSearchv920Active = true , and the UE is Release 9 onwards) when:

RSRPServingCell <= (eNB) EUtranCellFDD. qRxLevMin + (eNB) EUtranCellFDD.systemInformationBlock3. sIntraSearchP

or

RSRQServingCell <= (eNB) EUtranCellFDD. qQualMin + (eNB) EUtranCellFDD.systemInformationBlock3. sIntraSearchQ

<!-- page: 378 -->

Note that if sIntraSearch = 1000, the UE applies the default value of infinity (always measure).

If the above conditions are not met, then the UE may choose not to perform intra-frequency measurements.

### 11.1.3 Intra-Frequency Cell Reselection

Given that idle-mode measurements are being performed (see Section 11.1.2), reselection occurs as follows.

If camped on NR SA, reselection occurs when:

SS_RSRPtarget - SS_RSRPsource > (gNB) NRCellCU. qHyst

and

SS_RSRPtarget > (gNB) NRFreqRelation. qRxLevMin

and

SS_RSRQtarget > (gNB) NRFreqRelation. qQualMin

for a time of (gNB) NRFreqRelation. tReselectionNR , (default 2 s)

Additionally, to stay on the new cell, the cell selection criteria listed in Section 11.1.1 must be satisfied.

If camped on LTE, reselection occurs when:

RSRPtarget - RSRPsource > (eNB) EUtranCellFDD.systemInformationBlock3. qHyst + (eNB) EUtranCellRelation. qOffsetCellEUtran

and

RSRPtarget > (eNB) EUtranFreqRelation. qRxLevMin

and, if the UE is capable of RSRQ based evaluation (mandatory in 3GPP Release 9),

RSRQtarget > (eNB) EUtranFreqRelation. qQualMin

for a time of (eNB) EUtranFreqRelation. tReselectionEutra , (typically 2 s).

Additionally, to stay on the new cell, the cell selection criteria listed in Section 11.1.1 must be satisfied.

<!-- page: 379 -->

### 11.1.4 Criteria to Conduct Measurements for Inter-Frequency and Inter-RAT Cell Reselection

In idle mode, the UE must always measure frequencies with higher priority than the serving frequency.

If camped on NR SA, the UE must measure frequencies with priority equal to or lower than the current frequency when:

or

If sNonIntraSearchP is empty, then the UE applies the default value of infinity, always measure.

If sNonIntraSearchQ is empty, then the UE applies the default value of 0 dB, disabling the SS_RSRQ criteria.

If the above conditions are not met, then the UE can choose not to measure equal or lower priority frequencies.

If camped on LTE, the UE must measure frequencies with priority equal to or lower than the current frequency when:

RSRPServingCell < (eNB) EUtranCellFDD. qRxLevMin + (eNB) EUtranCellFDD.systemInformationBlock3. sNonIntraSearch

Or alternately (if sNonIntraSearchv920Active = true and the UE is Release 9 onwards) when:

RSRPServingCell < (eNB) EUtranCellFDD. qRxLevMin + (eNB) EUtranCellFDD.systemInformationBlock3. sNonIntraSearchP

or

RSRQServingCell < (eNB) EUtranCellFDD. qQualMin + (eNB) EUtranCellFDD.systemInformationBlock3. sNonIntraSearchQ

If sNonIntraSearch = 1000, the UE applies the default value of infinity (always measure).

If the above conditions are not met, then the UE can choose not to measure equal or lower priority frequencies.

Frequencies can be made unavailable for reselection, as follows:

<!-- page: 380 -->

- If (eNB) EUtranFreqRelation.cellReselectionPriority = -1, then the frequency is excluded from SIB5 and IMMCI, making it unavailable for reselection.

- If (eNB) GUtranFreqRelation.cellReselectionPriority = -1 the frequency is excluded from SIB24 and IMMCI, making it unavailable for cell reselection.

- If (gNB) EUtranFreqRelation.cellReselectionPriority is set to empty or -1 and (gNB) EUtranFreqRelation.candidateForSib5 is set to false , then the frequency is excluded from SIB5 and from the dedicated priority information that can be sent to the UE at release. This makes the frequency unavailable for reselection.

- If (gNB) NRFreqRelation.cellReselectionPriority = -1, the frequency is excluded from SIB2, SIB4 and from the dedicated priorities that can be sent to the UE at release, making it unavailable for cell reselection.

### 11.1.5 Inter-Frequency Equal Priority Reselection

Given that idle-mode measurements are being performed (see Section 11.1.4), reselection occurs as follows.

If camped on NR SA, reselection to an equal priority NR frequency occurs when:

SS_RSRPtarget - SS_RSRPsource > (gNB) NRCellCU. qHyst + (gNB) NRFreqRelation. qOffsetFreq and SS_RSRPtarget > (gNB) NRFreqRelation. qRxLevMin and SS_RSRQtarget > (gNB) NRFreqRelation. qQualMin for a time of (gNB) NRFreqRelation. tReselectionNR , (default 2 s)

Additionally, to stay on the new cell, the cell selection criteria listed in Section 11.1.1 must be satisfied.

If camped on LTE, reselection to an equal priority LTE frequency occurs when:

RSRPtarget - RSRPsource > (eNB) EUtranCellFDD.systemInformationBlock3. - (eNB) EUtranFreqRelation. qOffsetFreq + (eNB) EUtranCellRelation. qOffsetCellEUtran

qHyst and RSRPtarget > (eNB) EUtranFreqRelation. qRxLevMin and, if the UE is capable of RSRQ based evaluation (mandatory in 3GPP Release 9), RSRQtarget > (eNB) EUtranFreqRelation. qQualMin for a time of (eNB) EUtranFreqRelation. tReselectionEutra , (typically 2 s)

<!-- page: 381 -->

Additionally, to stay on the new cell, the cell selection criteria listed in Section 11.1.1 must be satisfied.

Note that the criteria for equal-priority, inter -frequency cell reselection include the attribute qOffsetFreq , whereas the criteria for intra -frequency cell reselection do not.

Note also, that for reselection in NR, qOffsetFreq is added to the hysteresis but for LTE it is subtracted.

### 11.1.6 Inter-Frequency, Low to High Priority Reselection

Measurements on higher priority frequencies are always performed (see Section 11.1.4).

If camped on NR SA and (gNB) threshServingLowQ is empty (and therefore not included in system information), reselection to a higher priority NR SA frequency occurs when:

for a time of (gNB) NRFreqRelation. tReselectionNR (default 2 s) and more than one second has elapsed since the UE camped on the serving cell.

If camped on NR SA and (gNB) threshServingLowQ is not empty (and therefore included in system information), reselection to a higher priority NR SA frequency occurs when:

SS_RSRQtarget > (gNB) NRFreqRelation. qQualMin + (gNB) NRFreqRelation. threshXHighQ

for a time of (gNB) NRFreqRelation. tReselectionNR (default 2 s) and more than one second has elapsed since the UE camped on the serving cell.

If camped on LTE and (eNB) threshServingLowQ = 1000 (and is therefore not included in system information), reselection to a higher priority LTE frequency occurs when:

RSRPtarget > (eNB) EUtranFreqRelation. qRxLevMin + (eNB) EUtranFreqRelation. threshXHigh

for a time of (eNB) EUtranFreqRelation. tReselectionEUtra (default 2 s) and more than one second has elapsed since the UE camped on the serving cell.

If camped on LTE and (eNB) threshServingLowQ ≠ 1000, (and is therefore included in system information), reselection to a higher priority LTE frequency occurs when:

RSRQtarget > (eNB) EUtranFreqRelation. qQualMin + (eNB) EUtranFreqRelation. threshXHighQ

<!-- page: 382 -->

for a time of (eNB) EUtranFreqRelation. tReselectionEUtra (default 2 s) and more than one second has elapsed since the UE camped on the serving cell.

Additionally, to stay on the new cell, the cell selection criteria listed in Section 11.1.1 must be satisfied.

### 11.1.7 Inter-Frequency, High to Low Priority Reselection

Given that measurements are being performed, (see Section 11.1.4):

If camped on NR SA and (gNB) threshServingLowQ is empty (and therefore not included in system information), reselection to a lower priority NR SA frequency occurs when:

SS_RSRPsource < (gNB) NRCellDU. qRxLevMin + (gNB) NRCellCU. threshServingLowP and SS_RSRPtarget > (gNB) NRFreqRelation. qRxLevMin + (gNB) NRFreqRelation. threshXLowP

for a time of (gNB) NRFreqRelation. tReselectionNR (default 2 s) and more than one second has elapsed since the UE camped on the serving cell.

If camped on NR SA and (gNB) threshServingLowQ is not empty (and therefore included in system information), reselection to a lower priority NR SA frequency occurs when:

SS_RSRQsource < (gNB) NRCellDU. qQualMin + (gNB) NRCellCU. threshServingLowQ and SS_RSRQtarget > (gNB) NRFreqRelation. qQualMin + (gNB) NRFreqRelation. threshXLowQ

for a time of (gNB) NRFreqRelation. tReselectionNR (default 2 s) and more than one second has elapsed since the UE camped on the serving cell.

If camped on LTE and (eNB) threshServingLowQ = 1000 (and is therefore not included in system information), reselection to a lower priority LTE frequency occurs when:

RSRPsource < (eNB) EUtranCellFDD. qRxLevMin + (eNB) EUtranCellFDD. threshServingLow and RSRPtarget > (eNB) EUtranFreqRelation. qRxLevMin + (eNB) EUtranFreqRelation. threshXLow

<!-- page: 383 -->

for a time of (eNB) EUtranFreqRelation. tReselectionEUtra (default 2 s) and more than one second has elapsed since the UE camped on the serving cell.

If camped on LTE and (eNB) threshServingLowQ ≠ 1000, (and is therefore included in system information), reselection to a lower priority LTE frequency occurs when:

RSRQsource < (eNB) EUtranCellFDD. qQualMin + (eNB) EUtranCellFDD. threshServingLowQ

and

for a time of (eNB) EUtranFreqRelation. tReselectionEUtra (default 2 s) and more than one second has elapsed since the UE camped on the serving cell.

Additionally, to stay on the new cell, the cell selection criteria listed in Section 11.1.1 must be satisfied.

### 11.1.8 Inter-RAT, Low to High Priority Reselection

Measurements on higher priority frequencies are always performed (see Section 11.1.4).

If camped on NR SA and (gNB) threshServingLowQ is empty (and therefore not included in system information), reselection to a higher priority LTE frequency occurs when:

RSRPLTE_target > (gNB) EUtranFreqRelation. qRxLevMin + (gNB) EUtranFreqRelation. threshXHighP

for a time of (gNB) EUtranFreqRelation. tReselectionEUtra (default 2 s) and more than one second has elapsed since the UE camped on the serving cell.

If camped on NR SA and (gNB) threshServingLowQ is not empty (and therefore included in system information), reselection to a higher priority LTE frequency occurs when:

RSRQLTE_target > (gNB) EUtranFreqRelation. qQualMin + (gNB) EUtranFreqRelation. threshXHighQ

for a time of (gNB) EUtranFreqRelation. tReselectionEUtra (default 2 s) and more than one second has elapsed since the UE camped on the serving cell.

Note that this case is unlikely to occur, as NR SA typically has a higher cellReselectionPriority than LTE.

If camped on LTE and (eNB) threshServingLowQ = 1000 (and is therefore not included in system information), reselection to a higher priority NR SA frequency occurs when:

<!-- page: 384 -->

SS_RSRPNR_target > (eNB) GUtranFreqRelation. qRxLevMin + (eNB) GUtranFreqRelation. threshXHigh

for a time of (eNB) EUtranCellFDD.systemInformationBlock24. tReselectionNR (default 2 s) and more than one second has elapsed since the UE camped on the serving cell.

If camped on LTE and (eNB) threshServingLowQ ≠ 1000, (and is therefore included in system information), reselection to a higher priority NR SA frequency occurs when:

SS_RSRQNR_target > (eNB) GUtranFreqRelation. qQualMin + (eNB) GUtranFreqRelation. threshXHighQ

for a time of (eNB) EUtranCellFDD.systemInformationBlock24. tReselectionNR (default 2 s) and more than one second has elapsed since the UE camped on the serving cell.

Additionally, to stay on the new cell, the cell selection criteria listed in Section 11.1.1 must be satisfied.

### 11.1.9 Inter-RAT, High to Low Priority Reselection

Given that measurements are being performed (see Section 11.1.4):

If camped on NR SA and (gNB) threshServingLowQ is empty (and therefore not included in system information), reselection to a lower priority LTE frequency occurs when:

SS_RSRPNR_Serving < (gNB) NRCellDU. qRxLevMin + (gNB) NRCellCU. threshServingLowP

and

RSRPLTE_Target > (gNB) EUtranFreqRelation. qRxLevMin + (gNB) EUtranFreqRelation. threshXLowP

for a time of (gNB) EUtranFreqRelation. tReselectionEUtra (default 2 s) and more than one second has elapsed since the UE camped on the serving cell.

If camped on NR SA and (gNB) threshServingLowQ is not empty (and therefore included in system information), reselection to a lower priority LTE frequency occurs when:

SS_RSRQNR_Serving < (gNB) NRCellDU. qQualMin + (gNB) NRCellCU. threshServingLowQ

and qQualMin

RSRQLTE_Target > (gNB) EUtranFreqRelation. + (gNB) EUtranFreqRelation. threshXLowQ

<!-- page: 385 -->

for a time of (gNB) EUtranFreqRelation. tReselectionEUtra (default 2 s) and more than one second has elapsed since the UE camped on the serving cell.

If camped on LTE and (eNB) threshServingLowQ = 1000 (and is therefore not included in system information), reselection to a lower priority NR SA frequency occurs when:

RSRPLTE_Serving < (eNB) EUtranCellFDD. qRxLevMin + (eNB) EUtranCellFDD. threshServingLow

and

SS_RSRPNR_Target > (eNB) GUtranFreqRelation. qRxLevMin + (eNB) GUtranFreqRelation. threshXLow

for a time of (eNB) EUtranCellFDD.systemInformationBlock24. tReselectionNR (default 2 s) and more than one second has elapsed since the UE camped on the serving cell.

If camped on LTE and (eNB) threshServingLowQ ≠ 1000, (and is therefore included in system information), reselection to a lower priority NR SA frequency occurs when:

RSRQLTE_Serving < (eNB) EUtranCellFDD. qQualMin + (eNB) EUtranCellFDD. threshServingLowQ

and

SS_RSRQNR_Target > (eNB) GUtranFreqRelation. qQualMin + (eNB) GUtranFreqRelation. threshXLowQ

for a time of (eNB)

EUtranCellFDD.systemInformationBlock24.

tReselectionNR (default 2 s) and more than one second has elapsed since the UE camped on the serving cell.

Additionally, to stay on the new cell, the cell selection criteria listed in Section 11.1.1 must be satisfied.

## 11.2 Connected Mode

### 11.2.1 Criteria to Commence Connected Mode Measurements

UEs in connected mode are required to perform any configured measurements when the RSRP drops below sMeasure . There are two sMeasure attributes, one configured in the eNodeB and the other in the gNodeB:

- The sMeasure attribute in the eNodeB applies to all Layer 3 measurements configured by the eNodeB, including the Event B1 measurement used for detecting NR coverage. UEs are required to make these measurements when:

<!-- page: 386 -->

RSRPLTE < (eNB) UeMeasControl. sMeasure

The default value is 0 which means disabled (always measure). This is the recommended setting to use.

- The sMeasure attribute in the gNodeB applies to the Layer 3 measurements configured by the gNodeB on non-serving cells. UEs are required to make non-serving cell measurements when:

SS_RSRPNR < (gNB) UeMCCellProfile. sMeasure

Leaving sMeasure at the default value of -29 or setting it to 'empty field' or 100 0 all mean the same thing, namely always measure non-serving cells. This is the recommended setting to use, to always measure.

The UE may also measure when the RSRP or SS_RSRP exceeds sMeasure , but this is not required by the standard.

### 11.2.2 Measurement-Based Secondary Node Addition - NSA

Secondary Node Addition is either measurement-based or configuration-based. Measurement-based Secondary Node addition uses Event B1 to check for acceptable coverage. The parameters to control this measurement are configured in the eNodeB.

The trigger quantity is set by (eNB) ReportConfigB1GUtra. triggerQuantityB1 , to either SS_RSRP (recommended) or SS_RSRQ . The cell level setting can be overridden per GUtranFreqRelation with triggerQuantityB1Override .

If the trigger quantity is SS_RSRP then Event B1 is triggered when:

SS_RSRPNR > (eNB) ReportConfigB1GUtra. b1ThresholdRsrp * + (eNB) GUtranFreqRelation. b1ThrRsrpFreqOffset - (eNB) GUtranFreqRelation. qOffsetFreq ** + min((eNB) ExternalGUtranCell. b1ThrRsrpCellOffset) + (eNB) ReportConfigB1GUtra. hysteresisB1 * / 2

SS_RSRQNR > (eNB) ReportConfigB1GUtra. b1ThresholdRsrq * / 10 + (eNB) GUtranFreqRelation. b1ThrRsrqFreqOffset / 10 - (eNB) GUtranFreqRelation. qOffsetFreq ** + min((eNB) ExternalGUtranCell. b1ThrRsrqCellOffset) + (eNB) ReportConfigB1GUtra. hysteresisB1 * / 2

*** is fulfilled for: (eNB) ReportConfigB1GUtra. timeToTriggerB1 * or (eNB) GUtranFreqRelation. timeToTriggerB1Override * if this is not set to -1000 Alternately, if trigger quantity is SS_RSRQ then Event B1 is triggered when: ***

<!-- page: 387 -->

̶

is fulfilled for: (eNB) ReportConfigB1GUtra. timeToTriggerB1 * or (eNB) GUtranFreqRelation. timeToTriggerB1Override * if this is not set to -1000

*  These attributes can be overridden per subscriber group using the ASGH Framework feature as follows:

| Attribute                                                                         | Overriding Attribute for Subscriber Group UEs (Only applies if not set to the default value of -1000)   |
|-----------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------|
| ReportConfigB1GUtra.b1ThresholdRsrp                                               | EndcUserProfile.b1ThresholdRsrpOverride                                                                 |
| ReportConfigB1GUtra.b1ThresholdRsrq                                               | EndcUserProfile.b1ThresholdRsrqOverride                                                                 |
| ReportConfigB1GUtra.hysteresisB1                                                  | EndcUserProfile.hysteresisB1Override                                                                    |
| ReportConfigB1GUtra.timeToTriggerB1 or GUtranFreqRelation.timeToTriggerB1Override | EndcUserProfile.timeToTriggerB1Override                                                                 |

** This offset is used only if the feature NR Coverage-Triggered NR Session Continuity is active and UeMeasControl.nrB1MeasEnabled = true .

- *** The B1 threshold configured in the UE is determined by the minimum reported frequency. The NR cell chosen for SN addition is not necessarily the strongest

b1ThrRsrpCellOffset of all the defined ExternalGUtranCell instances on the reported cell, but rather the one with the greatest RSRP margin above the cell level B1 threshold (including any cell level offset).

### 11.2.3 Release-With-Redirect or Handover from LTE to NR SA

The functionality described in this section involves three eNodeB features:

- NR Coverage-Triggered NR Session Continuity This section assumes this feature is activated.

- Mobility Control at Poor Coverage This section assumes this feature is activated.

- Outgoing NR IRAT Handover

̶

- When Outgoing NR IRAT Handover is activated, the behavior depends on whether the UE is in good coverage or poor coverage, as follows:

- In good coverage, Outgoing NR IRAT Handover uses B1 measurements to trigger handover (or release-with-redirect) to NR SA. This case is described in Section 11.2.3.1.

- In poor coverage, the eNodeB feature Mobility Control at Poor Coverage (MCPC) uses B2 measurements to trigger handover (or release-with-redirect) to NR SA (alongside measurements for other LTE frequencies or IRAT frequencies). This case is described in Section 11.2.3.2.

- When Outgoing NR IRAT Handover is not activated, Event B1 measurements are used in the whole coverage area of the serving cell for release-with-redirect to SA. This case is described in Section 11.2.3.1.

<!-- page: 388 -->

#### 11.2.3.1 Release-With-Redirect or Handover using Event B1

If (eNB) ReportConfigB1NR. triggerQuantityB1NR = SS_RSRP then Event B1 is triggered when:

SS_RSRPNR > (eNB) ReportConfigB1NR. b1ThresholdRsrp - (eNB) GUtranFreqRelation. qOffsetFreq ** + (eNB) ReportConfigB1NR. hysteresisB1 / 2

is fulfilled for: (eNB) ReportConfigB1NR. timeToTriggerB1 or (eNB) GUtranFreqRelation. timeToTriggerNrB1B2Override *

If (eNB) ReportConfigB1NR. triggerQuantityB1NR = SS_RSRQ then Event B1 is triggered when:

SS_RSRQNR > (eNB) ReportConfigB1NR. b1ThresholdRsrq - (eNB) GUtranFreqRelation. qOffsetFreq ** + (eNB) ReportConfigB1NR. hysteresisB1 / 2

is fulfilled for: (eNB) ReportConfigB1NR. timeToTriggerB1 or (eNB) GUtranFreqRelation. timeToTriggerNrB1B2Override

/ 10 *

If (eNB) ReportConfigB1NR. triggerQuantityB1NR = SS_SINR and the UE supports SINR measurements on NR, then Event B1 is triggered when:

SS_SINRNR > (eNB) ReportConfigB1NR. b1ThresholdSinr - (eNB) GUtranFreqRelation. qOffsetFreq ** + (eNB) ReportConfigB1NR. hysteresisB1 / 2

is fulfilled for: (eNB) ReportConfigB1NR. timeToTriggerB1 or (eNB) GUtranFreqRelation. timeToTriggerNrB1B2Override

/ 10 *

If (eNB) ReportConfigB1NR. triggerQuantityB1NR = SS_SINR and the UE does not support SINR measurements on NR, then the quantity specified with UeMeasControl. fallbackTriggerQuantitySinr ( SS_RSRP or SS_RSRQ ) is used

instead.

* If GUtranFreqRelation. timeToTriggerNrB1B2Override is set to = -1000, then ReportConfigB1NR. timeToTriggerB1 is used for the frequency relation.

** Note that qOffsetFreq also impacts SN addition and EN-DC triggered handover, if the feature NR Coverage-Triggered NR Session Continuity is active and UeMeasControl.nrB1MeasEnabled is set to true .

Additional checks on the target cell can be added for the non-triggering quantities, as follows:

<!-- page: 389 -->

/ 10

| Trigger quantity   | Attribute Used to Add Checks (in UeMeasControl )   | Settable Values                               |
|--------------------|----------------------------------------------------|-----------------------------------------------|
| SS_RSRP            | bothB1NRRsrpAdditionalCheck                        | NONE RSRQ SINR_FALLBACK_RSRQ SINR_NO_FALLBACK |
| SS_RSRQ            | bothB1NRRsrqAdditionalCheck                        | NONE RSRP                                     |
| SS_SINR            | bothB1NRSinrAdditionalCheck                        | NONE RSRP RSRQ                                |

**The additional RSRP check is:**

SS_RSRPNR > (eNB) ReportConfigB1NR. b1ThresholdRsrp - (eNB) GUtranFreqRelation. qOffsetFreq ** + (eNB) ReportConfigB1NR. hysteresisB1 / 2

The additional RSRQ check is:

SS_RSRQNR > (eNB) ReportConfigB1NR. b1ThresholdRsrq - (eNB) GUtranFreqRelation. qOffsetFreq ** + (eNB) ReportConfigB1NR. hysteresisB1 / 2

The additional SINR check is:

SS_SINRNR > (eNB) ReportConfigB1NR. b1ThresholdSinr / 10 - (eNB) GUtranFreqRelation. qOffsetFreq ** + (eNB) ReportConfigB1NR. hysteresisB1 / 2

If no additional target cell checks are enabled, the B1 report is sent every 480 ms while the event remains satisfied. If additional target cell checks are enabled, this time is increased to 2048 ms.

Ericsson recommends SS_RSRP as the trigger quantity for Event B1.

#### 11.2.3.2 Release-With-Redirect or Handover using Event B2

This section assumes that the eNodeB features Outgoing NR IRAT Handover and Mobility Control at Poor Coverage (MCPC) are activated.

The section covers only the MCPC Event B2. For the parameters and trigger level formulas associated with the MCPC Event A2 and A1 measurements, which are used to start and stop the B2 measurements respectively, refer to the LTE Mobility and Traffic Management Guideline in CPI.

The trigger quantities used are as follows:

<!-- page: 390 -->

- The trigger quantity used for B2 threshold 1 (serving LTE cell measurement) is the same as the trigger quantity for the Event A2 that triggered entry into the MCPC search zone (either RSRP or RSRQ).  The attribute triggerQuantityB2 is not used when MCPC is enabled.

- The trigger quantity used for the B2 threshold 2 (candidate NR cell measurement) is set by the attribute (eNB) ReportConfigB2NR. triggerQuantityB2NR , to either SS_RSRP or SS_RSRQ.

If entry into the search zone (Event A2) is triggered by RSRP, then Event B2 is triggered when:

RSRPLTE < (eNB) ReportConfigB2NR. b2Threshold1Rsrp - (eNB) ReportConfigB2NR. hysteresisB2 / 2 - (eNB) GUtranFreqRelation. qOffsetFreq *** - (eNB) ReportConfigB2NR. mbmsB2ThresholdRsrpOffset * and, if (eNB) ReportConfigB2NR. triggerQuantityB2NR = SS_RSRP then: SS_RSRPNR > (eNB) ReportConfigB2NR. b2Threshold2Rsrp - (eNB) GUtranFreqRelation. qOffsetFreq *** + (eNB) ReportConfigB2NR. hysteresisB2 / 2 or, if (eNB) ReportConfigB2NR. triggerQuantityB2NR = SS_RSRQ then: SS_RSRQNR > (eNB) ReportConfigB2NR. b2Threshold2Rsrq / 10 - (eNB) GUtranFreqRelation. qOffsetFreq *** + (eNB) ReportConfigB2NR. hysteresisB2 / 2 + (eNB) ReportConfigB2NR . hysteresisB2RsrqOffset / 2 or, if (eNB) ReportConfigB2NR. triggerQuantityB2NR = SS_SINR and the UE supports SINR measurements on NR, then: SS_SINRNR > (eNB) ReportConfigB2NR. b2Threshold2Sinr / 10 - (eNB) GUtranFreqRelation. qOffsetFreq *** + (eNB) ReportConfigB2NR. hysteresisB2 / 2 or, if (eNB) ReportConfigB2NR. triggerQuantityB2NR = SS_SINR and the UE does not support SINR measurements on NR, then the quantity specified with UeMeasControl. fallbackTriggerQuantitySinr ( SS_RSRP or SS_RSRQ ) is used instead. are fulfilled for: (eNB) ReportConfigB2NR. timeToTriggerB2 or (eNB) GUtranFreqRelation. timeToTriggerNrB1B2Override **

Alternately, if entry into the search zone (Event A2) is triggered by RSRQ, then Event B2 measurements are started only if UeMeasControl. inhibitB2RsrqConfig = false . In this case, Event B2 is triggered when:

<!-- page: 391 -->

RSRQLTE < (eNB) ReportConfigB2NR. b2Threshold1Rsrq / 10 - (eNB) GUtranFreqRelation. qOffsetFreq *** - (eNB) ReportConfigB2NR. hysteresisB2 / 2 - (eNB) ReportConfigB2NR. mbmsB2ThresholdRsrqOffset * / 10 and, if (eNB) ReportConfigB2NR. triggerQuantityB2NR = SS_RSRP then: SS_RSRPNR > (eNB) ReportConfigB2NR. b2Threshold2Rsrp - (eNB) GUtranFreqRelation. qOffsetFreq *** + (eNB) ReportConfigB2NR. hysteresisB2 / 2 or, if (eNB) ReportConfigB2NR. triggerQuantityB2NR = SS_RSRQ then: SS_RSRQNR > (eNB) ReportConfigB2NR. b2Threshold2Rsrq / 10 - (eNB) GUtranFreqRelation. qOffsetFreq *** + (eNB) ReportConfigB2NR. hysteresisB2 / 2 + (eNB) ReportConfigB2NR . hysteresisB2RsrqOffset / 2 or, if (eNB) ReportConfigB2NR. triggerQuantityB2NR = SS_SINR and the UE supports SINR measurements on NR, then: SS_SINRNR > (eNB) ReportConfigB2NR. b2Threshold2Sinr / 10 - (eNB) GUtranFreqRelation. qOffsetFreq *** + (eNB) ReportConfigB2NR. hysteresisB2 / 2 or, if (eNB) ReportConfigB2NR. triggerQuantityB2NR = SS_SINR and the UE does not support SINR measurements on NR, then the quantity specified with UeMeasControl. fallbackTriggerQuantitySinr ( SS_RSRP or SS_RSRQ ) is used instead. are fulfilled for: (eNB) ReportConfigB2NR. timeToTriggerB2 or (eNB) GUtranFreqRelation. timeToTriggerNrB1B2Override ** * The offsets mbmsB2ThresholdRsrpOffset and mbmsB2ThresholdRsrqOffset are applied to UEs in poor LTE coverage interested in MBMS. ** If GUtranFreqRelation. timeToTriggerNrB1B2Override is set to = -1000, then ReportConfigB2NR. timeToTriggerB2 or ReportConfigB2NR. timeToTriggerB2Rsrq is used for the frequency relation. *** Note that qOffsetFreq also impacts SN addition and EN-DC triggered handover, if the feature NR Coverage-Triggered NR Session Continuity is active and UeMeasControl.nrB1MeasEnabled is set to true .

Additional checks on the target cell can be added for the non-triggering quantities, as follows:

<!-- page: 392 -->

| Trigger quantity   | Attribute Used to Add Checks (in UeMeasControl )   | Settable Values                               |
|--------------------|----------------------------------------------------|-----------------------------------------------|
| SS_RSRP            | bothB2NRRsrpAdditionalCheck                        | NONE RSRQ SINR_FALLBACK_RSRQ SINR_NO_FALLBACK |
| SS_RSRQ            | bothB2NRRsrqAdditionalCheck                        | NONE RSRP                                     |
| SS_SINR            | bothB2NRSinrAdditionalCheck                        | NONE RSRP RSRQ                                |

The additional RSRP check is:

SS_RSRPNR > (eNB) ReportConfigB2NR. b2Threshold2Rsrp

- (eNB) GUtranFreqRelation. qOffsetFreq ** + (eNB) ReportConfigB2NR. hysteresisB2 / 2

The additional RSRQ check is:

SS_RSRQNR > (eNB) ReportConfigB2NR. b2Threshold2Rsrq / 10 - (eNB) GUtranFreqRelation. qOffsetFreq ** + (eNB) ReportConfigB2NR. hysteresisB2 / 2 + (eNB) ReportConfigB2NR . hysteresisB2RsrqOffset / 2

The additional SINR check is:

SS_SINRNR > (eNB) ReportConfigB2NR. b2Threshold2Sinr / 10

- (eNB) GUtranFreqRelation. qOffsetFreq ** + (eNB) ReportConfigB2NR. hysteresisB2 / 2

If no additional target cell checks are enabled, the B2 report is sent every 480 ms while the event remains satisfied. If additional target cell checks are enabled, this time is increased to 2048 ms.

Ericsson recommends SS_RSRP as the trigger quantity for threshold2 for Event B2.

### 11.2.4 NR Intra-Frequency Mobility - NSA and SA

Intra-frequency measurements are used to find better intra-frequency NR cells, for the PSCell for NSA and for the PCell for SA. Intra-frequency SCell change is described in Section 11.2.7.3.

NR Intra-frequency mobility always uses Event A3.

If (gNB) IntraFreqMCCellProfileUeCfg. betterSpCellTriggerQuantity = RSRP then Event A3 is triggered when:

<!-- page: 393 -->

SS_RSRPtarget - SS_RSRPsource >

(gNB) IntraFreqMCCellProfileUeCfg.rsrpBetterSpCell. offset / 10 + (gNB) IntraFreqMCCellProfileUeCfg.rsrpBetterSpCell. hysteresis / 10 - (gNB) NRCellRelation. cellIndividualOffsetNR is fulfilled for: (gNB) IntraFreqMCCellProfileUeCfg.rsrpBetterSpCell. timeToTrigger Alternately, if (gNB) IntraFreqMCCellProfileUeCfg. betterSpCellTriggerQuantity = RSRQ then Event A3 is triggered when: SS_RSRQtarget - SS_RSRQsource > (gNB) IntraFreqMCCellProfileUeCfg.rsrqBetterSpCell. offset / 10 + (gNB) IntraFreqMCCellProfileUeCfg.rsrqBetterSpCell. hysteresis / 10 is fulfilled for: (gNB) IntraFreqMCCellProfileUeCfg.rsrqBetterSpCell. timeToTrigger Alternately, if (gNB) IntraFreqMCCellProfileUeCfg. betterSpCellTriggerQuantity = SINR_FALLBACK_RSRP or SINR_FALLBACK_RSRQ then Event A3 is triggered when: SS_SINRtarget - SS_SINRsource > (gNB) IntraFreqMCCellProfileUeCfg.sinrBetterSpCell. offset / 10 + (gNB) IntraFreqMCCellProfileUeCfg.sinrBetterSpCell. hysteresis / 10 is fulfilled for: (gNB) IntraFreqMCCellProfileUeCfg.sinrBetterSpCell. timeToTrigger

If the UE does not support SINR measurements, betterSpCellTriggerQuantity determines the fallback quantity, namely RSRP ( SINR_FALLBACK_RSRP ) or RSRQ ( SINR_FALLBACK_RSRQ ).

Ericsson recommends RSRP as the trigger quantity for Event A3.

### 11.2.5 Voice and Emergency Voice Call Measurement-Based Fallback to LTE

Voice fallback from NR SA to LTE is enabled by the EPS Fallback for IMS Voice feature (Section 10.3.10) and emergency voice call fallback is enabled by the NR Emergency Fallback to LTE feature (Section 10.3.12). Fallback can be either blind or measurementbased.

If it is measurement-based, the gNodeB configures the UE with a B1 measurement to detect suitable LTE coverage and an A2 measurement to detect poor NR SA coverage.

If (gNB) McfbCellProfileUeCfg. triggerQuantity = RSRP then Event B1 is triggered when:

<!-- page: 394 -->

RSRPLTE > (gNB) McfbCellProfileUeCfg.rsrpCellCandidate. threshold + (gNB) McfbCellProfileUeCfg.rsrpCellCandidate. hysteresis / 10

- (gNB) EUtranCellRelation.

cellIndividualOffset

is fulfilled for:

(gNB) McfbCellProfileUeCfg.rsrpCellCandidate. timeToTrigger and Event A2 Critical is triggered when: SS_RSRPNR < (gNB) McfbCellProfileUeCfg.rsrpCriticalCoverage. threshold - (gNB) McfbCellProfileUeCfg.rsrpCriticalCoverage. hysteresis /  10 is fulfilled for: (gNB) McfbCellProfileUeCfg.rsrpCriticalCoverage. timeToTrigger Alternately, if (gNB) McfbCellProfileUeCfg. triggerQuantity = RSRQ then Event B1 is triggered when: RSRQLTE > (gNB) McfbCellProfileUeCfg.rsrqCellCandidate. threshold / 10 + (gNB) McfbCellProfileUeCfg.rsrqCellCandidate. hysteresis / 10 is fulfilled for: (gNB) McfbCellProfileUeCfg.rsrqCellCandidate .timeToTrigger Event A2 Critical is triggered when: SS_RSRQNR < (gNB) McfbCellProfileUeCfg.rsrqCriticalCoverage. threshold / 10 - (gNB) McfbCellProfileUeCfg.rsrqCriticalCoverage. hysteresis / 10 is fulfilled for: (gNB) McfbCellProfileUeCfg.rsrqCriticalCoverage. timeToTrigger Alternately, if (gNB) McfbCellProfileUeCfg. triggerQuantity = SINR_FALLBACK_RSRP or SINR_FALLBACK_RSRQ then Event B1 is triggered when: SINRLTE > (gNB) McfbCellProfileUeCfg.sinrCellCandidate. threshold / 10 + (gNB) McfbCellProfileUeCfg.sinrCellCandidate. hysteresis / 10 is fulfilled for: (gNB) McfbCellProfileUeCfg.sinrCellCandidate .timeToTrigger triggerQuantity

If the UE does not support LTE SINR measurements, then determines the fallback quantity, RSRP ( SINR_FALLBACK_RSRP ) or RSRQ ( SINR_FALLBACK_RSRQ ).

**Event A2 Critical is triggered when:**

<!-- page: 395 -->

**SS_SINRNR <**

(gNB) McfbCellProfileUeCfg.sinrCriticalCoverage. threshold / 10 - (gNB) McfbCellProfileUeCfg.sinrCriticalCoverage. hysteresis / 10

**is fulfilled for:**

(gNB) McfbCellProfileUeCfg.sinrCriticalCoverage. timeToTrigger

If the UE does not support NR SINR measurements, then triggerQuantity determines the fallback quantity, RSRP ( SINR_FALLBACK_RSRP ) or RSRQ ( SINR_FALLBACK_RSRQ ).

Ericsson recommends RSRP as the trigger quantity for voice fallback.

### 11.2.6 EN-DC Triggered Handover - NSA

The purpose of EN-DC Triggered Handover (ENDCHO) is to move the UE to an LTE cell which is better suited to provide it with EN-DC.

ENDCHO uses B1 measurements to detect NR coverage and A5 measurements to detect LTE coverage. To trigger the handover, the UE must first report an Event B1 for the NR cell and then, within ReportConfigB1GUtra . reportIntervalB1 (default value 240 ms), an Event A5 for an LTE cell that, together with the NR cell, gives a valid frequency combination for ENDCHO.

The Event B1 is triggered according to 11.2.2.

The Event A5, is triggered as follows:

If (eNB) ReportConfigA5EndcHo. triggerQuantityA5 = RSRP , the report is triggered when:

RSRPsource < (eNB) ReportConfigA5EndcHo. a5Threshold1Rsrp - (eNB) ReportConfigA5EndcHo. hysteresisA5 / 10

and

RSRPtarget > (eNB) ReportConfigA5EndcHo. a5Threshold2Rsrp +  (eNB) ReportConfigA5EndcHo. hysteresisA5 / 10 - (eNB) EUtranFreqRelation. qOffsetFreq - (eNB) EUtranCellRelation.

cellIndividualOffsetEUtran

are fulfilled for (eNB) ReportConfigA5EndcHo. timeToTriggerA5 .

If (eNB) ReportConfigA5EndcHo. reportQuantityA5 = BOTH , then the following additional check must be satisfied for handover to occur:

RSRQtarget > (eNB) ReportConfigA5EndcHo. a5Threshold2Rsrq / 10 + (eNB) ReportConfigA5EndcHo. hysteresisA5 / 10

<!-- page: 396 -->

If (eNB) ReportConfigA5EndcHo. triggerQuantityA5 = RSRQ , the report is triggered when:

RSRQsource < (eNB) ReportConfigA5EndcHo. a5Threshold1Rsrq / 10 - (eNB) ReportConfigA5EndcHo. hysteresisA5 / 10 and RSRQtarget > (eNB) ReportConfigA5EndcHo. a5Threshold2Rsrq / 10 +  (eNB) ReportConfigA5EndcHo. hysteresisA5 / 10 - (eNB) EUtranFreqRelation. qOffsetFreq - (eNB) EUtranCellRelation. cellIndividualOffsetEUtran are fulfilled for (eNB) ReportConfigA5EndcHo. timeToTriggerA5 .

If (eNB) ReportConfigA5EndcHo. reportQuantityA5 = BOTH , then the following additional check must be satisfied for handover to occur:

RSRPtarget > (eNB) ReportConfigA5EndcHo. a5Threshold2Rsrp + (eNB) ReportConfigA5EndcHo. hysteresisA5 / 10

### 11.2.7 NR Carrier Aggregation - NSA and SA

In FR1, Event A1 is used for NR SCell activation, Event A2 for NR SCell deactivation and Event A6 for NR SCell change, for both NSA and SA.

Additionally, for SA, Event A1 and A2 are used to configure and deconfigure UL CA if configuration of CA involves a power reduction.

#### 11.2.7.1 Event A1 - SCell Activation

The SCell activation is initiated when the gNodeB receives an A1 report from the UE.

If (gNB) CaCellMeasProfileUeCfg. sCellCoverageTriggerQuantity = RSRP then Event A1 is triggered when:

SS_RSRPSCell > (gNB) CaCellMeasProfileUeCfg.rsrpSCellCoverage. threshold

+ (gNB) CaCellMeasProfileUeCfg.rsrpSCellCoverage. hysteresis / 10 + (gNB) CaFreqRelMeasProfileUeCfg. rsrpSCellCoverageThrOffset

is fulfilled for:

(gNB) CaCellMeasProfileUeCfg.rsrpSCellCoverage. timeToTrigger

If (gNB) CaCellMeasProfileUeCfg. sCellCoverageTriggerQuantity = RSRQ then Event A1 is triggered when:

SS_RSRQSCell > (gNB) CaCellMeasProfileUeCfg.rsrqSCellCoverage. threshold + (gNB) CaCellMeasProfileUeCfg.rsrqSCellCoverage. hysteresis / 10 + (gNB) CaFreqRelMeasProfileUeCfg. rsrqSCellCoverageThrOffset /10

/ 10

<!-- page: 397 -->

**is fulfilled for:**

(gNB) CaCellMeasProfileUeCfg.rsrqSCellCoverage. timeToTrigger

If (gNB) CaCellMeasProfileUeCfg. sCellCoverageTriggerQuantity = SINR_FALLBACK_RSRP or SINR_FALLBACK_RSRQ then Event A1 is triggered when:

SS_SINRSCell > (gNB) CaCellMeasProfileUeCfg.sinrSCellCoverage. threshold / 10 + (gNB) CaCellMeasProfileUeCfg.sinrSCellCoverage. hysteresis / 10 + (gNB) CaFreqRelMeasProfileUeCfg. sinrSCellCoverageThrOffset /10

**is fulfilled for:**

(gNB) CaCellMeasProfileUeCfg.sinrSCellCoverage. timeToTrigger

**If the UE does not support NR SINR measurements, then**

sCellCoverageTriggerQuantity determines the fallback trigger quantity, namely RSRP for SINR_FALLBACK_RSRP or RSRQ for SINR_FALLBACK_RSRQ .

#### 11.2.7.2 Event A2 - SCell Deactivation

The SCell deactivation is initiated when the SN receives an A2 report from the UE.

If (gNB) CaCellMeasProfileUeCfg. sCellCoverageTriggerQuantity = RSRP then Event A2 is triggered when:

- SS_RSRPSCell < (gNB) CaCellMeasProfileUeCfg.rsrpSCellCoverage. threshold - (gNB) CaCellMeasProfileUeCfg.rsrpSCellCoverage. hysteresis / 10

- (gNB) CaFreqRelMeasProfileUeCfg. rsrpSCellCoverageThrOffset

is fulfilled for:

(gNB) CaCellMeasProfileUeCfg.rsrpSCellCoverage. timeToTrigger

If (gNB) CaCellMeasProfileUeCfg. sCellCoverageTriggerQuantity = RSRQ then Event A2 is triggered when:

- SS_RSRQSCell < (gNB) CaCellMeasProfileUeCfg.rsrqSCellCoverage. threshold / 10 - (gNB) CaCellMeasProfileUeCfg.rsrqSCellCoverage. hysteresis / 10 + (gNB) CaFreqRelMeasProfileUeCfg. rsrqSCellCoverageThrOffset /10

**is fulfilled for:**

(gNB) CaCellMeasProfileUeCfg.rsrqSCellCoverage. timeToTrigger

If (gNB) CaCellMeasProfileUeCfg. sCellCoverageTriggerQuantity = SINR_FALLBACK_RSRP or SINR_FALLBACK_RSRQ then Event A2 is triggered when:

- SS_SINRSCell < (gNB) CaCellMeasProfileUeCfg.sinrSCellCoverage. threshold / 10 - (gNB) CaCellMeasProfileUeCfg.sinrSCellCoverage. hysteresis / 10 + (gNB) CaFreqRelMeasProfileUeCfg. sinrSCellCoverageThrOffset /10

**is fulfilled for:**

(gNB) CaCellMeasProfileUeCfg.sinrSCellCoverage. timeToTrigger

<!-- page: 398 -->

**If the UE does not support NR SINR measurements, then**

sCellCoverageTriggerQuantity determines the fallback trigger quantity, namely RSRP for SINR_FALLBACK_RSRP or RSRQ for SINR_FALLBACK_RSRQ .

#### 11.2.7.3 Event A6 - SCell Change

Event A6 measurements are used to trigger intra-frequency SCell change. They are activated when betterSCellReportConfigMode = ALWAYS , or when betterSCellReportConfigMode = CONDITIONAL and there is more than one SCell candidate on the frequency.

The parameters to control this event are configured in the gNodeB.

If CaCellMeasProfileUeCfg.betterSCellTriggerQuantity = RSRP then the A6 event is triggered when:

SS_RSRPtargetSCell - SS_RSRPsourceSCell > (gNB) CaCellMeasProfileUeCfg.rsrpBetterSCell. offset / 10

- (gNB) CaCellMeasProfileUeCfg.rsrpBetterSCell. hysteresis / 10

- (gNB) NRCellRelation . cellIndividualOffsetNR

is fulfilled for:

(gNB) CaCellMeasProfileUeCfg.rsrpBetterSCell. timeToTrigger

If CaCellMeasProfileUeCfg.betterSCellTriggerQuantity = RSRQ then the A6 event is triggered when:

SS_RSRQtargetSCell - SS_RSRQsourceSCell > (gNB) CaCellMeasProfileUeCfg.rsrqBetterSCell. offset / 10 + (gNB) CaCellMeasProfileUeCfg.rsrqBetterSCell. hysteresis / 10

is fulfilled for:

(gNB) CaCellMeasProfileUeCfg.rsrqBetterSCell. timeToTrigger

If CaCellMeasProfileUeCfg.betterSCellTriggerQuantity = SINR then the A6 event is triggered when:

SS_SINRtargetSCell - SS_SINRsourceSCell > (gNB) CaCellMeasProfileUeCfg.sinrBetterSCell. offset / 10 + (gNB) CaCellMeasProfileUeCfg.sinrBetterSCell. hysteresis / 10

is fulfilled for:

(gNB) CaCellMeasProfileUeCfg.sinrBetterSCell. timeToTrigger

In addition, to trigger the SCell change, the target cell must satisfy the A1 threshold for SCell activation, as described in Section 11.2.7.1.

<!-- page: 399 -->

#### 11.2.7.4 Event A1 - UL PCell Power Reduction

This Event A1 (CA A1PR) is used to confirm that PCell coverage is good enough to configure uplink CA, in those cases where the configuration will cause a reduction in the maximum UE transmit power.

In the current release, the trigger level for this A1 event is derived using attributes that are also used for traffic steering.

**SS_RSRPPCell >**

(gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . threshold2

- (gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . hysteresis / 10

- (gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidatePCOffset[x] . threshold2Offset

+ (gNB) TrStSaNrFreqRelProfileUeCfg . rsrpPCellCandidateOffset

**is fulfilled for:**

(gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . timeToTrigger

where the index [x] is selected according to the UE power class, for high power UEs.

In the above formulas, the TrStSaNrFreqRelProfileUeCfg instance used is the one to corresponding to the PCell frequency.

#### 11.2.7.5 Event A2 - UL PCell Power Reduction

This Event A2 (CA A2PR) is used to detect poor PCell coverage and deconfigure uplink CA, in those cases where the CA configuration caused a reduced maximum UE transmit power.

In the current release, the trigger level for this A2 event is derived using attributes that are also used for traffic steering.

SS_RSRPPCell < (gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . threshold2 - (gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . hysteresis / 10

- (gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidatePCOffset[x] . threshold2Offset

- (gNB) TrStSaNrFreqRelProfileUeCfg . rsrpPCellCandidateOffset

**is fulfilled for:**

(gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . timeToTrigger

where the index [x] is selected according to the UE power class, for high power UEs.

In the above formulas, the TrStSaNrFreqRelProfileUeCfg instance used is the one to corresponding to the PCell frequency.

### 11.2.8 Mobility Control at Poor Coverage - SA

If MCPC is enabled for SA ( NRCellCU. mcpcPCellEnabled = true ), then the following functionality applies.

<!-- page: 400 -->

#### 11.2.8.1 Event A1 - Leaving Search Zone

The Event A1 Leaving Search Zone occurs when the UE leaves the search zone (poor PCell coverage) and enters good PCell coverage. It is triggered independently per enabled measurement quantity (RSRP, RSRQ, SINR or UL_SINR).

For RSRP, it is triggered when:

SS_RSRPNR > (gNB) McpcPCellProfileUeCfg.rsrpSearchZone. threshold + (gNB) McpcPCellProfileUeCfg.rsrpSearchZonePcOffset[x]. thresholdOffset + (gNB) McpcPCellProfileUeCfg.rsrpSearchZone. hysteresis / 10

**is fulfilled for:**

(gNB) McpcPCellProfileUeCfg.rsrpSearchZone .timeToTrigger

or alternately for:

(gNB) McpcPCellProfileUeCfg.rsrpSearchZone. timeToTriggerA1

if timeToTriggerA1 is not set to -1

where the index [x] is selected according to the UE power class, for high power UEs.

To obtain the corresponding trigger level formulas for RSRQ and SINR, replace 'rsrp' with 'rsrq' or 'sinr' in the struct attribute names. Additionally, note the following:

- rsrpSearchZonePcOffset does not have RSRQ or SINR equivalents, so omit this term

- Check the unit of each attribute. When it is dB, no divisor is needed. When it is 0.1 dB, a divisor of 10 is needed (i.e. 'attribute / 10')

For UL_SINR, the event is triggered when:

UL_SINRNR > (gNB) UlQualMcpcMeasCfg.ulQualSearchZone. threshold / 10 + (gNB) UlQualMcpcMeasCfg.ulQualSearchZone. hysteresis / 10

**is fulfilled for:**

(gNB) UlQualMcpcMeasCfg.ulQualSearchZone. timeToTrigger

or alternately for:

(gNB) UlQualMcpcMeasCfg.ulQualSearchZone. timeToTriggerA1

if timeToTriggerA1 is not set to -1.

<!-- page: 401 -->

#### 11.2.8.2 Event A2 - Entering Search Zone

The Event A2 Entering Search Zone occurs when the UE leaves good PCell coverage and enters the search zone (poor PCell coverage). It is triggered independently per enabled measurement quantity (RSRP, RSRQ, SINR or UL_SINR).

For RSRP, it is triggered when:

SS_RSRPNR < (gNB) McpcPCellProfileUeCfg.rsrpSearchZone. threshold + (gNB) McpcPCellProfileUeCfg.rsrpSearchZonePcOffset[x]. thresholdOffset - (gNB) McpcPCellProfileUeCfg.rsrpSearchZone. hysteresis / 10

is fulfilled for:

(gNB) McpcPCellProfileUeCfg.rsrpSearchZone .timeToTrigger

where the index [x] is selected according to the UE power class, for high power UEs.

To obtain the corresponding trigger level formulas for RSRQ and SINR, replace 'rsrp' with 'rsrq' or 'sinr' in the struct attribute names. Additionally, note the following:

- rsrpSearchZonePcOffset does not have RSRQ or SINR equivalents, so omit this term

- Check the unit of each attribute. When it is dB, no divisor is needed. When it is 0.1 dB, a divisor of 10 is needed (i.e. 'attribute / 10')

For UL_SINR, the event is triggered when:

UL_SINRNR < (gNB) UlQualMcpcMeasCfg.ulQualSearchZone. threshold / 10 - (gNB) UlQualMcpcMeasCfg.ulQualSearchZone. hysteresis / 10

is fulfilled for:

(gNB) UlQualMcpcMeasCfg.ulQualSearchZone. timeToTrigger

#### 11.2.8.3 Event A2 - Critical Coverage

The Event A2 Critical Coverage occurs when the UE enters critical PCell coverage.

This event is enabled per measurement quantity (RSRP, RSRQ, SINR or UL_SINR) by setting the corresponding (gNB) McpcPCellProfileUeCfg attribute to true ( rsrpCriticalEnabled , rsrqCriticalEnabled , sinrCriticalEnabled and/or ulQualCriticalEnabled respectively).

It is triggered independently per measurement quantity.

For RSRP, it is triggered when:

<!-- page: 402 -->

SS_RSRPNR < (gNB) McpcPCellProfileUeCfg.rsrpCritical. threshold + (gNB) McpcPCellProfileUeCfg.rsrpCriticalPcOffset[x]. thresholdOffset - (gNB) McpcPCellProfileUeCfg.rsrpCritical. hysteresis / 10

is fulfilled for:

(gNB) McpcPCellProfileUeCfg.rsrpCritical. timeToTrigger

where the index [x] is selected according to the UE power class, for high power UEs.

To obtain the corresponding trigger level formulas for RSRQ and SINR, replace 'rsrp' with 'rsrq' or 'sinr' in the struct attribute names. Additionally, note the following:

- rsrpCriticalPcOffset does not have RSRQ or SINR equivalents, so omit this term

- Check the unit of each attribute. When it is dB, no divisor is needed. When it is 0.1 dB, a divisor of 10 is needed (i.e. 'attribute / 10')

For UL_SINR, the event is triggered when:

UL_SINRNR < (gNB) UlQualMcpcMeasCfg.ulQualCritical. threshold / 10 - (gNB) UlQualMcpcMeasCfg.ulQualCritical. hysteresis / 10

is fulfilled for:

(gNB) UlQualMcpcMeasCfg.ulQualCritical. timeToTrigger

#### 11.2.8.4 Event A5 - Inter-Frequency Candidate

MCPC uses Event A5 to search for inter-frequency NR PCell candidates when:

- McpcPCellNrFreqRelProfileUeCfg.interFreqMeasType = EVENT_A5 , or

- Entry into the search zone is triggered by UL_SINR

If RSRP triggered entry into the search zone, then A5 is triggered when:

- SS_RSRPsource < (gNB) McpcPCellProfileUeCfg.rsrpCandidateA5. threshold1 + (gNB) McpcPCellProfileUeCfg.rsrpCandidateA5PcOffset[x]. threshold1Offset - (gNB) McpcPCellProfileUeCfg.rsrpCandidateA5. hysteresis / 10 + (gNB) McpcPCellNrFreqRelProfileUeCfg.rsrpCandidateA5Offsets .

threshold1Offset

and

SS_RSRPtarget > (gNB) McpcPCellProfileUeCfg.rsrpCandidateA5 .threshold2 + (gNB) McpcPCellProfileUeCfg.rsrpCandidateA5PcOffset[x].

threshold2Offset + (gNB) McpcPCellProfileUeCfg.rsrpCandidateA5 .hysteresis / 10 + (gNB) McpcPCellNrFreqRelProfileUeCfg.rsrpCandidateA5Offsets . threshold2Offset

- (gNB) NRCellRelation. cellIndividualOffsetNR

<!-- page: 403 -->

**are fulfilled for:**

(gNB) McpcPCellProfileUeCfg.rsrpCandidateA5 .timeToTrigger where the index [x] is selected according to the UE power class, for high power UEs. If RSRQ triggered entry into the search zone, then A5 is triggered when: SS_RSRQsource < (gNB) McpcPCellProfileUeCfg.rsrqCandidateA5. threshold1 / 10 - (gNB) McpcPCellProfileUeCfg.rsrqCandidateA5. hysteresis / 10 + (gNB) McpcPCellNrFreqRelProfileUeCfg.rsrqCandidateA5Offsets . threshold1Offset / 10 and SS_RSRQtarget > (gNB) McpcPCellProfileUeCfg.rsrqCandidateA5 .threshold2 /10 + (gNB) McpcPCellProfileUeCfg.rsrqCandidateA5 .hysteresis /10 + (gNB) McpcPCellNrFreqRelProfileUeCfg.rsrqCandidateA5Offsets . threshold2Offset /10 are fulfilled for: (gNB) McpcPCellProfileUeCfg.rsrqCandidateA5 .timeToTrigger If SINR triggered entry into the search zone, then A5 is triggered when: SS_SINRsource < (gNB) McpcPCellProfileUeCfg.sinrCandidateA5. threshold1 / 10 - (gNB) McpcPCellProfileUeCfg.sinrCandidateA5. hysteresis / 10 + (gNB) McpcPCellNrFreqRelProfileUeCfg.sinrCandidateA5Offsets . threshold1Offset / 10 and SS_SINRtarget > (gNB) McpcPCellProfileUeCfg.sinrCandidateA5 .threshold2 /10 + (gNB) McpcPCellProfileUeCfg.sinrCandidateA5 .hysteresis /10 + (gNB) McpcPCellNrFreqRelProfileUeCfg.sinrCandidateA5Offsets . threshold2Offset /10 are fulfilled for: (gNB) McpcPCellProfileUeCfg.sinrCandidateA5 .timeToTrigger If UL_SINR triggered entry into the search zone, then A5 is triggered when: SS_RSRPtarget > (gNB) McpcPCellProfileUeCfg.rsrpCandidateA5 .threshold2 + (gNB) McpcPCellProfileUeCfg.rsrpCandidateA5PcOffset[x]. threshold2Offset + (gNB) McpcPCellProfileUeCfg.rsrpCandidateA5 .hysteresis / 10 + (gNB) McpcPCellNrFreqRelProfileUeCfg.rsrpCandidateA5Offsets . threshold2Offset - (gNB) NRCellRelation. cellIndividualOffsetNR are fulfilled for: (gNB) McpcPCellProfileUeCfg.rsrpCandidateA5 .timeToTrigger

<!-- page: 404 -->

where the index [x] is selected according to the UE power class, for high power UEs.

Note that A5 threshold1 is set to -29 (infinity), so it is always satisfied.

If no additional target cell checks are enabled, the A5 report is sent every 480 ms while the event remains satisfied. If additional target cell checks are enabled, this time is increased to 2048 ms. The report amount is infinity.

Additional checks on the target cell can be added for the non-triggering quantities, as follows:

| A5 Trigger   | Attribute Used to Add Checks (in McpcPCellProfileUeCfg )   | Settable Values                                    |
|--------------|------------------------------------------------------------|----------------------------------------------------|
| RSRP         | rsrpCandidateA5AddTargEval                                 | NONE RSRQ SINR_FALLBACK_RSRQ SINR_NO_FALLBACK_RSRQ |
| RSRQ         | rsrqCandidateA5AddTargEval                                 | NONE RSRP                                          |
| SINR         | sinrCandidateA5AddTargEval                                 | NONE RSRP RSRQ RSRP_AND_RSRQ                       |

**The additional RSRP check is:**

SS_RSRPtarget > (gNB) McpcPCellProfileUeCfg.rsrpCandidateA5 .threshold2 +

(gNB) McpcPCellProfileUeCfg.rsrpCandidateA5PcOffset[x]. threshold2Offset

+ (gNB) McpcPCellProfileUeCfg.rsrpCandidateA5 .hysteresis / 10

+ (gNB) McpcPCellNrFreqRelProfileUeCfg.rsrpCandidateA5Offsets .

**threshold2Offset**

- (gNB) NRCellRelation. cellIndividualOffsetNR

where the index [x] is selected according to the UE power class, for high power UEs.

**The additional RSRQ check is:**

SS_RSRQtarget > (gNB) McpcPCellProfileUeCfg.rsrqCandidateA5 .threshold2 /10

+ (gNB) McpcPCellProfileUeCfg.rsrqCandidateA5 .hysteresis

+ (gNB) McpcPCellNrFreqRelProfileUeCfg.rsrqCandidateA5Offsets

threshold2Offset /10

**The additional SINR check is:**

SS_SINRtarget > (gNB) McpcPCellProfileUeCfg.sinrCandidateA5 .threshold2 /10 + (gNB) McpcPCellProfileUeCfg.sinrCandidateA5 .hysteresis /10 + (gNB) McpcPCellNrFreqRelProfileUeCfg.sinrCandidateA5Offsets . threshold2Offset /10

/10 .

<!-- page: 405 -->

Furthermore, if UL_SINR triggers entry into the search zone, and the source node has ExternalGNBCUCPFunction.ulTrigHoAllowed = false , and the target node has uplink triggered mobility enabled and

UeMCCellProfileUeCfg . checkUlQualityIncomingHo = true , then handover preparation includes a check of the estimated uplink quality on the target cell. The estimate is based on the target cell RSRP in the A5 report, which is forwarded to the target gNodeB in the Handover Request message. If the estimated quality is greater than or equal to UeMCCellProfileUeCfg.ulQualityThreshIncomingHo or if the RSRP value is not available, then the handover is accepted, otherwise the handover preparation is rejected.

#### 11.2.8.5 Event A3 - Inter-Frequency Candidate

MCPC uses Event A3 to search for inter-frequency NR PCell candidates when McpcPCellNrFreqRelProfileUeCfg.interFreqMeasType = EVENT_A3 and entry into the search zone is triggered by RSRP, RSRQ or SINR.

If entry into the search zone is triggered by UL_SINR, then MCPC always uses Event A5 RSRP; see Section 11.2.8.4.

If RSRP triggered entry into the search zone, then A3 is triggered when:

SS_RSRPtarget - SS_RSRPsource > (gNB) McpcPCellProfileUeCfg.rsrpCandidateA3. offset / 10 + (gNB) McpcPCellProfileUeCfg.rsrpCandidateA3. hysteresis / 10 + (gNB) McpcPCellNrFreqRelProfileUeCfg . rsrpCandidateA3Adjustment / 10 - (gNB) NRCellRelation. cellIndividualOffsetNR

is fulfilled for: (gNB) McpcPCellProfileUeCfg . rsrpCandidateA3 . timeToTrigger

If RSRQ triggered entry into the search zone, then A3 is triggered when:

SS_RSRQtarget - SS_RSRQsource > (gNB) McpcPCellProfileUeCfg.rsrqCandidateA3. offset / 10 + (gNB) McpcPCellProfileUeCfg.rsrqCandidateA3. hysteresis / 10 + (gNB) McpcPCellNrFreqRelProfileUeCfg . rsrqCandidateA3Adjustment / 10

is fulfilled for: (gNB) McpcPCellProfileUeCfg . rsrqCandidateA3 . timeToTrigger

If SINR triggered entry into the search zone, then A3 is triggered when:

SS_SINRtarget - SS_SINRsource > (gNB) McpcPCellProfileUeCfg.sinrCandidateA3. offset / 10 + (gNB) McpcPCellProfileUeCfg.sinrCandidateA3. hysteresis / 10 + (gNB) McpcPCellNrFreqRelProfileUeCfg . sinrCandidateA3Adjustment / 10

is fulfilled for: (gNB) McpcPCellProfileUeCfg . sinrCandidateA3 . timeToTrigger

If no additional target cell checks are enabled, the A3 report is sent every 480 ms while the event remains satisfied. If additional target cell checks are enabled, this time is increased to 2048 ms. The report amount is infinity.

<!-- page: 406 -->

Additional checks on the target cell can be added for the non-triggering quantities, as follows:

| A5 Trigger   | Attribute Used to Add Checks (in McpcPCellProfileUeCfg )   | Settable Values                                    |
|--------------|------------------------------------------------------------|----------------------------------------------------|
| RSRP         | rsrpCandidateA3AddTargEval                                 | NONE RSRQ SINR_FALLBACK_RSRQ SINR_NO_FALLBACK_RSRQ |
| RSRQ         | rsrqCandidateA3AddTargEval                                 | NONE RSRP                                          |
| SINR         | sinrCandidateA3AddTargEval                                 | NONE RSRP RSRQ RSRP_AND_RSRQ                       |

**The additional RSRP check is:**

SS_RSRPtarget > SS_RSRPsource +

(gNB) McpcPCellProfileUeCfg.rsrpCandidateA3. offset / 10

- (gNB) McpcPCellProfileUeCfg.rsrpCandidateA3. hysteresis / 10

- (gNB) McpcPCellNrFreqRelProfileUeCfg . rsrpCandidateA3Adjustment / 10

- (gNB) NRCellRelation. cellIndividualOffsetNR

**The additional RSRQ check is:**

- SS_RSRQtarget > SS_RSRQsource + (gNB) McpcPCellProfileUeCfg.rsrqCandidateA3. offset / 10 + (gNB) McpcPCellProfileUeCfg.rsrqCandidateA3. hysteresis / 10

- (gNB) McpcPCellNrFreqRelProfileUeCfg. rsrqCandidateA3Adjustment / 10

**The additional SINR check is:**

SS_SINRtarget > SS_SINRsource + (gNB) McpcPCellProfileUeCfg . sinrCandidateA3 . offset / 10 + (gNB) McpcPCellProfileUeCfg . sinrCandidateA3 . hysteresis / 10 + (gNB) McpcPCellNrFreqRelProfileUeCfg. sinrCandidateA3Adjustment

- / 10

#### 11.2.8.6 Event B2 - EUTRAN Candidate

The Event B2 EUTRAN Candidate is triggered when a suitable inter-RAT LTE cell candidate is found.

If RSRP triggered entry into the search zone, then B2 is triggered when:

- SS_RSRPNR < (gNB) McpcPCellProfileUeCfg.rsrpCandidateB2. threshold1 + (gNB) McpcPCellProfileUeCfg.rsrpCandidateB2PcOffset[x]. threshold1Offset - (gNB) McpcPCellProfileUeCfg.rsrpCandidateB2. hysteresis / 10 + (gNB) McpcPCellEUtranFreqRelProfileUeCfg.rsrpCandidateB2Offsets .

- threshold1Offset

<!-- page: 407 -->

**and**

RSRPLTE > (gNB) McpcPCellProfileUeCfg.rsrpCandidateB2 .threshold2EUtra + (gNB) McpcPCellProfileUeCfg.rsrpCandidateB2 .hysteresis / 10 + (gNB) McpcPCellEUtranFreqRelProfileUeCfg.rsrpCandidateB2Offsets . threshold2EUtraOffset - (gNB) EUtranCellRelation. cellIndividualOffset

are fulfilled for: (gNB) McpcPCellProfileUeCfg.rsrpCandidateB2 .timeToTrigger where the index [x] is selected according to the UE power class, for high power UEs. If RSRQ triggered entry into the search zone, then B2 is triggered when: SS_RSRQNR < (gNB) McpcPCellProfileUeCfg.rsrqCandidateB2. threshold1 / 10 - (gNB) McpcPCellProfileUeCfg.rsrqCandidateB2. hysteresis / 10 + (gNB) McpcPCellEUtranFreqRelProfileUeCfg.rsrqCandidateB2Offsets . threshold1Offset / 10 and RSRQLTE > (gNB) McpcPCellProfileUeCfg.rsrqCandidateB2 .threshold2EUtra / 10 + (gNB) McpcPCellProfileUeCfg.rsrqCandidateB2 .hysteresis / 10 + (gNB) McpcPCellNrFreqRelProfileUeCfg.rsrqCandidateB2Offsets . threshold2EUtraOffset / 10 are fulfilled for: (gNB) McpcPCellProfileUeCfg.rsrqCandidateB2 .timeToTrigger If SINR triggered entry into the search zone, and the UE is capable of SINR measurements on LTE, then B2 is triggered when: SS_SINRNR < (gNB) McpcPCellProfileUeCfg.sinrCandidateB2. threshold1 / 10 - (gNB) McpcPCellProfileUeCfg.sinrCandidateB2. hysteresis / 10 + (gNB) McpcPCellEUtranFreqRelProfileUeCfg.sinrCandidateB2Offsets . threshold1Offset / 10 and SINRLTE > (gNB) McpcPCellProfileUeCfg.sinrCandidateB2 .threshold2EUtra /10 + (gNB) McpcPCellProfileUeCfg.sinrCandidateB2 .hysteresis /10 + (gNB) McpcPCellNrFreqRelProfileUeCfg.sinrCandidateB2Offsets . threshold2EUtraOffset /10 are fulfilled for: (gNB) McpcPCellProfileUeCfg.sinrCandidateB2 .timeToTrigger If the UE is not capable of SINR measurements on LTE, then B2 uses RSRP for both the threshold 1 and 2 measurements, with threshold 1 set to -29 dBm.

<!-- page: 408 -->

**If UL_SINR triggered entry into the search zone, then B2 is triggered when:**

RSRPLTE > (gNB) McpcPCellProfileUeCfg.rsrpCandidateB2 .threshold2EUtra

- (gNB) McpcPCellProfileUeCfg.rsrpCandidateB2 .hysteresis / 10 + (gNB) McpcPCellEUtranFreqRelProfileUeCfg.rsrpCandidateB2Offsets . threshold2EUtraOffset

- (gNB) EUtranCellRelation. cellIndividualOffset

**are fulfilled for:**

(gNB) McpcPCellProfileUeCfg.rsrpCandidateB2 .timeToTrigger

Note that B2 threshold1 is set to -29 (infinity), so it is always satisfied.

If no additional target cell checks are enabled, the B2 report is sent every 480 ms while the event remains satisfied. If additional target cell checks are enabled, this time is increased to 2048 ms. The report amount is 4.

Furthermore, additional checks on the target cell can be added for the non-triggering quantities, as follows:

| B2 Trigger   | Attribute Used to Add Checks (in McpcPCellProfileUeCfg )   | Settable Values                                    |
|--------------|------------------------------------------------------------|----------------------------------------------------|
| RSRP         | rsrpCandidateB2AddTargEval                                 | NONE RSRQ SINR_FALLBACK_RSRQ SINR_NO_FALLBACK_RSRQ |
| RSRQ         | rsrqCandidateB2AddTargEval                                 | NONE RSRP                                          |
| SINR         | sinrCandidateB2AddTargEval                                 | NONE RSRP RSRQ RSRP_AND_RSRQ                       |

**The additional RSRP check is:**

RSRPLTE > (gNB) McpcPCellProfileUeCfg.rsrpCandidateB2 .threshold2EUtra

- (gNB) McpcPCellProfileUeCfg.rsrpCandidateB2 .hysteresis / 10

- (gNB) McpcPCellEUtranFreqRelProfileUeCfg.rsrpCandidateB2Offsets .

threshold2EUtraOffset

- (gNB) EUtranCellRelation. cellIndividualOffset

**The additional RSRQ check is:**

RSRQLTE > (gNB) McpcPCellProfileUeCfg.rsrqCandidateB2 .threshold2EUtra /10

- (gNB) McpcPCellProfileUeCfg.rsrqCandidateB2 .hysteresis /10

- (gNB) McpcPCellNrFreqRelProfileUeCfg.rsrqCandidateB2Offsets .

threshold2EUtraOffset /10

**The additional SINR check is:**

<!-- page: 409 -->

SINRLTE > (gNB) McpcPCellProfileUeCfg.sinrCandidateB2 .threshold2EUtra + (gNB) McpcPCellProfileUeCfg.sinrCandidateB2 .hysteresis /10 + (gNB) McpcPCellNrFreqRelProfileUeCfg.sinrCandidateB2Offsets . threshold2EUtraOffset /10

### 11.2.9 Mobility Control at Poor Coverage - NSA

If MCPC is enabled for NSA ( NRCellCU. mcpcPSCellEnabled = true ), then the following functionality applies.

#### 11.2.9.1 Event A1 - Leaving Search Zone

The Event A1 Leaving Search Zone is triggered when the UE leaves the search zone (poor PSCell coverage) and enters good PSCell coverage for the quantity used. It is triggered independently per enabled measurement quantity (RSRP, RSRQ and/or SINR).

For RSRP, it is triggered when:

SS_RSRPNR > (gNB) McpcPSCellProfileUeCfg.rsrpSearchZone. threshold + (gNB) McpcPSCellProfileUeCfg.rsrpSearchZone. hysteresis / 10

is fulfilled for: (gNB) McpcPSCellProfileUeCfg.rsrpSearchZone .timeToTrigger or alternately for: (gNB) McpcPSCellProfileUeCfg.rsrpSearchZone. timeToTriggerA1 if timeToTriggerA1 is not set to -1

To obtain the corresponding trigger level formulas for RSRQ and SINR, replace 'rsrp' with 'rsrq' or 'sinr' in the struct attribute names. Additionally, check the unit of each attribute. When it is dB, no divisor is needed. When it is 0.1 dB, a divisor of 10 is needed (i.e. 'attribute / 10') .

#### 11.2.9.2 Event A2 - Entering Search Zone

The Event A2 Entering Search Zone is triggered when the UE leaves good PSCell coverage and enters the search zone (poor PSCell coverage) for the quantity used. It is triggered independently per enabled measurement quantity (RSRP, RSRQ and/or SINR).

For RSRP, it is triggered when:

SS_RSRPNR < (gNB) McpcPSCellProfileUeCfg.rsrpSearchZone. threshold - (gNB) McpcPSCellProfileUeCfg.rsrpSearchZone. hysteresis / 10

is fulfilled for:

/10

<!-- page: 410 -->

(gNB) McpcPSCellProfileUeCfg.rsrpSearchZone .timeToTrigger

To obtain the corresponding trigger level formulas for RSRQ and SINR, replace 'rsrp' with 'rsrq' or 'sinr' in the struct attribute names. Additionally, check the unit of each attribute. When it is dB, no divisor is needed. When it is 0.1 dB, a divisor of 10 is needed (i.e. 'attribute / 10').

#### 11.2.9.3 Event A2 - Critical Coverage

The Event A2 Critical Coverage is triggered when the UE enters critical PSCell coverage.

This event is enabled per measurement quantity (RSRP, RSRQ or SINR) by setting the corresponding (gNB) McpcPSCellProfileUeCfg attribute to true ( rsrpCriticalEnabled , rsrqCriticalEnabled and/or sinrCriticalEnabled respectively).

It is triggered independently per measurement quantity.

For RSRP, it is triggered when:

SS_RSRPNR < (gNB) McpcPSCellProfileUeCfg.rsrpCritical. threshold - (gNB) McpcPSCellProfileUeCfg.rsrpCritical. hysteresis / 10 is fulfilled for: (gNB) McpcPSCellProfileUeCfg.rsrpCritical. timeToTrigger

To obtain the corresponding trigger level formulas for RSRQ and SINR, replace 'rsrp' with 'rsrq' or 'sinr' in the struct attribute names. Additionally, check the unit of each attribute. When it is dB, no divisor is needed. When it is 0.1 dB, a divisor of 10 is needed (i.e. 'attribute / 10').

#### 11.2.9.4 Event A5 - Inter-Frequency Candidate

The Event A5 Inter-Frequency Candidate is triggered when a suitable inter-frequency NR PSCell candidate is found. It uses the same measurement quantity as the A2 event that triggered entry to the search zone.

If RSRP triggered entry into the search zone, then A5 is triggered when:

SS_RSRPsource < (gNB) McpcPSCellProfileUeCfg.rsrpCandidateA5. threshold1 - (gNB) McpcPSCellProfileUeCfg.rsrpCandidateA5. hysteresis / 10 + (gNB) McpcPSCellNrFreqRelProfileUeCfg.rsrpCandidateA5Offsets

. threshold1Offset and

<!-- page: 411 -->

**SS_RSRPtarget >**

(gNB) McpcPSCellProfileUeCfg.rsrpCandidateA5 .threshold2

+ (gNB) McpcPSCellProfileUeCfg.rsrpCandidateA5 .hysteresis / 10 + (gNB) McpcPSCellNrFreqRelProfileUeCfg.rsrpCandidateA5Offsets . threshold2Offset - (gNB) NRCellRelation. cellIndividualOffsetNR are fulfilled for: (gNB) McpcPSCellProfileUeCfg.rsrpCandidateA5 .timeToTrigger If RSRQ triggered entry into the search zone, then A5 is triggered when: SS_RSRQsource < (gNB) McpcPSCellProfileUeCfg.rsrqCandidateA5. threshold1 / 10 - (gNB) McpcPSCellProfileUeCfg.rsrqCandidateA5. hysteresis / 10 + (gNB) McpcPSCellNrFreqRelProfileUeCfg.rsrqCandidateA5Offsets . threshold1Offset / 10 and SS_RSRQtarget > (gNB) McpcPSCellProfileUeCfg.rsrqCandidateA5 .threshold2 / 10 + (gNB) McpcPSCellProfileUeCfg.rsrqCandidateA5 .hysteresis / 10 + (gNB) McpcPSCellNrFreqRelProfileUeCfg.rsrqCandidateA5Offsets . threshold2Offset / 10 are fulfilled for: (gNB) McpcPSCellProfileUeCfg.rsrqCandidateA5 .timeToTrigger If SINR triggered entry into the search zone, then A5 is triggered when: SS_SINRsource < (gNB) McpcPSCellProfileUeCfg.sinrCandidateA5. threshold1 / 10 - (gNB) McpcPSCellProfileUeCfg.sinrCandidateA5. hysteresis / 10 + (gNB) McpcPSCellNrFreqRelProfileUeCfg.sinrCandidateA5Offsets . threshold1Offset / 10 and SS_SINRtarget > (gNB) McpcPSCellProfileUeCfg.sinrCandidateA5 .threshold2 / 10 + (gNB) McpcPSCellProfileUeCfg.sinrCandidateA5 .hysteresis / 10 + (gNB) McpcPSCellNrFreqRelProfileUeCfg.sinrCandidateA5Offsets . threshold2Offset / 10 are fulfilled for: (gNB) McpcPSCellProfileUeCfg.sinrCandidateA5 .timeToTrigger Furthermore, additional checks on the target cell can be added for the non-triggering quantities, as follows:

<!-- page: 412 -->

| A5 Trigger   | Attribute Used to Add Checks (in McpcPSCellProfileUeCfg )   | Settable Values                                    |
|--------------|-------------------------------------------------------------|----------------------------------------------------|
| RSRP         | rsrpCandidateA5AddTargEval                                  | NONE RSRQ SINR_FALLBACK_RSRQ SINR_NO_FALLBACK_RSRQ |
| RSRQ         | rsrqCandidateA5AddTargEval                                  | NONE RSRP                                          |
| SINR         | sinrCandidateA5AddTargEval                                  | NONE RSRP RSRQ RSRP_AND_RSRQ                       |

**The additional RSRP check is:**

SS_RSRPtarget > (gNB) McpcPSCellProfileUeCfg.rsrpCandidateA5 .threshold2 + (gNB) McpcPSCellProfileUeCfg.rsrpCandidateA5 .hysteresis / 10 + (gNB) McpcPSCellNrFreqRelProfileUeCfg.rsrpCandidateA5Offsets . threshold2Offset

- (gNB) NRCellRelation. cellIndividualOffsetNR

**The additional RSRQ check is:**

SS_RSRQtarget > (gNB) McpcPSCellProfileUeCfg.rsrqCandidateA5 .threshold2 /10

+ (gNB) McpcPSCellProfileUeCfg.rsrqCandidateA5 .hysteresis

+ (gNB) McpcPSCellNrFreqRelProfileUeCfg.rsrqCandidateA5Offsets

threshold2Offset /10

**The additional SINR check is:**

SS_SINRtarget > (gNB) McpcPSCellProfileUeCfg.sinrCandidateA5 .threshold2

+ (gNB) McpcPSCellProfileUeCfg.sinrCandidateA5 .hysteresis

+ (gNB) McpcPSCellNrFreqRelProfileUeCfg.sinrCandidateA5Offsets

threshold2Offset

/10 /10 . /10

The A5 report is sent every 2048 ms while the event remains satisfied, if an additional quantity check is enabled, otherwise it is sent every 480 ms. The report amount is infinity.

### 11.2.10 PSCell Change to Higher Priority - NSA

The Event A5 Inter-Frequency High Priority PSCell occurs when a suitable inter-frequency NR PSCell candidate is found.

If (gNB) TrStPSCellProfileUeCfg. candidateA5TriggerQuantity = RSRP then Event A5 is triggered when:

/10 .

<!-- page: 413 -->

SS_RSRPtarget > (gNB) TrStPSCellProfileUeCfg.rsrpCandidateA5

- (gNB) TrStPSCellProfileUeCfg.rsrpCandidateA5 .hysteresis

- (gNB) TrStPSCellNrFreqRelProfileUeCfg. rsrpCandidateA5Thr2Offset

- (gNB) NRCellRelation. cellIndividualOffsetNR

.threshold2 / 10

**are fulfilled for:**

(gNB) TrStPSCellProfileUeCfg.rsrpCandidateA5 .timeToTrigger

If (gNB) TrStPSCellProfileUeCfg.candidateA5TriggerQuantity = RSRQ then Event A5 is triggered when:

SS_RSRQtarget > (gNB) TrStPSCellProfileUeCfg.rsrqCandidateA5 .threshold2 / 10 + (gNB) TrStPSCellProfileUeCfg.rsrqCandidateA5 .hysteresis / 10 + (gNB) TrStPSCellNrFreqRelProfileUeCfg. rsrqCandidateA5Thr2Offset / 10

**are fulfilled for:**

(gNB) TrStPSCellProfileUeCfg.rsrqCandidateA5 .timeToTrigger

If (gNB) TrStPSCellProfileUeCfg. candidateA5TriggerQuantity = SINR_FALLBACK_RSRP or SINR_FALLBACK_RSRQ then Event A5 is triggered when:

SS_SINRtarget > (gNB) TrStPSCellProfileUeCfg.sinrCandidateA5 .threshold2 / 10

- (gNB) TrStPSCellProfileUeCfg.sinrCandidateA5 .hysteresis

+ (gNB) TrStPSCellNrFreqRelProfileUeCfg. sinrCandidateA5Thr2Offset

**are fulfilled for:**

(gNB) TrStPSCellProfileUeCfg.sinrCandidateA5 .timeToTrigger

**If the UE does not support NR SINR measurements,**

candidateA5TriggerQuantity determines the fallback quantity, namely RSRP ( SINR_FALLBACK_RSRP ) or RSRQ ( SINR_FALLBACK_RSRQ ).

The serving cell threshold1 for all the A5 measurements is fixed to a value that is always fulfilled.

Furthermore, additional checks on the target cell can be added for the non-triggering quantities, as follows:

| A5 Trigger   | Attribute Used to Add Checks (in TrStPSCellProfileUeCfg )   | Settable Values                                    |
|--------------|-------------------------------------------------------------|----------------------------------------------------|
| RSRP         | rsrpCandidateA5AddTargEval                                  | NONE RSRQ SINR_FALLBACK_RSRQ SINR_NO_FALLBACK_RSRQ |
| RSRQ         | rsrqCandidateA5AddTargEval                                  | NONE RSRP                                          |
| SINR         | sinrCandidateA5AddTargEval                                  | NONE RSRP RSRQ RSRP_AND_RSRQ                       |

/ 10 / 10

<!-- page: 414 -->

**The additional RSRP check is:**

SS_RSRPtarget > (gNB) TrStPSCellProfileUeCfg.rsrpCandidateA5

- (gNB) TrStPSCellProfileUeCfg.rsrpCandidateA5 .hysteresis

- (gNB) TrStPSCellNrFreqRelProfileUeCfg. rsrpCandidateA5Thr2Offset

- (gNB) NRCellRelation. cellIndividualOffsetNR

.threshold2 / 10

**The additional RSRQ check is:**

SS_RSRQtarget > (gNB) TrStPSCellProfileUeCfg.rsrqCandidateA5 .threshold2

- (gNB) TrStPSCellProfileUeCfg.rsrqCandidateA5 .hysteresis

- (gNB) TrStPSCellNrFreqRelProfileUeCfg. rsrqCandidateA5Thr2Offset

**The additional SINR check is:**

SS_SINRtarget > (gNB) TrStPSCellProfileUeCfg.sinrCandidateA5 .threshold2

- (gNB) TrStPSCellProfileUeCfg.sinrCandidateA5 .hysteresis

- (gNB) TrStPSCellNrFreqRelProfileUeCfg. sinrCandidateA5Thr2Offset / 10

/ 10 / 10 / 10

/ 10 / 10

The A5 report is sent every 2048 ms while the event remains satisfied, if an additional quantity check is enabled, otherwise it is sent every 480 ms. The report amount is infinity.

### 11.2.11 Multi-Layer Coordination and NR Small Cell Traffic Steering - SA

The following measurements are configured by Multi-Layer Coordination . The Event A5 measurements are also used by Dynamic Cell Set Change during Mobility and NR Advanced Multi-Layer Coordination , and to find other vendor cells if the feature NR Small Cell Traffic Steering (SCTS) is enabled.

#### 11.2.11.1 Event A1 - UL SCell Coverage

Event A1 (MLC A1UL) is used to detect whether a serving SCell that is configured for DL has good enough coverage to be configured for UL CA.

In the current release, the trigger level for this A1 event is derived using attributes that are also used for traffic steering.

SS_RSRPSCell >

(gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . threshold2

+ (gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . hysteresis / 10

+ (gNB) TrStSaNrFreqRelProfileUeCfg . rsrpPCellCandidateOffset

is fulfilled for:

(gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . timeToTrigger

In the above formulas, the TrStSaNrFreqRelProfileUeCfg instance used is the one corresponding to the SCell frequency.

<!-- page: 415 -->

#### 11.2.11.2 Event A1 - MLC Current PCell Uplink Coverage

Event A1 (MLC A1PR) is used if an MLC SCell reselection would require a UE power class reduction due to the UL CA band combination. The A1 event checks that the PCell coverage is good enough to avoid entering the MCPC search zone when the power class reduction occurs.

In the current release, the trigger level for this A1 event is derived using attributes that are also used for traffic steering.

SS_RSRPPCell > (gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . threshold2 + (gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . hysteresis / 10 + (gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidatePCOffset[x] . threshold2Offset + (gNB) TrStSaNrFreqRelProfileUeCfg . rsrpPCellCandidateOffset

is fulfilled for: (gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . timeToTrigger

where the index [x] is selected according to the UE power class, for high power UEs.

Event A1 (MLC A1UL 2L) is used if the current PCell is going to be used for UL 2-layer configuration in the candidate cell set PCell. The A1 event estimates that the PCell coverage is good enough for UL 2-layer configuration.

threshold2Offset

SS_RSRPPCell > (gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . threshold2 + (gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . hysteresis / 10 + (gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidatePCOffset[x] . + (gNB) TrStSaNrFreqRelProfileUeCfg . rsrpPCellCandidateOffset + (gNB) TrStSaNrFreqRelProfileUeCfg .rsrpUl2lCoverageThrOffset *

is fulfilled for:

(gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . timeToTrigger

where the index [x] is selected according to the UE power class, for high power UEs.

* This attribute is used to evaluate the reported RSRP for uplink 2-layer coverage. It is not included when deriving the threshold sent to the UE for measurement configuration.

In the above formulas, the TrStSaNrFreqRelProfileUeCfg instance used is the one corresponding to the PCell frequency.

#### 11.2.11.3 Event A2 - UL SCell Coverage

Event A2 (MLC A2UL) is used to detect whether a serving SCell that is configured for DL has poor coverage and is therefore not a valid UL SCell candidate for MLC.

In the current release, the trigger level for this A2 event is derived using attributes that are also used for traffic steering.

<!-- page: 416 -->

- SS_RSRPSCell < (gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . threshold2 - (gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . hysteresis / 10 + (gNB) TrStSaNrFreqRelProfileUeCfg . rsrpPCellCandidateOffset

**is fulfilled for:**

(gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . timeToTrigger

In the above formulas, the TrStSaNrFreqRelProfileUeCfg instance used is the one corresponding to the SCell frequency.

#### 11.2.11.4 Event A5 - MLC PCell and SCell Candidate

MLC uses different Event A5 measurements for PCell and SCell candidates. These measurements are also used to find other vendor 's cells if the feature NR Small Cell Traffic Steering (SCTS) is enabled.

The A5 threshold1 (the serving cell threshold) is fixed to a value that is always fulfilled. The triggering therefore depends only threshold2 (the target cell threshold), as follows.

If (gNB) TrStSaCellProfileUeCfg. mlcTriggerQuantity = RSRP, then:

The Event A5 (MLC A5 PCell) is used to check the coverage of an MLC PCell candidate. It is triggered when:

SS_RSRPtarget PCell > (gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidate .threshold2 + (gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidatePcOffset[x] . threshold2Offset + (gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidate .hysteresis / 10 + (gNB) TrStSaNrFreqRelProfileUeCfg. rsrpPCellCandidateOffset - (gNB) NRCellRelation. cellIndividualOffsetNR

**are fulfilled for:**

(gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . timeToTrigger

where the index [x] is selected according to the UE power class, for high power UEs.

The Event A5 (MLC A5UL 2L) is used to check the coverage of an MLC PCell candidate that is intended for 2-layer UL use. It is triggered when:

SS_RSRPtarget PCell > (gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidate .threshold2 + (gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidatePcOffset[x] . threshold2Offset + (gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidate .hysteresis / 10 + (gNB) TrStSaNrFreqRelProfileUeCfg. rsrpPCellCandidateOffset + (gNB) TrStSaNrFreqRelProfileUeCfg .rsrpUl2lCoverageThrOffset * - (gNB) NRCellRelation. cellIndividualOffsetNR

are fulfilled for:

<!-- page: 417 -->

(gNB) TrStSaCellProfileUeCfg . rsrpPCellCandidate . timeToTrigger

where the index [x] is selected according to the UE power class, for high power UEs. The (MLC A5UL 2L) measurement is configured using RSRP only.

- This attribute is used to evaluate the reported RSRP for uplink 2-layer coverage. It is not included when deriving the threshold sent to the UE for measurement configuration.

The Event A5 (MLC A5 SCell) is used to check the coverage of an MLC SCell candidate. It is triggered when:

SS_RSRPtargetSCell  > (gNB) TrStSaCellProfileUeCfg.rsrpSCellCandidate. threshold2 + (gNB) TrStSaCellProfileUeCfg.rsrpSCellCandidate. hysteresis / 10 + (gNB) TrStSaNrFreqRelProfileUeCfg. rsrpSCellCandidateOffset - (gNB) NRCellRelation. cellIndividualOffsetNR

**are fulfilled for:**

(gNB) TrStSaCellProfileUeCfg.rsrpSCellCandidate. timeToTrigger

If (gNB) TrStSaCellProfileUeCfg. mlcTriggerQuantity = RSRQ,

then:

The Event A5 (MLC A5 PCell) is used to check the coverage of an MLC PCell candidate. It is triggered when:

SS_RSRQtarget PCell > (gNB) TrStSaCellProfileUeCfg.rsrqPCellCandidate .threshold2 / 10 + (gNB) TrStSaCellProfileUeCfg.rsrqPCellCandidate .hysteresis / 10 + (gNB) TrStSaNrFreqRelProfileUeCfg. rsrqPCellCandidateOffset / 10

**are fulfilled for:**

(gNB) TrStSaCellProfileUeCfg . rsrqPCellCandidate . timeToTrigger

The Event A5 (MLC A5 SCell) is used to check the coverage of an MLC SCell candidate. It is triggered when:

SS_RSRQtargetSCell  > (gNB) TrStSaCellProfileUeCfg . rsrqSCellCandidate . threshold2 / 10 + (gNB) TrStSaCellProfileUeCfg.rsrqSCellCandidate. hysteresis / 10 + (gNB) TrStSaNrFreqRelProfileUeCfg. rsrqSCellCandidateOffset / 10

are fulfilled for:

(gNB) TrStSaCellProfileUeCfg . rsrqSCellCandidate . timeToTrigger

If (gNB) TrStSaCellProfileUeCfg. mlcTriggerQuantity = SINR_FALLBACK_RSRP or SINR_FALLBACK_RSRQ, then:

The Event A5 (MLC A5 PCell) is used to check the coverage of an MLC PCell candidate. It is triggered when:

<!-- page: 418 -->

SS_SINRtarget PCell >

(gNB) TrStSaCellProfileUeCfg.sinrPCellCandidate .threshold2 / 10

- (gNB) TrStSaCellProfileUeCfg.sinrPCellCandidate .hysteresis / 10

- (gNB) TrStSaNrFreqRelProfileUeCfg. sinrPCellCandidateOffset / 10

**are fulfilled for:**

(gNB) TrStSaCellProfileUeCfg . sinrPCellCandidate . timeToTrigger

The Event A5 (MLC A5 SCell) is used to check the coverage of an MLC SCell candidate. It is triggered when:

SS_SINRtargetSCell  >

(gNB) TrStSaCellProfileUeCfg . sinrSCellCandidate . threshold2 / 10

- (gNB) TrStSaCellProfileUeCfg.sinrSCellCandidate. hysteresis / 10

- (gNB) TrStSaNrFreqRelProfileUeCfg. sinrSCellCandidateOffset / 10

**are fulfilled for:**

(gNB) TrStSaCellProfileUeCfg . sinrSCellCandidate . timeToTrigger

The PCell report is sent every 240 ms while the event remains satisfied, and the report amount is infinity.

The SCell report is sent only once, and the report amount is 1.

For the MLC PCell candidate, additional checks on the target cell can be added for the non-triggering quantities as follows:

| A5 Trigger   | Attribute Used to Add Checks (in TrStSaCellProfileUeCfg )   | Settable Values                                    |
|--------------|-------------------------------------------------------------|----------------------------------------------------|
| RSRP         | rsrpPCellCandidateAddTargEval                               | NONE RSRQ SINR_FALLBACK_RSRQ SINR_NO_FALLBACK_RSRQ |
| RSRQ         | rsrqPCellCandidateAddTargEval                               | NONE RSRP                                          |
| SINR         | sinrPCellCandidateAddTargEval                               | NONE RSRP RSRQ RSRP_AND_RSRQ                       |

**The additional RSRP check is:**

**SS_RSRPtarget >**

(gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidate. threshold2

- (gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidatePcOffset[x] .

**threshold2Offset**

- (gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidate. hysteresis / 10

- (gNB) TrStSaNrFreqRelProfileUeCfg. rsrpPCellCandidateOffset

- (gNB) NRCellRelation. cellIndividualOffsetNR

<!-- page: 419 -->

where the index [x] is selected according to the UE power class, for high power UEs.

The additional RSRQ check is:

SS_RSRQtarget > (gNB) TrStSaCellProfileUeCfg.rsrqPCellCandidate. threshold2 / 10 + (gNB) TrStSaCellProfileUeCfg.rsrqPCellCandidate. hysteresis / 10 + (gNB) TrStSaNrFreqRelProfileUeCfg. rsrqPCellCandidateOffset

The additional SINR check is:

- SS_SINRtarget > (gNB) TrStSaCellProfileUeCfg.sinrPCellCandidate. threshold2 / 10 + (gNB) TrStSaCellProfileUeCfg.sinrPCellCandidate. hysteresis / 10

- (gNB) TrStSaNrFreqRelProfileUeCfg. sinrPCellCandidateOffset / 10

#### 11.2.11.5 Event A5 - MLC UL SCell Candidate

Event A5 (MLC A5UL) is used by MLC to detect whether a non-serving frequency has a cell with good enough coverage to be configured as an SCell for UL CA. These measurements are also used to find other vendor's cells if the feature NR Small Cell Traffic Steering (SCTS) is enabled.

The serving cell RSRP threshold1 is fixed to a value that is always fulfilled. The event is therefore triggered when the threshold2 criteria is satisfied, as follows:

SS_RSRPtarget SCell > (gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidate .threshold2

- (gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidate .hysteresis / 10

- (gNB) TrStSaNrFreqRelProfileUeCfg. rsrpPCellCandidateOffset

- (gNB) NRCellRelation. cellIndividualOffsetNR

is fulfilled for:

(gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidate .timeToTrigger

The SCell report is sent only once, and the report amount is 1.

### 11.2.12 Measurement-Based Secondary Node Addition - SA

The Event A4 Entering Coverage FR2 occurs when a suitable PSCell candidate for NR-DC is found.

The trigger quantity is set by (gNB) NrdcMnCellProfileUeCfg. pSCellTriggerQuantity , to either RSRP , RSRQ , SINR , SINR_FALLBACK_RSRP , SINR_FALLBACK_RSRQ , RSRP_AND_RSRQ , RSRP_AND_SINR_FALLBACK_RSRQ or RSRP_AND_SINR_NO_FALLBACK .

If the trigger quantity is RSRP then Event A4 is triggered when:

- / 10

<!-- page: 420 -->

**SS_RSRPtarget >**

(gNB) NrdcMnCellProfileUeCfg.rsrpPSCellCandidate. threshold

- (gNB) NrdcMnCellProfileUeCfg.rsrpPSCellCandidate. hysteresis / 10

- (gNB) NRFreqRelation . nrdcA4ThrRsrpFreqOffset

- (gNB) NRCellRelation. cellIndividualOffsetNR

**is fulfilled for:**

(gNB) NrdcMnCellProfileUeCfg.rsrpPSCellCandidate. timeToTrigger

**If the trigger quantity is RSRQ then Event A4 is triggered when:**

- SS_RSRQtarget > (gNB) NrdcMnCellProfileUeCfg.rsrqPSCellCandidate. threshold / 10 + (gNB) NrdcMnCellProfileUeCfg . rsrqPSCellCandidate. hysteresis / 10 + (gNB) NRFreqRelation . nrdcA4ThrRsrqFreqOffset / 10

**is fulfilled for:**

(gNB) NrdcMnCellProfileUeCfg.rsrqPSCellCandidate. timeToTrigger

If the trigger quantity is SINR then Event A4 is triggered when:

- SS_SINRtarget > (gNB) NrdcMnCellProfileUeCfg.sinrPSCellCandidate. threshold / 10 + (gNB) NrdcMnCellProfileUeCfg.sinrPSCellCandidate. hysteresis / 10 + (gNB) NRFreqRelation . nrdcA4ThrSinrFreqOffset / 10

**is fulfilled for:**

(gNB) NrdcMnCellProfileUeCfg.sinrPSCellCandidate. timeToTrigger

When the trigger quantity is RSRP, the gNodeB can be configured to perform an additional check on the reported values of RSRQ or SINR, as follows:

| A4 Trigger   | Attribute Used to Add Checks (in NrdcMnCellProfileUeCfg )   | Settable Values (for enabling additional evaluation)                |
|--------------|-------------------------------------------------------------|---------------------------------------------------------------------|
| RSRP         | pSCellTriggerQuantity                                       | RSRP_AND_RSRQ RSRP_AND_SINR_FALLBACK_RSRQ RSRP_AND_SINR_NO_FALLBACK |

**The additional RSRQ check is:**

- SS_RSRQtarget > (gNB) NrdcMnCellProfileUeCfg.rsrqPSCellCandidate. threshold / 10 + (gNB) NrdcMnCellProfileUeCfg.rsrqPSCellCandidate. hysteresis / 10 + (gNB) NRFreqRelation. nrdcA4ThrRsrqFreqOffset / 10

**The additional SINR check is:**

<!-- page: 421 -->

**SS_SINRtarget >**

(gNB) NrdcMnCellProfileUeCfg.sinrPSCellCandidate. threshold / 10

- (gNB) NrdcMnCellProfileUeCfg.sinrPSCellCandidate. hysteresis / 10

- (gNB) NRFreqRelation. nrdcA4ThrSinrFreqOffset / 10

If the additional evaluation threshold is not fulfilled, the measurement report is discarded.

If no additional evaluation check is enabled, the A4 report is sent every 240 ms while the event remains satisfied. If an additional evaluation check is enabled, this time is increased to 480 ms. The report amount is infinite.

### 11.2.13 Bandwidth-Triggered Inter-System Handover & NR Data-Aware Mobility - SA

The Event B2 EUTRAN Candidate PCell occurs when a suitable inter-RAT LTE cell candidate is found.

If (gNB) TrStSaCellProfileUeCfg. bwTrigISHoTriggerQuantity = RSRP, then the B2 event is triggered when:

**SS_RSRPNR <**

(gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidateB2. threshold1

- (gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidateB2PcOffset[x]. threshold1Offset

- (gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidateB2. hysteresis / 10

- (gNB) TrStSaEUtranFreqRelProfileUeCfg.rsrpPCellCandidateB2Offsets .

**threshold1Offset**

and

**RSRPLTE >**

(gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidateB2 .threshold2EUtra

- (gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidateB2 .hysteresis / 10

- (gNB) TrStSaEUtranFreqRelProfileUeCfg.rsrpPCellCandidateB2Offsets .

**threshold2EUtraOffset**

- (gNB) EUtranCellRelation. cellIndividualOffset

are fulfilled for:

(gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidateB2 .timeToTrigger

where the index [x] is selected according to the UE power class, for high power UEs.

If (gNB) TrStSaCellProfileUeCfg. bwTrigISHoTriggerQuantity = RSRQ, then the B2 event is triggered when:

- SS_RSRQNR < (gNB) TrStSaCellProfileUeCfg.rsrqPCellCandidateB2. threshold1 /10 - (gNB) TrStSaCellProfileUeCfg.rsrqPCellCandidateB2. hysteresis / 10

- (gNB) TrStSaEUtranFreqRelProfileUeCfg.rsrqPCellCandidateB2Offsets .

threshold1Offset / 10

and RSRQLTE >

<!-- page: 422 -->

(gNB) TrStSaCellProfileUeCfg.rsrqPCellCandidateB2 .threshold2EUtra / 10

+ (gNB) TrStSaCellProfileUeCfg.rsrqPCellCandidateB2 .hysteresis / 10

+ (gNB) TrStSaEUtranFreqRelProfileUeCfg.rsrqPCellCandidateB2Offsets .

threshold2EUtraOffset / 10

are fulfilled for:

(gNB) TrStSaCellProfileUeCfg.rsrqPCellCandidateB2 .timeToTrigger

If (gNB) TrStSaCellProfileUeCfg. bwTrigISHoTriggerQuantity = SINR_FALLBACK_RSRP or SINR_FALLBACK_RSRQ,

SS_SINRNR <

(gNB) TrStSaCellProfileUeCfg.sinrPCellCandidateB2. threshold1 /10

- (gNB) TrStSaCellProfileUeCfg.sinrPCellCandidateB2. hysteresis /10

+ (gNB)

TrStSaEUtranFreqRelProfileUeCfg.sinrPCellCandidateB2Offsets

.

threshold1Offset / 10

and

SINRLTE >

(gNB) TrStSaCellProfileUeCfg.sinrPCellCandidateB2 .threshold2EUtra /10

+ (gNB) TrStSaCellProfileUeCfg.sinrPCellCandidateB2 .hysteresis /10

+ (gNB) TrStSaEUtranFreqRelProfileUeCfg.sinrPCellCandidateB2Offsets .

threshold2EUtraOffset /10

are fulfilled for:

(gNB) TrStSaCellProfileUeCfg.sinrPCellCandidateB2 .timeToTrigger

The B2 report is sent only once; the report amount is 1.

Furthermore, additional checks on the target cell can be added for the non-triggering quantities, as follows:

| B2 Trigger   | Attribute Used to Add Checks (in TrStSaCellProfileUeCfg )   | Settable Values                                    |
|--------------|-------------------------------------------------------------|----------------------------------------------------|
| RSRP         | rsrpPCellCandidateB2AddTargEval                             | NONE RSRQ SINR_FALLBACK_RSRQ SINR_NO_FALLBACK_RSRQ |
| RSRQ         | rsrqPCellCandidateB2AddTargEval                             | NONE RSRP                                          |
| SINR         | sinrPCellCandidateB2AddTargEval                             | NONE RSRP RSRQ RSRP_AND_RSRQ                       |

The additional RSRP check is:

then the B2 event is triggered when:

<!-- page: 423 -->

RSRPLTE >

(gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidateB2 .threshold2EUtra

- (gNB) TrStSaCellProfileUeCfg.rsrpPCellCandidateB2 .hysteresis / 10

- (gNB) TrStSaEUtranFreqRelProfileUeCfg.rsrpPCellCandidateB2Offsets .

**threshold2EUtraOffset**

- (gNB) EUtranCellRelation. cellIndividualOffset

**The additional RSRQ check is:**

RSRQLTE > (gNB) TrStSaCellProfileUeCfg.rsrqPCellCandidateB2 .threshold2EUtra /10 + (gNB) TrStSaCellProfileUeCfg.rsrqPCellCandidateB2 .hysteresis /10

+ (gNB) TrStSaEUtranFreqRelProfileUeCfg.rsrqPCellCandidateB2Offsets .

threshold2EUtraOffset /10

**The additional SINR check is:**

SINRLTE > (gNB) TrStSaCellProfileUeCfg.sinrPCellCandidateB2 .threshold2EUtra /10 + (gNB) TrStSaCellProfileUeCfg.sinrPCellCandidateB2 .hysteresis /10 + (gNB) TrStSaEUtranFreqRelProfileUeCfg.sinrPCellCandidateB2Offsets . threshold2EUtraOffset /10

### 11.2.14 Traffic Offload - SA

These measurements (both the A5 and the B1) are used for NR Cell Soft Lock and Prohibited Cell-Triggered Mobility. Additionally, the B1 measurements are used for NR Traffic Offload .

#### 11.2.14.1 Event A5 - Inter-Frequency Candidate

The Event A5 Inter-Frequency Candidate occurs when a suitable inter-frequency NR cell candidate is found.

If (gNB) OffloadCellProfileUeCfg. pCellCandidateTriggerQuantity = RSRP , then the A5 event is triggered when:

**SS_RSRPtarget  >**

(gNB) OffloadCellProfileUeCfg . rsrpPCellCandidate .

- (gNB) OffloadCellProfileUeCfg . rsrpPCellCandidate . hysteresis

- (gNB) OffloadNrFreqRelProfileUeCfg . rsrpPCellCandidateOffset

- (gNB) NRCellRelation . cellIndividualOffsetNR

threshold2 / 10

**is fulfilled for:**

(gNB) OffloadCellProfileUeCfg . rsrpPCellCandidate . timeToTrigger

If (gNB) OffloadCellProfileUeCfg. pCellCandidateTriggerQuantity = RSRQ , then the A5 event is triggered when:

<!-- page: 424 -->

SS_RSRQtarget  > (gNB) OffloadCellProfileUeCfg . rsrqPCellCandidate . threshold2 / 10 + (gNB) OffloadCellProfileUeCfg . rsrqPCellCandidate . hysteresis / 10

+ (gNB) OffloadNrFreqRelProfileUeCfg . rsrqPCellCandidateOffset / 10

**is fulfilled for:**

(gNB) OffloadCellProfileUeCfg . rsrqPCellCandidate . timeToTrigger

If (gNB) OffloadCellProfileUeCfg. pCellCandidateTriggerQuantity = SINR_FALLBACK_RSRP or SINR_FALLBACK_RSRP then the A5 event is triggered when:

SS_SINRtarget  > (gNB) OffloadCellProfileUeCfg . sinrPCellCandidate . threshold2 / 10 + (gNB) OffloadCellProfileUeCfg . sinrPCellCandidate . hysteresis / 10 + (gNB) OffloadNrFreqRelProfileUeCfg . sinrPCellCandidateOffset / 10

**is fulfilled for:**

(gNB) OffloadCellProfileUeCfg . sinrPCellCandidate . timeToTrigger

If the UE does not support NR downlink SINR measurements,

pCellCandidateTriggerQuantity determines the fallback quantity, namely RSRP ( SINR_FALLBACK_RSRP ) or RSRQ ( SINR_FALLBACK_RSRQ ).

If no additional target cell checks are enabled, the A5 report is sent every 480 ms while the event remains satisfied. If additional target cell checks are enabled, this time is increased to 2048 ms. The report amount is infinity.

The serving cell threshold1 is fixed to a value that is always fulfilled.

Additional checks on the target cell can be added for the non-triggering quantities, as follows:

| A5 Trigger   | Attribute Used to Add Checks (in OffloadCellProfileUeCfg )   | Settable Values                                    |
|--------------|--------------------------------------------------------------|----------------------------------------------------|
| RSRP         | rsrpPCellCandAddTargEval                                     | NONE RSRQ SINR_FALLBACK_RSRQ SINR_NO_FALLBACK_RSRQ |
| RSRQ         | rsrqPCellCandAddTargEval                                     | NONE RSRP                                          |
| SINR         | sinrPCellCandAddTargEval                                     | NONE RSRP RSRQ RSRP_AND_RSRQ                       |

The added check(s) use the equation(s) shown above, ignoring the time-to-trigger because the event has already been triggered when the check is performed. If the additional check(s) pass, then the handover is allowed, otherwise it is inhibited.

<!-- page: 425 -->

#### 11.2.14.2 Event B1 - EUTRAN Candidate

The Event B1 EUTRAN Candidate occurs when a suitable inter-RAT LTE cell candidate is found.

If (gNB) OffloadCellProfileUeCfg. pCellCandidateTriggerQuantity = RSRP , then the B1 event is triggered when:

RSRPLTE > (gNB) OffloadCellProfileUeCfg . rsrpPCellCandidateB1 . threshold + (gNB) OffloadCellProfileUeCfg . rsrpPCellCandidateB1 . hysteresis / 10 + (gNB) OffloadEUtranFreqRelProfileUeCfg . rsrpPCellCandidateB1Offset - (gNB) EUtranCellRelation . cellIndividualOffset

is fulfilled for: (gNB) OffloadCellProfileUeCfg . rsrpPCellCandidateB1 . timeToTrigger If (gNB) OffloadCellProfileUeCfg. pCellCandidateTriggerQuantity = RSRQ , then the B1 event is triggered when: RSRQLTE > (gNB) OffloadCellProfileUeCfg . rsrqPCellCandidateB1 . threshold / 10 + (gNB) OffloadCellProfileUeCfg . rsrqPCellCandidateB1 . hysteresis / 10 + (gNB) OffloadEUtranFreqRelProfileUeCfg . rsrqPCellCandidateB1Offset / 10 is fulfilled for: (gNB) OffloadCellProfileUeCfg . rsrqPCellCandidateB1 . timeToTrigger If (gNB) OffloadCellProfileUeCfg. pCellCandidateTriggerQuantity = SINR_FALLBACK_RSRP or SINR_FALLBACK_RSRQ , then the B1 event is triggered when: SINRLTE > (gNB) OffloadCellProfileUeCfg . sinrPCellCandidateB1 . threshold / 10 + (gNB) OffloadCellProfileUeCfg . sinrPCellCandidateB1 . hysteresis / 10 + (gNB) OffloadEUtranFreqRelProfileUeCfg . sinrPCellCandidateB1Offset / 10

**is fulfilled for:**

(gNB) OffloadCellProfileUeCfg . sinrPCellCandidateB1 . timeToTrigger

If the UE does not support downlink LTE SINR measurements,

pCellCandidateTriggerQuantity determines the fallback quantity, namely RSRP ( SINR_FALLBACK_RSRP ) or RSRQ ( SINR_FALLBACK_RSRQ ).

If no additional target cell checks are enabled, the B1 report is sent every 480 ms while the event remains satisfied. If additional target cell checks are enabled, this time is increased to 2048 ms. The report amount is infinity.

<!-- page: 426 -->

Additional checks on the target cell can be added for the non-triggering quantities, as follows:

| B1 Trigger   | Attribute Used to Add Checks (in OffloadCellProfileUeCfg )   | Settable Values                                    |
|--------------|--------------------------------------------------------------|----------------------------------------------------|
| RSRP         | rsrpPCellCandB1AddTargEval                                   | NONE RSRQ SINR_FALLBACK_RSRQ SINR_NO_FALLBACK_RSRQ |
| RSRQ         | rsrqPCellCandB1AddTargEval                                   | NONE RSRP                                          |
| SINR         | sinrPCellCandB1AddTargEval                                   | NONE RSRP RSRQ RSRP_AND_RSRQ                       |

The added check(s) use the equation(s) shown above, ignoring the time-to-trigger because the event has already been triggered when the check is performed. If the additional check(s) pass, then the handover is allowed, otherwise it is inhibited.

### 11.2.15 Positioning of UEs without PDU Session

The following events are used by the feature Positioning of UEs without PDU Session to monitor the signaling connection. If a PDU session is later set up, these events are removed.

#### 11.2.15.1 Event A2 - Critical Coverage

This event is used to trigger connection release when the UE without a PDU session enters critical PCell coverage.

This event is enabled per measurement quantity (RSRP, RSRQ or SINR) by setting the corresponding (gNB) UeNoDrbPCellProfileUeCfg attribute ( rsrpCriticalEnabled , rsrqCriticalEnabled and/or sinrCriticalEnabled respectively) to true .

It is triggered independently per measurement quantity.

For RSRP, it is triggered when:

SS_RSRPNR < (gNB) UeNoDrbPCellProfileUeCfg.rsrpCritical. threshold + (gNB) UeNoDrbPCellProfileUeCfg.rsrpCriticalPcOffset[x]. thresholdOffset - (gNB) UeNoDrbPCellProfileUeCfg.rsrpCritical. hysteresis / 10

is fulfilled for:

(gNB) UeNoDrbPCellProfileUeCfg.rsrpCritical. timeToTrigger

where the index [x] is selected according to the UE power class, for high power UEs.

<!-- page: 427 -->

To obtain the corresponding trigger level formulas for RSRQ and SINR, replace 'rsrp' with 'rsrq' or 'sinr' in the struct attribute names. Additionally, note the following:

- rsrpCriticalPcOffset does not have RSRQ or SINR equivalents, so omit this term

- Check the unit of each attribute. When it is dB, no divisor is needed. When it is 0.1 dB, a divisor of 10 is needed (i.e. 'attribute / 10')

#### 11.2.15.2 Event A3

This measurement is used to trigger connection release of a UE without a PDU session when a neighboring PCell becomes stronger. Only RSRP is used.

If (gNB) UeNoDrbPCellProfileUeCfg. rsrpBetterPCellEnabled = true, then Event A3 is triggered when:

SS_RSRPtarget - SS_RSRPsource >

(gNB) UeNoDrbPCellProfileUeCfg . rsrpBetterPCell . offset / 10

+ (gNB) UeNoDrbPCellProfileUeCfg . rsrpBetterPCell . hysteresis / 10

- (gNB) NRCellRelation . cellIndividualOffsetNR

is fulfilled for:

(gNB) UeNoDrbPCellProfileUeCfg . rsrpBetterPCell . timeToTrigger

### 11.2.16 Measurement-based Secondary Node Release for NR-DC

The Event A2 Critical Coverage occurs when the UE enters critical PSCell coverage, triggering SN release. This functionality is configured in the secondary gNodeB.

This event is enabled per measurement quantity (RSRP, RSRQ or SINR) using McpcNrdcPSCellProfileUeCfg . mcpcA2Quantity as described in Section 10.3.2.4.

It is triggered independently per measurement quantity.

For RSRP, it is triggered when:

SS_RSRPNR < (gNB) McpcNrdcPSCellProfileUeCfg.rsrpCritical. threshold - (gNB) McpcNrdcPSCellProfileUeCfg.rsrpCritical. hysteresis / 10

is fulfilled for:

(gNB) McpcNrdcPSCellProfileUeCfg.rsrpCritical. timeToTrigger

To obtain the corresponding trigger level formulas for RSRQ and SINR, replace 'rsrp' with 'rsrq' or 'sinr' in the struct attribute names. Additionally, check the unit of each attribute. When it is dB, no divisor is needed. When it is 0.1 dB, a divisor of 10 is needed (i.e. 'attribute / 10') .

<!-- page: 428 -->

### 11.2.17 NR Intra-Frequency Mobility LTM - SA

L1/L2 Triggered Mobility (LTM) uses an Event A3 measurement to search for better intrafrequency PCell candidates. The measurement always uses RSRP and runs in parallel with the A3 measurement used for standard PCell handover (described in Section 11.2.4).

Event A3 (LTM) is triggered when:

SS_RSRPtarget - SS_RSRPsource > (gNB) IntraFreqMCLtmCellProfileUeCfg.rsrpBetterLtmCandCell. offset / 10 + (gNB) IntraFreqMCLtmCellProfileUeCfg.rsrpBetterLtmCandCell. hysteresis / 10 - (gNB) NRCellRelation. cellIndividualOffsetNR

**is fulfilled for:**

(gNB) IntraFreqMCLtmCellProfileUeCfg.rsrpBetterLtmCandCell. timeToTrigger

<!-- page: 429 -->

# 12 Appendix 3 - Observability

To ensure that the mobility and traffic management strategy is implemented correctly and performing well, it is important to monitor network performance.

## 12.1 Overview of PM Counters and Events

Performance can be monitored using statistics generated from performance management (PM) counters.

PM counters can be categorized into node counters and Event Based Statistics (EBS) counters.

- Node counters are generated directly on the node itself. They are stored periodically in Recording Output Period (ROP) files on the node, which can be retrieved by performance management tools running on other nodes. Node counters are defined within an MO Class and are described in the class definition in the Managed Object Model (MOM) documentation, which is available in the relevant RAN CPI Library. They are also described under the 'Counters' category in the 'Lists and Delta Lists' description. Additionally, their names are typically listed in the feature description of the feature responsible for generating them.

- EBS counters are generated off the node, in Ericsson Network Manager (ENM), and are also called off-node counters. As suggested by the name, EBS counters are based on events which occur in the node. The events are communicated from the node to ENM, along with instructions on how to generate the EBS counters from the events, and the available event filters, where applicable. The counters are then calculated and stored in ROP files on ENM. Each EBS counter is associated with an MO Class but, unlike node counters, EBS counters are not described in the class definition in the MOM. Instead, their definitions can be found in the ' EBS Counters' category of the 'Lists and Delta Lists' description. Additionally, their names are typically listed in the feature description of the feature responsible for generating them.

In LTE, performance monitoring is based mostly on node (eNodeB) counters, and EBS counters are typically used only for more in-depth investigation.

In NR, however, node (gNodeB) counters are focused mostly on the observability required for KPIs. The remaining metrics are provided by EBS counters, with the following advantages:

- EBS enables flexible counters, where filters are applied to create additional counters for a subset of UEs or bearers, for example for a particular combination of PLMN and 5QI.

- EBS provides more detailed and granular KPIs, for example counters per:

̶

- cell relation

̶

- network slice

̶

- shared PLMN level

<!-- page: 430 -->

̶

- setup / release / failure cause

- EBS provides shorter (5 minute) ROP files, enabling faster reaction to performance changes.

- EBS enables events from an individual UE to be combined to create session level counters, such as the throughput distribution per session.

- EBS allows counter definitions to be tailored per node or activity, e.g. to support trials or feature introductions.

- EBS allows the counter calculations to be offloaded to ENM, maximizing the traffic handling capacity of the node.

Given these advantages and the increased complexity and diversity associated with 5G, EBS counters are becoming essential for comprehensive performance monitoring. Much of the detailed observability required for mobility and traffic management is only possible using EBS counters.

In NR, EBS counter names always start with pmEbs . In LTE there is no such naming convention.

Flexible counters are a special category of counters that allow additional counters to be created from the base counter by applying filters.

- In LTE, flexible counters are node (eNodeB) counters, and are distinguished by names starting with pmFlex .

- In NR, all flexible counters are EBS counters but not all EBS counters are flex counters. To determine whether a particular EBS counter is also flexible counter, search for the counter in the ' Lists and Delta Lists ' description in CPI (under the EBS Counters category); those counters which have an entry in the Applicable Filter column are flexible counters.

The different handling of node, EBS and flexible counters in LTE and NR is summarized in Figure 12-1.

<!-- page: 431 -->

![Figure on page 431](5G_Mobility_and_Traffic_Management_Guideline_images/page_431_image_002.png)

Figure 12-1 -Counter Naming Conventions

The filters available for a particular flexible EBS counter depend on the information available in the PM event used to create the EBS counter. Some events do not allow filtering. Some of the filters available in the current NR release are:

- UeGrpId, PrefUeGrpId, UeMobilityGrpId, UeServiceGrpId, UePowerClass, PlmnId, Qos, QosType, Snssai, PartitionId, NrDcConfigured, EstablishmentCause, ReestablishmentCause, ResumeCause, Arp, Spid, TrafficSteeringType, MeasTriggerQuantity

Multiple filters combinations can be applied simultaneously, and their order is not important. Figure 12-2 shows an example of how filters can be used to create additional counters from a base counter. As shown, it is possible to create additional counters for just a subset of the total possible filter attribute values, to cover only the specific cases of interest. Multiple combinations of filters can be used in parallel to create multiple additional counters, each with a different focus. Additional counters can be defined and deleted dynamically, in response to changing observability requirements.

![Figure on page 431](5G_Mobility_and_Traffic_Management_Guideline_images/page_431_image_003.png)

Figure 12-2 - Flexible EBS Counter Example

<!-- page: 432 -->

Flexible EBS counters are managed using the Flexible Counter Management (FCM) application in ENM. This application is described in the ENM Online Help CPI Library.

The following KPI shows how EBS counters can be used to calculate the inter-frequency handover success rate for NR SA. This is not possible using node counters, which do not distinguish between intra and inter-frequency. This KPI is available at both the cell and cell relation level (including lightweight neighbor relations). Furthermore, additional KPIs can be created by applying filters to the underlying base EBS counters; for example, to determine the inter-frequency success rate for a particular UE group identity.

**Inter-Freq Handover Success Rate =**

100 * ( pmEbsHoPrepSuccOutInterGnb + pmEbsHoPrepSuccOutIntraGnb - pmEbsHoPrepSuccOutInterGnbIntraF - pmEbsHoPrepSuccOutIntraGnbIntraF ) / ( pmEbsHoPrepAttOutInterGnb + pmEbsHoPrepAttOutIntraGnb - pmEbsHoPrepAttOutInterGnbIntraF - pmEbsHoPrepAttOutIntraGnbIntraF ) * ( pmEbsHoExeSuccOutInterGnb + pmEbsHoExeSuccOutIntraGnb - pmEbsHoExeSuccOutInterGnbIntraF - pmEbsHoExeSuccOutIntraGnbIntraF ) / ( pmEbsHoExeAttOutInterGnb + pmEbsHoExeAttOutIntraGnb - pmEbsHoExeAttOutInterGnbIntraF - pmEbsHoExeAttOutIntraGnbIntraF )

The collection of both node counters and EBS counters is managed from ENM using the PM Initiation and Collection (PMIC) application. All PM counters are stored in the same format of ROP files. All PM counters can be retrieved for post processing using the Ericsson Network IQ (ENIQ) tool, or for external processing via the 3GPP standards compliant PM Northbound Interface (PM NBI). Refer to the ENM Online Help CPI library for more information.

In NR, EBS counters (including flexible EBS counters) are enabled with the gNodeB feature EBS Counter Enabler , described in Section 10.3.18.

In LTE, flexible counters are enabled with the eNodeB feature Flexible Counters (Section 10.2.9), and the individual features which define flexible counters, for example, Basic Intelligent Connectivity (Section 10.2.1) and ASGH Framework (Section 10.2.5).

## 12.2 Performance Indicators - NSA

KPIs for NR NSA are provided in the CPI document Key Performance Indicators . In addition to those KPIs, the following performance indicators are useful for assessing NR NSA mobility.

Note that the feature Flexible Counters can be used to obtain KPIs which focus on EN-DC users; see Section 10.2.9 for more details.

The formulas given below are for the case of an FDD cell. Replace EUtranCellFDD with EUtranCellTDD for the case of TDD.

<!-- page: 433 -->

Table 12-1 - Performance Indicators - NSA

| Description   | EN-DC - B1 Reports per Configuration Proportion of EN-DC Event B1 reports per EN-DC Event B1 configuration. If a single frequency is being measured, this KPI indicates the proportion of the traffic on the LTE cell which has coverage from the NR frequency. However, if more than one frequency is configured for measurement in parallel, then the interpretation of this PI becomes less clear, because the denominator is incremented once per frequency contained in each RRC configuration message sent to the UE.   |
|---------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Formula       | 100% * EUtranCellFDD.pmB1MeasRepEndcConfig / EUtranCellFDD.pmMeasConfigB1Endc                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Description   | EN-DC - Setups per Received B1 Measurement Report The percentage of received B1 measurement reports that trigger EN-DC setup. If ENDCHO is enabled, the B1 report and the EN-DC setup can be counted on different cells. Therefore, this formula may not give an accurate result when used at the level of an individual cell. However, when aggregated over the source cell(s) and all possible ENDCHO target cells, the formula is accurate.                                                                                |
| Formula       | 100% * EUtranCellFDD.pmEndcSetupUeAtt / EUtranCellFDD.pmB1MeasRepEndcConfig                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| Description   | EN-DC - Setup Success Rate EN-DC setup success rate per LTE anchor cell or per cell relation. This PI includes only the successful preparation of the target NR cell. It does not capture the random access process which completes the setup from the UE perspective.                                                                                                                                                                                                                                                        |
| Formula       | Per Cell: 100% * EUtranCellFDD.pmEndcSetupUeSucc / EUtranCellFDD.pmEndcSetupUeAtt Per Relation: 100% * GUtranCellRelation.pmEndcSetupUeSucc / GUtranCellRelation.pmEndcSetupUeAtt                                                                                                                                                                                                                                                                                                                                             |
| Description   | EN-DC - Proportion of Setups per NR Cell Proportion of EN-DC setups that occur to each NR cell (from a given LTE cell). This KPI is impacted by both the coverage overlap and the endcB1MeasPriority values, as higher priority frequencies are more likely to be measured and used for setup.                                                                                                                                                                                                                                |
| Formula       | 100% * GUtranCellRelation.pmEndcSetupUeSucc / EUtranCellFDD.pmEndcSetupUeSucc                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Description   | EN-DC - Proportion of Setups per NR Cell (per Frequency ) Proportion of EN-DC setups that occur to each NR cell per NR frequency. This PI better indicates the coverage overlap of each NR cell on a particular frequency, but it can also be impacted by the presence of higher priority frequency layers. The numerator of this KPI can also be used independently, to check the absolute number of setups per cell relation.                                                                                               |
| Formula       | 100% * GUtranCellRelation.pmEndcSetupUeSucc / ∑ GUtranFreqRelation GUtranCellRelation.pmEndcSetupUeSucc                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Description   | EN-DC - Buffer-Based EN-DC Setup Percentage of EN-DC setups that are avoided by the DL and UL Buffer-Based EN-DC Setup functionality, see Section 10.2.1.8.                                                                                                                                                                                                                                                                                                                                                                   |
| Formula       | 100% * (1 - pmEndcSetupBufMonReport / pmEndcSetupBufMonConfig)                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| Description   | CAIMC - Number of Releases Number of Capability-Aware Idle Mode Control (CAIMC) releases that prioritize a particular LTE frequency as the highest (priority 7). Impacted by both the proportion of UEs which support EN- DC on the frequency and the CAIMC prioritization method used.                                                                                                                                                                                                                                       |
| Formula       | EUtranFreqRelation.pmEndcPrioritizedUe                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |

Table 12-1 - Performance Indicators - NSA

<!-- page: 434 -->

| Description   | EN-DC Triggered HO - Success Rate EN-DC triggered handover (ENDCHO) success rate, at the source LTE cell level or at the cell relation level.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
|---------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Formula       | Per Cell: 100% * EUtranCellFDD . pmCellHoPrepSuccLteInterFEndcHo / EUtranCellFDD . pmCellHoPrepAttLteInterFEndcHo * EUtranCellFDD . pmCellHoExeSuccLteInterFEndcHo / EUtranCellFDD . pmCellHoExeAttLteInterFEndcHo Per Relation: 100% * EUtranCellRelation . pmCellHoPrepSuccLteInterFEndcHo / EUtranCellRelation . pmCellHoPrepAttLteInterFEndcHo * EUtranCellRelation . pmCellHoExeSuccLteInterFEndcHo / EUtranCellRelation . pmCellHoExeAttLteInterFEndcHo                                                                                                                                                                                                                                                       |
| Description   | LTE HO without PSCell Change - Success Rate Success rate of LTE handovers that do not involve a PSCell change.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Formula       | 100% * NRCellCU.pmEndcMnHoPSCellKeepSucc / NRCellCU.pmEndcMnHoPSCellKeepAtt                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Description   | UE-initiated SN releases Some UE vendors require a mechanism to intentionally trigger an SN release, e.g. to save power when the UE screen is turned off. To do this, the UE sends an SCGFailureInformationNR (3GPP 36.331) message with the measResultFreqListNR r15 IE set as follows, so that the eNodeB understands that this is an intentional 'failure': • The ARFCN -ValueNR-r15 attribute is set to 0 • The pci -r15 attribute is set to 0 • The measResultCell -r15 attribute is empty The eNodeB counts such intentional 'failures' with this counter, and sends an X2AP: SGNB RELEASE REQUEST message to the gNodeB, containing the cause 'User Inactivity'. The gNodeB treats this as a normal release. |
| Formula       | EUtranCellFDD.pmRrcScgFailureArfcnNil                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |

## 12.3 Performance Indicators - SA

KPIs for NR SA are provided in the CPI document Key Performance Indicators . In addition to those KPIs, the following performance indicators are useful for assessing NR SA mobility.

Table 12-2 - Performance Indicators - SA

| Description   | LTE to NR Release with Redirect Number of times the feature NR Coverage-Triggered NR Session Continuity or Outgoing NR IRAT Handover triggers release-with-redirect from LTE to NR SA.                                                                  |
|---------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Formula       | EUtranCellFDD.pmUeCtxtRelSCNr The following counters provide a further breakdown according to the triggering event: pmUeCtxtRelSCNrA2Rsrp pmUeCtxtRelSCNrA2Rsrq pmUeCtxtRelSCNrB1Rsrp pmUeCtxtRelSCNrB1Rsrq pmUeCtxtRelSCNrB2Rsrp pmUeCtxtRelSCNrB2Rsrq |
| Description   | LTE to NR Handover Handover success rate from LTE to NR SA, for both MBB and voice, per relation.                                                                                                                                                       |
| Formula       | 100% * GUtranCellRelation.pmHoPrepSucc / GUtranCellRelation.pmHoPrepAtt * GUtranCellRelation.pmHoExeSucc / GUtranCellRelation.pmHoExeAtt                                                                                                                |

Table 12-2 - Performance Indicators - SA

<!-- page: 435 -->

Formula

| Description   | NR to LTE Release with Redirect Number of times release-with-redirect from NR to LTE is triggered                                                                                                                                                                 |
|---------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Formula       | By the feature Mobility Control at Poor Coverage : NRCellCU.pmRwrEutranUeSuccNrCoverage By the feature NR Remote Interference Management : NRCellCU.pmRwrEutranUeSuccRi By the feature Bandwidth-Triggered Inter-System Handover : NRCellCU . pmRwrEutranUeSuccTs |
| Description   | NR to NR Release with Redirect Number of times the release-with-redirect from NR to NR is triggered                                                                                                                                                               |
| Formula       | By the feature Mobility Control at Poor Coverage : NRCellCU.pmRwrIntraNrUeSuccCoverage By the feature NR Remote Interference Management : NRCellCU.pmRwrIntraNrUeSuccRi                                                                                           |

**Description NR to NR Handover (both intra and inter frequency)**

Handover success rate

Node counters

:  (per NRCellCU

)

100% *

(pmHoPrepSuccOutInterGnb + pmHoPrepSuccOutIntraGnb) /

(pmHoPrepAttOutInterGnb + pmHoPrepAttOutIntraGnb) *

(pmHoExeSuccOutInterGnb + pmHoExeSuccOutIntraGnb) /

(pmHoExeAttOutInterGnb + pmHoExeAttOutIntraGnb)

EBS counters:

(per NRCellCU

or NRCellRelation

)

100% *

(pmEbsHoPrepSuccOutInterGnb + pmEbsHoPrepSuccOutIntraGnb) /

(pmEbsHoPrepAttOutInterGnb + pmEbsHoPrepAttOutIntraGnb) *

(pmEbsHoExeSuccOutInterGnb + pmEbsHoExeSuccOutIntraGnb) /

(pmEbsHoExeAttOutInterGnb + pmEbsHoExeAttOutIntraGnb)

**EBS Counter Filters:**

The EBS formula above can be modified by applying filters.  For example:

Set the TrafficSteeringType filter to

TRAFFIC_STEERING_TYPE_MULTI_LAYER_COORDINATION to obtain the success rate for handovers due to Multi Layer Coordination (MLC).

**Description NR to NR Intra-Frequency Handover**

Handover success rate

Formula EBS counters:

(per NRCellCU

or NRCellRelation

)

100% *

(pmEbsHoPrepSuccOutInterGnbIntraF + pmEbsHoPrepSuccOutIntraGnbIntraF) /

(pmEbsHoPrepAttOutInterGnbIntraF + pmEbsHoPrepAttOutIntraGnbIntraF) *

(pmEbsHoExeSuccOutInterGnbIntraF + pmEbsHoExeSuccOutIntraGnbIntraF) /

(pmEbsHoExeAttOutInterGnbIntraF + pmEbsHoExeAttOutIntraGnbIntraF)

<!-- page: 436 -->

| Description   | NR to NR Inter-Frequency Handover Handover success rate                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
|---------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Formula       | EBS counters: (per NRCellCU or NRCellRelation ) 100 * ( pmEbsHoPrepSuccOutInterGnb + pmEbsHoPrepSuccOutIntraGnb - pmEbsHoPrepSuccOutInterGnbIntraF - pmEbsHoPrepSuccOutIntraGnbIntraF ) / ( pmEbsHoPrepAttOutInterGnb + pmEbsHoPrepAttOutIntraGnb - pmEbsHoPrepAttOutInterGnbIntraF - pmEbsHoPrepAttOutIntraGnbIntraF ) * ( pmEbsHoExeSuccOutInterGnb + pmEbsHoExeSuccOutIntraGnb - pmEbsHoExeSuccOutInterGnbIntraF - pmEbsHoExeSuccOutIntraGnbIntraF ) / ( pmEbsHoExeAttOutInterGnb + pmEbsHoExeAttOutIntraGnb - pmEbsHoExeAttOutInterGnbIntraF - pmEbsHoExeAttOutIntraGnbIntraF ) |
| Description   | MCPC NR to LTE Handover Handover success rate                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Formula       | EBS counters: (per NRCellCU or EUtranCellRelation ) 100% * pmEbsHoPrepSuccOutEutranPoorCov / pmEbsHoPrepAttOutEutranPoorCov * pmEbsHoExeSuccOutEutranPoorCov / pmEbsHoExeAttOutEutranPoorCov                                                                                                                                                                                                                                                                                                                                                                                        |
| Description   | Bandwidth-Triggered Inter-System Handover (BWTISHO) - NR to LTE Handover success rate                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| Formula       | Node counters : (per NRCellCU ) 100% * pmHoPrepSuccOutEutranTs /pmHoPrepAttOutEutranTs * pmHoExeSuccOutEutranTs /pmHoExeAttOutEutranTs EBS counters: (per NRCellCU or EUtranCellRelation ) Set the TrafficSteeringType filter to TRAFFIC_STEERING_TYPE_BW_TRIGGERED_INTER_SYSTEM_HANDOVER and use: 100% * pmEbsHoPrepSuccOutEutran / pmEbsHoPrepAttOutEutran * pmEbsHoExeSuccOutEutran / pmEbsHoExeAttOutEutran Note that BWTISHO using RwR rather than HO is not captured by the above counters. Instead, BWTISHO RwR events increment NRCellCU . pmRwrEutranUeSuccTs and also     |
| Description   | EPS Fallback for IMS Voice - NR to LTE Number of times the feature EPS Fallback for IMS Voice triggers release-with-redirect                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Formula       | NRCellCU.pmRwrEutranUeSuccEpsfb                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |

# 13 Appendix 4 - Configuration Profiles and UE Groups

Configuration profiles are used in the gNodeB to manage the configuration of certain features. They enable related attributes to be grouped and configured together across multiple MO instances. The concept is best explained with examples.

<!-- page: 437 -->

Take the example in Figure 13-1. The node contains five cells. As indicated by the color, attribute_1 is set to a different value in each cell. Attributes 2 to 5 are set to one value in cells 1 and 2, and another value in cells 3, 4 and 5. In this case the attributes are contained within the cell class itself and must therefore be set to the correct value in every cell instance.

![Figure on page 437](5G_Mobility_and_Traffic_Management_Guideline_images/page_437_image_002.png)

Figure 13-1 - All attributes located within the cell class

An alternative way to structure these attributes is to use configuration profiles, as shown in Figure 13-2. Attribute_1, which must be set differently in every cell, remains within the cell class, and is set per individual cell instance. However, the other attributes have been moved into a configuration profile class. In this example, two instances of the profile class are created: one for the red settings and one for the blue settings. The profile instance used by each cell is indicated by the profileRef attribute, which points to the instance. With this method there is less duplication. If a blue attribute needs to be changed, then it is only changed in one place, not three. It is therefore easier to define standard sets of parameters and apply them consistently to all cells or to a subset of cells. For example, the red profile could be applied to all high-band cells and the blue profile to all mid-band cells.

![Figure on page 437](5G_Mobility_and_Traffic_Management_Guideline_images/page_437_image_003.png)

Figure 13-2 - Some attributes moved into a configuration profile class

The above example shows how configuration profiles are used at the cell level. Configuration profiles are also used at other levels, for example at the frequency relation level. In this case, each frequency relation would point to a specific profile instance.

<!-- page: 438 -->

Furthermore, configuration profiles are used to manage attributes that should be set differently depending on how the cell is being used. Consider the attributes used by the feature Mobility Control at Poor Coverage (MCPC). Some of these attributes should be set differently depending on whether the cell is used as a PCell (SA) or a PSCell (NSA). For this reason, two profile classes are defined for cell level MCPC attributes: Mcpc PCell Profile and Mcpc PSCell Profile .

Configuration profiles are also available to selectively apply different mobility configurations to UEs that fall into different groups. In this case, the class name ends with UeCfg.

Figure 13-3 shows an example for the McpcPCellProfile class and the child class McpcPCellProfileUeCfg , which are used to apply cell level MCPC attributes selectively to different cells and UE groups, for UEs that use the cell as a PCell (SA).

- An instance McpcPCellProfile = Default is created automatically when the parent ( Mcpc ) is created, unless created manually in same transaction. To provide different settings for different cells, create additional McpcPCellProfile instances. The McpcPCellProfile instances are referenced from NRCellCU using mcpcPCellProfileRef . Many cells can reference the same profile instance.

- An instance McpcPCellProfileUeCfg = Base is created automatically when the parent ( McpcPCellProfile ) is created, unless created manually in same transaction. To provide different settings for different UE groups within a cell, create additional McpcPCellProfileUeCfg instances under the corresponding parent instance. However, these other instances can only be used if the feature User and Service Specific Mobility is active. If not, only the Base instance is used, regardless of the UE grouping configuration; the other instances are ignored. Similar licensed features govern the use of UE groups for other gNodeB functions.

![Figure on page 438](5G_Mobility_and_Traffic_Management_Guideline_images/page_438_image_002.png)

Figure 13-3 - McpcPCellProfile Configuration Example

<!-- page: 439 -->

For most of the configuration profiles in this document, if the profile reference is not explicitly set, the system automatically sets it to the Default profile instance, and it is never empty. However, there are some cases where this automatic behavior is not implemented, and it is possible for the profile reference to be empty. In such cases, no profile instance applies, so the attributes within the profile use the default values from the relevant attribute or structure definition.

The most relevant configuration profile classes for mobility and traffic steering are shown, together with the associated container classes, in Figure 13-4.

![Figure on page 439](5G_Mobility_and_Traffic_Management_Guideline_images/page_439_image_002.png)

Figure 13-4 - Configuration Profiles for Mobility

<!-- page: 440 -->

# 14 Appendix 5 - Release History

This section summarizes the major changes and impacted sections in this document release. Note that there are also many smaller changes and updates which are not listed here in the table.

Table 14-1 - Changes per Release

| Release                    | Comments                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
|----------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 2026 Q2 (this release)     | • Updated support for up to 16 segments for LTE Uplink RRC Message Segmentation (Section 6.2.1) • Added optional mobility robustness support with release-with-redirect after a failed outgoing handover from LTE to SA (Section 8.3.2) • Added SS_SINR as a triggering quantity for event B1/B2, and support for evaluating an additional reported quantity for Outgoing NR IRAT Handover (Sections 8.3.2.1 & 8.3.2.2 & 11.2.3.1 & 11.2.3.2) • Updated NR PCI Conflict Reporting with PCI conflict mitigation (Section 10.2.21) • Updated criterion checks for Multi-Layer Coordination (Section 10.3.5.1) • Updated the description of Bandwidth Triggered Inter-System Handover (Section 10.3.5.3) • Updated the description of NR Data-Aware Mobility (Section 10.3.26) • Introduced feature NR Preemptive Mobility Management (Section 10.3.35) • Introduced feature Load-Based Prioritized UE Handling (Section 10.3.36) • Introduced feature NR Automated Neighbor Relations for NR-DC (Section 10.3.37) • Corrected the MO name for the additional SINR check for Multi-Layer Coordination (Section 11.2.11.4) • Updated feature NR Automated Neighbor Relations (Section 10.3.16) |
| 2026 Q1 (previous release) | • Introduced features for Low Latency Mobility for Public or Dedicated RAN (Sections 4.8.5.3 & 8.3.4 & 10.3.34 & 11.2.17). • Added impact of NR High-Load Handling for VoNR (Sections 8.3.13.1 & 8.3.14.1) • Added reference to CPI Ericsson Reduced Capability User Guide (Section 10.3.25) • Introduced feature Switched Uplink with FDD and TDD Uplink MIMO (Section 10.3.33)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |

Table 14-1 - Changes per Release
