# Ericsson agent v1.4.8 supervisor-local entity verification patch

This patch changes the Ericsson agent/graph API only. It does not modify the Nokia agent.

It is cumulative over the v1.4.4 package and also retains the previously prepared streamed-answer citation repair/source-selection improvements.

## What it adds

- `GET /tools/counter/context`: exact Ericsson PmCounter/EbsCounter resolution without Counter -> Feature traversal.
- `GET /tools/parameter/context`: exact Ericsson MOAttribute resolution without MOAttribute -> Feature traversal.
- `SUPERVISOR_LOCAL_ENTITY_TASK` handling for supervisor-initiated cross-vendor metric/parameter verification.
- Multiple local Ericsson candidates can be resolved in one request.
- Supervisor-local tasks ignore prior conversation history and skip LLM query rewrite.
- Knowledge-base queries use compact graph-resolved Ericsson identities rather than the full supervisor orchestration prompt.
- If no local candidate exists, the task does not fall through into generic Feature graph traversal.

No Neo4j reload and no Ericsson KB re-ingest are required. Restart the Ericsson agent and Ericsson graph API so the new code/endpoints are loaded.

## Files replaced

- `VERSION`
- `CHANGELOG.md`
- `agentInstruction.txt`
- `agent_core/clients.py`
- `agent_core/graph_tools.py`
- `agent_core/workflow.py`
- `graph_api/repository.py`
- `graph_api/routes/entities.py`
- `tests/test_graph_integration.py`

Cumulative compatibility files retained from the streaming-integrity update:

- `agent_core/synthesis.py`
- `agent_core/validation.py`
- `agent_service/routes/query.py`

## Install

From the Ericsson project root:

```bash
cp -a agent_core agent_core.before_v1.4.8
cp -a graph_api graph_api.before_v1.4.8
cp agentInstruction.txt agentInstruction.before_v1.4.8.txt
unzip -o ericsson_agent_v1.4.8_directional_entity_update.zip
python -m compileall -q agent_core agent_service graph_api tests
PYTHONPATH=. pytest -q
```

Then restart the Ericsson agent and graph API with your existing service scripts.

Expected logs for a supervisor-local counter verification:

```text
[SUPERVISOR LOCAL ENTITY TASK] isolated_history=true query_rewrite=false
[AGENT GRAPH_PLAN] calls=['counter_context', ...]
[AGENT KB_CALL] operation=entity_profile_search ... query='NRCellDU.pm...'
```

For parameters the graph plan uses `parameter_context`.
