#!/usr/bin/env python3
"""Historical Nokia-compatible alias that starts the Ericsson KB API."""
from local_kb_api import app
from agent_core.config import KB_API_PORT, SERVICE_BIND_HOST

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host=SERVICE_BIND_HOST, port=KB_API_PORT)
