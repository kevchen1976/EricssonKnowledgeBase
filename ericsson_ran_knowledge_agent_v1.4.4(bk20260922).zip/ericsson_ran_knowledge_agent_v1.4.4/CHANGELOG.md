# Changelog

## 1.4.8 supervisor-local entity verification

- Added `/tools/counter/context` and `/tools/parameter/context` for exact Counter/MOAttribute resolution without Feature traversal.
- Added `SUPERVISOR_LOCAL_ENTITY_TASK` handling for directional cross-vendor metric/parameter verification initiated by the supervisor.
- Supervisor-local tasks skip conversational query rewrite/history and search Ericsson documentation with compact graph-resolved local identities rather than the full orchestration prompt.
- Multiple Ericsson candidate counters or MOAttributes can be resolved in one verification request.
- If no concrete local candidate is supplied, the task does not fall through into generic Feature relationship graph traversal.
- Includes the v1.4.6 streamed-answer citation-repair behavior and the v1.4.7 source-selection/KB-first instruction updates.

## 1.4.4 Graph-authoritative relationship answering

- Neo4j is now explicitly the primary/authoritative evidence source for supported Feature/Counter/Parameter/Alarm relationship existence.
- Agent instructions require graph-first retrieval and graph-first answer ordering for relationship questions.
- Vector/BM25 evidence is supplementary for relationship existence and remains authoritative for procedures, troubleshooting, correction instructions and descriptive explanation.
- Vector results may no longer add extra relationship entities when Neo4j has returned a deterministic relationship set.
- A resolved graph entity with no current edge is reported as no graph relationship rather than being replaced by semantic co-occurrence.
- Document-only fallback is allowed when graph retrieval fails or is ambiguous, but must be explicitly qualified as not graph-verified.
- Graph context now carries an explicit `primary_for_supported_relationships` authority policy into answer synthesis.

## 1.4.3 Neo4j database-target readiness and diagnostics

- Graph `/ready` now executes a read against the configured Neo4j database instead of checking Bolt connectivity only.
- `DatabaseNotFound` / `Graph not found` is surfaced as an actionable configuration error.
- Graph tool endpoints return HTTP 503 for an invalid database target rather than an opaque 500.
- Documentation clarifies that `NEO4J_DATABASE` may be left blank to use the server default and is commonly `neo4j`.

## 1.4.2 Graph entity resolution hotfix

- Fixed Neo4j Cypher alias scoping in PM Counter, MOAttribute and FmAlarmType resolvers.
- Graph tool planning now passes exact counter/parameter identifiers (for example `pmRrcConnCatmMax`) instead of the full natural-language question.
- Added query-rewrite guidance to preserve Feature-to-Counter relationship intent.
- Added regression tests for exact graph tool arguments and resolver query scoping.

## 1.4.1 Graph tracing and component-aware frontend readiness

- Added request-correlated Graph API HTTP, tool, client, and Cypher query traces.
- Added rotating `ericsson_graph_api.log` and `ericsson_graph_queries.log` files with bounded query/parameter previews and credential redaction.
- Added `X-Request-ID` propagation on Graph API responses for end-to-end Agent -> Graph correlation.
- Fixed the frontend Knowledge Base indicator to use `kb_ready` rather than the aggregate `/ready` HTTP status.
- Added separate Graph ready/not-ready status and a degraded-services state when KB search remains usable.
- Exposed Graph log locations in Graph API health/readiness payloads.

## 1.4.0 Ericsson-native graph-assisted agent

- Enabled the Ericsson Neo4j Graph API for Feature-centred relationship tools.
- Added high-level Feature/Counter, Feature/Parameter and Feature/Alarm endpoints while preserving native edge types as metadata.
- Added reverse lookups and Counter -> Feature -> Parameter / Parameter -> Feature -> Counter multi-hop tools.
- Added graph-first alarm resolution followed by exact `specificProblem` OpenSearch retrieval for correction instructions.
- Added graph-related Feature document enrichment, graph-aware validation and graph tool audit records.
- Kept Feature-to-Feature questions in semantic/document search by design.
- Removed embedded credentials from the deployment template.


## 1.3.7 consolidated production distribution

- Canonical metadata comments are ignored by the ingestion parser, preventing a metadata-only `Document Overview` parent.

- Nokia-compatible WebSocket and SSE answer streaming.
- FastAPI 0.141 route introspection compatibility.
- Filesystem-only manifest routing, with OpenSearch parent and child indexes.
- Numbered Ericsson section headings are authoritative parent boundaries.
- Full-parent evidence image metadata recovery, asset serving and frontend rendering.
- Explicit 32K Ollama context on all LLM requests.
- Native Ollama timing trace and separate bounded client trace.
- Redis memory, query rewrite and SQLite audit parity with the Nokia agent.
- Strict embedding input-length preflight.
- Duplicate preparation implementation and patch/test artifacts removed.

## Preparation compatibility

Use Ericsson KB Preparation 1.1.2 or later. It fixes Docling reading order,
repairs malformed headings, removes front matter/footer chrome, canonicalizes
numbered outlines and generates filesystem routing manifests.
