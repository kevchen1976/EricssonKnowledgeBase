"""FastAPI assembly for the standalone Ericsson RAN knowledge agent."""
from __future__ import annotations

import importlib
import logging
from contextlib import asynccontextmanager

from fastapi import APIRouter, FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from agent_core.constants import PACKAGE_VERSION
from agent_core.settings import PROJECT_ROOT, get_settings

from .lifecycle import shutdown, startup

logger = logging.getLogger("ericsson_agent.web")


@asynccontextmanager
async def lifespan(_app: FastAPI):
    """Run service startup/shutdown using FastAPI's lifespan interface."""
    await startup()
    try:
        yield
    finally:
        await shutdown()


def _router_from(module_name: str, *, expected_path: str) -> APIRouter:
    """Load a completed route module and reject a partially initialized router."""
    module = importlib.import_module(module_name)
    router = getattr(module, "router", None)
    if not isinstance(router, APIRouter):
        raise RuntimeError(f"{module_name} does not expose an APIRouter named 'router'")

    paths = {getattr(route, "path", "") for route in router.routes}
    if expected_path not in paths:
        raise RuntimeError(
            f"{module_name} router is incomplete: expected {expected_path!r}; "
            f"loaded paths={sorted(paths)!r}"
        )
    return router


def create_app() -> FastAPI:
    """Build the API only after all router modules can be imported completely."""
    application = FastAPI(
        title="Ericsson RAN Knowledge Agent",
        version=PACKAGE_VERSION,
        description="Standalone Ericsson vendor agent with a stable API for a later supervisor.",
        lifespan=lifespan,
    )
    application.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=False,
        allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
        allow_headers=["*"],
    )

    # Import route modules only while create_app() is running.  Combined with
    # agent_service.__init__'s lazy app export, this prevents application
    # assembly from racing a caller that is importing agent_service.routes.*.
    query_router = _router_from(
        "agent_service.routes.query", expected_path="/query/stream"
    )
    system_router = _router_from(
        "agent_service.routes.system", expected_path="/health"
    )
    websocket_router = _router_from(
        "agent_service.routes.websocket", expected_path="/ws/stream"
    )

    application.include_router(query_router)
    application.include_router(system_router)
    application.include_router(websocket_router)

    # FastAPI >= 0.137 preserves included routers in app.routes as internal
    # _IncludedRouter nodes.  Those nodes intentionally do not expose each
    # child path via route.path, so app.routes must not be flattened manually
    # to validate registration.  OpenAPI is the supported traversal for HTTP
    # routes; the WebSocket source router was already validated by _router_from.
    http_paths = set(application.openapi().get("paths", {}))
    required_http = {"/query", "/query/stream", "/health", "/ready", "/capabilities"}
    missing_http = sorted(required_http - http_paths)
    if missing_http:
        raise RuntimeError(
            "Ericsson HTTP route registration incomplete: " + ", ".join(missing_http)
        )

    # Serve prepared Markdown assets (figures/images) from the Agent origin too.
    # The KB API already rewrites evidence image links to /kb-assets/...; mounting
    # the same prepared Markdown root here lets the browser render those URLs
    # directly from port 8100 instead of depending on a cross-origin KB URL.
    settings = get_settings()
    asset_mount = "/" + settings.kb_asset_url_prefix.strip("/")
    if asset_mount != "/":
        application.mount(
            asset_mount,
            StaticFiles(directory=str(settings.markdown_root), check_dir=False),
            name="kb-assets",
        )
        application.state.kb_asset_root = str(settings.markdown_root)
        application.state.kb_asset_mount = asset_mount
        logger.info(
            "[AGENT WEB] Mounted KB evidence assets %s -> %s",
            asset_mount,
            settings.markdown_root,
        )
    else:
        application.state.kb_asset_root = ""
        application.state.kb_asset_mount = ""
        logger.warning("[AGENT WEB] KB asset mount disabled because prefix resolved to '/'")

    static_root = PROJECT_ROOT / "static"
    root_index = PROJECT_ROOT / "index.html"

    if (static_root / "index.html").is_file():
        application.mount("/", StaticFiles(directory=str(static_root), html=True), name="static")
        application.state.frontend_root = str(static_root)
        logger.info("[AGENT WEB] Mounted frontend from %s", static_root)
    elif root_index.is_file():
        application.mount("/", StaticFiles(directory=str(PROJECT_ROOT), html=True), name="static")
        application.state.frontend_root = str(PROJECT_ROOT)
        logger.info("[AGENT WEB] Mounted frontend from %s", PROJECT_ROOT)
    else:
        application.state.frontend_root = ""
        logger.warning(
            "[AGENT WEB] Frontend not mounted; expected %s or %s",
            static_root / "index.html",
            root_index,
        )

    return application


app = create_app()
