"""Ericsson agent service package.

Expose ``app`` lazily so importing a route module does not assemble the FastAPI
application while that route module is still being imported.  This avoids
partially initialized/empty APIRouter objects under circular import orders.
"""
from __future__ import annotations

from typing import Any

__all__ = ["app"]


def __getattr__(name: str) -> Any:
    if name == "app":
        from .application import app

        globals()["app"] = app
        return app
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
