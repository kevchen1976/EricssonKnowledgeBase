"""Redis-backed conversation history for the standalone Ericsson service.

The implementation intentionally follows the Nokia agent's read/append/write
session contract.  Ericsson uses its own Redis key prefix, so both agents can
share one Redis deployment without sharing conversation state.
"""
from __future__ import annotations

import importlib
import json
import logging
import threading
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any, Iterable, List, Optional

logger = logging.getLogger("ericsson_agent")


class SessionStoreError(RuntimeError):
    """Raised when configured Redis-backed session memory is unavailable."""


@dataclass(frozen=True)
class Turn:
    query: str
    answer: str
    created_at: str

    @classmethod
    def create(cls, query: str, answer: str, *, answer_chars: int = 4000) -> "Turn":
        return cls(
            query=str(query or "").strip(),
            answer=str(answer or "")[: max(1, int(answer_chars))],
            created_at=datetime.now(timezone.utc).isoformat(),
        )

    @classmethod
    def from_value(cls, value: Any) -> "Turn | None":
        if not isinstance(value, dict):
            return None
        query = str(value.get("query") or "").strip()
        answer = str(value.get("answer") or "").strip()
        if not query and not answer:
            return None
        created_at = str(value.get("created_at") or datetime.now(timezone.utc).isoformat())
        return cls(query=query, answer=answer, created_at=created_at)


class SessionStore:
    """Persist a bounded conversation history in Redis with sliding TTL."""

    def __init__(
        self,
        *,
        enabled: bool = True,
        max_turns: int = 5,
        ttl_seconds: int = 3600,
        stored_answer_chars: int = 4000,
        redis_url: str = "",
        redis_host: str = "localhost",
        redis_port: int = 6379,
        redis_db: int = 0,
        redis_password: str = "",
        redis_ssl: bool = False,
        key_prefix: str = "ericsson:session:",
        socket_timeout: float = 5.0,
        connect_timeout: float = 3.0,
        client: Any = None,
    ) -> None:
        self.enabled = bool(enabled)
        self.max_turns = max(1, int(max_turns))
        self.ttl_seconds = max(1, int(ttl_seconds))
        self.stored_answer_chars = max(1, int(stored_answer_chars))
        self.redis_url = str(redis_url or "").strip()
        self.redis_host = str(redis_host or "localhost")
        self.redis_port = int(redis_port)
        self.redis_db = int(redis_db)
        self.redis_password = str(redis_password or "")
        self.redis_ssl = bool(redis_ssl)
        self.key_prefix = str(key_prefix or "ericsson:session:").strip().rstrip(":")
        self.socket_timeout = max(0.1, float(socket_timeout))
        self.connect_timeout = max(0.1, float(connect_timeout))
        self._client = client
        self._lock = threading.RLock()
        self._last_ping_ok: Optional[bool] = None
        self._last_error: str = ""

    @property
    def backend(self) -> str:
        return "redis" if self.enabled else "disabled"

    @property
    def last_ping_ok(self) -> Optional[bool]:
        return self._last_ping_ok

    @property
    def last_error(self) -> str:
        return self._last_error

    def key_for_session(self, session_id: str) -> str:
        """Return the Ericsson namespaced Redis key for diagnostics/tests."""
        return f"{self.key_prefix}:{session_id}"

    def _client_or_raise(self) -> Any:
        if self._client is not None:
            return self._client
        try:
            redis_module = importlib.import_module("redis")
        except ImportError as exc:
            raise SessionStoreError(
                "Redis session memory is enabled but the 'redis' Python package is not installed. "
                "Install requirements.txt before starting the Ericsson Agent API."
            ) from exc

        common: dict[str, Any] = {
            "decode_responses": True,
            "socket_timeout": self.socket_timeout,
            "socket_connect_timeout": self.connect_timeout,
            "health_check_interval": 30,
        }
        try:
            if self.redis_url:
                self._client = redis_module.Redis.from_url(self.redis_url, **common)
            else:
                self._client = redis_module.Redis(
                    host=self.redis_host,
                    port=self.redis_port,
                    db=self.redis_db,
                    password=self.redis_password or None,
                    ssl=self.redis_ssl,
                    **common,
                )
        except Exception as exc:
            raise SessionStoreError(f"Could not create Redis client: {exc}") from exc
        return self._client

    def ping(self) -> bool:
        if not self.enabled:
            self._last_ping_ok = None
            self._last_error = ""
            return False
        try:
            ok = bool(self._client_or_raise().ping())
            self._last_ping_ok = ok
            self._last_error = "" if ok else "Redis PING returned false"
            return ok
        except Exception as exc:
            self._last_ping_ok = False
            self._last_error = str(exc)
            if isinstance(exc, SessionStoreError):
                raise
            raise SessionStoreError(f"Could not connect to Redis: {exc}") from exc

    def get(self, session_id: str | None) -> List[Turn]:
        """Retrieve and decode session history from Redis."""
        if not self.enabled or not session_id:
            return []
        key = self.key_for_session(session_id)
        logger.info("[REDIS] Getting history for session=%s key=%s", session_id, key)
        try:
            data = self._client_or_raise().get(key)
        except Exception as exc:
            self._last_ping_ok = False
            self._last_error = str(exc)
            if isinstance(exc, SessionStoreError):
                raise
            raise SessionStoreError(f"Redis GET failed for session {session_id}: {exc}") from exc
        if not data:
            logger.info("[REDIS] No data found for session=%s", session_id)
            return []
        try:
            decoded = json.loads(data)
        except (TypeError, json.JSONDecodeError):
            logger.warning("[REDIS] Corrupted session data for session=%s; ignoring it", session_id)
            return []
        if not isinstance(decoded, list):
            logger.warning("[REDIS] Session payload is not a list for session=%s; ignoring it", session_id)
            return []
        turns = [turn for item in decoded if (turn := Turn.from_value(item)) is not None]
        if len(turns) > self.max_turns:
            turns = turns[-self.max_turns :]
        self._last_ping_ok = True
        self._last_error = ""
        logger.info("[REDIS] Parsed %d exchange(s) for session=%s", len(turns), session_id)
        return turns

    def set(self, session_id: str | None, turns: Iterable[Turn | dict[str, Any]]) -> None:
        """Store bounded history and refresh its expiry, like the Nokia agent."""
        if not self.enabled or not session_id:
            return
        normalized: list[Turn] = []
        for value in turns:
            if isinstance(value, Turn):
                normalized.append(value)
            elif (turn := Turn.from_value(value)) is not None:
                normalized.append(turn)
        bounded = normalized[-self.max_turns :]
        key = self.key_for_session(session_id)
        payload = json.dumps([asdict(turn) for turn in bounded], ensure_ascii=False)
        logger.info(
            "[REDIS] Storing %d exchange(s) for session=%s ttl_seconds=%d key=%s",
            len(bounded),
            session_id,
            self.ttl_seconds,
            key,
        )
        try:
            client = self._client_or_raise()
            stored = client.set(key, payload, ex=self.ttl_seconds)
            if stored is False:
                raise SessionStoreError(f"Redis SET returned false for session {session_id}")
            # Keep the same read-after-write verification used by Nokia.
            verify = client.get(key)
        except Exception as exc:
            self._last_ping_ok = False
            self._last_error = str(exc)
            if isinstance(exc, SessionStoreError):
                raise
            raise SessionStoreError(f"Redis SET failed for session {session_id}: {exc}") from exc
        if not verify:
            self._last_ping_ok = False
            self._last_error = f"Redis verification failed for session {session_id}"
            raise SessionStoreError(self._last_error)
        self._last_ping_ok = True
        self._last_error = ""
        logger.info("[REDIS] Verified session=%s stored successfully", session_id)

    def add(self, session_id: str | None, query: str, answer: str) -> None:
        """Append one exchange using Nokia's read/append/write behavior."""
        if not self.enabled or not session_id:
            return
        with self._lock:
            history = self.get(session_id)
            history.append(
                Turn.create(query, answer, answer_chars=self.stored_answer_chars)
            )
            self.set(session_id, history)

    def clear(self, session_id: str) -> bool:
        if not self.enabled or not session_id:
            return False
        key = self.key_for_session(session_id)
        logger.info("[REDIS] Clearing session=%s key=%s", session_id, key)
        try:
            deleted = int(self._client_or_raise().delete(key) or 0)
        except Exception as exc:
            self._last_ping_ok = False
            self._last_error = str(exc)
            if isinstance(exc, SessionStoreError):
                raise
            raise SessionStoreError(f"Redis DELETE failed for session {session_id}: {exc}") from exc
        self._last_ping_ok = True
        self._last_error = ""
        return deleted > 0

    def close(self) -> None:
        client = self._client
        if client is None:
            return
        close = getattr(client, "close", None)
        if callable(close):
            try:
                close()
            except Exception:
                logger.exception("[REDIS] Error while closing Redis client")


def format_history(
    turns: Iterable[Turn | dict[str, Any]],
    *,
    max_turns: int = 5,
    answer_chars: int = 2000,
) -> str:
    """Format history as the Nokia rewrite and synthesis prompts expect."""
    recent = list(turns)[-max(1, int(max_turns)) :]
    lines: list[str] = []
    answer_limit = max(1, int(answer_chars))
    for value in recent:
        if isinstance(value, Turn):
            query, answer = value.query, value.answer
        elif isinstance(value, dict):
            query = str(value.get("query") or "")
            answer = str(value.get("answer") or "")
        else:
            continue
        lines.append(f"User: {query}\nAssistant: {answer[:answer_limit]}")
    return "\n".join(lines)
