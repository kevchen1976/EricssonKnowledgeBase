"""Optional allow-list authentication compatible with the Nokia API header."""
from __future__ import annotations

from typing import Optional

from fastapi import Header, HTTPException, status

from agent_core.settings import get_settings


def authorize(x_user_email: Optional[str] = Header(default=None, alias="X-User-Email")) -> Optional[str]:
    settings = get_settings()
    if not settings.auth_enabled:
        return x_user_email
    if not x_user_email:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="X-User-Email header is required")
    allowed = {value.casefold() for value in settings.allowed_emails}
    if allowed and x_user_email.casefold() not in allowed:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="User is not allowed to access this agent")
    return x_user_email
