"""Agent API startup and shutdown hooks."""
from __future__ import annotations

from .state import get_state


async def startup() -> None:
    """Initialize the Nokia-aligned Redis session dependency."""
    state = get_state()
    if not state.settings.session_memory_enabled:
        state.logger.info("[REDIS] Session memory is disabled")
        return
    try:
        if not state.sessions.ping():
            raise RuntimeError("Redis PING returned false")
        endpoint = (
            "configured REDIS_URL"
            if state.settings.redis_url
            else f"{state.settings.redis_host}:{state.settings.redis_port}"
        )
        state.logger.info(
            "[REDIS] Connected successfully endpoint=%s db=%d key_prefix=%s ttl_seconds=%d max_history=%d",
            endpoint,
            state.settings.redis_db,
            state.settings.redis_key_prefix,
            state.settings.session_ttl_seconds,
            state.settings.max_session_history,
        )
    except Exception as exc:
        # The process remains available for diagnostics and stateless calls,
        # while /ready reports 503 until Redis is restored.
        state.logger.error(
            "[REDIS] Could not connect to Redis. Session memory will fail: %s",
            exc,
        )


async def shutdown() -> None:
    state = get_state()
    state.sessions.close()
    state.logger.info("[REDIS] Session client closed")
