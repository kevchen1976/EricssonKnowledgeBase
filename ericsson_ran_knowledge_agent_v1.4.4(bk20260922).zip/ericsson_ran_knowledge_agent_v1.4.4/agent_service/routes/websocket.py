"""Nokia-compatible WebSocket streaming endpoint for Ericsson queries."""
from __future__ import annotations

import asyncio
from typing import Optional

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from agent_core.contracts import QueryRequest
from agent_core.settings import get_settings

from ..state import get_state
from .query import iter_query_events

router = APIRouter()


def _websocket_user(email: str | None) -> Optional[str]:
    settings = get_settings()
    value = str(email or "").strip()
    if not settings.auth_enabled:
        return value or None
    if not value:
        raise PermissionError("Email is required when Ericsson Agent authentication is enabled")
    allowed = {item.casefold() for item in settings.allowed_emails}
    if allowed and value.casefold() not in allowed:
        raise PermissionError("User is not allowed to access this agent")
    return value


@router.websocket("/ws/stream")
async def websocket_stream(websocket: WebSocket) -> None:
    """Stream workflow/chunk/done messages using Nokia's browser transport."""
    await websocket.accept()
    logger = get_state().logger
    ping_task: asyncio.Task[None] | None = None

    async def send_pings() -> None:
        try:
            while True:
                await asyncio.sleep(25)
                await websocket.send_json({"type": "ping"})
        except Exception:
            return

    ping_task = asyncio.create_task(send_pings())
    try:
        data = await websocket.receive_json()
        if not isinstance(data, dict):
            await websocket.send_json({"type": "error", "content": "Invalid request payload"})
            return

        query = str(data.get("query") or "").strip()
        if not query:
            await websocket.send_json({"type": "error", "content": "Empty query"})
            return

        try:
            user_email = _websocket_user(data.get("email"))
        except PermissionError as exc:
            logger.warning("[WEBSOCKET AUTH] rejected email=%s reason=%s", data.get("email") or "", exc)
            await websocket.send_json({"type": "error", "content": str(exc)})
            await websocket.close(code=1008)
            return

        request = QueryRequest(
            query=query,
            session_id=data.get("session_id") or None,
            limit=data.get("limit"),
            include_evidence=bool(data.get("include_evidence", True)),
        )
        logger.info(
            "[WEBSOCKET START] session_id=%s user_email=%s include_evidence=%s query=%r",
            request.session_id or "",
            user_email or "",
            request.include_evidence,
            request.query,
        )

        async for event in iter_query_events(request, user_email):
            await websocket.send_json(event)

        logger.info(
            "[WEBSOCKET COMPLETE] session_id=%s user_email=%s",
            request.session_id or "",
            user_email or "",
        )
    except WebSocketDisconnect:
        logger.info("[WEBSOCKET] client disconnected")
    except Exception as exc:
        logger.exception("[WEBSOCKET ERROR] error=%s", exc)
        try:
            await websocket.send_json(
                {"type": "error", "content": f"Ericsson streaming request failed: {exc}"}
            )
        except Exception:
            pass
    finally:
        if ping_task is not None and not ping_task.done():
            ping_task.cancel()
            try:
                await ping_task
            except asyncio.CancelledError:
                pass
