"""FastAPI route groups.

Keep this package initializer intentionally side-effect free.  Importing route
modules here can create partially-initialized APIRouter objects when
agent_service.application is imported through agent_service.__init__.  Nokia's
service uses the same side-effect-free pattern.
"""
