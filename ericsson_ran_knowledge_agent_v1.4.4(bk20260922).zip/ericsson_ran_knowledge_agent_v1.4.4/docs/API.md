# API

## Non-streaming agent query

```bash
curl -s -X POST http://localhost:8100/query \
  -H 'Content-Type: application/json' \
  -d '{
    "session_id": "ericsson-example",
    "query": "What are the correction instructions for Resource Allocation Failure alarm?",
    "limit": 5,
    "include_evidence": true
  }'
```

The agent can combine OpenSearch evidence with Neo4j graph relationships. For
an alarm-correction question it resolves the exact `specificProblem` in Neo4j,
uses that phrase for document search, and enriches the response with related
Features.

## SSE streaming

```bash
curl -N -X POST http://localhost:8100/query/stream \
  -H 'Content-Type: application/json' \
  -d '{
    "session_id": "ericsson-stream-example",
    "query": "Which parameters are related to EUtranCellFDD.pmHoExeAttBlindNr through Features?",
    "include_evidence": true
  }'
```

Events are `workflow`, `chunk`, `done`, `error`, and `ping`.

## WebSocket streaming

Connect to `ws://localhost:8100/ws/stream` and send one JSON request containing
`query`, optional `session_id`, `limit`, `include_evidence`, and optional
`email`.

## Direct KB retrieval

```bash
curl -s -X POST \
  'http://localhost:8102/kb/feature/FAJ%20121%205377/retrieve' \
  -H 'Content-Type: application/json' \
  -d '{"query":"handover parameters","limit":5,"include_related":true}'
```

## Direct Graph API tools

The Graph API is read-only and normally runs at `http://localhost:8101`.

### Feature to any related counter

```bash
curl -sG http://localhost:8101/tools/feature/counters \
  --data-urlencode 'feature=FAJ 121 5377' \
  --data-urlencode 'limit=200'
```

This returns both `PmCounter` and `EbsCounter` nodes. Detailed native relation
types are returned as metadata but do not need to be specified.

### Feature to parameters / MO attributes

```bash
curl -sG http://localhost:8101/tools/feature/parameters \
  --data-urlencode 'feature=Outgoing NR IRAT Handover'
```

### Feature to FM alarm types

```bash
curl -sG http://localhost:8101/tools/feature/alarms \
  --data-urlencode 'feature=Digital Sectorization with AAS FDD'
```

### Alarm to related Features

```bash
curl -sG http://localhost:8101/tools/alarm/features \
  --data-urlencode 'alarm=Resource Allocation Failure'
```

### Counter to parameters through shared Features

```bash
curl -sG http://localhost:8101/tools/counter/parameters-via-features \
  --data-urlencode 'counter=EUtranCellFDD.pmHoExeAttBlindNr'
```

### Parameter to counters through shared Features

```bash
curl -sG http://localhost:8101/tools/parameter/counters-via-features \
  --data-urlencode 'parameter=UeMeasControl.nrB1MeasEnabled'
```

## Capability and health endpoints

```text
Agent: GET /health, GET /ready, GET /capabilities
KB:    GET /health, GET /ready
Graph: GET /health, GET /ready, GET /openapi.json
```

### Component-aware Agent readiness

The Agent `/ready` endpoint can return HTTP 503 when any required dependency is unavailable, while still reporting individual component state:

```json
{
  "ready": false,
  "status": "degraded",
  "kb_ready": true,
  "graph_ready": false,
  "redis_ready": true
}
```

Clients must use `kb_ready` for the Knowledge Base indicator rather than inferring KB health from the aggregate HTTP status or `ready` field.

### Graph request tracing

Graph responses include `X-Request-ID`. Agent-originated calls propagate the same identifier. Trace one request in:

```text
logs/ericsson_agent.log
logs/ericsson_graph_api.log
logs/ericsson_graph_queries.log
```

The Graph `/health` and `/ready` payloads also report the active Graph log paths.

