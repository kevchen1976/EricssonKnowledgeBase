# Operations

## Start and status

```bash
./startup_all_service.sh start
./startup_all_service.sh status
```

With `GRAPH_ENABLED=true`, the launcher starts:

```text
Agent API  :8100
Graph API  :8101
KB API     :8102
```

## Neo4j configuration

```dotenv
GRAPH_ENABLED=true
GRAPH_API_URL=http://localhost:8101
NEO4J_URI=bolt://localhost:7688
NEO4J_USER=neo4j
NEO4J_PASSWORD=<set locally>
NEO4J_DATABASE=
```

Do not put the Neo4j password into tracked source files.

## Graph diagnostics

```bash
curl -s http://localhost:8101/health | python -m json.tool
curl -s http://localhost:8101/ready | python -m json.tool
curl -s http://localhost:8101/openapi.json > /tmp/ericsson-graph-openapi.json
```

Example tool check:

```bash
curl -sG http://localhost:8101/tools/feature/counters \
  --data-urlencode 'feature=FAJ 121 5377' | python -m json.tool
```

## End-to-end agent checks

Alarm correction:

```bash
curl -s -X POST http://localhost:8100/query \
  -H 'Content-Type: application/json' \
  -d '{"query":"What are the correction instructions for Resource Allocation Failure alarm?","include_evidence":true}'
```

Counter-to-parameter:

```bash
curl -s -X POST http://localhost:8100/query \
  -H 'Content-Type: application/json' \
  -d '{"query":"What parameters are related to EUtranCellFDD.pmHoExeAttBlindNr through Features?"}'
```

## OpenSearch, Redis and Ollama diagnostics

```bash
python scripts/check_opensearch.py
./startup_all_service.sh redis-check
./startup_all_service.sh ollama-status
tail -f logs/ericsson_agent.log
tail -f logs/ericsson_graph_api.log
tail -f logs/ericsson_graph_queries.log
tail -f logs/chunks.log
tail -f logs/ollama-client.log
```

## Graph API call tracing

Every Graph API request receives or propagates an `X-Request-ID`. The same ID is written to:

```text
logs/ericsson_agent.log
logs/ericsson_graph_api.log
logs/ericsson_graph_queries.log
```

`ericsson_graph_api.log` records HTTP method/path, tool arguments, resolution summary, status and latency. `ericsson_graph_queries.log` records the Cypher operation name, query hash, bounded query/parameter preview, row count and latency. Password/secret/token-named parameters are redacted.

```bash
tail -f logs/ericsson_graph_api.log logs/ericsson_graph_queries.log
```

The Graph `/health` and `/ready` responses include the active log paths.

## Frontend readiness semantics

The browser status panel uses dependency fields from the Agent `/ready` payload:

- `kb_ready` controls **Knowledge Base**.
- `graph_ready` controls **Graph** when graph integration is enabled.
- `redis_ready` contributes to aggregate service readiness.

A non-KB dependency failure displays **Services Degraded** while leaving **Knowledge Base: ready** when OpenSearch retrieval is healthy.
