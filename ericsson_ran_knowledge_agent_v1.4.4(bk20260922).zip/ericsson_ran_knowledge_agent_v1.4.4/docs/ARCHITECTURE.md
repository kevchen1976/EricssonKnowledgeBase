# Architecture

## Vendor-agent contract

Ericsson remains independently accessible through its own API and can be
registered behind a future Nokia/Ericsson supervisor.

```text
query -> deterministic routing -> graph tools + document retrieval -> synthesis
```

## Storage roles

### OpenSearch and filesystem manifests

OpenSearch contains child windows for BM25/vector retrieval and full parent
sections for evidence. Filesystem manifests provide Feature, package and topic
routing.

OpenSearch is authoritative for:

- alarm correction instructions and procedures;
- configuration and operational guidance;
- limitations, prerequisites and explanatory prose;
- Feature-to-Feature similarity and dependency questions.

### Ericsson-native Neo4j

Neo4j contains the current Ericsson-native object graph plus curated Feature
overlays. The agent-facing API exposes only a small vocabulary:

```text
Feature <-> Counter
Feature <-> Parameter
Feature <-> Alarm
```

`Counter` maps to `PmCounter` or `EbsCounter`; `Parameter` maps to
`MOAttribute`; `Alarm` maps to `FmAlarmType` (and may also carry the generic
`:Alarm` label).

Detailed native relationship types are retained on the graph and returned as
metadata, but discovery queries ignore their distinction by default.

## Two-stage alarm workflow

```text
User alarm question
        |
        v
Neo4j resolves exact FmAlarmType.specific_problem
        |
        +--> related Feature context
        |
        v
OpenSearch searches exact specificProblem + correction intent
        |
        v
Answer: documented correction instructions + graph enrichment
```

## Multi-hop graph workflow

```text
Counter -> Feature -> MOAttribute
MOAttribute -> Feature -> Counter
```

These paths identify objects associated through the same Feature. They do not
imply a direct causal or mathematical dependency.

## Parent boundaries and images

Numbered Ericsson headings define parent boundaries. Parent content remains the
citation/evidence unit. Prepared images are served under `/kb-assets`.

## Supervisor readiness

Nokia and Ericsson remain physically isolated by vendor. The supervisor sees a
small generic entity vocabulary while each vendor agent retains its own native
graph schema.

## Graph observability

The Agent propagates `X-Request-ID` to the Graph API. The Graph HTTP middleware, high-level tool layer, and Cypher repository all log with that request ID. This allows a single request to be followed from Agent tool selection through HTTP transport, entity resolution, Cypher row count, and response latency without exposing Neo4j credentials.

## Readiness versus component health

Agent readiness is aggregate, but frontend indicators are component-specific. A Graph or Redis outage can make the Agent readiness endpoint return 503 while OpenSearch remains usable. The browser therefore uses `kb_ready`, `graph_ready`, and `redis_ready` independently and displays `Services Degraded` when KB retrieval remains available.

