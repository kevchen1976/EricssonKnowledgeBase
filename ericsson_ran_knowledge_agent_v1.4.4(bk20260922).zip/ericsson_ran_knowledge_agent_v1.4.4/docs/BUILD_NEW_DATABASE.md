# Build a brand-new Ericsson database

## 1. Set locations

```bash
export ROOT="$HOME/RANKB_Local_Ericsson"
export VENV="$ROOT/.venv"
export PREP_ROOT="$ROOT/ericsson_kb_preparation_v1.1.2"
export AGENT_ROOT="$ROOT/ericsson_ran_knowledge_agent_v1.4.4"
export PDF_ROOT="/path/to/ericsson_pdfs"
export KB_VERSION="$(date +%Y%m%d)clean01"
```

## 2. Activate dependencies

```bash
source "$VENV/bin/activate"
python -m pip install -r "$PREP_ROOT/requirements.txt"
python -m pip install -r "$AGENT_ROOT/requirements.txt"
```

## 3. Stop Ericsson APIs

```bash
cd "$AGENT_ROOT"
./startup_all_service.sh stop-agent
./startup_all_service.sh stop-kb
```

Shared Nokia, OpenSearch and Redis services are not stopped.

## 4. Remove old prepared data

```bash
rm -rf "$AGENT_ROOT/data/prepared"
mkdir -p "$AGENT_ROOT/data/prepared"
```

## 5. Prepare PDFs

```bash
cd "$PREP_ROOT"
python -m ericsson_kb "$PDF_ROOT" \
  --output-dir "$AGENT_ROOT/data/prepared" \
  --overwrite \
  --no-fallback \
  2>&1 | tee "$AGENT_ROOT/logs/preparation_${KB_VERSION}.log"
```

`--no-fallback` makes a Docling failure visible. Remove it only when PyMuPDF
fallback is deliberately accepted.

## 6. Validate prepared data

```bash
cd "$AGENT_ROOT"
python scripts/validate_prepared_data.py \
  data/prepared \
  --output "logs/prepared_validation_${KB_VERSION}.json"
```

## 7. Enforce embedding length

```bash
python scripts/check_embedding_lengths.py \
  --prepared-root data/prepared \
  --output "logs/embedding_length_preflight_${KB_VERSION}.json"
```

Required result:

```text
status=passed
embedding_dimension=1024
over_limit_inputs=0
opensearch_touched=false
```

## 8. Optional offline parent/child preview

```bash
rm -rf data/prepared/ingestion-preview
python ingest_ericsson.py \
  --prepared-root data/prepared \
  --mode dry-run \
  --skip-embeddings \
  --preview-dir data/prepared/ingestion-preview

python scripts/verify_parent_child_storage.py \
  --preview-dir data/prepared/ingestion-preview \
  --output "logs/parent_child_preview_${KB_VERSION}.json"

rm -rf data/prepared/ingestion-preview
```

## 9. Check shared OpenSearch

```bash
python scripts/check_opensearch.py
```

For the first build, missing Ericsson aliases are acceptable. Cluster
connectivity must succeed.

## 10. Ingest and switch aliases

```bash
python ingest_ericsson.py \
  --prepared-root data/prepared \
  --mode rebuild \
  --version "$KB_VERSION" \
  --delete-old \
  2>&1 | tee "logs/ingestion_${KB_VERSION}.log"
```

The rebuild creates only parent and child backing indexes. Aliases are switched
only after a successful load.

## 11. Validate live storage

```bash
python scripts/verify_parent_child_storage.py \
  --live \
  --sample-size 200 \
  --output "logs/parent_child_live_${KB_VERSION}.json"
```

## 12. Start APIs

```bash
./startup_all_service.sh kb
./startup_all_service.sh agent
./startup_all_service.sh status
```

Verify:

```bash
curl -s http://localhost:8102/ready | python -m json.tool
curl -s http://localhost:8100/ready | python -m json.tool
```
