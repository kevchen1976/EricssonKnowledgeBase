# Ericsson graph integration

The Ericsson-native V4 graph is active when `GRAPH_ENABLED=true`. It is a
separate current-state Neo4j database and is accessed through the Graph API on
port 8101.

## Agent-facing relationship families

The native graph preserves detailed edge types such as
`INTRODUCES_COUNTER`, `USES_COUNTER`, `ASSOCIATED_COUNTER`,
`INTRODUCES_ATTRIBUTE`, and `AFFECTED_BY_ATTRIBUTE`. The agent does not need to
select those types for discovery. It uses these high-level families:

```text
Feature <-> Counter      PmCounter or EbsCounter
Feature <-> Parameter    MOAttribute
Feature <-> Alarm        FmAlarmType
```

Native edge types and source evidence are returned as metadata for explanation
or precise follow-up questions.

## Multi-hop tools

```text
Counter -> Feature -> MOAttribute
MOAttribute -> Feature -> Counter
```

These paths show shared Feature associations. They do not prove that a
parameter directly controls a counter.

## Deliberate exclusion

Feature-to-Feature similarity, dependency, prerequisite, conflict and related
Feature questions remain in OpenSearch semantic/document retrieval. No
Feature-to-Feature graph tool is exposed.
