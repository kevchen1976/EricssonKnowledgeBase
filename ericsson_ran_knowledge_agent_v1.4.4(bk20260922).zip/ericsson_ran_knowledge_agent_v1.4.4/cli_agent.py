#!/usr/bin/env python3
"""Interactive CLI for the standalone Ericsson agent API."""
from __future__ import annotations

import argparse
import json
import uuid

import httpx

from agent_core.settings import get_settings


def main() -> int:
    settings = get_settings()
    parser = argparse.ArgumentParser(description="Ericsson RAN Assistant CLI")
    parser.add_argument("--api-url", default=settings.agent_api_url.rstrip("/") + "/query")
    parser.add_argument("--email", default="")
    parser.add_argument("--show-evidence", action="store_true")
    args = parser.parse_args()
    session_id = str(uuid.uuid4())
    headers = {"X-User-Email": args.email} if args.email else {}
    print("Ericsson RAN Assistant CLI (type 'exit' to quit)")
    while True:
        try:
            text = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if text.casefold() in {"exit", "quit"}:
            break
        if not text:
            continue
        try:
            response = httpx.post(
                args.api_url,
                headers=headers,
                json={"query": text, "session_id": session_id, "include_evidence": args.show_evidence},
                timeout=settings.ollama_timeout + settings.kb_timeout,
            )
            response.raise_for_status()
            payload = response.json()
            print(payload.get("answer", ""))
            if payload.get("citations"):
                print("\nSources:")
                for citation in payload["citations"]:
                    print(f"  [{citation['citation_id']}] {citation.get('source')} pages {citation.get('pages', [])}")
        except Exception as exc:
            print(f"Error: {exc}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
