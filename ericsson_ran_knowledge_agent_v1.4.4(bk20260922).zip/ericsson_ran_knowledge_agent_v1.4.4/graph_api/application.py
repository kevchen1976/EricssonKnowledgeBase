"""FastAPI assembly for the Ericsson-native Neo4j graph service."""
from __future__ import annotations

import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request

from agent_core.constants import PACKAGE_VERSION
from agent_core.logging_utils import request_context, single_line

from .routes import entities, health
from .state import get_state


@asynccontextmanager
async def lifespan(_app: FastAPI):
    state = get_state()
    state.logger.info("[GRAPH API START] version=%s", PACKAGE_VERSION)
    try:
        yield
    finally:
        state.logger.info("[GRAPH API STOP]")
        state.close()


app = FastAPI(
    title="Ericsson RAN Knowledge Graph API",
    version=PACKAGE_VERSION,
    description=(
        "Read-only Ericsson-native Neo4j tools. The public tool vocabulary is "
        "Feature-centred (counters, parameters and alarms); native relationship "
        "types remain available as result metadata."
    ),
    lifespan=lifespan,
)
app.include_router(entities.router)
app.include_router(health.router)


@app.middleware("http")
async def trace_graph_request(request: Request, call_next):
    """Trace every Graph API call with a propagated request identifier.

    Agent -> Graph calls already carry ``X-Request-ID``. Direct curl/browser
    calls receive a generated ID, returned in the response header and written
    to both HTTP/tool and Cypher traces for correlation.
    """
    supplied_request_id = str(request.headers.get("X-Request-ID") or "").strip() or None
    state = get_state()
    started = time.perf_counter()
    client_host = request.client.host if request.client else "unknown"
    query_preview = single_line(str(request.url.query or ""), max_chars=1000)
    user_agent = single_line(request.headers.get("user-agent", ""), max_chars=240)

    with request_context(supplied_request_id) as request_id:
        state.logger.info(
            "[GRAPH HTTP REQUEST] method=%s path=%s query=%s client=%s user_agent=%s",
            request.method,
            request.url.path,
            query_preview or "<none>",
            client_host,
            user_agent or "<none>",
        )
        try:
            response = await call_next(request)
        except Exception as exc:
            latency_ms = (time.perf_counter() - started) * 1000.0
            state.logger.exception(
                "[GRAPH HTTP ERROR] method=%s path=%s latency_ms=%.1f error=%s",
                request.method,
                request.url.path,
                latency_ms,
                exc,
            )
            raise

        latency_ms = (time.perf_counter() - started) * 1000.0
        response.headers["X-Request-ID"] = request_id
        state.logger.info(
            "[GRAPH HTTP RESPONSE] method=%s path=%s status=%s latency_ms=%.1f",
            request.method,
            request.url.path,
            response.status_code,
            latency_ms,
        )
        return response
