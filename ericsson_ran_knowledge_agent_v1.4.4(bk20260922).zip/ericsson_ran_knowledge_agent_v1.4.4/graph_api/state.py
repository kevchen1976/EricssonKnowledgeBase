"""Lazy Neo4j lifecycle and detailed logging for the Ericsson graph layer."""
from __future__ import annotations

import os
import threading
from pathlib import Path
from typing import Any, Optional

from agent_core.logging_utils import configure_rotating_file_logger
from agent_core.settings import Settings, get_settings


class GraphDisabledError(RuntimeError):
    pass


class GraphConfigurationError(RuntimeError):
    """Raised when Neo4j is reachable but the configured graph target is invalid."""
    pass


def is_database_not_found(exc: BaseException) -> bool:
    """Best-effort detection without requiring Neo4j exception imports at module load."""
    code = str(getattr(exc, "code", "") or getattr(exc, "neo4j_code", ""))
    text = str(exc)
    return "DatabaseNotFound" in code or "Graph not found:" in text


def database_configuration_message(database: str) -> str:
    configured = str(database or "").strip()
    if configured:
        return (
            f"Configured Neo4j database '{configured}' was not found. "
            "Set NEO4J_DATABASE to an existing database name (commonly 'neo4j') "
            "or leave NEO4J_DATABASE blank to use the server default database."
        )
    return (
        "The Neo4j server default database could not be opened. "
        "Set NEO4J_DATABASE to an existing database name or correct the Neo4j default database configuration."
    )


def _env_int(name: str, default: int) -> int:
    value = str(os.getenv(name, "")).strip()
    if not value:
        return int(default)
    try:
        return int(value)
    except ValueError:
        return int(default)


class GraphState:
    def __init__(self, settings: Optional[Settings] = None) -> None:
        self.settings = settings or get_settings()
        self._driver: Any = None
        self._lock = threading.RLock()

        max_bytes = max(0, _env_int("GRAPH_LOG_MAX_BYTES", 20 * 1024 * 1024))
        backup_count = max(0, _env_int("GRAPH_LOG_BACKUP_COUNT", 5))
        self.query_preview_chars = max(120, _env_int("GRAPH_LOG_QUERY_PREVIEW_CHARS", 1200))
        self.parameter_preview_chars = max(120, _env_int("GRAPH_LOG_PARAMETER_PREVIEW_CHARS", 1000))

        self.http_log_path = (Path(self.settings.logs_dir) / "ericsson_graph_api.log").resolve()
        self.query_log_path = (Path(self.settings.logs_dir) / "ericsson_graph_queries.log").resolve()

        self.logger = configure_rotating_file_logger(
            "ericsson_graph_api",
            self.http_log_path,
            max_bytes=max_bytes,
            backup_count=backup_count,
        )
        self.query_logger = configure_rotating_file_logger(
            "ericsson_graph_queries",
            self.query_log_path,
            max_bytes=max_bytes,
            backup_count=backup_count,
        )
        self.logger.info(
            "[GRAPH STATE READY] enabled=%s uri=%s database=%s http_log=%s query_log=%s",
            self.enabled,
            self.settings.neo4j_uri,
            self.settings.neo4j_database or "<default>",
            self.http_log_path,
            self.query_log_path,
        )

    @property
    def enabled(self) -> bool:
        return self.settings.graph_enabled

    def driver(self):
        if not self.enabled:
            raise GraphDisabledError("Ericsson Neo4j integration is disabled (GRAPH_ENABLED=false)")
        with self._lock:
            if self._driver is None:
                try:
                    from neo4j import GraphDatabase
                except ImportError as exc:
                    self.logger.exception("[GRAPH DRIVER ERROR] neo4j Python package is not installed")
                    raise RuntimeError("neo4j Python package is not installed") from exc
                auth = (self.settings.neo4j_user, self.settings.neo4j_password)
                self.logger.info(
                    "[GRAPH DRIVER CONNECT] uri=%s database=%s user=%s",
                    self.settings.neo4j_uri,
                    self.settings.neo4j_database or "<default>",
                    self.settings.neo4j_user,
                )
                try:
                    self._driver = GraphDatabase.driver(self.settings.neo4j_uri, auth=auth)
                except Exception:
                    self.logger.exception(
                        "[GRAPH DRIVER ERROR] uri=%s database=%s user=%s",
                        self.settings.neo4j_uri,
                        self.settings.neo4j_database or "<default>",
                        self.settings.neo4j_user,
                    )
                    raise
                self.logger.info("[GRAPH DRIVER CREATED] uri=%s", self.settings.neo4j_uri)
            return self._driver

    def close(self) -> None:
        with self._lock:
            if self._driver is not None:
                try:
                    self._driver.close()
                    self.logger.info("[GRAPH DRIVER CLOSED]")
                finally:
                    self._driver = None

    def status(self) -> dict[str, Any]:
        base = {
            "enabled": self.enabled,
            "uri": self.settings.neo4j_uri,
            "database": self.settings.neo4j_database,
            "http_log": str(self.http_log_path),
            "query_log": str(self.query_log_path),
        }
        if not self.enabled:
            return {**base, "connected": False, "status": "disabled"}
        try:
            driver = self.driver()
            # verify_connectivity() only proves the Bolt server is reachable; it does
            # not prove that a configured database actually exists.  Execute a tiny
            # read against the exact database used by graph queries so /ready cannot
            # report healthy while every tool call fails with DatabaseNotFound.
            driver.verify_connectivity()
            database = self.settings.neo4j_database or None
            with driver.session(database=database) as session:
                session.run("RETURN 1 AS graph_ready").consume()
            return {**base, "connected": True, "database_ready": True, "status": "ok"}
        except Exception as exc:
            if is_database_not_found(exc):
                message = database_configuration_message(self.settings.neo4j_database)
                self.logger.error(
                    "[GRAPH DATABASE CONFIG ERROR] database=%s error=%s",
                    self.settings.neo4j_database or "<default>",
                    exc,
                )
                return {
                    **base,
                    "connected": False,
                    "database_ready": False,
                    "status": "configuration_error",
                    "error": message,
                    "neo4j_error": str(exc),
                }
            self.logger.error("[GRAPH STATUS ERROR] error=%s", exc)
            return {
                **base,
                "connected": False,
                "database_ready": False,
                "status": "error",
                "error": str(exc),
            }


_STATE: Optional[GraphState] = None


def get_state(*, reload: bool = False) -> GraphState:
    global _STATE
    if _STATE is None or reload:
        if reload and _STATE is not None:
            _STATE.close()
        _STATE = GraphState()
    return _STATE
