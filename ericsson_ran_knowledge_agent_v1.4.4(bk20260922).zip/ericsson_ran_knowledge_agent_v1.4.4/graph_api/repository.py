"""Read-only Ericsson-native Neo4j queries exposed as agent tools.

The graph service runs against the dedicated Ericsson V4 database.  The native
schema is intentionally richer than the agent-facing vocabulary.  The API
therefore exposes a small set of high-level relationship families:

* Feature <-> Counter    (:PmCounter or :EbsCounter)
* Feature <-> Parameter  (:MOAttribute)
* Feature <-> Alarm      (:FmAlarmType, optionally also labelled :Alarm)

Native relationship types are preserved in every result as metadata, but the
caller does not need to choose between INTRODUCES_COUNTER, USES_COUNTER,
ASSOCIATED_COUNTER, and similar edge types during discovery.
"""
from __future__ import annotations

import hashlib
import json
import re
import time
from typing import Any, Dict, Iterable, List, Sequence

from agent_core.ids import feature_key, normalize_feature_id, normalize_package_id
from agent_core.logging_utils import single_line

from .state import (
    GraphConfigurationError,
    GraphState,
    database_configuration_message,
    is_database_not_found,
)


_WHITESPACE_RE = re.compile(r"\s+")
_QUALIFIED_REF_RE = re.compile(
    r"(?<![A-Za-z0-9_])([A-Za-z][A-Za-z0-9_]*)\.([A-Za-z][A-Za-z0-9_]*)(?![A-Za-z0-9_])"
)
_PM_REF_RE = re.compile(
    r"(?<![A-Za-z0-9_])(?:([A-Za-z][A-Za-z0-9_]*)\.)?(pm[A-Za-z0-9_]+)(?![A-Za-z0-9_])",
    re.IGNORECASE,
)


def _clean(value: Any) -> str:
    return _WHITESPACE_RE.sub(" ", str(value or "")).strip()


def _canonical(value: Any) -> str:
    text = _clean(value).casefold().replace("&", " and ")
    return _clean(re.sub(r"[^a-z0-9]+", " ", text))


def _compact(value: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", _clean(value).casefold())




def _json_safe(value: Any) -> Any:
    """Convert Neo4j temporal/spatial values into FastAPI-safe values."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _json_safe(child) for key, child in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(child) for child in value]
    return str(value)


def _dedupe_dicts(rows: Iterable[Dict[str, Any]], key_fields: Sequence[str]) -> List[Dict[str, Any]]:
    seen: set[tuple[Any, ...]] = set()
    out: List[Dict[str, Any]] = []
    for row in rows:
        key = tuple(row.get(field) for field in key_fields)
        if key in seen:
            continue
        seen.add(key)
        out.append(row)
    return out


def _edge_evidence(properties: Dict[str, Any]) -> Dict[str, Any]:
    """Return bounded, useful relationship provenance for the agent."""
    allowed = (
        "source_file",
        "source_section",
        "source_line",
        "source_lines_json",
        "evidence",
        "confidence",
        "verified",
        "extraction_method",
        "resolution_method",
        "last_enriched_at",
    )
    return _json_safe({key: properties.get(key) for key in allowed if properties.get(key) not in (None, "", [])})


class GraphRepository:
    """Ericsson-native graph queries.

    The Neo4j instance is Ericsson-only, so V4 objects are not required to carry
    ``vendor`` or ``corpus_id`` properties.  This is deliberately different
    from the pre-V4 graph scaffold.
    """

    def __init__(self, state: GraphState) -> None:
        self.state = state
        self.settings = state.settings

    def _run(
        self,
        query: str,
        *,
        trace_name: str = "cypher",
        **parameters: Any,
    ) -> List[Dict[str, Any]]:
        """Execute one read query and write a bounded, request-correlated trace."""
        normalized_query = " ".join(str(query or "").split())
        query_id = hashlib.sha256(normalized_query.encode("utf-8")).hexdigest()[:12]
        query_preview = single_line(
            normalized_query,
            max_chars=self.state.query_preview_chars,
        )

        safe_parameters: Dict[str, Any] = {}
        for key, value in parameters.items():
            if any(secret in key.casefold() for secret in ("password", "secret", "token")):
                safe_parameters[key] = "<redacted>"
            elif isinstance(value, (list, tuple, set)) and len(value) > 20:
                safe_parameters[key] = {
                    "count": len(value),
                    "preview": list(value)[:10],
                }
            else:
                safe_parameters[key] = _json_safe(value)
        parameter_preview = single_line(
            json.dumps(safe_parameters, ensure_ascii=False, default=str, sort_keys=True),
            max_chars=self.state.parameter_preview_chars,
        )

        started = time.perf_counter()
        self.state.query_logger.info(
            "[GRAPH CYPHER START] operation=%s query_id=%s database=%s parameters=%s query=%s",
            trace_name,
            query_id,
            self.settings.neo4j_database or "<default>",
            parameter_preview or "{}",
            query_preview,
        )
        try:
            with self.state.driver().session(
                database=self.settings.neo4j_database or None
            ) as session:
                result = session.run(query, **parameters)
                rows = [dict(record) for record in result]
        except Exception as exc:
            latency_ms = (time.perf_counter() - started) * 1000.0
            self.state.query_logger.exception(
                "[GRAPH CYPHER ERROR] operation=%s query_id=%s latency_ms=%.1f error=%s",
                trace_name,
                query_id,
                latency_ms,
                exc,
            )
            if is_database_not_found(exc):
                raise GraphConfigurationError(
                    database_configuration_message(self.settings.neo4j_database)
                ) from exc
            raise

        latency_ms = (time.perf_counter() - started) * 1000.0
        self.state.query_logger.info(
            "[GRAPH CYPHER END] operation=%s query_id=%s rows=%d latency_ms=%.1f",
            trace_name,
            query_id,
            len(rows),
            latency_ms,
        )
        return rows

    # ------------------------------------------------------------------
    # Entity resolution
    # ------------------------------------------------------------------

    def _resolve_feature(self, value: str, *, limit: int = 20) -> Dict[str, Any]:
        raw = _clean(value)
        normalized = normalize_feature_id(raw)
        normalized_key = feature_key(raw)
        graph_id = f"ERI::FEATURE::{normalized_key}" if normalized_key else ""
        raw_lower = raw.casefold()
        canonical = _canonical(raw)

        rows = self._run(
            """
            MATCH (f:Feature)
            WITH f,
                 CASE
                   WHEN $graph_id <> '' AND toLower(coalesce(f.id,'')) = toLower($graph_id) THEN 1000
                   WHEN $feature_key <> '' AND toUpper(coalesce(f.feature_identity_norm,'')) = toUpper($feature_key) THEN 980
                   WHEN $feature_id <> '' AND toLower(coalesce(f.feature_identity,'')) = toLower($feature_id) THEN 960
                   WHEN toLower(coalesce(f.name,'')) = $raw_lower THEN 940
                   WHEN toLower(coalesce(f.canonical_name,'')) = $canonical THEN 920
                   WHEN size(coalesce(f.name,'')) >= 5 AND $raw_lower CONTAINS toLower(f.name) THEN 800 + size(f.name)
                   WHEN size($raw_lower) >= 5 AND toLower(coalesce(f.name,'')) CONTAINS $raw_lower THEN 600 + size($raw_lower)
                   ELSE 0
                 END AS score
            WHERE score > 0
            RETURN elementId(f) AS element_id, properties(f) AS entity, score
            ORDER BY score DESC, size(coalesce(f.name,'')) DESC
            LIMIT $limit
            """,
            trace_name="resolve_feature",
            graph_id=graph_id,
            feature_key=normalized_key,
            feature_id=normalized,
            raw_lower=raw_lower,
            canonical=canonical,
            limit=limit,
        )
        return self._resolution_payload("Feature", raw, rows)

    def _resolve_parameter(self, value: str, *, limit: int = 30) -> Dict[str, Any]:
        raw = _clean(value)
        raw_lower = raw.casefold()
        canonical = _canonical(raw)
        refs = _QUALIFIED_REF_RE.findall(raw)
        owner = refs[0][0] if refs else ""
        name = refs[0][1] if refs else ""

        rows = self._run(
            """
            MATCH (p:MOAttribute)
            WITH p,
                 toLower(coalesce(p.mo_class,'')) + '.' + toLower(coalesce(p.name,'')) AS qualified
            WITH p, qualified,
                 CASE
                   WHEN toLower(coalesce(p.id,'')) = $raw_lower THEN 100
                   WHEN $owner <> '' AND $name <> ''
                        AND toLower(coalesce(p.mo_class,'')) = toLower($owner)
                        AND toLower(coalesce(p.name,'')) = toLower($name) THEN 98
                   WHEN toLower(coalesce(p.name,'')) = $raw_lower THEN 92
                   WHEN toLower(coalesce(p.name,'')) = toLower($name) AND $name <> '' THEN 90
                   WHEN $raw_lower CONTAINS qualified AND size(qualified) >= 5 THEN 88
                   WHEN size(coalesce(p.name,'')) >= 5 AND $raw_lower CONTAINS toLower(p.name) THEN 78
                   WHEN toLower(coalesce(p.name,'')) CONTAINS $raw_lower AND size($raw_lower) >= 5 THEN 65
                   ELSE 0
                 END AS score
            WHERE score > 0
            RETURN elementId(p) AS element_id, properties(p) AS entity, score,
                   coalesce(p.mo_class,'') + '.' + coalesce(p.name,'') AS qualified_name
            ORDER BY score DESC, size(coalesce(p.name,'')) DESC
            LIMIT $limit
            """,
            trace_name="resolve_parameter",
            raw_lower=raw_lower,
            canonical=canonical,
            owner=owner,
            name=name,
            limit=limit,
        )
        return self._resolution_payload("MOAttribute", raw, rows)

    def _resolve_counter(self, value: str, *, limit: int = 40) -> Dict[str, Any]:
        raw = _clean(value)
        raw_lower = raw.casefold()
        refs = _PM_REF_RE.findall(raw)
        owner = refs[0][0] if refs else ""
        name = refs[0][1] if refs else ""

        pm_rows = self._run(
            """
            MATCH (c:PmCounter)
            OPTIONAL MATCH (g:PmGroup)-[:HAS_COUNTER]->(c)
            OPTIONAL MATCH (g)-[:FOR_CLASS]->(m:MOClass)
            WITH c, m,
                 toLower(coalesce(m.name,'')) + '.' + toLower(coalesce(c.name,'')) AS qualified
            WITH c, m, qualified,
                 CASE
                   WHEN toLower(coalesce(c.id,'')) = $raw_lower THEN 100
                   WHEN $owner <> '' AND $name <> ''
                        AND toLower(coalesce(m.name,'')) = toLower($owner)
                        AND toLower(coalesce(c.name,'')) = toLower($name) THEN 98
                   WHEN toLower(coalesce(c.name,'')) = $raw_lower THEN 92
                   WHEN toLower(coalesce(c.name,'')) = toLower($name) AND $name <> '' THEN 90
                   WHEN $raw_lower CONTAINS qualified AND size(qualified) >= 5 THEN 88
                   WHEN size(coalesce(c.name,'')) >= 5 AND $raw_lower CONTAINS toLower(c.name) THEN 78
                   ELSE 0
                 END AS score
            WHERE score > 0
            RETURN elementId(c) AS element_id, properties(c) AS entity, score,
                   'PmCounter' AS concrete_type, coalesce(m.name,'') AS owner,
                   coalesce(m.name,'') + '.' + coalesce(c.name,'') AS qualified_name
            ORDER BY score DESC
            LIMIT $limit
            """,
            trace_name="resolve_pm_counter",
            raw_lower=raw_lower,
            owner=owner,
            name=name,
            limit=limit,
        )
        ebs_rows = self._run(
            """
            MATCH (c:EbsCounter)
            OPTIONAL MATCH (c)-[:FOR_CLASS]->(m:MOClass)
            WITH c, m,
                 coalesce(m.name, c.mo_class, '') AS resolved_owner,
                 CASE
                   WHEN toLower(coalesce(c.id,'')) = $raw_lower THEN 100
                   WHEN $owner <> '' AND $name <> ''
                        AND toLower(coalesce(m.name,c.mo_class,'')) = toLower($owner)
                        AND toLower(coalesce(c.name,'')) = toLower($name) THEN 98
                   WHEN toLower(coalesce(c.name,'')) = $raw_lower THEN 92
                   WHEN toLower(coalesce(c.name,'')) = toLower($name) AND $name <> '' THEN 90
                   WHEN size(coalesce(c.name,'')) >= 5 AND $raw_lower CONTAINS toLower(c.name) THEN 78
                   ELSE 0
                 END AS score
            WHERE score > 0
            RETURN elementId(c) AS element_id, properties(c) AS entity, score,
                   'EbsCounter' AS concrete_type, resolved_owner AS owner,
                   resolved_owner + '.' + coalesce(c.name,'') AS qualified_name
            ORDER BY score DESC
            LIMIT $limit
            """,
            trace_name="resolve_ebs_counter",
            raw_lower=raw_lower,
            owner=owner,
            name=name,
            limit=limit,
        )
        rows = sorted(pm_rows + ebs_rows, key=lambda row: int(row.get("score") or 0), reverse=True)[:limit]
        return self._resolution_payload("Counter", raw, rows)

    def _resolve_alarm(self, value: str, *, limit: int = 30) -> Dict[str, Any]:
        raw = _clean(value)
        raw_lower = raw.casefold()
        compact = _compact(raw)
        rows = self._run(
            """
            MATCH (a:FmAlarmType)
            WITH a,
                 toLower(replace(replace(replace(coalesce(a.fm_alarm_type_id,''),' ',''),'-',''),'_','')) AS compact_id,
                 toLower(replace(replace(replace(coalesce(a.specific_problem,''),' ',''),'-',''),'_','')) AS compact_problem
            WITH a, compact_id, compact_problem,
                 CASE
                   WHEN toLower(coalesce(a.id,'')) = $raw_lower THEN 100
                   WHEN compact_id = $compact THEN 99
                   WHEN compact_problem = $compact THEN 98
                   WHEN toLower(coalesce(a.specific_problem,'')) = $raw_lower THEN 97
                   WHEN toLower(coalesce(a.alarm_name,'')) = $raw_lower THEN 96
                   WHEN size(coalesce(a.specific_problem,'')) >= 5
                        AND $raw_lower CONTAINS toLower(a.specific_problem) THEN 92
                   WHEN size($raw_lower) >= 5
                        AND toLower(coalesce(a.specific_problem,'')) CONTAINS $raw_lower THEN 70
                   ELSE 0
                 END AS score
            WHERE score > 0
            RETURN elementId(a) AS element_id, properties(a) AS entity, score
            ORDER BY score DESC, size(coalesce(a.specific_problem,'')) DESC
            LIMIT $limit
            """,
            trace_name="resolve_alarm",
            raw_lower=raw_lower,
            compact=compact,
            limit=limit,
        )
        return self._resolution_payload("FmAlarmType", raw, rows)

    @staticmethod
    def _resolution_payload(entity_type: str, query: str, rows: List[Dict[str, Any]]) -> Dict[str, Any]:
        rows = [_json_safe(row) for row in rows]
        if not rows:
            return {
                "entity_type": entity_type,
                "query": query,
                "found": False,
                "ambiguous": False,
                "candidates": [],
            }
        top_score = int(rows[0].get("score") or 0)
        top = [row for row in rows if int(row.get("score") or 0) == top_score]
        return {
            "entity_type": entity_type,
            "query": query,
            "found": True,
            "ambiguous": len(top) > 1,
            "top_score": top_score,
            "resolved": top[0] if len(top) == 1 else None,
            "candidates": rows,
        }

    # ------------------------------------------------------------------
    # High-level relationship tools
    # ------------------------------------------------------------------

    def counter_context(self, counter: str, *, limit: int = 40) -> Dict[str, Any]:
        """Resolve one Ericsson counter without traversing Feature relationships."""
        return {
            "tool": "counter_context",
            "query": counter,
            "counter_resolution": self._resolve_counter(counter, limit=limit),
        }

    def parameter_context(self, parameter: str, *, limit: int = 30) -> Dict[str, Any]:
        """Resolve one Ericsson MOAttribute without traversing Feature relationships."""
        return {
            "tool": "parameter_context",
            "query": parameter,
            "parameter_resolution": self._resolve_parameter(parameter, limit=limit),
        }

    def feature_counters(self, feature: str, *, limit: int = 200) -> Dict[str, Any]:
        return self._feature_targets(feature, target_kind="counter", limit=limit)

    def feature_parameters(self, feature: str, *, limit: int = 200) -> Dict[str, Any]:
        return self._feature_targets(feature, target_kind="parameter", limit=limit)

    def feature_alarms(self, feature: str, *, limit: int = 200) -> Dict[str, Any]:
        return self._feature_targets(feature, target_kind="alarm", limit=limit)

    def feature_context(self, feature: str, *, limit: int = 100) -> Dict[str, Any]:
        resolution = self._resolve_feature(feature)
        payload = {
            "tool": "feature_context",
            "query": feature,
            "feature_resolution": resolution,
            "counters": [],
            "parameters": [],
            "alarms": [],
        }
        if not resolution.get("found") or resolution.get("ambiguous"):
            return payload
        payload["counters"] = self.feature_counters(feature, limit=limit).get("results", [])
        payload["parameters"] = self.feature_parameters(feature, limit=limit).get("results", [])
        payload["alarms"] = self.feature_alarms(feature, limit=limit).get("results", [])
        return payload

    def _feature_targets(self, feature: str, *, target_kind: str, limit: int) -> Dict[str, Any]:
        resolution = self._resolve_feature(feature)
        tool_name = f"feature_{'parameters' if target_kind == 'parameter' else target_kind + 's'}"
        payload: Dict[str, Any] = {
            "tool": tool_name,
            "query": feature,
            "feature_resolution": resolution,
            "relationship_family": {
                "counter": "FEATURE_COUNTER",
                "parameter": "FEATURE_PARAMETER",
                "alarm": "FEATURE_ALARM",
            }[target_kind],
            "results": [],
            "count": 0,
        }
        resolved = resolution.get("resolved")
        if not isinstance(resolved, dict):
            return payload
        feature_eid = str(resolved.get("element_id") or "")
        if not feature_eid:
            return payload

        if target_kind == "counter":
            label_where = "(t:PmCounter OR t:EbsCounter)"
        elif target_kind == "parameter":
            label_where = "t:MOAttribute"
        else:
            label_where = "t:FmAlarmType"

        rows = self._run(
            f"""
            MATCH (f:Feature)-[r]-(t)
            WHERE elementId(f) = $feature_eid AND {label_where}
            WITH t,
                 collect(DISTINCT type(r)) AS native_relationships,
                 collect(DISTINCT properties(r))[0..10] AS raw_evidence
            RETURN elementId(t) AS element_id, labels(t) AS labels,
                   properties(t) AS entity, native_relationships, raw_evidence
            ORDER BY coalesce(t.name, t.specific_problem, '')
            LIMIT $limit
            """,
            trace_name=f"feature_targets_{target_kind}",
            feature_eid=feature_eid,
            limit=limit,
        )
        results = []
        for row in rows:
            results.append({
                "element_id": row.get("element_id"),
                "labels": row.get("labels") or [],
                "entity": _json_safe(row.get("entity") or {}),
                "relationship_family": payload["relationship_family"],
                "native_relationships": row.get("native_relationships") or [],
                "evidence": [_edge_evidence(x) for x in (row.get("raw_evidence") or []) if isinstance(x, dict)],
            })
        payload["results"] = results
        payload["count"] = len(results)
        return payload

    def counter_features(self, counter: str, *, limit: int = 100) -> Dict[str, Any]:
        return self._reverse_features(counter, source_kind="counter", limit=limit)

    def parameter_features(self, parameter: str, *, limit: int = 100) -> Dict[str, Any]:
        return self._reverse_features(parameter, source_kind="parameter", limit=limit)

    def alarm_features(self, alarm: str, *, limit: int = 100) -> Dict[str, Any]:
        return self._reverse_features(alarm, source_kind="alarm", limit=limit)

    def _reverse_features(self, value: str, *, source_kind: str, limit: int) -> Dict[str, Any]:
        if source_kind == "counter":
            resolution = self._resolve_counter(value)
            family = "FEATURE_COUNTER"
        elif source_kind == "parameter":
            resolution = self._resolve_parameter(value)
            family = "FEATURE_PARAMETER"
        else:
            resolution = self._resolve_alarm(value)
            family = "FEATURE_ALARM"

        payload: Dict[str, Any] = {
            "tool": f"{source_kind}_features",
            "query": value,
            f"{source_kind}_resolution": resolution,
            "relationship_family": family,
            "results": [],
            "count": 0,
        }
        candidates = resolution.get("candidates") or []
        # Follow all highest-score candidates.  This preserves useful results for
        # same-name counters while marking the resolution as ambiguous.
        top_score = resolution.get("top_score")
        source_eids = [
            str(row.get("element_id") or "")
            for row in candidates
            if row.get("element_id") and (top_score is None or row.get("score") == top_score)
        ]
        if not source_eids:
            return payload

        rows = self._run(
            """
            MATCH (s)-[r]-(f:Feature)
            WHERE elementId(s) IN $source_eids
            WITH s, f,
                 collect(DISTINCT type(r)) AS native_relationships,
                 collect(DISTINCT properties(r))[0..10] AS raw_evidence
            RETURN elementId(s) AS source_element_id, labels(s) AS source_labels,
                   properties(s) AS source_entity,
                   elementId(f) AS feature_element_id, properties(f) AS feature,
                   native_relationships, raw_evidence
            ORDER BY coalesce(f.name,'')
            LIMIT $limit
            """,
            trace_name=f"reverse_features_{source_kind}",
            source_eids=source_eids,
            limit=limit,
        )
        results = []
        for row in rows:
            results.append({
                "source_element_id": row.get("source_element_id"),
                "source_labels": row.get("source_labels") or [],
                "source_entity": _json_safe(row.get("source_entity") or {}),
                "feature_element_id": row.get("feature_element_id"),
                "feature": _json_safe(row.get("feature") or {}),
                "relationship_family": family,
                "native_relationships": row.get("native_relationships") or [],
                "evidence": [_edge_evidence(x) for x in (row.get("raw_evidence") or []) if isinstance(x, dict)],
            })
        payload["results"] = results
        payload["count"] = len(results)
        return payload

    def counter_parameters_via_features(self, counter: str, *, limit: int = 300) -> Dict[str, Any]:
        resolution = self._resolve_counter(counter)
        return self._via_features(
            query=counter,
            source_resolution=resolution,
            source_kind="counter",
            target_kind="parameter",
            target_label="MOAttribute",
            limit=limit,
        )

    def parameter_counters_via_features(self, parameter: str, *, limit: int = 300) -> Dict[str, Any]:
        resolution = self._resolve_parameter(parameter)
        return self._via_features(
            query=parameter,
            source_resolution=resolution,
            source_kind="parameter",
            target_kind="counter",
            target_label="COUNTER_UNION",
            limit=limit,
        )

    def _via_features(
        self,
        *,
        query: str,
        source_resolution: Dict[str, Any],
        source_kind: str,
        target_kind: str,
        target_label: str,
        limit: int,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "tool": f"{source_kind}_{target_kind}s_via_features",
            "query": query,
            f"{source_kind}_resolution": source_resolution,
            "path": f"{source_kind} -> Feature -> {target_kind}",
            "results": [],
            "count": 0,
        }
        candidates = source_resolution.get("candidates") or []
        top_score = source_resolution.get("top_score")
        source_eids = [
            str(row.get("element_id") or "")
            for row in candidates
            if row.get("element_id") and (top_score is None or row.get("score") == top_score)
        ]
        if not source_eids:
            return payload

        target_where = "(t:PmCounter OR t:EbsCounter)" if target_label == "COUNTER_UNION" else f"t:{target_label}"
        rows = self._run(
            f"""
            MATCH (s)-[sr]-(f:Feature)-[tr]-(t)
            WHERE elementId(s) IN $source_eids AND {target_where}
              AND elementId(s) <> elementId(t)
            WITH s, f, t,
                 collect(DISTINCT type(sr)) AS source_native_relationships,
                 collect(DISTINCT type(tr)) AS target_native_relationships,
                 collect(DISTINCT properties(sr))[0..5] AS source_raw_evidence,
                 collect(DISTINCT properties(tr))[0..5] AS target_raw_evidence
            RETURN elementId(s) AS source_element_id, labels(s) AS source_labels,
                   properties(s) AS source_entity,
                   elementId(f) AS feature_element_id, properties(f) AS feature,
                   elementId(t) AS target_element_id, labels(t) AS target_labels,
                   properties(t) AS target_entity,
                   source_native_relationships, target_native_relationships,
                   source_raw_evidence, target_raw_evidence
            ORDER BY coalesce(f.name,''), coalesce(t.name,t.specific_problem,'')
            LIMIT $limit
            """,
            trace_name=f"via_features_{source_kind}_to_{target_kind}",
            source_eids=source_eids,
            limit=limit,
        )
        results = []
        for row in rows:
            results.append({
                "source_element_id": row.get("source_element_id"),
                "source_labels": row.get("source_labels") or [],
                "source_entity": _json_safe(row.get("source_entity") or {}),
                "feature_element_id": row.get("feature_element_id"),
                "feature": _json_safe(row.get("feature") or {}),
                "target_element_id": row.get("target_element_id"),
                "target_labels": row.get("target_labels") or [],
                "target_entity": _json_safe(row.get("target_entity") or {}),
                "source_relationship_family": f"FEATURE_{source_kind.upper()}",
                "target_relationship_family": f"FEATURE_{target_kind.upper()}",
                "source_native_relationships": row.get("source_native_relationships") or [],
                "target_native_relationships": row.get("target_native_relationships") or [],
                "source_evidence": [_edge_evidence(x) for x in (row.get("source_raw_evidence") or []) if isinstance(x, dict)],
                "target_evidence": [_edge_evidence(x) for x in (row.get("target_raw_evidence") or []) if isinstance(x, dict)],
            })
        payload["results"] = results
        payload["count"] = len(results)
        return payload

    # ------------------------------------------------------------------
    # Agent-oriented generic context and backward compatibility
    # ------------------------------------------------------------------

    def search_context(self, query_text: str, *, limit: int = 20) -> Dict[str, Any]:
        """Resolve likely high-level entities and expose related Features.

        This intentionally does not dump arbitrary schema neighbours.  It is the
        safe fallback used when deterministic graph-tool planning cannot select
        a narrower operation.
        """
        limit = max(1, min(int(limit), 100))
        feature = self._resolve_feature(query_text, limit=limit)
        counter = self._resolve_counter(query_text, limit=limit)
        parameter = self._resolve_parameter(query_text, limit=limit)
        alarm = self._resolve_alarm(query_text, limit=limit)
        payload: Dict[str, Any] = {
            "tool": "search_context",
            "query": query_text,
            "resolutions": {
                "feature": feature,
                "counter": counter,
                "parameter": parameter,
                "alarm": alarm,
            },
            "related": {},
        }
        if feature.get("resolved"):
            payload["related"]["feature_context"] = self.feature_context(query_text, limit=limit)
        if counter.get("found"):
            payload["related"]["counter_features"] = self.counter_features(query_text, limit=limit)
        if parameter.get("found"):
            payload["related"]["parameter_features"] = self.parameter_features(query_text, limit=limit)
        if alarm.get("found"):
            payload["related"]["alarm_features"] = self.alarm_features(query_text, limit=limit)
        return payload

    def package_context(self, value: str) -> Dict[str, Any]:
        package_id = normalize_package_id(value)
        return {
            "package_id": package_id,
            "found": False,
            "message": "Value-package relationships are provided by the OpenSearch manifest layer, not the Ericsson V4 graph.",
        }

    def relations(self, value: str, *, limit: int = 100) -> Dict[str, Any]:
        feature = self._resolve_feature(value)
        if feature.get("resolved"):
            return self.feature_context(value, limit=limit)
        return self.search_context(value, limit=min(limit, 100))
