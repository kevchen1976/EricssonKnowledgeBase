"""Agent-facing Ericsson graph tools with detailed call tracing.

The endpoint names describe high-level relationship families. Native Neo4j
relationship types are returned as metadata but are not required as input.
"""
from __future__ import annotations

import json
import time
from typing import Any, Callable

from fastapi import APIRouter, HTTPException, Query

from agent_core.logging_utils import single_line

from ..repository import GraphRepository
from ..state import GraphConfigurationError, GraphDisabledError, get_state

router = APIRouter()


def _repository() -> GraphRepository:
    state = get_state()
    if not state.enabled:
        raise HTTPException(status_code=503, detail="Ericsson Neo4j integration is disabled")
    return GraphRepository(state)


def _result_summary(payload: Any) -> str:
    if not isinstance(payload, dict):
        return f"type={type(payload).__name__}"

    summary: dict[str, Any] = {
        "tool": payload.get("tool"),
        "count": payload.get("count"),
    }
    for key in (
        "feature_resolution",
        "counter_resolution",
        "parameter_resolution",
        "alarm_resolution",
    ):
        resolution = payload.get(key)
        if not isinstance(resolution, dict):
            continue
        summary[key] = {
            "found": resolution.get("found"),
            "ambiguous": resolution.get("ambiguous"),
            "top_score": resolution.get("top_score"),
            "candidate_count": len(resolution.get("candidates") or []),
        }

    if isinstance(payload.get("results"), list):
        summary["result_count"] = len(payload["results"])
    for key in ("counters", "parameters", "alarms"):
        if isinstance(payload.get(key), list):
            summary[f"{key}_count"] = len(payload[key])
    if isinstance(payload.get("related"), dict):
        summary["related_keys"] = sorted(payload["related"].keys())

    return single_line(
        json.dumps(summary, ensure_ascii=False, default=str, sort_keys=True),
        max_chars=1200,
    )


def _translate(tool: str, arguments: dict[str, Any], call: Callable[[], Any]):
    state = get_state()
    started = time.perf_counter()
    argument_preview = single_line(
        json.dumps(arguments, ensure_ascii=False, default=str, sort_keys=True),
        max_chars=1200,
    )
    state.logger.info(
        "[GRAPH TOOL START] tool=%s arguments=%s",
        tool,
        argument_preview,
    )
    try:
        payload = call()
    except GraphDisabledError as exc:
        latency_ms = (time.perf_counter() - started) * 1000.0
        state.logger.warning(
            "[GRAPH TOOL DISABLED] tool=%s latency_ms=%.1f error=%s",
            tool,
            latency_ms,
            exc,
        )
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except GraphConfigurationError as exc:
        latency_ms = (time.perf_counter() - started) * 1000.0
        state.logger.error(
            "[GRAPH TOOL CONFIG ERROR] tool=%s latency_ms=%.1f error=%s",
            tool,
            latency_ms,
            exc,
        )
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        latency_ms = (time.perf_counter() - started) * 1000.0
        state.logger.warning(
            "[GRAPH TOOL BAD REQUEST] tool=%s latency_ms=%.1f error=%s",
            tool,
            latency_ms,
            exc,
        )
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        latency_ms = (time.perf_counter() - started) * 1000.0
        state.logger.exception(
            "[GRAPH TOOL ERROR] tool=%s latency_ms=%.1f error=%s",
            tool,
            latency_ms,
            exc,
        )
        raise HTTPException(status_code=500, detail=f"Ericsson graph query failed: {exc}") from exc

    latency_ms = (time.perf_counter() - started) * 1000.0
    state.logger.info(
        "[GRAPH TOOL END] tool=%s latency_ms=%.1f summary=%s",
        tool,
        latency_ms,
        _result_summary(payload),
    )
    return payload


# ---------------------------------------------------------------------------
# Primary graph tools
# ---------------------------------------------------------------------------

@router.get("/tools/feature/context", summary="Get Feature graph context")
def feature_context_tool(
    feature: str = Query(..., min_length=1),
    limit: int = Query(100, ge=1, le=500),
) -> dict:
    args = {"feature": feature, "limit": limit}
    return _translate("feature_context", args, lambda: _repository().feature_context(feature, limit=limit))


@router.get("/tools/feature/counters", summary="Find all counters related to a Feature")
def feature_counters(
    feature: str = Query(..., min_length=1),
    limit: int = Query(200, ge=1, le=1000),
) -> dict:
    args = {"feature": feature, "limit": limit}
    return _translate("feature_counters", args, lambda: _repository().feature_counters(feature, limit=limit))


@router.get("/tools/feature/parameters", summary="Find all parameters/attributes related to a Feature")
def feature_parameters(
    feature: str = Query(..., min_length=1),
    limit: int = Query(200, ge=1, le=1000),
) -> dict:
    args = {"feature": feature, "limit": limit}
    return _translate("feature_parameters", args, lambda: _repository().feature_parameters(feature, limit=limit))


@router.get("/tools/feature/attributes", summary="Alias: find all MO attributes related to a Feature")
def feature_attributes(
    feature: str = Query(..., min_length=1),
    limit: int = Query(200, ge=1, le=1000),
) -> dict:
    args = {"feature": feature, "limit": limit}
    return _translate("feature_attributes", args, lambda: _repository().feature_parameters(feature, limit=limit))


@router.get("/tools/feature/alarms", summary="Find all FM alarm types related to a Feature")
def feature_alarms(
    feature: str = Query(..., min_length=1),
    limit: int = Query(200, ge=1, le=1000),
) -> dict:
    args = {"feature": feature, "limit": limit}
    return _translate("feature_alarms", args, lambda: _repository().feature_alarms(feature, limit=limit))


@router.get("/tools/counter/context", summary="Resolve one Ericsson counter without Feature traversal")
def counter_context(
    counter: str = Query(..., min_length=1),
    limit: int = Query(40, ge=1, le=100),
) -> dict:
    args = {"counter": counter, "limit": limit}
    return _translate("counter_context", args, lambda: _repository().counter_context(counter, limit=limit))


@router.get("/tools/parameter/context", summary="Resolve one Ericsson MOAttribute without Feature traversal")
def parameter_context(
    parameter: str = Query(..., min_length=1),
    limit: int = Query(30, ge=1, le=100),
) -> dict:
    args = {"parameter": parameter, "limit": limit}
    return _translate("parameter_context", args, lambda: _repository().parameter_context(parameter, limit=limit))


@router.get("/tools/counter/features", summary="Find Features related to a counter")
def counter_features(
    counter: str = Query(..., min_length=1),
    limit: int = Query(100, ge=1, le=500),
) -> dict:
    args = {"counter": counter, "limit": limit}
    return _translate("counter_features", args, lambda: _repository().counter_features(counter, limit=limit))


@router.get("/tools/parameter/features", summary="Find Features related to a parameter/attribute")
def parameter_features(
    parameter: str = Query(..., min_length=1),
    limit: int = Query(100, ge=1, le=500),
) -> dict:
    args = {"parameter": parameter, "limit": limit}
    return _translate("parameter_features", args, lambda: _repository().parameter_features(parameter, limit=limit))


@router.get("/tools/attribute/features", summary="Alias: find Features related to an MO attribute")
def attribute_features(
    attribute: str = Query(..., min_length=1),
    limit: int = Query(100, ge=1, le=500),
) -> dict:
    args = {"attribute": attribute, "limit": limit}
    return _translate("attribute_features", args, lambda: _repository().parameter_features(attribute, limit=limit))


@router.get("/tools/alarm/features", summary="Find Features related to an FM alarm type")
def alarm_features(
    alarm: str = Query(..., min_length=1),
    limit: int = Query(100, ge=1, le=500),
) -> dict:
    args = {"alarm": alarm, "limit": limit}
    return _translate("alarm_features", args, lambda: _repository().alarm_features(alarm, limit=limit))


@router.get(
    "/tools/counter/parameters-via-features",
    summary="Find parameters connected to a counter through shared Features",
)
def counter_parameters_via_features(
    counter: str = Query(..., min_length=1),
    limit: int = Query(300, ge=1, le=1000),
) -> dict:
    args = {"counter": counter, "limit": limit}
    return _translate(
        "counter_parameters_via_features",
        args,
        lambda: _repository().counter_parameters_via_features(counter, limit=limit),
    )


@router.get(
    "/tools/parameter/counters-via-features",
    summary="Find counters connected to a parameter through shared Features",
)
def parameter_counters_via_features(
    parameter: str = Query(..., min_length=1),
    limit: int = Query(300, ge=1, le=1000),
) -> dict:
    args = {"parameter": parameter, "limit": limit}
    return _translate(
        "parameter_counters_via_features",
        args,
        lambda: _repository().parameter_counters_via_features(parameter, limit=limit),
    )


@router.get("/tools/search", summary="Resolve graph entities and return safe Feature-centred context")
def graph_search(
    query: str = Query(..., min_length=1),
    limit: int = Query(20, ge=1, le=100),
) -> dict:
    args = {"query": query, "limit": limit}
    return _translate("search_context", args, lambda: _repository().search_context(query, limit=limit))


# ---------------------------------------------------------------------------
# Backward-compatible endpoints retained for older clients
# ---------------------------------------------------------------------------

@router.get("/feature/{feature_id}/context")
def feature_context(feature_id: str) -> dict:
    args = {"feature_id": feature_id}
    return _translate("feature_context_legacy", args, lambda: _repository().feature_context(feature_id))


@router.get("/package/{package_id}/context")
def package_context(package_id: str) -> dict:
    args = {"package_id": package_id}
    return _translate("package_context_legacy", args, lambda: _repository().package_context(package_id))


@router.get("/relations/search")
def search_relations(query: str, limit: int = Query(20, ge=1, le=100)) -> dict:
    args = {"query": query, "limit": limit}
    return _translate("relations_search_legacy", args, lambda: _repository().search_context(query, limit=limit))


@router.get("/relations/{entity_id}")
def relations(entity_id: str, limit: int = Query(100, ge=1, le=1000)) -> dict:
    args = {"entity_id": entity_id, "limit": limit}
    return _translate("relations_legacy", args, lambda: _repository().relations(entity_id, limit=limit))
