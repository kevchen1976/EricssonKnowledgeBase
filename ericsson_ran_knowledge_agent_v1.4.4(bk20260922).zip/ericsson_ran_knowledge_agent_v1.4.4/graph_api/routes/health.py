from __future__ import annotations

from fastapi import APIRouter, Response, status

from ..state import get_state

router = APIRouter()


@router.get("/health")
def health() -> dict:
    state = get_state()
    graph = state.status()
    return {
        "status": "ok" if not state.enabled else graph.get("status", "unknown"),
        "service": "ericsson-graph-api",
        "graph": graph,
        "logging": {
            "http_log": str(state.http_log_path),
            "query_log": str(state.query_log_path),
        },
    }


@router.get("/ready")
def ready(response: Response) -> dict:
    state = get_state()
    graph = state.status()
    ready_value = bool(graph.get("connected"))
    if not ready_value:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    return {
        "ready": ready_value,
        "graph": graph,
        "logging": {
            "http_log": str(state.http_log_path),
            "query_log": str(state.query_log_path),
        },
    }
