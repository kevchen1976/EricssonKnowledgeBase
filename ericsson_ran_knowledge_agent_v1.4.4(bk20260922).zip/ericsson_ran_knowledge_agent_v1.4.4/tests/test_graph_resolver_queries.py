from __future__ import annotations

import unittest
from types import SimpleNamespace

from graph_api.repository import GraphRepository


class CapturingRepository(GraphRepository):
    def __init__(self):
        self.state = SimpleNamespace()
        self.settings = SimpleNamespace()
        self.queries = []

    def _run(self, query: str, *, trace_name: str = "cypher", **parameters):
        self.queries.append((trace_name, query, parameters))
        return []


class ResolverQueryShapeTests(unittest.TestCase):
    def test_pm_counter_qualified_alias_is_projected_before_score_case(self):
        repo = CapturingRepository()
        repo._resolve_counter("pmRrcConnCatmMax")
        query = next(q for name, q, _ in repo.queries if name == "resolve_pm_counter")
        self.assertIn("AS qualified\n            WITH c, m, qualified,", query)
        self.assertIn("$raw_lower CONTAINS qualified", query)

    def test_parameter_qualified_alias_is_projected_before_score_case(self):
        repo = CapturingRepository()
        repo._resolve_parameter("UeMeasControl.nrB1MeasEnabled")
        query = next(q for name, q, _ in repo.queries if name == "resolve_parameter")
        self.assertIn("AS qualified\n            WITH p, qualified,", query)
        self.assertIn("$raw_lower CONTAINS qualified", query)

    def test_alarm_compact_aliases_are_projected_before_score_case(self):
        repo = CapturingRepository()
        repo._resolve_alarm("Resource Allocation Failure")
        query = next(q for name, q, _ in repo.queries if name == "resolve_alarm")
        self.assertIn("AS compact_problem\n            WITH a, compact_id, compact_problem,", query)
        self.assertIn("WHEN compact_id = $compact", query)


if __name__ == "__main__":
    unittest.main()
