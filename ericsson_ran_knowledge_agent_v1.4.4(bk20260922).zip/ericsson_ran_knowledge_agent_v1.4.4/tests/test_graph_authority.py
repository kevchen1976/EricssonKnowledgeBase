from __future__ import annotations

import unittest
from pathlib import Path

from agent_core.graph_tools import execute_graph_tools, GraphToolCall
from agent_core.synthesis import synthesize_answer


class FakeCounterGraphClient:
    def counter_features(self, counter: str, *, limit: int = 100):
        return {
            "tool": "counter_features",
            "query": counter,
            "counter_resolution": {"found": True, "ambiguous": False},
            "results": [
                {
                    "source_entity": {"name": counter},
                    "feature": {"name": "64-QAM Uplink", "feature_identity": "FAJ 121 4363"},
                    "native_relationships": ["USES_COUNTER"],
                }
            ],
        }


class CapturingModel:
    def __init__(self):
        self.prompt = ""
        self.system = ""

    def generate(self, prompt: str, *, system: str, temperature: float):
        self.prompt = prompt
        self.system = system
        return "According to the Ericsson graph, the counter is related to 64-QAM Uplink."


class GraphAuthorityTests(unittest.TestCase):
    def _graph_context(self):
        execution = execute_graph_tools(
            FakeCounterGraphClient(),
            [GraphToolCall("counter_features", {"counter": "pmRrcConnCatmMax", "limit": 25})],
        )
        return execution.context

    def _evidence(self):
        return [
            {
                "_id": "doc-1",
                "_score": 100.0,
                "_source": {
                    "parent_id": "doc-1",
                    "title": "Vector Candidate",
                    "filename": "Feature.md",
                    "content": "Semantic search also mentions another feature, but this is not graph relationship evidence.",
                    "page_start": 1,
                    "page_end": 1,
                    "heading_path": "Overview",
                },
            }
        ]

    def test_graph_context_declares_relationship_authority(self):
        context = self._graph_context()
        self.assertEqual(context["authority"], "primary_for_supported_relationships")
        self.assertIn("must come from the graph", context["relationship_policy"])

    def test_system_instruction_prioritizes_graph_relationships(self):
        root = Path(__file__).resolve().parents[1]
        instruction = (root / "agentInstruction.txt").read_text(encoding="utf-8")
        self.assertIn("Neo4j is the primary and authoritative source", instruction)
        self.assertIn("MUST come from Neo4j", instruction)
        self.assertIn("vector search may be used as a fallback", instruction)

    def test_llm_prompt_places_graph_before_vector_and_forbids_vector_expansion(self):
        model = CapturingModel()
        synthesize_answer(
            "Which feature is related to pmRrcConnCatmMax?",
            self._evidence(),
            ollama=model,
            graph_context=self._graph_context(),
        )
        self.assertLess(
            model.prompt.index("ERICSSON NEO4J GRAPH CONTEXT"),
            model.prompt.index("ERICSSON DOCUMENT / VECTOR EVIDENCE"),
        )
        self.assertIn("must not add extra relationship entities", model.prompt)
        self.assertIn("lead with the Neo4j graph result", model.prompt)

    def test_no_llm_fallback_presents_graph_before_document_evidence(self):
        answer, _ = synthesize_answer(
            "Which feature is related to pmRrcConnCatmMax?",
            self._evidence(),
            ollama=None,
            graph_context=self._graph_context(),
        )
        self.assertLess(
            answer.index("Ericsson graph provides"),
            answer.index("indexed Ericsson documentation"),
        )


if __name__ == "__main__":
    unittest.main()
