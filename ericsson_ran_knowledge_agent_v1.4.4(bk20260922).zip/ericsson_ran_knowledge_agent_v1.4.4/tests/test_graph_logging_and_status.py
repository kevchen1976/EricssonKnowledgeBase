from __future__ import annotations

import logging
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from graph_api.repository import GraphRepository
from graph_api.state import GraphConfigurationError, GraphState


class RecordingLogger:
    def __init__(self) -> None:
        self.entries: list[str] = []

    def _add(self, message: str, args: tuple) -> None:
        self.entries.append(message % args if args else message)

    def info(self, message: str, *args, **kwargs) -> None:
        del kwargs
        self._add(message, args)

    def error(self, message: str, *args, **kwargs) -> None:
        del kwargs
        self._add(message, args)

    def warning(self, message: str, *args, **kwargs) -> None:
        del kwargs
        self._add(message, args)

    def exception(self, message: str, *args, **kwargs) -> None:
        del kwargs
        self._add(message, args)


class FakeSession:
    def __init__(self) -> None:
        self.query = ""
        self.parameters = {}

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def run(self, query: str, **parameters):
        self.query = query
        self.parameters = parameters
        return [{"value": parameters.get("value")}]


class FakeDriver:
    def __init__(self) -> None:
        self.last_session = FakeSession()

    def session(self, database=None):
        self.database = database
        return self.last_session




class DatabaseNotFoundError(RuntimeError):
    code = "Neo.ClientError.Database.DatabaseNotFound"


class MissingDatabaseSession:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def run(self, query: str, **parameters):
        raise DatabaseNotFoundError("Graph not found: ne04j")


class MissingDatabaseDriver:
    def verify_connectivity(self):
        return None

    def session(self, database=None):
        self.database = database
        return MissingDatabaseSession()


class ConsumingResult:
    def consume(self):
        return None


class ReadySession:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def run(self, query: str, **parameters):
        return ConsumingResult()


class ReadyDriver:
    def verify_connectivity(self):
        return None

    def session(self, database=None):
        self.database = database
        return ReadySession()


class GraphLoggingAndFrontendTests(unittest.TestCase):
    def test_repository_writes_start_and_end_query_trace_with_redaction(self):
        logger = RecordingLogger()
        driver = FakeDriver()
        state = SimpleNamespace(
            settings=SimpleNamespace(neo4j_database="neo4j"),
            query_preview_chars=1200,
            parameter_preview_chars=1000,
            query_logger=logger,
            driver=lambda: driver,
        )
        repository = GraphRepository(state)

        rows = repository._run(
            "RETURN $value AS value",
            trace_name="unit_trace",
            value=7,
            password="do-not-log-this",
        )

        self.assertEqual(rows, [{"value": 7}])
        joined = "\n".join(logger.entries)
        self.assertIn("[GRAPH CYPHER START]", joined)
        self.assertIn("operation=unit_trace", joined)
        self.assertIn("[GRAPH CYPHER END]", joined)
        self.assertIn('"password": "<redacted>"', joined)
        self.assertNotIn("do-not-log-this", joined)

    def test_graph_state_configures_dedicated_rotating_logs(self):
        with tempfile.TemporaryDirectory() as tmp:
            settings = SimpleNamespace(
                logs_dir=Path(tmp),
                graph_enabled=False,
                neo4j_uri="bolt://localhost:7688",
                neo4j_database="",
                neo4j_user="neo4j",
                neo4j_password="",
            )
            state = GraphState(settings)
            try:
                self.assertEqual(state.http_log_path.name, "ericsson_graph_api.log")
                self.assertEqual(state.query_log_path.name, "ericsson_graph_queries.log")
                self.assertTrue(state.http_log_path.exists())
                self.assertTrue(state.query_log_path.exists())
                self.assertEqual(state.status()["status"], "disabled")
            finally:
                state.close()
                for logger_name in ("ericsson_graph_api", "ericsson_graph_queries"):
                    logger = logging.getLogger(logger_name)
                    for handler in list(logger.handlers):
                        handler.flush()
                        handler.close()
                        logger.removeHandler(handler)

    def test_graph_state_ready_validates_configured_database_not_just_bolt(self):
        with tempfile.TemporaryDirectory() as tmp:
            settings = SimpleNamespace(
                logs_dir=Path(tmp),
                graph_enabled=True,
                neo4j_uri="bolt://localhost:7688",
                neo4j_database="ne04j",
                neo4j_user="neo4j",
                neo4j_password="",
            )
            state = GraphState(settings)
            state._driver = MissingDatabaseDriver()
            try:
                payload = state.status()
                self.assertFalse(payload["connected"])
                self.assertFalse(payload["database_ready"])
                self.assertEqual(payload["status"], "configuration_error")
                self.assertIn("NEO4J_DATABASE", payload["error"])
                self.assertIn("ne04j", payload["error"])
            finally:
                state._driver = None
                for logger_name in ("ericsson_graph_api", "ericsson_graph_queries"):
                    logger = logging.getLogger(logger_name)
                    for handler in list(logger.handlers):
                        handler.flush()
                        handler.close()
                        logger.removeHandler(handler)

    def test_graph_state_ready_uses_exact_configured_database(self):
        with tempfile.TemporaryDirectory() as tmp:
            settings = SimpleNamespace(
                logs_dir=Path(tmp),
                graph_enabled=True,
                neo4j_uri="bolt://localhost:7688",
                neo4j_database="neo4j",
                neo4j_user="neo4j",
                neo4j_password="",
            )
            state = GraphState(settings)
            driver = ReadyDriver()
            state._driver = driver
            try:
                payload = state.status()
                self.assertTrue(payload["connected"])
                self.assertTrue(payload["database_ready"])
                self.assertEqual(driver.database, "neo4j")
            finally:
                state._driver = None
                for logger_name in ("ericsson_graph_api", "ericsson_graph_queries"):
                    logger = logging.getLogger(logger_name)
                    for handler in list(logger.handlers):
                        handler.flush()
                        handler.close()
                        logger.removeHandler(handler)

    def test_repository_translates_missing_database_to_configuration_error(self):
        logger = RecordingLogger()
        driver = MissingDatabaseDriver()
        state = SimpleNamespace(
            settings=SimpleNamespace(neo4j_database="ne04j"),
            query_preview_chars=1200,
            parameter_preview_chars=1000,
            query_logger=logger,
            driver=lambda: driver,
        )
        repository = GraphRepository(state)
        with self.assertRaises(GraphConfigurationError) as ctx:
            repository._run("RETURN 1", trace_name="missing_database")
        self.assertIn("ne04j", str(ctx.exception))
        self.assertIn("NEO4J_DATABASE", str(ctx.exception))

    def test_frontend_uses_component_kb_status_not_aggregate_ready(self):
        root = Path(__file__).resolve().parents[1]
        html = (root / "static" / "index.html").read_text(encoding="utf-8")
        self.assertIn("const kbOk = hasKbStatus ? ready.kb_ready", html)
        self.assertIn("Services Degraded", html)
        self.assertIn("ready.graph_ready", html)
        self.assertNotIn("const kbOk = readyResp.ok && !!ready.ready;", html)


class AgentReadyComponentTests(unittest.TestCase):
    def test_kb_can_be_ready_when_aggregate_service_is_degraded(self):
        from fastapi import Response
        from unittest.mock import patch
        from agent_service.routes import system as system_routes

        class FakeResponse:
            def __init__(self, status_code, payload):
                self.status_code = status_code
                self._payload = payload
                self.text = str(payload)

            def json(self):
                return self._payload

        settings = SimpleNamespace(
            kb_api_url="http://kb",
            kb_timeout=5,
            session_memory_enabled=False,
            graph_enabled=True,
            graph_api_url="http://graph",
            graph_timeout=5,
        )
        fake_state = SimpleNamespace(settings=settings, sessions=SimpleNamespace())
        response = Response()

        with patch.object(system_routes, "get_state", return_value=fake_state), patch.object(
            system_routes.httpx,
            "get",
            side_effect=[
                FakeResponse(200, {"ready": True}),
                FakeResponse(503, {"ready": False}),
            ],
        ):
            payload = system_routes.ready(response)

        self.assertEqual(response.status_code, 503)
        self.assertTrue(payload["kb_ready"])
        self.assertFalse(payload["graph_ready"])
        self.assertEqual(payload["status"], "degraded")
        self.assertTrue(payload["components"]["knowledge_base"]["ready"])


if __name__ == "__main__":
    unittest.main()
