from __future__ import annotations

import unittest
from types import SimpleNamespace

from agent_core.graph_tools import execute_graph_tools, plan_graph_tools
from agent_core.routing import route_query
from agent_core.validation import validate_answer
from graph_api.application import app
from graph_api.repository import _json_safe
from agent_core.workflow import EricssonAgent, _supervisor_local_kb_queries


class FakeGraphClient:
    def alarm_features(self, alarm: str, *, limit: int = 100):
        return {
            "tool": "alarm_features",
            "query": alarm,
            "alarm_resolution": {
                "found": True,
                "ambiguous": False,
                "top_score": 92,
                "candidates": [
                    {
                        "score": 92,
                        "entity": {
                            "specific_problem": "Resource Allocation Failure",
                            "fm_alarm_type_id": "ResourceAllocationFailure",
                        },
                    }
                ],
            },
            "results": [
                {
                    "feature": {
                        "name": "Digital Sectorization with AAS FDD",
                        "feature_identity": "FAJ 121 5066",
                    },
                    "native_relationships": ["RELATED_ALARM"],
                }
            ],
        }


class FakeKBClient:
    def __init__(self):
        self.search_queries = []
        self.feature_queries = []

    @staticmethod
    def _hit(query: str):
        return {
            "_id": query,
            "_score": 1.0,
            "_source": {
                "parent_id": query,
                "title": "Alarm Instructions",
                "filename": "Operation Instructions.md",
                "content": "Follow the documented correction procedure for the alarm.",
                "page_start": 1,
                "page_end": 1,
                "heading_path": "Correction Instructions",
            },
        }

    def search(self, query: str, *, limit: int, filters=None):
        self.search_queries.append(query)
        return {"results": [self._hit(query)], "warnings": [], "fallback_type": "test"}

    def retrieve_feature(self, feature_id: str, query: str, *, limit: int, include_related=True):
        self.feature_queries.append(feature_id)
        return {"results": [self._hit(feature_id + query)], "warnings": [], "fallback_type": "test"}

    def retrieve_package(self, package_id: str, query: str, *, limit: int):
        return {"results": [], "warnings": []}


class FakeWorkflowGraphClient(FakeGraphClient):
    pass


class FakeLocalEntityGraphClient:
    def counter_context(self, counter: str, *, limit: int = 40):
        owner, name = counter.split(".", 1) if "." in counter else ("NRCellDU", counter)
        return {
            "tool": "counter_context",
            "query": counter,
            "counter_resolution": {
                "found": True,
                "ambiguous": False,
                "top_score": 98,
                "resolved": {
                    "qualified_name": f"{owner}.{name}",
                    "owner": owner,
                    "entity": {
                        "name": name,
                        "description": "Test counter description",
                        "unit": "bytes",
                    },
                    "score": 98,
                },
                "candidates": [],
            },
        }

    def parameter_context(self, parameter: str, *, limit: int = 30):
        owner, name = parameter.split(".", 1) if "." in parameter else ("NRCellDU", parameter)
        return {
            "tool": "parameter_context",
            "query": parameter,
            "parameter_resolution": {
                "found": True,
                "ambiguous": False,
                "top_score": 98,
                "resolved": {
                    "qualified_name": f"{owner}.{name}",
                    "entity": {"name": name, "mo_class": owner, "description": "Test parameter description"},
                    "score": 98,
                },
                "candidates": [],
            },
        }


class GraphIntegrationTests(unittest.TestCase):
    def test_alarm_query_routes_to_graph(self):
        route = route_query(
            "What are the correction instructions for Resource Allocation Failure alarm?",
            graph_enabled=True,
        )
        self.assertTrue(route.use_graph)
        self.assertEqual(route.workflow, "graph_assisted_search")

    def test_feature_to_feature_stays_in_vector_search(self):
        route = route_query(
            "Which related features are similar to Outgoing NR IRAT Handover?",
            graph_enabled=True,
        )
        self.assertFalse(route.use_graph)
        self.assertEqual(route.workflow, "knowledge_search")

    def test_feature_counter_tool_plan(self):
        calls = plan_graph_tools(
            "What counters are related to FAJ 121 5377?",
            feature_ids=["FAJ 121 5377"],
            limit=5,
        )
        self.assertEqual([call.tool for call in calls], ["feature_counters"])

    def test_counter_to_parameter_multihop_plan(self):
        calls = plan_graph_tools(
            "What parameters are related to EUtranCellFDD.pmHoExeAttBlindNr through features?",
            limit=5,
        )
        self.assertEqual([call.tool for call in calls], ["counter_parameters_via_features"])

    def test_parameter_to_counter_multihop_plan(self):
        calls = plan_graph_tools(
            "What counters are related to UeMeasControl.nrB1MeasEnabled through features?",
            limit=5,
        )
        self.assertEqual([call.tool for call in calls], ["parameter_counters_via_features"])


    def test_counter_reverse_lookup_passes_exact_counter_token(self):
        calls = plan_graph_tools(
            "What is the functionality of the counter pmRrcConnCatmMax?",
            limit=5,
        )
        self.assertEqual([call.tool for call in calls], ["counter_context"])
        self.assertEqual(calls[0].arguments["counter"], "pmRrcConnCatmMax")

    def test_counter_multihop_passes_exact_counter_token(self):
        calls = plan_graph_tools(
            "What parameters are related to EUtranCellFDD.pmHoExeAttBlindNr through features?",
            limit=5,
        )
        self.assertEqual(calls[0].arguments["counter"], "EUtranCellFDD.pmHoExeAttBlindNr")

    def test_parameter_reverse_lookup_passes_exact_parameter_token(self):
        calls = plan_graph_tools(
            "Which features use parameter UeMeasControl.nrB1MeasEnabled?",
            limit=5,
        )
        self.assertEqual([call.tool for call in calls], ["parameter_features"])
        self.assertEqual(calls[0].arguments["parameter"], "UeMeasControl.nrB1MeasEnabled")

    def test_parameter_profile_uses_context_not_feature_traversal(self):
        calls = plan_graph_tools(
            "Explain Ericsson parameter NRCellDU.cellRange",
            limit=5,
        )
        self.assertEqual([call.tool for call in calls], ["parameter_context"])
        self.assertEqual(calls[0].arguments["parameter"], "NRCellDU.cellRange")

    def test_supervisor_local_task_resolves_multiple_local_counters_only(self):
        calls = plan_graph_tools(
            "SUPERVISOR_LOCAL_ENTITY_TASK verify candidates NRCellDU.pmMacVolDl and NRCellDU.pmMacPduVolDlUePCell",
            limit=5,
        )
        self.assertEqual([call.tool for call in calls], ["counter_context", "counter_context"])
        self.assertEqual(calls[0].arguments["counter"], "NRCellDU.pmMacVolDl")
        self.assertEqual(calls[1].arguments["counter"], "NRCellDU.pmMacPduVolDlUePCell")


    def test_supervisor_local_task_resolves_multiple_local_parameters_only(self):
        calls = plan_graph_tools(
            "SUPERVISOR_LOCAL_ENTITY_TASK verify candidates NRCellDU.cellRange and NRCellDU.nRTAC",
            limit=5,
        )
        self.assertEqual([call.tool for call in calls], ["parameter_context", "parameter_context"])
        self.assertEqual(calls[0].arguments["parameter"], "NRCellDU.cellRange")
        self.assertEqual(calls[1].arguments["parameter"], "NRCellDU.nRTAC")

    def test_supervisor_local_task_ignores_incidental_feature_ids_in_candidate_context(self):
        calls = plan_graph_tools(
            "SUPERVISOR_LOCAL_ENTITY_TASK verify NRCellDU.pmMacVolDl; catalog note mentions FAJ 121 4908",
            feature_ids=["FAJ 121 4908"],
            limit=5,
        )
        self.assertEqual([call.tool for call in calls], ["counter_context"])
        self.assertEqual(calls[0].arguments["counter"], "NRCellDU.pmMacVolDl")

    def test_supervisor_local_task_without_local_entity_does_not_fall_through_to_graph_relations(self):
        calls = plan_graph_tools(
            "SUPERVISOR_LOCAL_ENTITY_TASK verify Ericsson metric/counter candidates only. External source meaning: downlink user data volume in bytes",
            limit=5,
        )
        self.assertEqual(calls, [])

    def test_supervisor_local_kb_query_extraction_prefers_local_candidates(self):
        queries = _supervisor_local_kb_queries(
            "SUPERVISOR_LOCAL_ENTITY_TASK\n"
            "External source meaning: downlink MAC PDU volume\n"
            "Candidate Ericsson entities from the supervisor catalog:\n"
            "1. NRCellDU.pmMacVolDl | ERICSSON_PMCOUNTER\n"
            "2. NRCellDU.pmMacPduVolDlUePCell | ERICSSON_PMCOUNTER"
        )
        self.assertEqual(queries, ["NRCellDU.pmMacVolDl", "NRCellDU.pmMacPduVolDlUePCell"])

    def test_supervisor_local_kb_query_falls_back_to_external_meaning_when_no_candidate(self):
        queries = _supervisor_local_kb_queries(
            "SUPERVISOR_LOCAL_ENTITY_TASK\n"
            "External source meaning: downlink MAC PDU volume for the serving primary cell"
        )
        self.assertEqual(queries, ["downlink MAC PDU volume for the serving primary cell"])

    def test_alarm_graph_output_drives_exact_kb_query(self):
        calls = plan_graph_tools(
            "How do I correct the Resource Allocation Failure alarm?",
            limit=5,
        )
        execution = execute_graph_tools(FakeGraphClient(), calls)
        self.assertIn("FAJ 121 5066", execution.related_feature_ids)
        self.assertTrue(
            any('"Resource Allocation Failure"' in query for query in execution.kb_queries)
        )

    def test_validation_accepts_graph_supported_feature_id(self):
        graph_context = {
            "tool_results": [
                {
                    "tool": "alarm_features",
                    "output": {
                        "results": [
                            {"feature": {"feature_identity": "FAJ 121 5066"}}
                        ]
                    },
                }
            ]
        }
        result = validate_answer(
            "The graph relates this alarm to FAJ 121 5066.",
            [],
            graph_context=graph_context,
        )
        self.assertEqual(result.unsupported_feature_ids, [])


    def test_supervisor_local_workflow_searches_kb_with_resolved_local_identity_only(self):
        settings = SimpleNamespace(
            graph_enabled=True,
            llm_enabled=False,
            enable_llm_query_rewrite=True,
            default_limit=5,
            maximum_limit=20,
        )
        kb = FakeKBClient()
        agent = EricssonAgent(
            settings=settings,
            kb=kb,
            graph=FakeLocalEntityGraphClient(),
            ollama=None,
        )
        result = agent.run(
            "SUPERVISOR_LOCAL_ENTITY_TASK\n"
            "Supervisor verification task: verify Ericsson-local metric/counter candidates only.\n"
            "External source meaning: downlink data volume in bytes\n"
            "Candidate Ericsson entities from the supervisor catalog:\n"
            "1. NRCellDU.pmMacVolDl | ERICSSON_PMCOUNTER",
            limit=5,
            include_evidence=True,
            history="irrelevant previous conversation",
        )
        self.assertEqual(kb.search_queries, ["NRCellDU.pmMacVolDl"])
        self.assertEqual(result.metadata.get("history_chars"), 0)
        self.assertTrue(result.metadata.get("supervisor_local_entity_task"))
        self.assertEqual(result.metadata.get("entity_profile_kb_queries"), ["NRCellDU.pmMacVolDl"])

    def test_workflow_combines_graph_resolution_and_vector_search(self):
        settings = SimpleNamespace(
            graph_enabled=True,
            llm_enabled=False,
            enable_llm_query_rewrite=False,
            default_limit=5,
            maximum_limit=20,
        )
        kb = FakeKBClient()
        agent = EricssonAgent(
            settings=settings,
            kb=kb,
            graph=FakeWorkflowGraphClient(),
            ollama=None,
        )
        result = agent.run(
            "How do I correct the Resource Allocation Failure alarm?",
            limit=5,
            include_evidence=True,
        )
        self.assertTrue(any('"Resource Allocation Failure"' in q for q in kb.search_queries))
        self.assertIn("FAJ 121 5066", kb.feature_queries)
        self.assertTrue(result.metadata.get("graph_tool_calls"))
        self.assertEqual(result.source, "ericsson_kb_graph")

    def test_graph_api_exposes_high_level_tools(self):
        paths = app.openapi()["paths"]
        expected = {
            "/tools/feature/counters",
            "/tools/feature/parameters",
            "/tools/feature/alarms",
            "/tools/counter/context",
            "/tools/parameter/context",
            "/tools/counter/features",
            "/tools/parameter/features",
            "/tools/alarm/features",
            "/tools/counter/parameters-via-features",
            "/tools/parameter/counters-via-features",
        }
        self.assertTrue(expected.issubset(set(paths)))

    def test_neo4j_values_are_json_safe(self):
        class FakeTemporal:
            def __str__(self):
                return "2026-09-14T10:00:00Z"

        self.assertEqual(
            _json_safe({"when": FakeTemporal()}),
            {"when": "2026-09-14T10:00:00Z"},
        )


if __name__ == "__main__":
    unittest.main()
