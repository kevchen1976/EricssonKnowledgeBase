#!/usr/bin/env python3
"""Backward-compatible executable and import facade for :mod:`agent_service`."""
from agent_service import *  # noqa: F401,F403
from agent_core.config import AGENT_WEB_PORT, SERVICE_BIND_HOST

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host=SERVICE_BIND_HOST, port=AGENT_WEB_PORT)
