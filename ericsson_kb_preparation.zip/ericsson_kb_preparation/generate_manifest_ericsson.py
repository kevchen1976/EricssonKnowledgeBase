#!/usr/bin/env python3
"""Generate Ericsson manifest records from already-produced Markdown files."""
from __future__ import annotations

import argparse
from pathlib import Path

from ericsson_kb.analyze import analyze_markdown
from ericsson_kb.manifest import manifest_records, write_jsonl, write_sidecar
from ericsson_kb.routing import build_routing


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("markdown", help="Markdown file or directory")
    p.add_argument("--output-dir", required=True)
    p.add_argument("--overwrite", action="store_true")
    args = p.parse_args()

    src = Path(args.markdown).expanduser().resolve()
    out = Path(args.output_dir).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    files = [src] if src.is_file() else sorted(src.glob("*.md"))
    all_records = []
    for md in files:
        analysis = analyze_markdown(md)
        records = manifest_records(analysis)
        all_records.extend(records)
        write_sidecar(analysis)
        write_jsonl(out / "manifests" / f"{md.stem}.manifest.jsonl", records)
        print(f"OK {md.name}: {analysis.doc_type}, owner={analysis.owner_feature_id or '-'}")
    combined = out / "combined_manifest.jsonl"
    write_jsonl(combined, all_records)
    build_routing(combined, out, overwrite=args.overwrite)
    print(f"Wrote {len(all_records)} records to {combined}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
