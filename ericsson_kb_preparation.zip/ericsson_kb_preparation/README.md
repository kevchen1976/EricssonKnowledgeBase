# Ericsson Knowledge-Base Preparation Pipeline

This package is a vendor-specific preparation fork derived from the design patterns in the Nokia pipeline and Nokia agent runtime that were supplied for review.

## What was preserved from the Nokia design

The Nokia implementation has several useful architectural properties that this Ericsson fork keeps:

- PDF -> Markdown conversion with page-aware content and image extraction.
- A combined JSONL manifest plus routing shards.
- `document`, `section`, and `fact` manifest records.
- Document-only topic aliases, matching the correction in the Nokia `manifest_rewrite.py`.
- Agent-facing fields such as `feature_id`, `filename`, `doc_type`, `manifest_stage`, `section_type`, `section_heading`, `heading_path`, `page_start`, `page_end`, `prerequisites`, `restriction_status`, and `feature_title`.
- Exact feature-document routing for feature-specific retrieval, while retaining global/topic retrieval for general documentation.

## Ericsson-specific changes

Ericsson documentation is not safely represented by a single feature-ID namespace. The preparation model therefore separates:

- Feature Identity: `FAJ 121 xxxx`
- Value Package Identity: `FAJ 801 xxxx`
- General documentation that may mention a feature without owning it

Three major document roles are used:

- `feature_document`: dedicated Feature Description with one owning `FAJ 121 xxxx`
- `package_document`: Commercial Product Description / package material with one or more included features
- `general_document`: Solution Guideline, System Description, operating/configuration information, and other topical documentation

A general document is never promoted to a feature owner merely because it mentions a Feature ID.

## Output layout

```text
output/
├── markdown/
│   ├── 16-QAM Uplink.md
│   └── ...
├── images/
├── manifests/
│   └── <document>.manifest.jsonl
├── combined_manifest.jsonl
├── ericsson_feature_catalog.json
└── routing-manifest/
    ├── manifest-index.json
    ├── by-feature-id/
    │   └── FAJ121/
    │       └── FAJ1210488.jsonl
    ├── by-package-id/
    │   └── FAJ801/
    │       └── FAJ8010400.jsonl
    ├── by-topic/
    │   └── <topic>.jsonl
    └── by-mentioned-feature-id/
        └── FAJ121/
            └── <feature>.jsonl
```

The `by-mentioned-feature-id` route is intentionally separate. It prevents a guideline that merely references a feature from being mistaken for the direct feature PDF.

## Installation

Python 3.11+ is recommended.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Docling is the production extraction engine. PyMuPDF is included as a fallback so that a document can still be prepared when Docling is not available or conversion fails.

## Run

```bash
python -m ericsson_kb /path/to/ericsson_pdfs \
  --output-dir /path/to/ericsson_output \
  --overwrite
```

To require Docling and fail if it cannot process a PDF:

```bash
python -m ericsson_kb /path/to/ericsson_pdfs \
  --output-dir /path/to/ericsson_output \
  --no-fallback
```

## Manifest semantics

### Dedicated feature document

A document such as a Feature Description containing one owning Feature Identity will receive fields such as:

```json
{
  "doc_type": "feature_description",
  "doc_role": "feature_document",
  "owner_feature_id": "FAJ 121 0488",
  "feature_id": "FAJ 121 0488",
  "primary_package_id": "FAJ 801 0400",
  "is_feature_owner": true,
  "content_retrievable": true
}
```

### Package document

A Commercial Product Description may contain multiple feature/package/access combinations. Those are emitted as `package_feature` relationship records instead of forcing the document to own one feature.

### General document

A Solution Guideline receives `doc_role=general_document`. Feature IDs found inside it are placed in `mentioned_feature_ids`; it remains topic-retrievable and content-retrievable.

## Compatibility with the supplied Nokia agent

The supplied Nokia agent makes two important assumptions in its Knowledge Base service:

1. The router extracts Nokia feature IDs with a Nokia-specific regular expression.
2. The KB manifest loader searches an exact feature manifest and then constrains OpenSearch retrieval by the resolved source filename.

For a future Ericsson agent, make equivalent changes rather than weakening the manifest:

- Extend feature-ID extraction to canonical `FAJ 121 xxxx` values.
- Point the manifest root to `routing-manifest/by-feature-id`.
- Resolve the path `FAJ121/<compact_feature_id>.jsonl`.
- Prefer a `record_kind=document` record with `doc_role=feature_document` for direct feature retrieval.
- Do not treat `package_document` or `general_document` records as a standalone feature PDF.
- Add optional package lookup using `routing-manifest/by-package-id`.
- Preserve topic/global hybrid retrieval for Solution Guidelines and other general content.

The output keeps the fields already consumed by the Nokia KB service so the Ericsson runtime can reuse most of the response and synthesis contracts.

## OpenSearch indexing guidance

Index Markdown chunks with at least these metadata fields:

```text
vendor
filename
feature_id
feature_ids
included_feature_ids
mentioned_feature_ids
package_ids
doc_type
doc_role
heading_path
section_type
page_start
page_end
content
embedding
```

For a dedicated Feature Description, use the owning feature as `feature_id` on its chunks. For a package/general document, leave `feature_id` empty unless the chunk is explicitly associated with a particular feature; retain `feature_ids` / `mentioned_feature_ids` as arrays.

## Validation

Run:

```bash
python -m unittest discover -s tests -v
```

The tests cover Ericsson ID normalization, classification, and manifest routing behavior.
