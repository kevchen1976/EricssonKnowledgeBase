import json
import tempfile
import unittest
from pathlib import Path
from ericsson_kb.manifest import write_jsonl
from ericsson_kb.routing import build_routing

class RoutingTest(unittest.TestCase):
    def test_general_mentions_do_not_become_direct_feature(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            manifest = root / "combined.jsonl"
            write_jsonl(manifest, [
                {
                    "record_kind": "document", "doc_role": "feature_document",
                    "feature_id": "FAJ 121 0488", "feature_ids": ["FAJ 121 0488"],
                    "filename": "16-QAM Uplink.md", "topic_aliases": ["16-qam-uplink"]
                },
                {
                    "record_kind": "document", "doc_role": "general_document",
                    "feature_id": "", "feature_ids": ["FAJ 121 0804"],
                    "mentioned_feature_ids": ["FAJ 121 0804"],
                    "filename": "MTU.md", "topic_aliases": ["ipsec-mtu"]
                }
            ])
            build_routing(manifest, root, overwrite=True)
            self.assertTrue((root / "routing-manifest/by-feature-id/FAJ121/FAJ1210488.jsonl").exists())
            self.assertFalse((root / "routing-manifest/by-feature-id/FAJ121/FAJ1210804.jsonl").exists())
            self.assertTrue((root / "routing-manifest/by-mentioned-feature-id/FAJ121/FAJ1210804.jsonl").exists())

if __name__ == "__main__":
    unittest.main()
