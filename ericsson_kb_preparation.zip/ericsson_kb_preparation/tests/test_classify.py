import unittest
from ericsson_kb.classify import classify_document, document_role

class ClassifyTest(unittest.TestCase):
    def test_feature(self):
        text = "Feature Description\n16-QAM Uplink\nFeature Identity FAJ 121 0488"
        self.assertEqual(classify_document(text), "feature_description")
        self.assertEqual(document_role("feature_description", ["FAJ 121 0488"]), "feature_document")

    def test_solution(self):
        self.assertEqual(classify_document("Solution Guideline\nEnd-to-end MTU Recommendation with IPsec"), "solution_guideline")
        self.assertEqual(document_role("solution_guideline", []), "general_document")

if __name__ == "__main__":
    unittest.main()
