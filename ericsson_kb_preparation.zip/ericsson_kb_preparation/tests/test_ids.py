import unittest
from ericsson_kb.ids import find_feature_ids, find_package_ids, normalize_feature_id

class EricssonIdsTest(unittest.TestCase):
    def test_feature_normalization(self):
        self.assertEqual(normalize_feature_id("FAJ1210488"), "FAJ 121 0488")
        self.assertEqual(normalize_feature_id("faj 121 0804"), "FAJ 121 0804")

    def test_ids(self):
        text = "Feature Identity FAJ 121 0488; Value Package Identity FAJ8010400"
        self.assertEqual(find_feature_ids(text), ["FAJ 121 0488"])
        self.assertEqual(find_package_ids(text), ["FAJ 801 0400"])

if __name__ == "__main__":
    unittest.main()
