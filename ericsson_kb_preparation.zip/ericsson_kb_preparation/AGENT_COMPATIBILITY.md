# Findings from the supplied Nokia agent code

The preparation output was designed after reviewing the supplied Nokia agent runtime, not only the Nokia conversion scripts.

## Knowledge Base behavior that matters

The Nokia KB service follows this sequence for a feature-specific question:

1. Parse a feature ID in the agent router.
2. Load a feature manifest from a feature-family directory.
3. Select a document-level manifest record as the primary source.
4. Enrich the search query with `feature_title`.
5. Run hybrid BM25 + vector retrieval constrained by the resolved filename.
6. Return `retrievalResults[].content` plus metadata such as filename, feature ID, heading path, section type, score, and images.
7. The synthesis prompt distinguishes a direct feature PDF from citation-only/non-direct material.

This is why the Ericsson preparation pipeline emits an exact per-feature shard and makes document ownership explicit.

## Fields kept for compatibility

The Nokia `public_manifest_record` exposes fields including:

- `feature_id`
- `filename`
- `doc_type`
- `manifest_stage`
- `section_type`
- `section_heading`
- `heading_path`
- `page_start`
- `page_end`
- `prerequisites`
- `restriction_status`
- `feature_title`

The Ericsson manifests preserve these names and add Ericsson-specific fields instead of replacing them.

## Required runtime changes for Ericsson

A later Ericsson agent should change the Nokia-specific feature parser and manifest loader. Recommended canonical runtime regex:

```python
ERICSSON_FEATURE_ID_RE = re.compile(
    r"(?<![A-Z0-9])FAJ\\s*121\\s*(\\d{4})(?![A-Z0-9])",
    re.I,
)
```

Normalize user input such as `FAJ1210488` and `FAJ 121 0488` to `FAJ 121 0488` before lookup. Use the compact form `FAJ1210488` only for filenames/routing keys.

Direct feature lookup should resolve:

```text
<manifest_root>/FAJ121/FAJ1210488.jsonl
```

and select the document record satisfying:

```text
record_kind == "document"
doc_role == "feature_document"
owner_feature_id == requested_feature_id
```

Package and general documents may still be retrieved through global/topic search but must not set `direct_feature_pdf_available=true`.
