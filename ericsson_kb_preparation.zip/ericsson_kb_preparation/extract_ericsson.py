#!/usr/bin/env python3
"""Docling-first Ericsson PDF -> Markdown extractor."""
from __future__ import annotations

import argparse
from pathlib import Path

from ericsson_kb.extract_docling import extract_pdf
from ericsson_kb.pipeline import iter_pdfs


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("input")
    p.add_argument("--output-dir", required=True)
    p.add_argument("--backend", default=None)
    p.add_argument("--no-fallback", action="store_true")
    p.add_argument("--overwrite", action="store_true")
    args = p.parse_args()

    inp = Path(args.input).expanduser().resolve()
    out = Path(args.output_dir).expanduser().resolve()
    md_dir = out / "markdown"
    md_dir.mkdir(parents=True, exist_ok=True)
    for pdf in iter_pdfs(inp):
        target = md_dir / f"{pdf.stem}.md"
        if target.exists() and not args.overwrite:
            print(f"SKIP {target.name}")
            continue
        result = extract_pdf(pdf, out, backend=args.backend, allow_fallback=not args.no_fallback)
        target.write_text(result.markdown, encoding="utf-8")
        print(f"OK {pdf.name} -> {target.name} engine={result.engine} pages={result.page_count}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
