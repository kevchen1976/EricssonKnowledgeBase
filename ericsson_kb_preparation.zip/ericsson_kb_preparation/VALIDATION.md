# Validation against the supplied Ericsson examples

The pipeline was exercised against the three supplied Ericsson PDFs in this session.

Because Docling is not installed in this execution environment, the validation run used the built-in PyMuPDF fallback. The production path remains Docling-first.

Observed classification/identity results:

| Document | Classification | Ownership / identity result |
|---|---|---|
| 16-QAM Uplink | `feature_description` / `feature_document` | owner `FAJ 121 0488`; package `FAJ 801 0400` |
| IPsec | `commercial_product_description` / `package_document` | included `FAJ 121 0804`, `FAJ 121 3586`; package relationships paired to NR/LTE/WCDMA/GSM |
| End-to-end MTU Recommendation with IPsec | `solution_guideline` / `general_document` | no feature owner; topic-routed |

The fallback parser also reconstructed these IPsec relationships by the column order of the flattened identity table:

- `FAJ 121 0804` -> `FAJ 801 4002` -> NR
- `FAJ 121 0804` -> `FAJ 801 0417` -> LTE
- `FAJ 121 3586` -> `FAJ 801 0516` -> WCDMA
- `FAJ 121 0804` -> `FAJ 801 0747` -> GSM

Five unit tests pass for ID normalization, document classification, and separation of direct-feature routing from mentioned-feature routing.
