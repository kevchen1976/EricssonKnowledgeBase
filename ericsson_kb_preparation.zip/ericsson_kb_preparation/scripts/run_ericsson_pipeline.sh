#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 2 ]; then
  echo "Usage: $0 <input-pdf-or-directory> <output-directory> [extra args...]" >&2
  exit 2
fi

INPUT=$1
OUTPUT=$2
shift 2

python -m ericsson_kb "$INPUT" --output-dir "$OUTPUT" "$@"
