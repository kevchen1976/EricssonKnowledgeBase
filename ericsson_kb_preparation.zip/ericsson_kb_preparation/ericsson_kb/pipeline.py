from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Iterable, List

from .analyze import analyze_markdown
from .extract_docling import extract_pdf
from .manifest import manifest_records, write_jsonl, write_sidecar
from .routing import build_routing

log = logging.getLogger(__name__)


def iter_pdfs(input_path: Path) -> List[Path]:
    if input_path.is_file() and input_path.suffix.lower() == ".pdf":
        return [input_path]
    return sorted(input_path.glob("*.pdf")) if input_path.is_dir() else []


def run_pipeline(input_path: Path, output_dir: Path, backend: str | None = None,
                 overwrite: bool = False, allow_fallback: bool = True) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    markdown_dir = output_dir / "markdown"
    markdown_dir.mkdir(exist_ok=True)
    analyses = []
    all_records = []

    for pdf in iter_pdfs(input_path):
        md_path = markdown_dir / f"{pdf.stem}.md"
        if md_path.exists() and not overwrite:
            log.info("Reusing markdown: %s", md_path)
            page_count = 0
        else:
            extraction = extract_pdf(pdf, output_dir, backend=backend, allow_fallback=allow_fallback)
            md_path.write_text(extraction.markdown, encoding="utf-8")
            page_count = extraction.page_count
            log.info("Extracted %s with %s", pdf.name, extraction.engine)

        analysis = analyze_markdown(md_path, source_pdf=pdf, page_count=page_count)
        analyses.append(analysis)
        write_sidecar(analysis)
        records = manifest_records(analysis)
        all_records.extend(records)
        write_jsonl(output_dir / "manifests" / f"{pdf.stem}.manifest.jsonl", records)

    combined = output_dir / "combined_manifest.jsonl"
    write_jsonl(combined, all_records)
    index = build_routing(combined, output_dir, overwrite=overwrite)

    catalog = []
    for a in analyses:
        if a.feature_variants:
            for v in a.feature_variants:
                catalog.append({
                    "feature_id": v.feature_id,
                    "feature_title": v.feature_name,
                    "access_type": v.access_type,
                    "package_id": v.package_id,
                    "package_title": v.package_name,
                    "node_type": v.node_type,
                    "source": a.markdown_path.name,
                })
        elif a.owner_feature_id:
            catalog.append({
                "feature_id": a.owner_feature_id,
                "feature_title": a.feature_title or a.title,
                "access_type": ", ".join(a.access_types),
                "package_id": a.primary_package_id,
                "package_title": ", ".join(a.package_names),
                "node_type": ", ".join(a.node_types),
                "source": a.markdown_path.name,
            })
    # JSON catalog avoids making a CSV library mandatory; it can be converted later.
    (output_dir / "ericsson_feature_catalog.json").write_text(json.dumps(catalog, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    return {"documents": len(analyses), "records": len(all_records), "manifest_index": index}
