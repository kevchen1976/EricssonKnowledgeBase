from __future__ import annotations

import json
import shutil
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List

from .ids import feature_key, normalize_feature_id, normalize_package_id, package_key
from .manifest import write_jsonl


def _load_jsonl(path: Path) -> List[Dict[str, object]]:
    out = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                out.append(json.loads(line))
    return out


def _route_feature_ids(record: Dict[str, object]) -> List[str]:
    kind = str(record.get("record_kind", ""))
    role = str(record.get("doc_role", ""))
    association = str(record.get("feature_association", ""))
    out: List[str] = []
    # Dedicated feature docs own their feature. Package relations are included routes.
    if role == "feature_document" or kind == "package_feature" or association in {"primary", "included"}:
        for key in ("feature_id",):
            fid = normalize_feature_id(str(record.get(key, "")))
            if fid: out.append(fid)
        vals = record.get("feature_ids", [])
        if isinstance(vals, list):
            for value in vals:
                fid = normalize_feature_id(str(value))
                if fid and fid not in out: out.append(fid)
    return out


def _route_package_ids(record: Dict[str, object]) -> List[str]:
    out: List[str] = []
    pid = normalize_package_id(str(record.get("package_id", "")))
    if pid: out.append(pid)
    vals = record.get("package_ids", [])
    if isinstance(vals, list):
        for value in vals:
            pid = normalize_package_id(str(value))
            if pid and pid not in out: out.append(pid)
    return out


def build_routing(combined_manifest: Path, output_dir: Path, overwrite: bool = False) -> Dict[str, object]:
    records = _load_jsonl(combined_manifest)
    root = output_dir / "routing-manifest"
    if overwrite and root.exists():
        shutil.rmtree(root)

    feature_buckets: Dict[str, List[Dict[str, object]]] = defaultdict(list)
    package_buckets: Dict[str, List[Dict[str, object]]] = defaultdict(list)
    topic_buckets: Dict[str, List[Dict[str, object]]] = defaultdict(list)
    mentioned_buckets: Dict[str, List[Dict[str, object]]] = defaultdict(list)

    for rec in records:
        for fid in _route_feature_ids(rec):
            feature_buckets[fid].append(rec)
        for pid in _route_package_ids(rec):
            package_buckets[pid].append(rec)

        # Same correction as the Nokia manifest rewrite: topic aliases are document-only.
        if str(rec.get("record_kind", "")) == "document":
            for alias in rec.get("topic_aliases", []) if isinstance(rec.get("topic_aliases"), list) else []:
                alias = str(alias).strip()
                if alias:
                    topic_buckets[alias].append({
                        "topic_alias": alias,
                        "filename": rec.get("filename", ""),
                        "source_markdown": rec.get("source_markdown", ""),
                        "feature_id": rec.get("feature_id", ""),
                        "feature_ids": rec.get("feature_ids", []),
                        "included_feature_ids": rec.get("included_feature_ids", []),
                        "package_ids": rec.get("package_ids", []),
                        "doc_type": rec.get("doc_type", ""),
                        "doc_role": rec.get("doc_role", ""),
                        "topics": rec.get("topics", ""),
                        "record_id": rec.get("record_id", ""),
                    })
            for fid in rec.get("mentioned_feature_ids", []) if isinstance(rec.get("mentioned_feature_ids"), list) else []:
                n = normalize_feature_id(str(fid))
                if n:
                    mentioned_buckets[n].append(rec)

    for fid, bucket in feature_buckets.items():
        write_jsonl(root / "by-feature-id" / "FAJ121" / f"{feature_key(fid)}.jsonl", bucket)
    for pid, bucket in package_buckets.items():
        write_jsonl(root / "by-package-id" / "FAJ801" / f"{package_key(pid)}.jsonl", bucket)
    for alias, bucket in topic_buckets.items():
        write_jsonl(root / "by-topic" / f"{alias}.jsonl", bucket)
    for fid, bucket in mentioned_buckets.items():
        write_jsonl(root / "by-mentioned-feature-id" / "FAJ121" / f"{feature_key(fid)}.jsonl", bucket)

    def info(base: Path) -> List[Dict[str, object]]:
        result = []
        if base.exists():
            for p in sorted(base.rglob("*.jsonl")):
                with p.open("rb") as fh:
                    count = sum(1 for _ in fh)
                result.append({"path": p.relative_to(output_dir).as_posix(), "records": count})
        return result

    index = {
        "vendor": "Ericsson",
        "schema_version": "1.0",
        "feature_shards": info(root / "by-feature-id"),
        "package_shards": info(root / "by-package-id"),
        "topic_shards": info(root / "by-topic"),
        "mentioned_feature_shards": info(root / "by-mentioned-feature-id"),
    }
    (root / "manifest-index.json").parent.mkdir(parents=True, exist_ok=True)
    (root / "manifest-index.json").write_text(json.dumps(index, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return index
