from __future__ import annotations

import re
from typing import Iterable, List

_FEATURE_RE = re.compile(r"(?<![A-Z0-9])FAJ\s*121\s*(\d{4})(?![A-Z0-9])", re.I)
_PACKAGE_RE = re.compile(r"(?<![A-Z0-9])FAJ\s*801\s*(\d{4})(?![A-Z0-9])", re.I)


def _dedupe(values: Iterable[str]) -> List[str]:
    seen = set()
    out: List[str] = []
    for value in values:
        if value and value not in seen:
            seen.add(value)
            out.append(value)
    return out


def normalize_feature_id(value: str) -> str:
    compact = re.sub(r"\s+", "", (value or "").upper())
    m = re.fullmatch(r"FAJ121(\d{4})", compact)
    return f"FAJ 121 {m.group(1)}" if m else ""


def normalize_package_id(value: str) -> str:
    compact = re.sub(r"\s+", "", (value or "").upper())
    m = re.fullmatch(r"FAJ801(\d{4})", compact)
    return f"FAJ 801 {m.group(1)}" if m else ""


def feature_key(value: str) -> str:
    fid = normalize_feature_id(value)
    return fid.replace(" ", "") if fid else ""


def package_key(value: str) -> str:
    pid = normalize_package_id(value)
    return pid.replace(" ", "") if pid else ""


def find_feature_ids(text: str) -> List[str]:
    return _dedupe(f"FAJ 121 {m.group(1)}" for m in _FEATURE_RE.finditer(text or ""))


def find_package_ids(text: str) -> List[str]:
    return _dedupe(f"FAJ 801 {m.group(1)}" for m in _PACKAGE_RE.finditer(text or ""))


def is_feature_id(value: str) -> bool:
    return bool(normalize_feature_id(value))


def is_package_id(value: str) -> bool:
    return bool(normalize_package_id(value))
