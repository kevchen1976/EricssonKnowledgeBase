from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

from .pipeline import run_pipeline


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Prepare Ericsson CPI PDFs as Markdown + routing manifests")
    p.add_argument("input", help="PDF file or directory containing PDFs")
    p.add_argument("--output-dir", required=True)
    p.add_argument("--backend", default=None, help="Optional Docling PDF backend")
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--no-fallback", action="store_true", help="Fail instead of using PyMuPDF when Docling fails")
    p.add_argument("--verbose", action="store_true")
    args = p.parse_args(argv)

    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO, format="%(levelname)s %(message)s")
    result = run_pipeline(Path(args.input).expanduser().resolve(), Path(args.output_dir).expanduser().resolve(),
                          backend=args.backend, overwrite=args.overwrite, allow_fallback=not args.no_fallback)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
