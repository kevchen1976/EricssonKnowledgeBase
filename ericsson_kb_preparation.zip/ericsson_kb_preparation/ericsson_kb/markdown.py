from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

PAGE_MARKER_RE = re.compile(r"^<!--\s*page:\s*(\d+)\s*-->\s*$", re.I | re.M)
HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$")


def normalize_markdown(text: str) -> str:
    text = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n{4,}", "\n\n\n", text)
    return text.strip() + "\n"


def build_markdown(pages: Dict[int, str]) -> str:
    chunks: List[str] = []
    for page_no in sorted(pages):
        body = (pages[page_no] or "").strip()
        chunks.append(f"<!-- page: {page_no} -->\n\n{body}" if body else f"<!-- page: {page_no} -->")
    return normalize_markdown("\n\n".join(chunks))


def split_pages(markdown: str) -> Dict[int, str]:
    matches = list(PAGE_MARKER_RE.finditer(markdown or ""))
    if not matches:
        return {1: markdown or ""}
    out: Dict[int, str] = {}
    for idx, m in enumerate(matches):
        start = m.end()
        end = matches[idx + 1].start() if idx + 1 < len(matches) else len(markdown)
        out[int(m.group(1))] = markdown[start:end].strip()
    return out


def page_for_offset(markdown: str, offset: int) -> int:
    page = 1
    for m in PAGE_MARKER_RE.finditer(markdown[: max(offset, 0)]):
        page = int(m.group(1))
    return page


def first_nonempty_heading(markdown: str) -> str:
    for line in (markdown or "").splitlines():
        m = HEADING_RE.match(line.strip())
        if m:
            title = m.group(2).strip()
            if title.lower() not in {"contents", "table of contents"}:
                return title
    return ""


def slugify(value: str, max_len: int = 80) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", (value or "").lower()).strip("-")
    return s[:max_len].strip("-")


def markdown_tables(text: str) -> Iterable[List[List[str]]]:
    lines = (text or "").splitlines()
    i = 0
    while i < len(lines) - 1:
        if "|" not in lines[i]:
            i += 1
            continue
        if not re.match(r"^\s*\|?\s*:?-{3,}", lines[i + 1]):
            i += 1
            continue
        table_lines = [lines[i]]
        j = i + 1
        while j < len(lines) and "|" in lines[j] and lines[j].strip():
            table_lines.append(lines[j])
            j += 1
        rows: List[List[str]] = []
        for k, line in enumerate(table_lines):
            if k == 1:  # markdown separator
                continue
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            rows.append(cells)
        if len(rows) >= 2:
            yield rows
        i = max(j, i + 1)
