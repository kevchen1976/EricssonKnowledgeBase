from __future__ import annotations

import re
from typing import List, Tuple

from .ids import find_feature_ids, find_package_ids
from .markdown import PAGE_MARKER_RE, page_for_offset
from .models import Section

HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$", re.M)


def infer_section_type(heading: str, text: str) -> str:
    s = f"{heading} {text[:500]}".lower()
    if "deactivat" in s or "disable" in heading.lower(): return "deactivation"
    if "activat" in s or "enable" in heading.lower(): return "activation"
    if any(k in s for k in ("dependenc", "prerequisite", "requirement")): return "prerequisite"
    if any(k in s for k in ("parameter", "configuration attribute", "setting")): return "parameter"
    if any(k in s for k in ("counter", "kpi", "measurement", "observability", "monitor")): return "monitoring"
    if any(k in s for k in ("limitation", "restriction", "incompatib")): return "restriction"
    if any(k in s for k in ("impact", "performance")): return "impact"
    if any(k in s for k in ("operation", "function", "behavior", "behaviour")): return "operation"
    if any(k in s for k in ("identity", "overview", "introduction", "benefit")): return "overview"
    if "change history" in s or "revision" in s: return "change_log"
    return "general"


def _promote_plain_headings(markdown: str) -> str:
    """Promote common Ericsson numbered headings when a fallback extractor lost styles.

    It intentionally does not alter page markers. The rule requires a numbered
    section prefix, reducing the chance that normal prose is promoted.
    """
    if HEADING_RE.search(markdown or ""):
        return markdown
    lines = (markdown or "").splitlines()
    out: List[str] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        # "1 Introduction" or "4.3 Example ..."
        m = re.match(r"^(\d+(?:\.\d+){0,4})\s+([A-Z][^|]{2,150})$", stripped)
        if m and not re.search(r"\b(?:bytes?|kbps|mbps|mhz|db)\b", stripped, re.I):
            level = min(6, 1 + m.group(1).count("."))
            out.append(f"{'#' * level} {m.group(1)} {m.group(2).strip()}")
            i += 1
            continue
        # PyMuPDF sometimes splits section number and heading into two blocks.
        if re.fullmatch(r"\d+(?:\.\d+){0,4}", stripped) and i + 2 < len(lines):
            j = i + 1
            while j < len(lines) and not lines[j].strip():
                j += 1
            if j < len(lines):
                title = lines[j].strip()
                if re.match(r"^[A-Z][A-Za-z0-9].{1,150}$", title) and not title.startswith("<!--"):
                    level = min(6, 1 + stripped.count("."))
                    out.append(f"{'#' * level} {stripped} {title}")
                    i = j + 1
                    continue
        out.append(line)
        i += 1
    return "\n".join(out)


def _heading_path(stack: List[Tuple[int, str]], level: int, heading: str) -> str:
    while stack and stack[-1][0] >= level:
        stack.pop()
    stack.append((level, heading))
    return " > ".join(x[1] for x in stack)


def parse_sections(markdown: str) -> List[Section]:
    markdown = _promote_plain_headings(markdown)
    matches = list(HEADING_RE.finditer(markdown or ""))
    if not matches:
        page_end = max([int(x) for x in PAGE_MARKER_RE.findall(markdown or "")] or [1])
        return [Section(1, "Document", markdown.strip(), 1, page_end, "general", "Document",
                        find_feature_ids(markdown), find_package_ids(markdown))]

    sections: List[Section] = []
    stack: List[Tuple[int, str]] = []
    for idx, m in enumerate(matches, 1):
        level = len(m.group(1))
        heading = m.group(2).strip()
        body_start = m.end()
        body_end = matches[idx].start() if idx < len(matches) else len(markdown)
        text = markdown[body_start:body_end].strip()
        pstart = page_for_offset(markdown, m.start())
        pend = page_for_offset(markdown, max(body_start, body_end - 1))
        path = _heading_path(stack, level, heading)
        full = f"{heading}\n{text}"
        sections.append(Section(
            order=idx,
            heading=heading,
            text=text,
            page_start=pstart,
            page_end=max(pstart, pend),
            section_type=infer_section_type(heading, text),
            heading_path=path,
            feature_ids=find_feature_ids(full),
            package_ids=find_package_ids(full),
        ))
    return sections
