from agent_core.validation import validate_answer


def _evidence():
    return [
        {
            "_source": {
                "content": "The feature identity is FAJ 121 0488.",
                "feature_ids": ["FAJ 121 0488"],
            }
        }
    ]


def test_validation_accepts_supported_identity_and_valid_marker():
    result = validate_answer("FAJ 121 0488 increases uplink peak rates. [E1]", _evidence())
    assert result.unsupported_feature_ids == []
    assert result.invalid_citations == []
    assert result.missing_citations is False


def test_validation_rejects_invalid_or_missing_markers():
    invalid = validate_answer("Supported by the document. [E2]", _evidence())
    assert invalid.invalid_citations == [2]
    assert invalid.missing_citations is False

    missing = validate_answer("Supported by the document.", _evidence())
    assert missing.invalid_citations == []
    assert missing.missing_citations is True
