import json
from pathlib import Path

from ericsson_preparation.routing import build_routing


def _read(path: Path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def test_package_document_routes_to_included_features_but_general_mentions_do_not(tmp_path: Path):
    combined = tmp_path / "combined_manifest.jsonl"
    records = [
        {
            "record_kind": "document",
            "record_id": "IPsec.md#document",
            "filename": "IPsec.md",
            "doc_role": "package_document",
            "route_by_feature": True,
            "feature_ids": ["FAJ 121 0804", "FAJ 121 3586"],
            "included_feature_ids": ["FAJ 121 0804", "FAJ 121 3586"],
            "package_ids": ["FAJ 801 0417"],
            "topic_aliases": ["ipsec"],
        },
        {
            "record_kind": "document",
            "record_id": "Guide.md#document",
            "filename": "Guide.md",
            "doc_role": "general_document",
            "route_by_feature": False,
            "feature_ids": ["FAJ 121 0804"],
            "mentioned_feature_ids": ["FAJ 121 0804"],
            "topic_aliases": ["guide"],
        },
    ]
    combined.write_text("".join(json.dumps(record) + "\n" for record in records), encoding="utf-8")
    build_routing(combined, tmp_path, overwrite=True)

    feature_0804 = _read(tmp_path / "routing-manifest/by-feature-id/FAJ121/FAJ1210804.jsonl")
    feature_3586 = _read(tmp_path / "routing-manifest/by-feature-id/FAJ121/FAJ1213586.jsonl")
    mentioned = _read(tmp_path / "routing-manifest/by-mentioned-feature-id/FAJ121/FAJ1210804.jsonl")
    assert [item["filename"] for item in feature_0804] == ["IPsec.md"]
    assert [item["filename"] for item in feature_3586] == ["IPsec.md"]
    assert [item["filename"] for item in mentioned] == ["Guide.md"]


def test_document_classification_uses_earliest_banner_not_later_cross_reference():
    from ericsson_preparation.classify import classify_document

    text = "Solution Guideline\n\n1 Introduction\nFor details, see Feature Description IPsec."
    assert classify_document(text, "Guideline.pdf") == "solution_guideline"
