from dataclasses import replace
from pathlib import Path

from agent_core.settings import get_settings
from ingestion.chunker import build_child_chunks, build_parent_chunks
from ingestion.manifest_loader import ManifestStore
from ingestion.markdown_parser import parse_markdown_sections
from ingestion.models import MarkdownBlock, ParentChunk
from ingestion.pipeline import settings_for_prepared_root
from ingestion.prepared_loader import build_parent_child_for_document, load_prepared_documents

FIXTURE = Path(__file__).resolve().parents[1] / "examples" / "prepared_fixture"
EMPTY_STORE = ManifestStore([], {}, {}, {}, {})


def test_page_markers_headings_tables_and_images_are_preserved():
    markdown = (FIXTURE / "markdown" / "Synthetic Ericsson Feature.md").read_text(encoding="utf-8")
    sections = parse_markdown_sections(markdown)
    assert sections
    operation = next(section for section in sections if section.heading == "2 Operation")
    assert operation.page_start == 2
    assert operation.page_end == 2
    assert any(block.kind == "image" for block in operation.blocks)
    title_section = sections[0]
    assert any(block.kind == "table" for block in title_section.blocks)


def test_fixture_generates_separate_parents_and_children_with_valid_references():
    settings = settings_for_prepared_root(get_settings(), FIXTURE)
    store = ManifestStore.load(settings.combined_manifest)
    documents = load_prepared_documents(settings, store)
    assert len(documents) == 1

    parents, children = build_parent_child_for_document(documents[0], store, settings)
    assert parents
    assert children
    assert all(parent.metadata.get("chunk_kind") == "markdown" for parent in parents)
    assert all(child.metadata.get("chunk_kind") == "markdown" for child in children)
    assert {child.parent_id for child in children}.issubset({parent.parent_id for parent in parents})
    assert all(parent.page_end >= parent.page_start >= 1 for parent in parents)
    assert all(child.page_end >= child.page_start >= 1 for child in children)
    assert all(child.metadata.get("vendor") == "Ericsson" for child in children)
    assert all(child.metadata.get("corpus_id") == "ericsson-ran" for child in children)
    assert any(
        "Synthetic_Ericsson_Feature_images/page_002_image_001.png" in parent.image_paths
        for parent in parents
    )
    assert any(child.metadata.get("feature_id") == "FAJ 121 9999" for child in children)

    # The parent index owns full context once. Children own only searchable text,
    # an embedding slot, and a parent reference.
    assert all("embedding" not in parent.to_source() for parent in parents)
    assert all("embedding_text" not in parent.to_source() for parent in parents)
    assert all("parent_content" not in child.to_source([0.1, 0.2]) for child in children)


def test_four_level_ericsson_headings_build_full_heading_path_and_reject_steps():
    markdown = """<!-- page: 1 -->
# Contents
1 Introduction
2 Principles and Guidelines
2.1 Terminology and Concepts
2.2 Solution Overview
2.3 LCS and BB-HCS Activation Rule
3 Connected Mode IL
3.1 License Refresh
3.2 Software Upgrade
4 Non-Connected Mode

<!-- page: 2 -->
# 1 Introduction
Introduction text.

<!-- page: 3 -->
# 2 Principles and Guidelines
Principles text.

## 2.2 Solution Overview
Overview text.

### 2.2.3 Network Elements
Network-element text.

#### 2.2.3.1 Radio Node
Radio-node text.

1. Launch a command line.
2. Continue with the operation.

<!-- page: 4 -->
# 3 Connected Mode IL
Connected-mode text.

## 3.2 Software Upgrade
Upgrade text.

### 3.2.2 Considerations for Improved Delivery
Considerations text.

#### 3.2.2.1 Improved Delivery and IL Use Case Interaction
Interaction text.

#### 3.2.2.2 Network Case for Improved Delivery
Network-case text.
"""
    sections = parse_markdown_sections(markdown)
    by_number = {section.heading_number: section for section in sections}

    radio = by_number["2.2.3.1"]
    assert radio.level == 4
    assert radio.heading == "2.2.3.1 Radio Node"
    assert radio.heading_path == (
        "2 Principles and Guidelines > 2.2 Solution Overview > "
        "2.2.3 Network Elements > 2.2.3.1 Radio Node"
    )
    assert radio.page_start == 3
    assert "1. Launch a command line." in radio.text
    assert "1. Launch a command line." not in [section.heading for section in sections]

    interaction = by_number["3.2.2.1"]
    network_case = by_number["3.2.2.2"]
    assert interaction.level == network_case.level == 4
    assert interaction.heading_path.startswith("3 Connected Mode IL > 3.2 Software Upgrade > 3.2.2")


def test_toc_rows_and_numeric_table_rows_do_not_become_parent_sections():
    markdown = """<!-- page: 1 -->
# Contents
1 Introduction
2 Operation

<!-- page: 2 -->
# 1 Introduction
Intro body.

| Size | Description |
|---:|---|
| 73 | Total overhead |

<!-- page: 3 -->
# 2 Operation
Operational body.
1. Open the interface.
2. Start processing.
"""
    sections = parse_markdown_sections(markdown)
    headings = [section.heading for section in sections]
    assert headings == ["1 Introduction", "2 Operation"]
    assert all("Contents" not in section.text for section in sections)
    assert all("73 Total overhead" not in heading for heading in headings)
    assert "1. Open the interface." in sections[-1].text


def test_one_real_section_remains_one_parent_even_above_parent_soft_limit():
    settings = replace(
        get_settings(),
        parent_max_tokens=50,
        child_max_tokens=30,
        child_overlap_tokens=6,
        include_document_preamble=False,
        include_manifest_facts=False,
    )
    markdown = "<!-- page: 1 -->\n\n# 1 Overview\n\n" + " ".join(f"token{i}" for i in range(240))
    record = {
        "vendor": "Ericsson",
        "corpus_id": "ericsson-ran",
        "filename": "Long.md",
        "title": "Long",
        "doc_type": "solution_guideline",
        "doc_role": "general_document",
    }
    parents = build_parent_chunks("Long.md", "Long", markdown, record, EMPTY_STORE, settings, "sha")
    children = build_child_chunks(parents, settings)

    assert len(parents) == 1
    assert parents[0].metadata["parent_strategy"] == "one_real_section"
    assert parents[0].metadata["parent_exceeds_soft_limit"] is True
    assert parents[0].metadata["parent_token_count"] > settings.parent_max_tokens
    assert len(children) > 1
    assert all(child.parent_id == parents[0].parent_id for child in children)
    assert all(child.metadata["child_window_tokens"] == 30 for child in children)
    assert all(child.metadata["child_overlap_tokens"] == 6 for child in children)


def test_procedure_like_section_below_900_tokens_is_kept_as_one_child():
    settings = replace(
        get_settings(),
        child_max_tokens=30,
        child_overlap_tokens=6,
        keep_procedure_sections=True,
        procedure_max_tokens=900,
    )
    body = "\n".join(["Steps", *[f"{i}. Perform operation step {i}." for i in range(1, 45)]])
    parent = ParentChunk(
        parent_id="procedure-parent",
        filename="Procedure.md",
        title="Procedure",
        heading="3.8 Feature Activation",
        heading_path="3 Connected Mode IL > 3.8 Feature Activation",
        section_type="activation",
        feature_association="none",
        page_start=10,
        page_end=12,
        content=f"## 3.8 Feature Activation\n\n{body}",
        image_paths=[],
        metadata={"vendor": "Ericsson", "corpus_id": "ericsson-ran", "chunk_kind": "markdown"},
        parent_order=1,
        blocks=[MarkdownBlock(body, 10, 12, "list")],
    )
    children = build_child_chunks([parent], settings)
    assert len(children) == 1
    assert "1. Perform operation step 1." in children[0].content
    assert "44. Perform operation step 44." in children[0].content


def test_wrapped_nokia_style_sidecar_is_accepted_when_combined_manifest_is_absent(tmp_path: Path):
    prepared = tmp_path / "prepared"
    markdown_root = prepared / "markdown"
    markdown_root.mkdir(parents=True)
    md = markdown_root / "Wrapped.md"
    md.write_text("<!-- page: 1 -->\n\n1 Overview\n\nFeature Identity FAJ 121 9123\n", encoding="utf-8")
    (markdown_root / "Wrapped.md.metadata.json").write_text(
        """{
  "metadataAttributes": {
    "title": "Wrapped Feature",
    "doc_type": "feature_description",
    "doc_role": "feature_document",
    "owner_feature_id": "FAJ 121 9123",
    "feature_ids": ["FAJ 121 9123"]
  }
}
""",
        encoding="utf-8",
    )
    settings = settings_for_prepared_root(get_settings(), prepared)
    store = ManifestStore.load(settings.combined_manifest)
    documents = load_prepared_documents(settings, store)
    assert documents[0].title == "Wrapped Feature"
    assert documents[0].document_record["owner_feature_id"] == "FAJ 121 9123"


def test_general_document_feature_mentions_do_not_become_direct_feature_ids(tmp_path: Path):
    prepared = tmp_path / "prepared"
    markdown_root = prepared / "markdown"
    markdown_root.mkdir(parents=True)
    (markdown_root / "Guideline.md").write_text(
        "<!-- page: 1 -->\n\n# 1 Scope\n\nSee Feature Identity FAJ 121 4321 for related behavior.\n",
        encoding="utf-8",
    )

    settings = settings_for_prepared_root(get_settings(), prepared)
    store = ManifestStore.load(settings.combined_manifest)
    documents = load_prepared_documents(settings, store)
    record = documents[0].document_record
    assert record["doc_role"] == "general_document"
    assert record["feature_ids"] == []
    assert record["included_feature_ids"] == []
    assert record["mentioned_feature_ids"] == ["FAJ 121 4321"]

    parents, children = build_parent_child_for_document(documents[0], store, settings)
    assert parents and children
    assert all(child.metadata.get("feature_ids") == [] for child in children)
    assert any("FAJ 121 4321" in child.metadata.get("mentioned_feature_ids", []) for child in children)
    assert any(child.metadata.get("feature_association") == "mentioned" for child in children)


def test_feature_fallback_keeps_owner_direct_and_other_ids_as_mentions(tmp_path: Path):
    prepared = tmp_path / "prepared"
    markdown_root = prepared / "markdown"
    markdown_root.mkdir(parents=True)
    md = markdown_root / "Feature.md"
    md.write_text(
        "<!-- page: 1 -->\n\n# 1 Overview\n\n"
        "Feature Identity FAJ 121 1111. Related Feature Identity FAJ 121 2222.\n",
        encoding="utf-8",
    )
    (markdown_root / "Feature.md.metadata.json").write_text(
        """{
  "metadataAttributes": {
    "title": "Feature",
    "doc_type": "feature_description",
    "doc_role": "feature_document",
    "owner_feature_id": "FAJ1211111",
    "feature_ids": "FAJ 121 1111"
  }
}
""",
        encoding="utf-8",
    )

    settings = settings_for_prepared_root(get_settings(), prepared)
    store = ManifestStore.load(settings.combined_manifest)
    documents = load_prepared_documents(settings, store)
    record = documents[0].document_record
    assert record["owner_feature_id"] == "FAJ 121 1111"
    assert record["feature_ids"] == ["FAJ 121 1111"]
    assert record["mentioned_feature_ids"] == ["FAJ 121 2222"]


def test_short_tail_child_is_retained_even_below_minimum_threshold():
    settings = replace(
        get_settings(),
        child_max_tokens=20,
        child_overlap_tokens=0,
        minimum_chunk_tokens=20,
        keep_procedure_sections=False,
    )
    parent = ParentChunk(
        parent_id="parent-short-tail",
        filename="Short Tail.md",
        title="Short Tail",
        heading="2 Dependencies",
        heading_path="2 Dependencies",
        section_type="prerequisite",
        feature_association="primary",
        page_start=1,
        page_end=2,
        content=" ".join(["context"] * 80) + " No dependencies.",
        image_paths=[],
        metadata={"vendor": "Ericsson", "corpus_id": "ericsson-ran"},
        parent_order=1,
        blocks=[
            MarkdownBlock(" ".join(["context"] * 80), 1, 1),
            MarkdownBlock("No dependencies.", 2, 2),
        ],
    )

    children = build_child_chunks([parent], settings)
    assert any("No dependencies" in child.content for child in children)
    short = next(child for child in children if "No dependencies" in child.content)
    assert short.metadata["below_minimum_chunk_tokens"] is True
    assert short.page_start == 1
    assert short.page_end == 2
