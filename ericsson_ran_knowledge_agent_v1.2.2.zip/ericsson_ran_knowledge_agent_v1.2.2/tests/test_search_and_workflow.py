from dataclasses import replace
import hashlib

from agent_core.settings import get_settings
from agent_core.workflow import EricssonAgent
from kb_api.search import HybridSearchEngine, _expand_parents, _rank_children


class _Embedder:
    def encode(self, texts):
        return [[0.1, 0.2, 0.3] for _ in texts]


class _Indices:
    pass


class _SearchClient:
    def __init__(self):
        self.search_calls = []
        self.mget_calls = []
        self.indices = _Indices()

    def search(self, index, body):
        self.search_calls.append((index, body))
        if "knn" in body["query"]:
            return {
                "hits": {
                    "hits": [
                        {
                            "_id": "child-2",
                            "_score": 0.9,
                            "_source": {
                                "chunk_id": "child-2",
                                "content": "Vector child evidence",
                                "parent_id": "parent-2",
                                "parent_storage_id": "parent-2",
                                "parent_content_sha256": hashlib.sha256(b"Full parent evidence 2").hexdigest(),
                                "filename": "Feature.md",
                                "vendor": "Ericsson",
                                "corpus_id": "ericsson-ran",
                                "feature_id": "FAJ 121 9999",
                                "feature_ids": ["FAJ 121 9999"],
                                "feature_association": "primary",
                                "page_start": 2,
                                "page_end": 2,
                            },
                        }
                    ]
                }
            }
        return {
            "hits": {
                "hits": [
                    {
                        "_id": "child-1",
                        "_score": 2.0,
                        "_source": {
                            "chunk_id": "child-1",
                            "content": "Text child evidence",
                            "parent_id": "parent-1",
                            "parent_storage_id": "parent-1",
                            "parent_content_sha256": hashlib.sha256(b"Full parent evidence 1").hexdigest(),
                            "filename": "Feature.md",
                            "vendor": "Ericsson",
                            "corpus_id": "ericsson-ran",
                            "feature_id": "FAJ 121 9999",
                            "feature_ids": ["FAJ 121 9999"],
                            "feature_association": "primary",
                            "page_start": 1,
                            "page_end": 1,
                        },
                    }
                ]
            }
        }

    def mget(self, index, body):
        self.mget_calls.append((index, body))
        docs = []
        for parent_id in body["ids"]:
            number = parent_id.rsplit("-", 1)[-1]
            docs.append(
                {
                    "_id": parent_id,
                    "found": True,
                    "_source": {
                        "parent_id": parent_id,
                        "parent_storage_id": parent_id,
                        "content": f"Full parent evidence {number}",
                        "content_sha256": hashlib.sha256(f"Full parent evidence {number}".encode()).hexdigest(),
                        "filename": "Feature.md",
                        "vendor": "Ericsson",
                        "corpus_id": "ericsson-ran",
                        "feature_id": "FAJ 121 9999",
                        "feature_ids": ["FAJ 121 9999"],
                        "feature_association": "primary",
                        "page_start": int(number),
                        "page_end": int(number),
                    },
                }
            )
        return {"docs": docs}


class _SearchState:
    def __init__(self):
        self.settings = replace(get_settings(), allow_bm25_only=False, reranker_enabled=False)
        self._client = _SearchClient()
        self.logger = type("Logger", (), {"info": lambda *args, **kwargs: None})()

    def client(self):
        return self._client

    def embedder(self):
        return _Embedder()


def test_hybrid_search_scopes_child_index_then_mgets_parent_index():
    state = _SearchState()
    outcome = HybridSearchEngine(state).search("synthetic feature", limit=5)

    assert len(outcome.hits) == 2
    assert outcome.mode == "hybrid_parent_child_search"
    assert all(index == state.settings.child_alias for index, _ in state._client.search_calls)
    assert state._client.mget_calls == [
        (state.settings.parent_alias, {"ids": ["parent-1", "parent-2"]})
    ]
    text_filter = state._client.search_calls[0][1]["query"]["bool"]["filter"]
    assert {"term": {"vendor": "Ericsson"}} in text_filter
    assert {"term": {"corpus_id": "ericsson-ran"}} in text_filter
    assert {"term": {"storage_role": "child"}} in text_filter
    assert {"term": {"retrieval_contract": "rank-children-then-mget-parents"}} in text_filter
    assert outcome.hits[0]["_source"]["content"].startswith("Full parent evidence")
    assert outcome.hits[0]["_source"]["matched_children"][0]["content"]


class _KB:
    def retrieve_feature(self, feature_id, query, *, limit, include_related=True):
        return {
            "manifest": {"feature_id": feature_id, "feature_title": "Synthetic Ericsson Feature"},
            "retrievalResults": [
                {
                    "_id": "parent-1",
                    "_score": 1.0,
                    "_source": {
                        "content": "The synthetic feature demonstrates Ericsson retrieval.",
                        "parent_id": "parent-1",
                        "parent_storage_id": "parent-1",
                        "filename": "Synthetic Ericsson Feature.md",
                        "source_pdf": "Synthetic Ericsson Feature.pdf",
                        "title": "Synthetic Ericsson Feature",
                        "heading_path": "1 Overview",
                        "page_start": 1,
                        "page_end": 1,
                        "feature_id": "FAJ 121 9999",
                        "feature_ids": ["FAJ 121 9999"],
                        "package_ids": ["FAJ 801 9999"],
                        "feature_association": "primary",
                        "matched_children": [
                            {
                                "child_id": "child-1",
                                "content": "synthetic feature demonstrates Ericsson retrieval",
                                "page_start": 1,
                                "page_end": 1,
                            }
                        ],
                    },
                }
            ],
        }

    def retrieve_package(self, package_id, query, *, limit):
        raise AssertionError("not expected")

    def search(self, query, *, limit, filters=None):
        raise AssertionError("not expected")


def test_standalone_agent_returns_supervisor_friendly_contract():
    settings = replace(get_settings(), llm_enabled=False, graph_enabled=False)
    agent = EricssonAgent(settings, kb=_KB(), graph=None, ollama=None)
    response = agent.run("What does FAJ 121 9999 do?", include_evidence=True)
    assert response.vendor == "Ericsson"
    assert response.workflow == "feature_lookup"
    assert response.feature_ids == ["FAJ 121 9999"]
    assert response.package_ids == ["FAJ 801 9999"]
    assert response.citations[0].citation_id == "E1"
    assert response.evidence
    assert "[E1]" in response.answer


def test_manifest_priority_and_association_boosts_change_final_child_order():
    state = _SearchState()
    hits = [
        {
            "_id": "raw-first",
            "_rrf_score": 0.020,
            "_source": {
                "parent_id": "p1",
                "content": "mentioned",
                "feature_association": "mentioned",
                "manifest_priority": 0,
            },
        },
        {
            "_id": "raw-second",
            "_rrf_score": 0.019,
            "_source": {
                "parent_id": "p2",
                "content": "primary",
                "feature_association": "primary",
                "manifest_priority": 100,
            },
        },
    ]
    ranked = _rank_children(hits, state)
    assert ranked[0]["_source"]["parent_id"] == "p2"


def test_parent_expansion_deduplicates_and_returns_full_parent_with_child_evidence():
    children = [
        {
            "_id": "child-1",
            "_final_child_score": 0.04,
            "_source": {
                "chunk_id": "child-1",
                "parent_id": "logical-parent",
                "parent_storage_id": "stored-parent",
                "parent_content_sha256": hashlib.sha256(b"full parent content").hexdigest(),
                "content": "first child evidence",
                "page_start": 4,
                "page_end": 4,
            },
        },
        {
            "_id": "child-2",
            "_final_child_score": 0.03,
            "_source": {
                "chunk_id": "child-2",
                "parent_id": "logical-parent",
                "parent_storage_id": "stored-parent",
                "parent_content_sha256": hashlib.sha256(b"full parent content").hexdigest(),
                "content": "second child evidence",
                "page_start": 5,
                "page_end": 5,
            },
        },
    ]
    parents = {
        "stored-parent": {
            "parent_id": "logical-parent",
            "parent_storage_id": "stored-parent",
            "content": "full parent content",
            "content_sha256": hashlib.sha256(b"full parent content").hexdigest(),
            "page_start": 3,
            "page_end": 6,
        }
    }
    warnings = []
    ranked = _expand_parents(children, parents, warnings)
    assert warnings == []
    assert len(ranked) == 1
    assert ranked[0]["_source"]["content"] == "full parent content"
    assert ranked[0]["_source"]["page_start"] == 3
    assert ranked[0]["_source"]["page_end"] == 6
    assert [item["child_id"] for item in ranked[0]["_source"]["matched_children"]] == [
        "child-1",
        "child-2",
    ]


class _LimitCapturingKB(_KB):
    def __init__(self):
        self.feature_limits = []
        self.search_limits = []

    def retrieve_feature(self, feature_id, query, *, limit, include_related=True):
        self.feature_limits.append(limit)
        return super().retrieve_feature(
            feature_id,
            query,
            limit=limit,
            include_related=include_related,
        )

    def search(self, query, *, limit, filters=None):
        self.search_limits.append(limit)
        return {"retrievalResults": []}


def test_agent_clamps_requested_limit_to_safe_bounds():
    settings = replace(get_settings(), llm_enabled=False, graph_enabled=False, maximum_limit=7)
    kb = _LimitCapturingKB()
    agent = EricssonAgent(settings, kb=kb, graph=None, ollama=None)
    agent.run("Explain secure transport", limit=0)
    agent.run("What does FAJ 121 9999 do?", limit=999)
    assert kb.search_limits == [1]
    assert kb.feature_limits == [7]
