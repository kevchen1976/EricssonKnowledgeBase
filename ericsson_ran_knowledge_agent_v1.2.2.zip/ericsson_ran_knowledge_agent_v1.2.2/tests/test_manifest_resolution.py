import json
from dataclasses import replace
from pathlib import Path

from agent_core.settings import get_settings
from kb_api.manifest import ManifestRepository, rewrite_asset_links
from kb_api.state import KBState

FIXTURE = Path(__file__).resolve().parents[1] / "examples" / "prepared_fixture"


def _state(root: Path) -> KBState:
    base = get_settings()
    return KBState(replace(
        base,
        prepared_root=root,
        markdown_root=root / "markdown",
        combined_manifest=root / "combined_manifest.jsonl",
        feature_manifest_root=root / "routing-manifest/by-feature-id",
        package_manifest_root=root / "routing-manifest/by-package-id",
        topic_manifest_root=root / "routing-manifest/by-topic",
        mentioned_feature_manifest_root=root / "routing-manifest/by-mentioned-feature-id",
    ))


def test_direct_feature_owner_is_resolved():
    bundle = ManifestRepository(_state(FIXTURE)).feature_bundle("FAJ1219999")
    assert bundle["primary"]["filename"] == "Synthetic Ericsson Feature.md"
    assert bundle["primary"]["is_feature_owner"] is True
    package = ManifestRepository(_state(FIXTURE)).package_bundle("FAJ 801 9999")
    assert package["primary"]["filename"] == "Synthetic Ericsson Feature.md"


def test_package_document_is_not_promoted_to_direct_feature(tmp_path: Path):
    root = tmp_path
    path = root / "routing-manifest/by-feature-id/FAJ121/FAJ1210804.jsonl"
    path.parent.mkdir(parents=True)
    package_doc = {
        "record_kind": "document",
        "filename": "IPsec.md",
        "doc_type": "commercial_product_description",
        "doc_role": "package_document",
        "is_feature_owner": False,
        "feature_ids": ["FAJ 121 0804"],
        "included_feature_ids": ["FAJ 121 0804"],
    }
    path.write_text(json.dumps(package_doc) + "\n", encoding="utf-8")
    bundle = ManifestRepository(_state(root)).feature_bundle("FAJ 121 0804")
    assert bundle["primary"] is None
    assert bundle["related_documents"][0]["filename"] == "IPsec.md"


def test_image_links_rewrite_to_kb_assets():
    content = "![Figure](Synthetic_Ericsson_Feature_images/page_002_image_001.png)"
    rewritten = rewrite_asset_links(content, "/kb-assets/")
    assert rewritten == "![Figure](/kb-assets/Synthetic_Ericsson_Feature_images/page_002_image_001.png)"
    assert rewrite_asset_links("![x](../secret.png)", "/kb-assets/") == "![x](../secret.png)"


def test_local_feature_bundle_combines_direct_and_mentioned_routes(tmp_path: Path):
    root = tmp_path
    direct_path = root / "routing-manifest/by-feature-id/FAJ121/FAJ1210804.jsonl"
    mentioned_path = root / "routing-manifest/by-mentioned-feature-id/FAJ121/FAJ1210804.jsonl"
    direct_path.parent.mkdir(parents=True)
    mentioned_path.parent.mkdir(parents=True)
    package_doc = {
        "record_kind": "document",
        "record_id": "IPsec.md#document",
        "filename": "IPsec.md",
        "doc_role": "package_document",
        "feature_ids": ["FAJ 121 0804"],
        "included_feature_ids": ["FAJ 121 0804"],
        "feature_title": "IPsec",
    }
    guideline = {
        "record_kind": "document",
        "record_id": "Guideline.md#document",
        "filename": "Guideline.md",
        "doc_role": "general_document",
        "feature_ids": ["FAJ 121 0804"],
        "mentioned_feature_ids": ["FAJ 121 0804"],
    }
    direct_path.write_text(json.dumps(package_doc) + "\n", encoding="utf-8")
    mentioned_path.write_text(json.dumps(guideline) + "\n", encoding="utf-8")
    bundle = ManifestRepository(_state(root)).feature_bundle("FAJ 121 0804")
    assert {item["filename"] for item in bundle["related_documents"]} == {"IPsec.md", "Guideline.md"}
