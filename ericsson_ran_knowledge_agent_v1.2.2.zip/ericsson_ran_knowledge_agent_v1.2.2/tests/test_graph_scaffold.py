from dataclasses import replace

from agent_core.settings import get_settings
from graph_api.state import GraphDisabledError, GraphState


def test_graph_is_disabled_by_default_and_import_is_lazy():
    state = GraphState(replace(get_settings(), graph_enabled=False))
    assert state.status()["status"] == "disabled"
    try:
        state.driver()
    except GraphDisabledError:
        pass
    else:
        raise AssertionError("Disabled graph should not create a Neo4j driver")


def test_graph_settings_use_ericsson_database_namespace():
    settings = get_settings()
    assert settings.neo4j_database == "ericsson"


def test_relationship_staging_preserves_graph_attributes():
    from neo4j.import_staging import relationship_rows

    rows = relationship_rows([{
        "record_kind": "package_feature",
        "feature_id": "FAJ1210804",
        "feature_title": "IPsec",
        "package_id": "FAJ8010417",
        "package_name": "IPsec",
        "access_type": "LTE",
        "node_type": "Baseband Radio Node",
        "filename": "IPsec.md",
        "title": "IPsec",
        "doc_type": "commercial_product_description",
        "doc_role": "package_document",
        "page_start": 1,
        "page_end": 2,
    }])
    assert rows[0]["feature_id"] == "FAJ 121 0804"
    assert rows[0]["package_id"] == "FAJ 801 0417"
    assert rows[0]["node_type"] == "Baseband Radio Node"
    assert rows[0]["doc_role"] == "package_document"
