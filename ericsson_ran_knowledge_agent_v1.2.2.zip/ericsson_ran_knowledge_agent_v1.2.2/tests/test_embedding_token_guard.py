from __future__ import annotations

from dataclasses import replace

import pytest

from agent_core.settings import get_settings
from ingestion.embedding import (
    EmbeddingInputLengthError,
    SentenceTransformerEmbedder,
    resolve_model_max_input_tokens,
)
from ingestion.models import ChildChunk
from ingestion.pipeline import preflight_embedding_inputs
from ingestion.tokenization import HuggingFaceTokenCodec


class FakeTokenizer:
    model_max_length = 8

    def __init__(self) -> None:
        self.verbose_values: list[bool] = []

    def __call__(
        self,
        text: str,
        *,
        add_special_tokens: bool,
        padding: bool,
        truncation: bool,
        return_attention_mask: bool,
        return_token_type_ids: bool,
        verbose: bool,
    ):
        assert padding is False
        assert truncation is False
        assert return_attention_mask is False
        assert return_token_type_ids is False
        self.verbose_values.append(verbose)
        count = len(text.split()) + (2 if add_special_tokens else 0)
        return {"input_ids": list(range(count))}

    def decode(self, tokens, skip_special_tokens=True):
        del skip_special_tokens
        return " ".join(str(token) for token in tokens)


class FakeModel:
    max_seq_length = 8


def _guarded_embedder(max_tokens: int = 8) -> SentenceTransformerEmbedder:
    embedder = SentenceTransformerEmbedder.__new__(SentenceTransformerEmbedder)
    embedder._tokenizer = FakeTokenizer()
    embedder._max_input_tokens = max_tokens
    embedder._validated_input_count = 0
    embedder._largest_input_tokens = 0
    embedder._largest_input_label = ""
    embedder._name = "fake-model"
    embedder._dimension = 3
    return embedder


def test_unbounded_counting_disables_huggingface_length_warning():
    tokenizer = FakeTokenizer()
    codec = HuggingFaceTokenCodec(tokenizer, "fake")
    tokens = codec.encode("one two three four five six seven eight nine", add_special_tokens=False)
    assert len(tokens) == 9
    assert tokenizer.verbose_values == [False]


def test_model_limit_uses_strictest_detected_value_and_rejects_unsafe_override():
    tokenizer = FakeTokenizer()
    assert resolve_model_max_input_tokens(FakeModel(), tokenizer, 0) == 8
    assert resolve_model_max_input_tokens(FakeModel(), tokenizer, 7) == 7
    with pytest.raises(ValueError, match="cannot exceed"):
        resolve_model_max_input_tokens(FakeModel(), tokenizer, 9)


def test_embedding_guard_counts_special_tokens_and_fails_before_inference():
    embedder = _guarded_embedder(8)
    assert embedder.validate_inputs(["one two three four five six"], labels=["safe-child"]) == [8]
    with pytest.raises(EmbeddingInputLengthError) as exc_info:
        embedder.validate_inputs(
            ["one two three four five six seven"],
            labels=["Document.md :: 2.1 Operation :: child 1"],
        )
    error = exc_info.value
    assert error.max_input_tokens == 8
    assert error.total_violations == 1
    assert error.violations[0]["token_count"] == 9
    assert "Document.md" in str(error)


def test_ingestion_preflight_reports_largest_final_child(monkeypatch):
    safe = ChildChunk(
        chunk_id="child-safe",
        parent_id="parent",
        content="one two three four five",
        embedding_text="one two three four five",
        page_start=1,
        page_end=1,
        child_order=1,
        token_count=5,
        metadata={"filename": "Safe.md", "heading_path": "1 Overview"},
    )
    embedder = _guarded_embedder(8)
    monkeypatch.setattr("ingestion.pipeline._iter_children", lambda documents, store, settings: iter([safe]))
    report = preflight_embedding_inputs([], object(), replace(get_settings(), procedure_max_tokens=480), embedder)
    assert report.inputs_checked == 1
    assert report.model_max_tokens == 8
    assert report.largest_input_tokens == 7  # five text tokens plus two model special tokens
    assert "Safe.md" in report.largest_input_label
    assert report.over_limit_inputs == 0


def test_ingestion_preflight_rejects_over_limit_child_with_context(monkeypatch):
    too_long = ChildChunk(
        chunk_id="child-long",
        parent_id="parent",
        content="one two three four five six seven",
        embedding_text="one two three four five six seven",
        page_start=1,
        page_end=1,
        child_order=2,
        token_count=7,
        metadata={"filename": "Long.md", "heading_path": "3.8 Feature Activation"},
    )
    embedder = _guarded_embedder(8)
    monkeypatch.setattr("ingestion.pipeline._iter_children", lambda documents, store, settings: iter([too_long]))
    with pytest.raises(EmbeddingInputLengthError) as exc_info:
        preflight_embedding_inputs([], object(), get_settings(), embedder)
    assert "Long.md" in str(exc_info.value)
    assert "3.8 Feature Activation" in str(exc_info.value)
