from __future__ import annotations

import hashlib
import sqlite3
from dataclasses import replace
from types import SimpleNamespace

from agent_core.audit import AuditStore
from agent_core.contracts import QueryRequest, QueryResponse
from agent_core.settings import get_settings
from agent_service.routes import query as query_route
from kb_api.search import HybridSearchEngine


class _CaptureLogger:
    def __init__(self):
        self.messages: list[str] = []

    def _append(self, message, *args):
        self.messages.append(message % args if args else str(message))

    info = _append
    warning = _append
    error = _append
    exception = _append


class _Embedder:
    def encode(self, texts):
        return [[0.1, 0.2, 0.3] for _ in texts]


class _Reranker:
    def predict(self, pairs, convert_to_numpy=True, show_progress_bar=False):
        del convert_to_numpy, show_progress_bar
        return [0.9 - (index * 0.1) for index, _pair in enumerate(pairs)]


class _SearchClient:
    def search(self, index, body):
        del index
        vector = "knn" in body["query"]
        child_id = "child-vector" if vector else "child-bm25"
        parent_id = "parent-vector" if vector else "parent-bm25"
        parent_content = "Full vector parent" if vector else "Full BM25 parent"
        return {
            "hits": {
                "hits": [
                    {
                        "_id": child_id,
                        "_score": 0.9 if vector else 2.0,
                        "_source": {
                            "chunk_id": child_id,
                            "content": "Vector recalled child" if vector else "BM25 recalled child",
                            "parent_id": parent_id,
                            "parent_storage_id": parent_id,
                            "parent_content_sha256": hashlib.sha256(parent_content.encode()).hexdigest(),
                            "filename": "Example.md",
                            "heading_path": "1 Overview",
                            "feature_association": "primary",
                            "manifest_priority": 100,
                            "storage_role": "child",
                            "retrieval_contract": "rank-children-then-mget-parents",
                        },
                    }
                ]
            }
        }

    def mget(self, index, body):
        del index
        docs = []
        for parent_id in body["ids"]:
            content = "Full vector parent" if parent_id == "parent-vector" else "Full BM25 parent"
            docs.append(
                {
                    "_id": parent_id,
                    "found": True,
                    "_source": {
                        "parent_id": parent_id,
                        "parent_storage_id": parent_id,
                        "content": content,
                        "content_sha256": hashlib.sha256(content.encode()).hexdigest(),
                        "filename": "Example.md",
                        "heading_path": "1 Overview",
                        "feature_association": "primary",
                    },
                }
            )
        return {"docs": docs}


class _SearchState:
    def __init__(self):
        self.settings = replace(
            get_settings(),
            allow_bm25_only=False,
            reranker_enabled=True,
            initial_candidate_count=2,
        )
        self._client = _SearchClient()
        self.logger = _CaptureLogger()
        self.rag_logger = _CaptureLogger()

    def client(self):
        return self._client

    def embedder(self):
        return _Embedder()

    def reranker(self):
        return _Reranker()


def test_rag_trace_logs_every_retrieval_stage():
    state = _SearchState()
    outcome = HybridSearchEngine(state).search("example", limit=2)
    assert len(outcome.hits) == 2
    log_text = "\n".join(state.rag_logger.messages)
    for marker in (
        "[RAG START]",
        "[RAG BM25_RECALL]",
        "[RAG VECTOR_RECALL]",
        "[RAG RRF]",
        "[RAG RERANKER]",
        "[RAG FINAL_CHILD_SELECTION]",
        "[RAG FINAL_CHILD]",
        "[RAG PARENT_MGET_REQUEST]",
        "[RAG PARENT_MGET_RESULT]",
        "[RAG FINAL_PARENT_SELECTION]",
        "[RAG FINAL_PARENT]",
        "[RAG COMPLETE]",
    ):
        assert marker in log_text
    assert "BM25 recalled child" in log_text
    assert "Vector recalled child" in log_text


def test_audit_store_records_full_query_and_answer(tmp_path):
    database = tmp_path / "ericsson_agent_audit.db"
    store = AuditStore(database)
    store.record(
        request_id="request-123",
        query="What is FAJ 121 0488?",
        workflow="feature_lookup",
        source="ericsson_kb",
        latency_ms=123,
        success=True,
        session_id="session-1",
        user_email="engineer@example.com",
        tool_calls=[{"tool": "ericsson_knowledge_workflow"}],
        tool_outputs=[{"parents": 5}],
        final_answer="It is the 16-QAM Uplink feature.",
        validation_ok=True,
        feature_ids=["FAJ 121 0488"],
        package_ids=["FAJ 801 0400"],
        citation_count=1,
        citations=[{"citation_id": "E1"}],
        response={"answer": "It is the 16-QAM Uplink feature."},
    )

    with sqlite3.connect(database) as connection:
        row = connection.execute(
            "SELECT request_id, query, final_answer, workflow, success, response_json FROM audit"
        ).fetchone()
    assert row[0] == "request-123"
    assert row[1] == "What is FAJ 121 0488?"
    assert row[2] == "It is the 16-QAM Uplink feature."
    assert row[3] == "feature_lookup"
    assert row[4] == 1
    assert "16-QAM Uplink" in row[5]


class _AuditCapture:
    def __init__(self):
        self.rows = []

    def record(self, **kwargs):
        self.rows.append(kwargs)


class _Sessions:
    def get(self, session_id):
        del session_id
        return []

    def set(self, session_id, history):
        del session_id, history

    def clear(self, session_id):
        del session_id


class _Agent:
    def run(self, query, *, limit=None, include_evidence=False, history=""):
        del query, limit, include_evidence, history
        return QueryResponse(
            answer="Recorded Ericsson answer.",
            source="ericsson_kb",
            workflow="knowledge_search",
        )


def test_query_endpoint_passes_final_answer_to_sqlite_audit(monkeypatch):
    audit = _AuditCapture()
    state = SimpleNamespace(
        agent=_Agent(),
        sessions=_Sessions(),
        audit=audit,
        logger=_CaptureLogger(),
    )
    monkeypatch.setattr(query_route, "get_state", lambda: state)
    result = query_route.query_agent(
        QueryRequest(query="Recorded query", session_id="session-1"),
        user_email="engineer@example.com",
    )
    assert result.answer == "Recorded Ericsson answer."
    assert len(audit.rows) == 1
    row = audit.rows[0]
    assert row["query"] == "Recorded query"
    assert row["final_answer"] == "Recorded Ericsson answer."
    assert row["success"] is True
    assert row["request_id"]
    assert row["response"]["answer"] == "Recorded Ericsson answer."


def test_audit_store_preserves_and_dual_writes_legacy_query_audit(tmp_path):
    database = tmp_path / "legacy_audit.db"
    with sqlite3.connect(database) as connection:
        connection.execute(
            """
            CREATE TABLE query_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                session_id TEXT,
                user_email TEXT,
                query TEXT NOT NULL,
                workflow TEXT,
                source TEXT,
                latency_ms INTEGER,
                feature_ids_json TEXT,
                package_ids_json TEXT,
                citation_count INTEGER,
                warnings_json TEXT,
                success INTEGER NOT NULL,
                error TEXT
            )
            """
        )
        connection.execute(
            """
            INSERT INTO query_audit (
                created_at, session_id, user_email, query, workflow, source,
                latency_ms, feature_ids_json, package_ids_json, citation_count,
                warnings_json, success, error
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                "2026-09-02T00:00:00+00:00",
                "legacy-session",
                "legacy@example.com",
                "Legacy Ericsson query",
                "knowledge_search",
                "ericsson_kb",
                50,
                "[]",
                "[]",
                0,
                "[]",
                1,
                "",
            ),
        )

    store = AuditStore(database)
    store.record(
        request_id="request-new",
        query="New Ericsson query",
        workflow="knowledge_search",
        source="ericsson_kb",
        latency_ms=75,
        success=True,
        final_answer="New Ericsson answer",
        validation_ok=True,
    )

    with sqlite3.connect(database) as connection:
        canonical = connection.execute(
            "SELECT query, final_answer FROM audit ORDER BY created_at"
        ).fetchall()
        legacy = connection.execute(
            "SELECT request_id, query, final_answer FROM query_audit WHERE request_id = ?",
            ("request-new",),
        ).fetchone()

    assert any(row[0] == "Legacy Ericsson query" for row in canonical)
    assert any(row == ("New Ericsson query", "New Ericsson answer") for row in canonical)
    assert legacy == ("request-new", "New Ericsson query", "New Ericsson answer")
