from dataclasses import replace

import pytest

from agent_core.settings import get_settings
from ingestion.index_schema import child_index_body, manifest_index_body, parent_index_body
from ingestion.opensearch_store import (
    IndexSafetyError,
    backing_names,
    delete_stale_by_filenames,
    switch_aliases_atomic,
    validate_index_configuration,
    validate_index_name,
)
from ingestion.pipeline import _incremental_physical_id, _physical_parent_id


def test_ericsson_index_safety_rejects_nokia_names():
    settings = get_settings()
    assert validate_index_name(settings.child_alias, settings) == "ericsson-ran-kb-children"
    assert validate_index_name(settings.parent_alias, settings) == "ericsson-ran-kb-parents"
    with pytest.raises(IndexSafetyError):
        validate_index_name("ran_kb", settings)
    with pytest.raises(IndexSafetyError):
        validate_index_name("nokia-ran-kb-children", settings)


def test_backing_names_are_ericsson_scoped_and_separate():
    child, parent, manifest = backing_names(get_settings(), "2026-09-02T12:30")
    assert child == "ericsson-ran-kb-children-v20260902t1230"
    assert parent == "ericsson-ran-kb-parents-v20260902t1230"
    assert manifest == "ericsson-ran-kb-manifests-v20260902t1230"


def test_safety_prefix_cannot_be_changed_to_generic_or_nokia_namespace():
    settings = get_settings()
    with pytest.raises(IndexSafetyError):
        validate_index_name("generic-kb-children", replace(settings, index_safety_prefix="generic-"))
    with pytest.raises(IndexSafetyError):
        validate_index_name("nokia-kb-children", replace(settings, index_safety_prefix="nokia-"))


def test_child_parent_manifest_aliases_and_prefixes_must_be_distinct():
    settings = get_settings()
    for invalid in (
        replace(settings, parent_alias=settings.child_alias),
        replace(settings, manifest_alias=settings.child_alias),
        replace(settings, parent_backing_prefix=settings.child_backing_prefix),
        replace(settings, manifest_backing_prefix=settings.parent_backing_prefix),
    ):
        with pytest.raises(IndexSafetyError):
            validate_index_configuration(invalid)


class _Indices:
    def __init__(self):
        self.body = None

    def get_alias(self, name):
        return {f"{name}-old": {"aliases": {name: {"is_write_index": True}}}}

    def update_aliases(self, body):
        self.body = body


class _Client:
    def __init__(self):
        self.indices = _Indices()


def test_child_parent_and_manifest_aliases_switch_in_one_request():
    settings = get_settings()
    client = _Client()
    switch_aliases_atomic(
        client,
        {
            settings.child_alias: "ericsson-ran-kb-children-v1",
            settings.parent_alias: "ericsson-ran-kb-parents-v1",
            settings.manifest_alias: "ericsson-ran-kb-manifests-v1",
        },
        settings,
    )
    actions = client.indices.body["actions"]
    assert len([item for item in actions if "add" in item]) == 3
    assert len([item for item in actions if "remove" in item]) == 3


class _DeleteClient:
    def __init__(self):
        self.body = None

    def delete_by_query(self, **kwargs):
        self.body = kwargs["body"]
        return {"deleted": 2}


def test_incremental_delete_is_scoped_by_vendor_and_corpus_for_each_index_type():
    from ingestion.opensearch_store import delete_by_filenames

    settings = get_settings()
    for index_name in (settings.child_alias, settings.parent_alias, settings.manifest_alias):
        client = _DeleteClient()
        assert delete_by_filenames(client, index_name, ["A.md"], settings) == 2
        clauses = client.body["query"]["bool"]["filter"]
        assert {"term": {"vendor": "Ericsson"}} in clauses
        assert {"term": {"corpus_id": "ericsson-ran"}} in clauses
        assert {"terms": {"filename": ["A.md"]}} in clauses


def test_incremental_cleanup_keeps_records_from_current_run():
    settings = get_settings()
    client = _DeleteClient()

    assert delete_stale_by_filenames(
        client,
        settings.child_alias,
        ["B.md", "A.md", "A.md"],
        "run-123",
        settings,
    ) == 2

    query = client.body["query"]["bool"]
    assert {"term": {"vendor": "Ericsson"}} in query["filter"]
    assert {"term": {"corpus_id": "ericsson-ran"}} in query["filter"]
    assert {"terms": {"filename": ["A.md", "B.md"]}} in query["filter"]
    assert query["must_not"] == [{"term": {"ingestion_run_id": "run-123"}}]


def test_failed_incremental_run_cleanup_is_scoped_by_vendor_corpus_and_run_id():
    from ingestion.opensearch_store import delete_by_run_id

    settings = get_settings()
    client = _DeleteClient()
    assert delete_by_run_id(client, settings.parent_alias, "run-123", settings) == 2
    clauses = client.body["query"]["bool"]["filter"]
    assert {"term": {"vendor": "Ericsson"}} in clauses
    assert {"term": {"corpus_id": "ericsson-ran"}} in clauses
    assert {"term": {"ingestion_run_id": "run-123"}} in clauses


def test_incremental_parent_and_child_use_same_run_scoped_parent_storage_id():
    logical_parent = "logical-parent-id"
    first = _incremental_physical_id("run-1", logical_parent)
    second = _incremental_physical_id("run-2", logical_parent)
    assert first != second
    assert first == _physical_parent_id(logical_parent, "run-1", incremental=True)
    assert logical_parent == _physical_parent_id(logical_parent, "run-1", incremental=False)


def test_complete_index_configuration_is_ericsson_only():
    settings = get_settings()
    validate_index_configuration(settings)

    for unsafe in (
        replace(settings, vendor="Nokia"),
        replace(settings, corpus_id="ran-shared"),
        replace(settings, child_alias="nokia-ran-kb-children"),
        replace(settings, parent_alias=settings.child_alias),
        replace(settings, manifest_alias=settings.child_alias),
    ):
        with pytest.raises(IndexSafetyError):
            validate_index_configuration(unsafe)


def test_parent_and_child_mappings_enforce_storage_separation():
    settings = get_settings()
    child_properties = child_index_body(settings, 32)["mappings"]["properties"]
    parent_properties = parent_index_body(settings)["mappings"]["properties"]

    assert child_properties["embedding"]["type"] == "knn_vector"
    assert child_properties["parent_storage_id"]["type"] == "keyword"
    assert "parent_content" not in child_properties

    assert parent_properties["content"]["type"] == "text"
    assert parent_properties["parent_storage_id"]["type"] == "keyword"
    assert "embedding" not in parent_properties
    assert "embedding_text" not in parent_properties


def test_manifest_identity_and_deep_heading_fields_have_exact_types():
    properties = manifest_index_body(get_settings())["mappings"]["properties"]
    for field in (
        "feature_id",
        "primary_feature_id",
        "owner_feature_id",
        "feature_ids",
        "included_feature_ids",
        "mentioned_feature_ids",
        "related_feature_ids",
        "package_id",
        "primary_package_id",
        "package_ids",
        "heading_number",
    ):
        assert properties[field]["type"] == "keyword"
    assert properties["heading_level"]["type"] == "integer"
