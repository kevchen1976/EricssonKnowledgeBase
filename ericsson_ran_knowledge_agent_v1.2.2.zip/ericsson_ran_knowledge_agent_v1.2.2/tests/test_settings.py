from agent_core.settings.loader import Settings


def test_relative_settings_file_is_resolved_from_project_root(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("AGENT_SETTINGS_FILE", "config/settings.json")
    settings = Settings.load()
    assert settings.vendor == "Ericsson"
    assert settings.child_alias == "ericsson-ran-kb-children"
    assert settings.parent_alias == "ericsson-ran-kb-parents"
    assert settings.manifest_alias == "ericsson-ran-kb-manifests"
    assert settings.chunk_alias == settings.child_alias  # v1.0 compatibility property
    assert settings.index_safety_prefix == "ericsson-ran-kb-"
    assert settings.parent_max_tokens == 3000
    assert settings.child_max_tokens == 300
    assert settings.child_overlap_tokens == 60
    assert settings.procedure_max_tokens == 480
    assert settings.embedding_max_input_tokens == 0
    assert settings.include_manifest_facts is False


def test_parent_child_integrity_and_embedding_defaults_are_fail_closed(monkeypatch):
    monkeypatch.delenv("REQUIRE_PARENT_CONTEXT", raising=False)
    monkeypatch.delenv("VERIFY_PARENT_CONTENT_HASH", raising=False)
    monkeypatch.delenv("EMBEDDING_INPUT_MODE", raising=False)
    settings = Settings.load()
    assert settings.require_parent_context is True
    assert settings.verify_parent_content_hash is True
    assert settings.embedding_input_mode == "content"
