from pathlib import Path


def test_launcher_contains_nokia_style_ollama_startup():
    text = (Path(__file__).parents[1] / "startup_all_service.sh").read_text(encoding="utf-8")
    assert "start_ollama()" in text
    assert "local ollama_command=(ollama serve)" in text
    assert 'export OLLAMA_FLASH_ATTENTION="${OLLAMA_FLASH_ATTENTION:-1}"' in text
    assert 'export OLLAMA_KV_CACHE_TYPE="${OLLAMA_KV_CACHE_TYPE:-q8_0}"' in text
    assert 'export OLLAMA_DEBUG="${OLLAMA_DEBUG:-INFO}"' in text
    assert "start_ollama_log_forwarder" in text
    assert "start_ollama\n    start_one ericsson-kb" in text


def test_launcher_does_not_kill_external_shared_ollama():
    text = (Path(__file__).parents[1] / "startup_all_service.sh").read_text(encoding="utf-8")
    assert "sudo systemctl stop ollama" not in text
    assert "pkill -f.*ollama serve" not in text
