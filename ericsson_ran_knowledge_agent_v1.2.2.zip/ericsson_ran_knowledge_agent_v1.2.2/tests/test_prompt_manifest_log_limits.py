from __future__ import annotations

import json
from dataclasses import replace
from types import SimpleNamespace

from agent_core.logging_utils import single_line_words
from agent_core.settings import DEFAULT_SYSTEM_PROMPT, SYSTEM_PROMPT_PATH, get_settings
from kb_api.manifest import ManifestRepository
from kb_api.search import (
    _trace_child_hits,
    _trace_final_children,
    _trace_final_parents,
    _trace_reranker,
    _trace_rrf,
)


class _CaptureLogger:
    def __init__(self) -> None:
        self.messages: list[str] = []

    def _append(self, message, *args) -> None:
        self.messages.append(message % args if args else str(message))

    info = _append
    warning = _append
    error = _append
    exception = _append


def _long_text(count: int = 80) -> str:
    return " ".join(f"word{index}" for index in range(1, count + 1))


def _hit(index: int) -> dict:
    return {
        "_id": f"child-{index}",
        "_score": 1.0 / index,
        "_rrf_score": 0.1 / index,
        "_rerank_score": 1.0 - (index / 100),
        "_final_child_score": 1.0 - (index / 100),
        "_source": {
            "chunk_id": f"child-{index}",
            "parent_id": f"parent-{index}",
            "parent_storage_id": f"parent-{index}",
            "filename": f"Document {index}.md",
            "heading_path": f"1 Section {index}",
            "content": _long_text(),
            "feature_association": "primary",
            "manifest_priority": 0,
            "matched_children": [],
        },
    }


def _result_lines(messages: list[str], marker: str) -> list[str]:
    return [line for line in messages if line.startswith(marker) and "rank=" in line]


def test_root_agent_instruction_matches_loaded_system_prompt() -> None:
    assert SYSTEM_PROMPT_PATH.name == "agentInstruction.txt"
    assert SYSTEM_PROMPT_PATH.is_file()
    assert DEFAULT_SYSTEM_PROMPT == SYSTEM_PROMPT_PATH.read_text(encoding="utf-8").strip()


def test_single_line_words_is_bounded_at_50_words() -> None:
    rendered = single_line_words(_long_text(80), max_words=50)
    assert len(rendered.split()) == 50
    assert rendered.startswith("word1 word2")
    assert rendered.endswith("word50...")
    assert "word51" not in rendered


def test_all_rag_result_stages_log_only_five_items_with_50_word_snippets() -> None:
    hits = [_hit(index) for index in range(1, 9)]
    logger = _CaptureLogger()
    state = SimpleNamespace(settings=SimpleNamespace(feature_association_boost=0.08, manifest_priority_boost=0.001))

    _trace_child_hits(logger, "search-1", "BM25_RECALL", hits)
    _trace_child_hits(logger, "search-1", "VECTOR_RECALL", hits)
    _trace_rrf(logger, "search-1", hits, hits, hits)
    _trace_reranker(logger, "search-1", hits)
    _trace_final_children(logger, "search-1", hits, hits, state)
    _trace_final_parents(logger, "search-1", hits)

    for marker in (
        "[RAG BM25_RECALL]",
        "[RAG VECTOR_RECALL]",
        "[RAG RRF]",
        "[RAG RERANKER]",
        "[RAG FINAL_CHILD]",
        "[RAG FINAL_PARENT]",
    ):
        lines = _result_lines(logger.messages, marker)
        assert len(lines) == 5, (marker, lines)
        for line in lines:
            snippet = line.split("snippet=", 1)[1]
            assert len(snippet.split()) == 50
            assert "word51" not in snippet

    assert any("omitted_candidates=3" in line for line in logger.messages)


def test_manifest_lookup_logs_start_paths_top_five_results_and_selection(tmp_path) -> None:
    root = tmp_path / "prepared"
    path = root / "routing-manifest/by-feature-id/FAJ121/FAJ1210488.jsonl"
    path.parent.mkdir(parents=True)
    records = []
    for index in range(1, 8):
        records.append(
            {
                "record_kind": "document" if index == 1 else "section",
                "record_id": f"record-{index}",
                "filename": "16-QAM Uplink.md",
                "doc_type": "feature_description",
                "doc_role": "feature_document",
                "is_feature_owner": index == 1,
                "owner_feature_id": "FAJ 121 0488" if index == 1 else "",
                "feature_id": "FAJ 121 0488",
                "feature_ids": ["FAJ 121 0488"],
                "feature_title": "16-QAM Uplink",
                "feature_association": "primary",
                "summary": _long_text(),
            }
        )
    path.write_text("".join(json.dumps(record) + "\n" for record in records), encoding="utf-8")

    settings = replace(
        get_settings(),
        prepared_root=root,
        markdown_root=root / "markdown",
        combined_manifest=root / "combined_manifest.jsonl",
        feature_manifest_root=root / "routing-manifest/by-feature-id",
        package_manifest_root=root / "routing-manifest/by-package-id",
        topic_manifest_root=root / "routing-manifest/by-topic",
        mentioned_feature_manifest_root=root / "routing-manifest/by-mentioned-feature-id",
    )
    logger = _CaptureLogger()
    state = SimpleNamespace(settings=settings, logger=logger, rag_logger=logger)

    bundle = ManifestRepository(state).feature_bundle("FAJ1210488")
    assert bundle["primary"]["filename"] == "16-QAM Uplink.md"

    text = "\n".join(logger.messages)
    for marker in (
        "[MANIFEST SEARCH START]",
        "[MANIFEST FILE_SEARCH]",
        "[MANIFEST RESULTS]",
        "[MANIFEST RESULT]",
        "[MANIFEST FEATURE_SELECTION]",
        "[MANIFEST SEARCH COMPLETE]",
    ):
        assert marker in text

    result_lines = _result_lines(logger.messages, "[MANIFEST RESULT]")
    assert len(result_lines) == 5
    for line in result_lines:
        snippet = line.split("snippet=", 1)[1]
        assert len(snippet.split()) == 50
        assert "word51" not in snippet
    assert "omitted_candidates=2" in text


def test_synthesis_uses_loaded_agent_instruction() -> None:
    from agent_core.synthesis import synthesize_answer

    class _Ollama:
        def __init__(self) -> None:
            self.system = ""

        def generate(self, prompt, *, system="", temperature=0.1):
            del prompt, temperature
            self.system = system
            return "Grounded answer [E1]"

    ollama = _Ollama()
    evidence = [
        {
            "_source": {
                "content": "Ericsson evidence.",
                "filename": "Example.md",
                "page_start": 1,
                "page_end": 1,
            }
        }
    ]
    answer, warnings = synthesize_answer("Question?", evidence, ollama=ollama)
    assert answer == "Grounded answer [E1]"
    assert warnings == []
    assert ollama.system == DEFAULT_SYSTEM_PROMPT
