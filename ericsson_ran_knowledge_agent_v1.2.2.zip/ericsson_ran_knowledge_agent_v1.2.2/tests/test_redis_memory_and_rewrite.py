from __future__ import annotations

from dataclasses import replace
from types import SimpleNamespace

from agent_core.contracts import QueryRequest, QueryResponse
from agent_core.rewrite import parse_rewritten_query, rewrite_query_with_llm
from agent_core.settings import get_settings
from agent_core.settings.loader import Settings
from agent_core.workflow import EricssonAgent
from agent_service.routes import query as query_route
from agent_service.sessions import SessionStore, Turn, format_history


class FakeRedis:
    def __init__(self):
        self.values = {}
        self.ttls = {}
        self.closed = False

    def ping(self):
        return True

    def get(self, key):
        return self.values.get(key)

    def set(self, key, value, ex=None):
        self.values[key] = value
        self.ttls[key] = ex
        return True

    def delete(self, key):
        return 1 if self.values.pop(key, None) is not None else 0

    def close(self):
        self.closed = True


class FakeRewriteOllama:
    def __init__(self, response):
        self.response = response
        self.prompts = []

    def generate(self, prompt, *, system="", temperature=0.1):
        self.prompts.append((prompt, system, temperature))
        return self.response


def test_redis_store_uses_ericsson_namespace_ttl_and_history_limit():
    client = FakeRedis()
    store = SessionStore(
        client=client,
        key_prefix="ericsson:session:",
        max_turns=2,
        ttl_seconds=3600,
    )
    store.set(
        "abc",
        [
            Turn.create("q1", "a1"),
            Turn.create("q2", "a2"),
            Turn.create("q3", "a3"),
        ],
    )
    key = "ericsson:session:abc"
    assert key in client.values
    assert client.ttls[key] == 3600
    history = store.get("abc")
    assert [turn.query for turn in history] == ["q2", "q3"]
    assert store.clear("abc") is True
    assert store.get("abc") == []


def test_history_format_matches_nokia_user_assistant_contract():
    history = [
        Turn.create("What is FAJ 121 0488?", "A" * 20),
        Turn.create("What package?", "B" * 20),
    ]
    text = format_history(history, max_turns=1, answer_chars=5)
    assert text == "User: What package?\nAssistant: BBBBB"


def test_query_rewrite_resolves_ericsson_follow_up_from_history():
    ollama = FakeRewriteOllama("Rewritten query: What are the dependencies of FAJ 121 0488?")
    history = (
        "User: What is FAJ 121 0488?\n"
        "Assistant: FAJ 121 0488 is the 16-QAM Uplink feature."
    )
    rewritten = rewrite_query_with_llm("What are its dependencies?", history, ollama)
    assert rewritten == "What are the dependencies of FAJ 121 0488?"
    assert ollama.prompts
    assert ollama.prompts[0][2] == 0.1


def test_query_rewrite_rejects_hallucinated_ericsson_identity():
    ollama = FakeRewriteOllama("What are the dependencies of FAJ 121 9999?")
    rewritten = rewrite_query_with_llm(
        "What are its dependencies?",
        "User: Explain IPsec.\nAssistant: IPsec secures transport.",
        ollama,
    )
    assert rewritten == "What are its dependencies?"


def test_parse_rewritten_query_removes_labels_and_markdown():
    assert parse_rewritten_query("```text\nRewritten query: **Explain FAJ 121 0488**\n```") == "Explain FAJ 121 0488"


class WorkflowKB:
    def __init__(self):
        self.calls = []

    def retrieve_feature(self, feature_id, query, *, limit, include_related=True):
        self.calls.append((feature_id, query, limit, include_related))
        return {
            "manifest": {"feature_id": feature_id, "feature_title": "16-QAM Uplink"},
            "retrievalResults": [
                {
                    "_id": "parent-1",
                    "_score": 1.0,
                    "_source": {
                        "parent_id": "parent-1",
                        "content": "This feature has no dependencies or limitations.",
                        "filename": "16-QAM Uplink.md",
                        "source_pdf": "16-QAM Uplink.pdf",
                        "title": "16-QAM Uplink",
                        "heading_path": "2 Dependencies of 16-QAM Uplink",
                        "page_start": 1,
                        "page_end": 1,
                        "feature_id": "FAJ 121 0488",
                        "feature_ids": ["FAJ 121 0488"],
                        "package_ids": ["FAJ 801 0400"],
                        "feature_association": "primary",
                    },
                }
            ],
        }

    def retrieve_package(self, package_id, query, *, limit):
        raise AssertionError("package lookup not expected")

    def search(self, query, *, limit, filters=None):
        raise AssertionError(f"generic search not expected for rewritten feature query: {query}")


class WorkflowOllama:
    def __init__(self):
        self.calls = []

    def generate(self, prompt, *, system="", temperature=0.1):
        self.calls.append((prompt, system, temperature))
        if "You are a query rewriter" in prompt:
            return "What are the dependencies of FAJ 121 0488?"
        return "FAJ 121 0488 has no dependencies or limitations. [E1]"


def test_agent_routes_and_retrieves_with_rewritten_query():
    settings = replace(
        get_settings(),
        llm_enabled=True,
        graph_enabled=False,
        enable_llm_query_rewrite=True,
    )
    kb = WorkflowKB()
    ollama = WorkflowOllama()
    agent = EricssonAgent(settings, kb=kb, graph=None, ollama=ollama)
    history = (
        "User: What is FAJ 121 0488?\n"
        "Assistant: FAJ 121 0488 is 16-QAM Uplink."
    )
    result = agent.run("What are its dependencies?", history=history)
    assert result.workflow == "feature_lookup"
    assert kb.calls[0][0] == "FAJ 121 0488"
    assert kb.calls[0][1] == "What are the dependencies of FAJ 121 0488?"
    assert result.metadata["original_query"] == "What are its dependencies?"
    assert result.metadata["effective_query"] == "What are the dependencies of FAJ 121 0488?"
    assert result.metadata["query_rewritten"] is True
    assert "[E1]" in result.answer


class AuditCapture:
    def __init__(self, events):
        self.events = events
        self.rows = []

    def record(self, **kwargs):
        self.events.append("audit")
        self.rows.append(kwargs)


class SessionCapture:
    backend = "redis"

    def __init__(self, events):
        self.events = events
        self.saved = None

    def get(self, session_id):
        self.events.append("memory_get")
        return [Turn.create("What is FAJ 121 0488?", "It is 16-QAM Uplink.")]

    def set(self, session_id, history):
        self.events.append("memory_set")
        self.saved = (session_id, list(history))

    def clear(self, session_id):
        return True


class AgentCapture:
    def __init__(self, events):
        self.events = events
        self.history = ""

    def run(self, query, *, limit=None, include_evidence=False, history=""):
        self.events.append("agent_run")
        self.history = history
        return QueryResponse(
            answer="No dependencies. [E1]",
            source="ericsson_kb",
            workflow="feature_lookup",
            feature_ids=["FAJ 121 0488"],
            metadata={
                "effective_query": "What are the dependencies of FAJ 121 0488?",
                "query_rewritten": True,
            },
        )


class LogCapture:
    def info(self, *args, **kwargs):
        pass

    def exception(self, *args, **kwargs):
        pass


def test_query_route_reads_memory_before_agent_and_writes_after_audit(monkeypatch):
    events = []
    sessions = SessionCapture(events)
    agent = AgentCapture(events)
    audit = AuditCapture(events)
    state = SimpleNamespace(
        settings=SimpleNamespace(
            max_session_history=5,
            session_history_answer_chars=2000,
            session_stored_answer_chars=4000,
            session_ttl_seconds=3600,
            session_memory_enabled=True,
        ),
        sessions=sessions,
        agent=agent,
        audit=audit,
        logger=LogCapture(),
    )
    monkeypatch.setattr(query_route, "get_state", lambda: state)
    result = query_route.query_agent(
        QueryRequest(query="What are its dependencies?", session_id="session-1"),
        user_email="engineer@example.com",
    )
    assert result.answer.startswith("No dependencies")
    assert events == ["memory_get", "agent_run", "audit", "memory_set"]
    assert "FAJ 121 0488" in agent.history
    assert sessions.saved[0] == "session-1"
    assert len(sessions.saved[1]) == 2
    assert audit.rows[0]["tool_calls"][0]["query_rewritten"] is True


def test_settings_support_exact_nokia_environment_names(monkeypatch):
    monkeypatch.setenv("SESSION_TTL", "7200")
    monkeypatch.setenv("MAX_HISTORY", "7")
    monkeypatch.setenv("REDIS_KEY_PREFIX", "ericsson:test:")
    settings = Settings.load()
    assert settings.session_ttl_seconds == 7200
    assert settings.max_session_history == 7
    assert settings.redis_key_prefix == "ericsson:test:"
    assert settings.enable_llm_query_rewrite is True
