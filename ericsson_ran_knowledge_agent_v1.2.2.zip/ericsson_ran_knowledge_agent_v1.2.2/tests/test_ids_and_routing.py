from agent_core.ids import (
    feature_key,
    find_feature_ids,
    find_package_ids,
    normalize_feature_id,
    normalize_package_id,
)
from agent_core.routing import route_query


def test_ericsson_identity_normalization_preserves_leading_zeroes():
    assert normalize_feature_id("faj1210488") == "FAJ 121 0488"
    assert normalize_feature_id("FAJ 121 0488") == "FAJ 121 0488"
    assert normalize_package_id("FAJ8010400") == "FAJ 801 0400"
    assert feature_key("FAJ 121 0488") == "FAJ1210488"


def test_find_multiple_ids_and_deduplicate():
    text = "FAJ 121 0804, FAJ1213586 and FAJ 121 0804; packages FAJ 801 0417 / FAJ8010516"
    assert find_feature_ids(text) == ["FAJ 121 0804", "FAJ 121 3586"]
    assert find_package_ids(text) == ["FAJ 801 0417", "FAJ 801 0516"]


def test_deterministic_routing():
    decision = route_query("What does FAJ 121 0488 do?")
    assert decision.workflow == "feature_lookup"
    assert decision.feature_ids == ["FAJ 121 0488"]
    package = route_query("What is in FAJ 801 0417?")
    assert package.workflow == "package_lookup"
    generic = route_query("Explain IPsec MTU planning")
    assert generic.workflow == "knowledge_search"
