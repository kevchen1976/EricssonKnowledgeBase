from ericsson_preparation.analyze import extract_feature_variants


def test_flattened_transposed_identity_table_preserves_feature_package_columns():
    markdown = """
Commercial Product Description

Feature
Name
IPsec
IPsec
IPsec
IPsec

Feature
Identity
FAJ 121 0804
FAJ 121 0804
FAJ 121 3586
FAJ 121 0804

NR Base Package
IPsec
IPsec
Baseband IPsec GSM RAN

Value
Package
Name

FAJ 801 4002
FAJ 801 0417
FAJ 801 0516
FAJ 801 0747

Value
Package
Identity

Node Type
Baseband Radio Node
Baseband Radio Node
Baseband Radio Node
Baseband Radio Node

Access Type
NR
LTE
WCDMA
GSM

Licensing
License-controlled
feature. One license is
required for each node.

License-controlled
feature. One license is
required for each node.

License-controlled
feature. One license is
required for each node.

License-controlled
feature. One license is
required for each node.

Summary
"""
    variants = extract_feature_variants(markdown)
    assert [(v.feature_id, v.package_id, v.access_type) for v in variants] == [
        ("FAJ 121 0804", "FAJ 801 4002", "NR"),
        ("FAJ 121 0804", "FAJ 801 0417", "LTE"),
        ("FAJ 121 3586", "FAJ 801 0516", "WCDMA"),
        ("FAJ 121 0804", "FAJ 801 0747", "GSM"),
    ]
    assert [v.feature_name for v in variants] == ["IPsec"] * 4
    assert [v.package_name for v in variants] == [
        "NR Base Package",
        "IPsec",
        "IPsec",
        "Baseband IPsec GSM RAN",
    ]
    assert all(v.node_type == "Baseband Radio Node" for v in variants)
    assert all("One license is required" in v.licensing for v in variants)


def test_dedicated_feature_identity_list_becomes_feature_package_variant(tmp_path):
    from pathlib import Path
    from ericsson_preparation.analyze import analyze_markdown

    md = tmp_path / "Feature.md"
    md.write_text(
        """<!-- page: 1 -->
Feature Description
16-QAM Uplink
Feature Name 16-QAM Uplink
Feature Identity FAJ 121 0488
Value Package Name LTE Base Package
Value Package Identity FAJ 801 0400
Node Type Baseband Radio Node
Access Type LTE
Licensing Non-license-controlled feature. No license is required.
""",
        encoding="utf-8",
    )
    analysis = analyze_markdown(md, source_pdf=Path("Feature.pdf"), page_count=1)
    assert analysis.package_names == ["LTE Base Package"]
    assert len(analysis.feature_variants) == 1
    variant = analysis.feature_variants[0]
    assert variant.feature_id == "FAJ 121 0488"
    assert variant.package_id == "FAJ 801 0400"
    assert variant.package_name == "LTE Base Package"
