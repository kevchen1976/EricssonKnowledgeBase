from pathlib import Path
from types import SimpleNamespace

import agent_core.clients as clients
from agent_core.logging_utils import configure_rotating_file_logger, request_context


class _Response:
    status_code = 200

    def raise_for_status(self):
        return None

    def json(self):
        return {
            "response": "answer text",
            "eval_count": 7,
            "prompt_eval_count": 11,
            "total_duration": 1234,
        }


class _Client:
    last_json = None

    def __init__(self, *args, **kwargs):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def post(self, url, json):
        self.__class__.last_json = json
        return _Response()


def _settings(tmp_path: Path, verbose=True):
    return SimpleNamespace(
        llm_enabled=True,
        ollama_model="test-model",
        ollama_url="http://localhost:11434/api/generate",
        ollama_timeout=10,
        ollama_verbose=verbose,
        ollama_log_prompt_max_chars=8,
        ollama_log_response_max_chars=6,
        ollama_log_file=tmp_path / "ollama.log",
        ollama_log_max_bytes=1024 * 1024,
        ollama_log_backup_count=2,
    )


def _flush(logger):
    for handler in logger.handlers:
        handler.flush()


def test_verbose_logging_is_bounded_and_written_to_dedicated_file(monkeypatch, tmp_path):
    monkeypatch.setattr(clients.httpx, "Client", _Client)
    settings = _settings(tmp_path, True)

    with request_context("request-123"):
        result = clients.OllamaClient(settings).generate(
            "123456789012345",
            system="abcdefghijklm",
            purpose="query_rewrite",
        )

    assert result == "answer text"
    assert _Client.last_json["prompt"] == "123456789012345"
    assert _Client.last_json["system"] == "abcdefghijklm"

    dedicated = configure_rotating_file_logger(
        "ericsson_ollama",
        settings.ollama_log_file,
        max_bytes=settings.ollama_log_max_bytes,
        backup_count=settings.ollama_log_backup_count,
    )
    _flush(dedicated)
    text = settings.ollama_log_file.read_text(encoding="utf-8")
    assert "request_id=request-123" in text
    assert "[OLLAMA REQUEST]" in text
    assert "purpose=query_rewrite" in text
    assert "prompt_truncated=True" in text
    assert "[OLLAMA REQUEST PAYLOAD]" in text
    assert "[OLLAMA RESPONSE]" in text
    assert "response_truncated=True" in text
    assert "[OLLAMA RESPONSE PAYLOAD]" in text
    assert "...[log truncated]" in text


def test_non_verbose_mode_still_logs_summary_without_payload(monkeypatch, tmp_path):
    monkeypatch.setattr(clients.httpx, "Client", _Client)
    settings = _settings(tmp_path, False)

    assert clients.OllamaClient(settings).generate("hello", purpose="answer_synthesis") == "answer text"
    dedicated = configure_rotating_file_logger(
        "ericsson_ollama",
        settings.ollama_log_file,
        max_bytes=settings.ollama_log_max_bytes,
        backup_count=settings.ollama_log_backup_count,
    )
    _flush(dedicated)
    text = settings.ollama_log_file.read_text(encoding="utf-8")
    assert "[OLLAMA REQUEST]" in text
    assert "[OLLAMA RESPONSE]" in text
    assert "purpose=answer_synthesis" in text
    assert "verbose=False" in text
    assert "[OLLAMA REQUEST PAYLOAD]" not in text
    assert "[OLLAMA RESPONSE PAYLOAD]" not in text


def test_rotating_logger_uses_requested_limits(tmp_path):
    logger = configure_rotating_file_logger(
        "ericsson_ollama_test_rotation",
        tmp_path / "ollama.log",
        max_bytes=4321,
        backup_count=3,
    )
    handler = next(item for item in logger.handlers if hasattr(item, "maxBytes"))
    assert handler.maxBytes == 4321
    assert handler.backupCount == 3
