from fastapi.testclient import TestClient

from agent_service.application import app


def test_capabilities_expose_separate_ericsson_parent_child_indexes_and_disabled_graph():
    response = TestClient(app).get("/capabilities")
    assert response.status_code == 200
    payload = response.json()
    assert payload["vendor"] == "Ericsson"
    assert payload["retrieval_schema"] == "ericsson-kb-1.2-parent-child"
    opensearch = payload["data_sources"]["opensearch"]
    assert opensearch["child_alias"] == "ericsson-ran-kb-children"
    assert opensearch["parent_alias"] == "ericsson-ran-kb-parents"
    assert opensearch["manifest_alias"] == "ericsson-ran-kb-manifests"
    assert opensearch["retrieval_contract"] == "rank-children-then-mget-parents"
    assert payload["data_sources"]["neo4j"]["enabled"] is False
    assert payload["data_sources"]["neo4j"]["database"] == "ericsson"


def test_kb_readiness_requires_child_parent_and_manifest_aliases(monkeypatch):
    from pathlib import Path
    from types import SimpleNamespace

    from fastapi import Response

    from kb_api.routes import system

    fake_state = SimpleNamespace(
        settings=SimpleNamespace(
            markdown_root=Path("."),
            combined_manifest=Path("combined_manifest.jsonl"),
        ),
        opensearch_status=lambda: {
            "connected": True,
            "child_alias_exists": True,
            "parent_alias_exists": False,
            "manifest_alias_exists": True,
        },
    )
    monkeypatch.setattr(system, "get_state", lambda: fake_state)
    response = Response()
    payload = system.ready(response)
    assert payload["ready"] is False
    assert response.status_code == 503
