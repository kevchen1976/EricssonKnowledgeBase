from pathlib import Path
from types import SimpleNamespace

import agent_core.clients as clients
from agent_core.settings.loader import Settings


class _Response:
    status_code = 200

    def raise_for_status(self):
        return None

    def json(self):
        return {"response": "ok"}


class _Client:
    last_json = None

    def __init__(self, *args, **kwargs):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def post(self, url, json):
        self.__class__.last_json = json
        return _Response()


def _client_settings(tmp_path: Path, context_tokens: int = 32000):
    return SimpleNamespace(
        llm_enabled=True,
        ollama_model="test-model",
        ollama_url="http://localhost:11434/api/generate",
        ollama_timeout=10,
        ollama_context_tokens=context_tokens,
        ollama_verbose=False,
        ollama_log_prompt_max_chars=1000,
        ollama_log_response_max_chars=1000,
        ollama_log_file=tmp_path / "ollama-client.log",
        ollama_log_max_bytes=1024 * 1024,
        ollama_log_backup_count=1,
        logs_dir=tmp_path,
    )


def test_settings_default_matches_nokia_context(monkeypatch):
    monkeypatch.delenv("OLLAMA_CONTEXT_TOKENS", raising=False)
    settings = Settings.load()
    assert settings.ollama_context_tokens == 32000


def test_environment_override_is_respected(monkeypatch):
    monkeypatch.setenv("OLLAMA_CONTEXT_TOKENS", "16384")
    settings = Settings.load()
    assert settings.ollama_context_tokens == 16384


def test_every_generate_request_sends_num_ctx(monkeypatch, tmp_path):
    monkeypatch.setattr(clients.httpx, "Client", _Client)
    result = clients.OllamaClient(_client_settings(tmp_path, 32000)).generate(
        "hello",
        purpose="answer_synthesis",
    )
    assert result == "ok"
    assert _Client.last_json["options"]["num_ctx"] == 32000
    assert _Client.last_json["options"]["temperature"] == 0.1
