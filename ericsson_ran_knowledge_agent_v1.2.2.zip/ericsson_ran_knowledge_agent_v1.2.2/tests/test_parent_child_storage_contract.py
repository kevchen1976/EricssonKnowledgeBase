from __future__ import annotations

import hashlib
import json
from dataclasses import replace
from pathlib import Path

import pytest

from agent_core.constants import (
    CHILD_STORAGE_ROLE,
    PARENT_CHILD_CONTRACT,
    PARENT_STORAGE_ROLE,
    RETRIEVAL_SCHEMA,
)
from agent_core.settings import get_settings
from ingestion.chunker import build_child_chunks
from ingestion.models import MarkdownBlock, ParentChunk
from ingestion.storage_validation import validate_preview_storage, validate_storage_records
from kb_api.search import ParentContextUnavailableError, _expand_parents


def _parent() -> ParentChunk:
    content = "## 2.2.3.1 Radio Node\n\nThe radio node requests and installs the license file."
    return ParentChunk(
        parent_id="logical-parent",
        filename="Instantaneous Licensing Solution Guideline.md",
        title="Instantaneous Licensing Solution Guideline",
        heading="2.2.3.1 Radio Node",
        heading_path=(
            "2 Principles and Guidelines > 2.2 Solution Overview > "
            "2.2.3 Network Elements > 2.2.3.1 Radio Node"
        ),
        section_type="general",
        feature_association="none",
        page_start=6,
        page_end=7,
        content=content,
        image_paths=[],
        metadata={
            "vendor": "Ericsson",
            "corpus_id": "ericsson-ran",
            "heading_level": 4,
            "chunk_kind": "markdown",
        },
        parent_order=1,
        blocks=[MarkdownBlock(content, 6, 7, "paragraph")],
    )


def test_parent_and_child_sources_implement_the_nokia_storage_contract():
    settings = replace(
        get_settings(),
        child_max_tokens=300,
        child_overlap_tokens=60,
        embedding_input_mode="content",
    )
    parent = _parent()
    child = build_child_chunks([parent], settings)[0]

    parent_source = parent.to_source()
    child_source = child.to_source([0.1, 0.2, 0.3])

    assert parent_source["storage_role"] == PARENT_STORAGE_ROLE
    assert child_source["storage_role"] == CHILD_STORAGE_ROLE
    assert parent_source["retrieval_contract"] == PARENT_CHILD_CONTRACT
    assert child_source["retrieval_contract"] == PARENT_CHILD_CONTRACT

    assert "embedding" not in parent_source
    assert "embedding_text" not in parent_source
    assert "parent_content" not in child_source
    assert child_source["embedding"] == [0.1, 0.2, 0.3]

    assert child_source["embedding_input_mode"] == "content"
    assert child_source["embedding_text"] == child_source["content"]
    assert child_source["parent_id"] == parent_source["parent_id"]
    assert child_source["parent_content_sha256"] == parent_source["content_sha256"]
    assert parent_source["content_sha256"] == hashlib.sha256(
        parent_source["content"].encode("utf-8")
    ).hexdigest()


def test_strict_parent_expansion_rejects_a_missing_stored_parent():
    children = [{
        "_id": "child-1",
        "_source": {
            "chunk_id": "child-1",
            "parent_id": "logical-parent",
            "parent_storage_id": "stored-parent",
            "content": "matching child",
            "page_start": 6,
            "page_end": 6,
        },
    }]

    with pytest.raises(ParentContextUnavailableError, match="Stored parent stored-parent was unavailable"):
        _expand_parents(
            children,
            {},
            [],
            require_parent_context=True,
            verify_parent_content_hash=True,
        )


def test_strict_parent_expansion_rejects_parent_content_hash_mismatch():
    expected = hashlib.sha256(b"expected parent").hexdigest()
    children = [{
        "_id": "child-1",
        "_source": {
            "chunk_id": "child-1",
            "parent_id": "logical-parent",
            "parent_storage_id": "stored-parent",
            "parent_content_sha256": expected,
            "content": "matching child",
            "page_start": 6,
            "page_end": 6,
        },
    }]
    parents = {
        "stored-parent": {
            "parent_id": "logical-parent",
            "parent_storage_id": "stored-parent",
            "content": "different parent",
        }
    }

    with pytest.raises(ParentContextUnavailableError, match="failed content-integrity validation"):
        _expand_parents(
            children,
            parents,
            [],
            require_parent_context=True,
            verify_parent_content_hash=True,
        )



def test_strict_parent_expansion_rejects_child_without_expected_parent_hash():
    children = [{
        "_id": "child-1",
        "_source": {
            "chunk_id": "child-1",
            "parent_id": "logical-parent",
            "parent_storage_id": "stored-parent",
            "content": "matching child",
            "page_start": 6,
            "page_end": 6,
        },
    }]
    parents = {
        "stored-parent": {
            "parent_id": "logical-parent",
            "parent_storage_id": "stored-parent",
            "content": "full parent",
            "content_sha256": hashlib.sha256(b"full parent").hexdigest(),
        }
    }

    with pytest.raises(ParentContextUnavailableError, match="no expected parent-content hash"):
        _expand_parents(
            children,
            parents,
            [],
            require_parent_context=True,
            verify_parent_content_hash=True,
        )

def test_controlled_non_strict_mode_can_fall_back_to_child_content():
    children = [{
        "_id": "child-1",
        "_source": {
            "chunk_id": "child-1",
            "parent_id": "logical-parent",
            "parent_storage_id": "stored-parent",
            "content": "matching child",
            "page_start": 6,
            "page_end": 6,
        },
    }]
    warnings: list[str] = []
    results = _expand_parents(
        children,
        {},
        warnings,
        require_parent_context=False,
        verify_parent_content_hash=True,
    )
    assert results[0]["_source"]["content"] == "matching child"
    assert warnings and "Child content was returned as fallback" in warnings[0]


def test_preview_storage_validator_accepts_complete_parent_child_records(tmp_path: Path):
    parent = _parent()
    settings = replace(get_settings(), embedding_input_mode="content")
    child = build_child_chunks([parent], settings)[0]
    parent_source = parent.to_source()
    parent_source["parent_storage_id"] = parent.parent_id
    child_source = child.to_source([0.1, 0.2])
    child_source["parent_storage_id"] = parent.parent_id

    preview = tmp_path / "preview"
    preview.mkdir()
    (preview / "parents.jsonl").write_text(
        json.dumps({"_id": parent.parent_id, "_source": parent_source}) + "\n",
        encoding="utf-8",
    )
    (preview / "children.jsonl").write_text(
        json.dumps({"_id": child.chunk_id, "_source": child_source}) + "\n",
        encoding="utf-8",
    )

    report = validate_preview_storage(preview, require_embeddings=True)
    assert report.ok is True
    assert report.parent_records == 1
    assert report.child_records == 1
    assert report.level_four_parents == 1
    assert report.parents_with_embeddings == 0
    assert report.children_with_parent_content == 0
    assert report.children_missing_parent_reference == 0
    assert report.to_dict()["retrieval_schema"] == RETRIEVAL_SCHEMA


def test_storage_validator_rejects_vector_parent_and_duplicated_child_context():
    parent = _parent()
    parent_source = parent.to_source()
    parent_source["parent_storage_id"] = parent.parent_id
    parent_source["embedding"] = [0.1]
    child_source = {
        "chunk_id": "child-1",
        "parent_id": parent.parent_id,
        "parent_storage_id": parent.parent_id,
        "content": "child",
        "embedding_text": "child",
        "embedding_input_mode": "content",
        "embedding": [0.1],
        "parent_content": parent.content,
        "parent_content_sha256": parent_source["content_sha256"],
    }

    report = validate_storage_records(
        [{"_id": parent.parent_id, "_source": parent_source}],
        [{"_id": "child-1", "_source": child_source}],
        require_embeddings=True,
    )
    assert report.ok is False
    assert report.parents_with_embeddings == 1
    assert report.children_with_parent_content == 1
