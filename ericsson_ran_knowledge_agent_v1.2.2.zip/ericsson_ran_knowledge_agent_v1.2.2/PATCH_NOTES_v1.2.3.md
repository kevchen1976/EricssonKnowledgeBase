# Ericsson RAN Knowledge Agent v1.2.3

This release is limited to prompt configuration and operational logging.
It does not change retrieval, scoring, reranking, parent/child storage,
embeddings, OpenSearch mappings, manifests, API response contracts, SQLite
audit behavior, or Neo4j behavior.

## Nokia-style agent instruction file

The Agent LLM system instruction is now stored at the repository root:

```text
agentInstruction.txt
```

`agent_core/settings/paths.py` exposes `SYSTEM_PROMPT_PATH`, and
`agent_core/settings/prompt.py` loads the file at process startup. The fallback
prompt is semantically identical to the former hard-coded prompt in
`agent_core/synthesis.py`. Restart the Agent service after editing the file.

## Manifest lookup trace

Feature, package, and topic manifest resolution is now recorded in
`logs/chunks.log` before the vector/BM25 search begins. Trace stages include:

```text
[MANIFEST SEARCH START]
[MANIFEST FILE_SEARCH]
[MANIFEST REMOTE_FALLBACK]
[MANIFEST REMOTE_SEARCH]
[MANIFEST RESULTS]
[MANIFEST RESULT]
[MANIFEST FEATURE_SELECTION]
[MANIFEST PACKAGE_SELECTION]
[MANIFEST SEARCH COMPLETE]
```

Local JSONL paths, record counts, OpenSearch fallback, selected direct/related
documents, and elapsed time are recorded. At most five manifest records are
printed, with a 50-word preview per record.

## Reduced RAG result logging

Every result-bearing RAG stage now logs at most five records and at most 50
words of content per record:

```text
BM25_RECALL
VECTOR_RECALL
RRF
RERANKER
FINAL_CHILD
FINAL_PARENT
AGENT EVIDENCE
```

Stage totals and omitted counts are still logged, so diagnostic counts remain
visible without printing every candidate. Parent-ID lists are also limited to
five displayed IDs while preserving the full requested count.

No OpenSearch re-ingestion is required.
