# Ericsson Agent v1.2.9 — explicit Nokia-aligned Ollama context

This patch adds the missing `OLLAMA_CONTEXT_TOKENS` setting and sends it as
Ollama's `options.num_ctx` on every query-rewrite and answer-synthesis request.

Default: `32000`, matching the supplied Nokia agent.

Without this option, the long-context model can use its 262144-token model
default. That can allocate a much larger KV cache, partially offload the model
to CPU, and reduce generation throughput.

Changed runtime files:

- `agent_core/settings/loader.py`
- `agent_core/clients.py`
- `agent_core/config.py`
- `agent_core/constants.py`

Added:

- `scripts/check_ollama_context.py`
- `tests/test_ollama_context_tokens.py`

The installer also adds `limits.ollama_context_tokens: 32000` to
`config/settings.json` and documents/adds `OLLAMA_CONTEXT_TOKENS=32000` in the
environment files without overwriting an existing value.

No OpenSearch re-ingestion is required.
