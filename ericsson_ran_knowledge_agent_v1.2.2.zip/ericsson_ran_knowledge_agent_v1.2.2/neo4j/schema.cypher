// Ericsson graph schema scaffold. Run only in the Ericsson Neo4j database.
CREATE CONSTRAINT ericsson_feature_identity IF NOT EXISTS
FOR (n:Feature) REQUIRE (n.vendor, n.corpus_id, n.id) IS UNIQUE;

CREATE CONSTRAINT ericsson_package_identity IF NOT EXISTS
FOR (n:Package) REQUIRE (n.vendor, n.corpus_id, n.id) IS UNIQUE;

CREATE CONSTRAINT ericsson_document_identity IF NOT EXISTS
FOR (n:Document) REQUIRE (n.vendor, n.corpus_id, n.filename) IS UNIQUE;

CREATE CONSTRAINT ericsson_access_identity IF NOT EXISTS
FOR (n:AccessType) REQUIRE (n.vendor, n.corpus_id, n.name) IS UNIQUE;

CREATE CONSTRAINT ericsson_node_type_identity IF NOT EXISTS
FOR (n:NodeType) REQUIRE (n.vendor, n.corpus_id, n.name) IS UNIQUE;
