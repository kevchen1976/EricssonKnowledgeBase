#!/usr/bin/env python3
"""Import curated Ericsson document/package/feature relationships into Neo4j.

The command is dry-run by default.  It only writes when ``--execute`` is used
and GRAPH_ENABLED=true.  This lets relationship collection mature before the
graph becomes part of production answering.
"""
from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import argparse
import json
from typing import Any, Dict, Iterable, List

from agent_core.ids import normalize_feature_id, normalize_package_id
from agent_core.settings import get_settings


def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    records: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            line = line.strip()
            if not line:
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"Expected object at {path}:{line_no}")
            records.append(value)
    return records


def relationship_rows(records: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for record in records:
        if str(record.get("record_kind") or "") != "package_feature":
            continue
        feature_id = normalize_feature_id(str(record.get("feature_id") or ""))
        package_id = normalize_package_id(str(record.get("package_id") or ""))
        if not feature_id or not package_id:
            continue
        rows.append({
            "feature_id": feature_id,
            "feature_title": str(record.get("feature_title") or ""),
            "package_id": package_id,
            "package_title": str(record.get("package_title") or record.get("package_name") or ""),
            "access_type": str(record.get("access_type") or ""),
            "node_type": str(record.get("node_type") or ""),
            "filename": str(record.get("filename") or record.get("source_markdown") or ""),
            "document_title": str(record.get("title") or ""),
            "doc_type": str(record.get("doc_type") or ""),
            "doc_role": str(record.get("doc_role") or ""),
            "page_start": int(record.get("page_start") or 1),
            "page_end": int(record.get("page_end") or record.get("page_start") or 1),
        })
    return rows


def execute(rows: List[Dict[str, Any]]) -> None:
    settings = get_settings()
    if not settings.graph_enabled:
        raise RuntimeError("Set GRAPH_ENABLED=true before using --execute")
    from neo4j import GraphDatabase

    query = """
    UNWIND $rows AS row
    MERGE (f:Feature {vendor: $vendor, corpus_id: $corpus_id, id: row.feature_id})
      ON CREATE SET f.title = row.feature_title
      ON MATCH SET f.title = CASE WHEN row.feature_title = '' THEN f.title ELSE row.feature_title END
    MERGE (p:Package {vendor: $vendor, corpus_id: $corpus_id, id: row.package_id})
      ON CREATE SET p.title = row.package_title
      ON MATCH SET p.title = CASE WHEN row.package_title = '' THEN p.title ELSE row.package_title END
    MERGE (f)-[r:IN_PACKAGE {access_type: row.access_type}]->(p)
    SET r.source_markdown = row.filename,
        r.page_start = row.page_start,
        r.page_end = row.page_end
    FOREACH (_ IN CASE WHEN row.filename = '' THEN [] ELSE [1] END |
      MERGE (d:Document {vendor: $vendor, corpus_id: $corpus_id, filename: row.filename})
      SET d.title = row.document_title, d.doc_type = row.doc_type, d.doc_role = row.doc_role
      MERGE (d)-[:DOCUMENTS_FEATURE]->(f)
      MERGE (d)-[:DOCUMENTS_PACKAGE]->(p)
    )
    FOREACH (_ IN CASE WHEN row.access_type = '' THEN [] ELSE [1] END |
      MERGE (a:AccessType {vendor: $vendor, corpus_id: $corpus_id, name: row.access_type})
      MERGE (f)-[:APPLIES_TO_ACCESS]->(a)
      MERGE (p)-[:APPLIES_TO_ACCESS]->(a)
    )
    FOREACH (_ IN CASE WHEN row.node_type = '' THEN [] ELSE [1] END |
      MERGE (n:NodeType {vendor: $vendor, corpus_id: $corpus_id, name: row.node_type})
      MERGE (f)-[:APPLIES_TO_NODE_TYPE]->(n)
      MERGE (p)-[:APPLIES_TO_NODE_TYPE]->(n)
    )
    """
    driver = GraphDatabase.driver(settings.neo4j_uri, auth=(settings.neo4j_user, settings.neo4j_password))
    try:
        with driver.session(database=settings.neo4j_database or None) as session:
            session.run(query, rows=rows, vendor=settings.vendor, corpus_id=settings.corpus_id).consume()
    finally:
        driver.close()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("jsonl", type=Path, help="combined_manifest.jsonl or graph_staging_relationships.jsonl")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--preview", type=Path, default=None)
    args = parser.parse_args()
    rows = relationship_rows(read_jsonl(args.jsonl))
    preview = args.preview or args.jsonl.with_name("neo4j_import_preview.jsonl")
    preview.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows), encoding="utf-8")
    print(json.dumps({"relationships": len(rows), "preview": str(preview), "executed": args.execute}, indent=2))
    if args.execute:
        execute(rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
