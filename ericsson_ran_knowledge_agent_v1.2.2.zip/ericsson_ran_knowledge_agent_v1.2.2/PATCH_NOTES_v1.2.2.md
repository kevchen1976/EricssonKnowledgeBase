# Ericsson RAN Knowledge Agent v1.2.2 logging/audit patch

## Scope

This is an observability-only patch for v1.2.1. It adds detailed RAG tracing and Nokia-compatible SQLite query/answer auditing. It does not change document preparation, section parsing, parent/child generation, embeddings, OpenSearch mappings, search queries, RRF calculations, reranker calculations, ranking boosts, result limits, response contracts, or Neo4j behavior.

## New runtime outputs

- `logs/chunks.log`: BM25 and vector child recall, RRF, reranker, selected children, parent expansion, selected parents, and stage timings.
- `logs/ericsson_agent.log`: Agent routing, KB/graph calls, evidence merge, synthesis, validation, final answer lifecycle, and SQLite audit status.
- `logs/ericsson_kb.log`: existing KB summary log, now correlated by request ID.
- `data/ericsson_agent_audit.db`, table `audit`: every Agent API query and final answer, including tool details, citations, warnings, validation fields, latency, and response JSON.

## Compatibility

- Existing OpenSearch indexes are unchanged and do not need re-ingestion.
- Existing `config/services.env`, prepared Markdown, manifests, model directories, logs, and data are preserved by `apply_patch.sh`.
- An existing v1.2.1 SQLite `query_audit` table is retained, migrated into the canonical `audit` table, and dual-written for compatibility.
- One `request_id` correlates Agent logs, KB/RAG logs, and the SQLite row. A `search_id` distinguishes multiple KB searches within one Agent request.

## Apply

Stop the Ericsson Agent and KB services, then run:

```bash
unzip ericsson_v1.2.2_rag_logging_audit_patch.zip
cd ericsson_v1.2.2_rag_logging_audit_patch
bash apply_patch.sh /path/to/ericsson_ran_knowledge_agent_v1.2.1
```

The installation directory may still be named `ericsson_ran_knowledge_agent_v1.2.0`; the script checks the installed package version rather than the directory name. Restart the Agent and KB services after applying the patch.

## Validate

```bash
python -c "from agent_core.constants import PACKAGE_VERSION; print(PACKAGE_VERSION)"
python -m compileall -q agent_core agent_service kb_api
python -m pytest -q
```

Expected package version: `1.2.2`. No OpenSearch rebuild is required.
