# OpenSearch deployment and index lifecycle

## Shared-cluster rule

Use the existing physical cluster, but keep Ericsson in three dedicated aliases:

```text
OPENSEARCH_CHILD_ALIAS=ericsson-ran-kb-children
OPENSEARCH_PARENT_ALIAS=ericsson-ran-kb-parents
OPENSEARCH_MANIFEST_ALIAS=ericsson-ran-kb-manifests
```

The application fails closed unless:

- `VENDOR=Ericsson`;
- `CORPUS_ID` starts with `ericsson`;
- all managed names begin with `ericsson-ran-kb-`;
- child, parent, and manifest aliases are distinct;
- their backing prefixes are distinct.

Use a cluster service account whose index privileges are limited to `ericsson-ran-kb-*`.

## Mapping separation

### Child index

- `content`: BM25 text;
- `embedding_text`: stored, not indexed;
- `embedding`: `knn_vector`;
- `chunk_id`, `parent_id`, `parent_storage_id`;
- heading, page, identity, role, association, and source metadata;
- no `parent_content` field.

### Parent index

- full section `content` stored once;
- `parent_id` and `parent_storage_id`;
- heading, page, identity, role, association, and source metadata;
- no vector and no `embedding_text`.

### Manifest index

Document, section, fact, and relationship records, without vectors.

## Rebuild lifecycle

For version `20260902`:

```text
ericsson-ran-kb-children-v20260902
ericsson-ran-kb-parents-v20260902
ericsson-ran-kb-manifests-v20260902
```

The ingestion job creates and fills all three before one atomic alias operation installs the new generation. Old backings are retained by default for rollback.

## Incremental lifecycle

Incremental mode resolves each alias's write index and verifies that the child vector dimension matches the selected embedding model. Replacement parent, child, and manifest records use run-scoped physical IDs. Children reference their same-run parent. After all writes succeed, stale records for affected filenames are removed under mandatory vendor/corpus filters.

A failure before stale cleanup removes records from only the failed `ingestion_run_id`. A failure after stale deletion begins can leave a mixed generation and should be repaired with a rebuild.

## Retrieval

Every BM25 and KNN child request applies the v1.2 storage contract and Ericsson corpus boundary:

```json
[
  {"term": {"storage_role": "child"}},
  {"term": {"retrieval_contract": "rank-children-then-mget-parents"}},
  {"term": {"vendor": "Ericsson"}},
  {"term": {"corpus_id": "ericsson-ran"}}
]
```

After child ranking, the KB service performs one parent-alias `mget` for unique `parent_storage_id` values. Full parents are returned with contributing child snippets under `matched_children`.

### Storage integrity

Parent records contain `storage_role=parent` and `content_sha256`. Child records contain `storage_role=child`, `parent_storage_id`, and `parent_content_sha256`. The query path verifies that the fetched parent content matches the hash expected by each selected child. Missing or mismatched parents fail with HTTP 503 by default.

The child vector is generated from exactly `child.content` when `EMBEDDING_INPUT_MODE=content` (the default and Nokia-aligned mode). Changing to `content_plus_metadata` changes the vector input and requires a new versioned rebuild.

## Readiness

```bash
python scripts/check_opensearch.py
python scripts/verify_parent_child_storage.py --live --sample-size 100
curl http://localhost:8102/kb/debug/index-info
curl 'http://localhost:8102/kb/debug/parent-child-status?sample_size=100'
curl http://localhost:8102/ready
```

KB readiness requires child, parent, and manifest aliases. A process can be healthy but not ready before the first v1.2 ingestion.

## Migration from v1.0

The old combined alias `ericsson-ran-kb-chunks` cannot serve as the v1.2 parent index because child records do not contain one authoritative full-section document. Run a new versioned rebuild to create the `children`, `parents`, and `manifests` generation. Rebuild v1.1 indexes as well so the v1.2 storage-role and parent-content hash fields are populated consistently.
