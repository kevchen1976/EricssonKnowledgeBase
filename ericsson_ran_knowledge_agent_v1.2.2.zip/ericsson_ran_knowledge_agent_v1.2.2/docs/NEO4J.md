# Ericsson Neo4j plan

## Initial state

Neo4j is not part of the first Ericsson answering path:

```text
GRAPH_ENABLED=false
NEO4J_DATABASE=ericsson
```

The Graph API can still be started for deployment checks; entity endpoints return 503 while disabled.

## Proposed logical isolation

Use a separate Ericsson database in the existing Neo4j DBMS when the installed edition supports multiple databases. The client and importer use `NEO4J_DATABASE` when opening sessions. Where that is not available, retain a mandatory composite namespace on every node:

```text
vendor=Ericsson
corpus_id=ericsson-ran
```

The supplied constraints use `(vendor, corpus_id, id)` or `(vendor, corpus_id, filename)` uniqueness.

## Initial graph model

```text
(:Feature {id: "FAJ 121 xxxx"})
(:Package {id: "FAJ 801 xxxx"})
(:Document {filename: "...md"})
(:AccessType {name: "LTE|NR|WCDMA|GSM"})
(:NodeType {name: "..."})

(Feature)-[:IN_PACKAGE]->(Package)
(Document)-[:DOCUMENTS_FEATURE]->(Feature)
(Document)-[:DOCUMENTS_PACKAGE]->(Package)
(Feature)-[:APPLIES_TO_ACCESS]->(AccessType)
(Package)-[:APPLIES_TO_ACCESS]->(AccessType)
(Feature)-[:APPLIES_TO_NODE_TYPE]->(NodeType)
(Package)-[:APPLIES_TO_NODE_TYPE]->(NodeType)
```

Later curated relationships can add parameters, counters, KPIs, dependencies, limitations and network entities. They should not be inferred solely from vector similarity.

## Staging and import

The ingestion preview writes `graph_staging_relationships.jsonl`. Review it and then generate a normalized preview:

```bash
python neo4j/import_staging.py \
  data/prepared/ingestion-preview/graph_staging_relationships.jsonl
```

Apply the schema to the Ericsson database:

```bash
cypher-shell -d ericsson -f neo4j/schema.cypher
```

Execute only after review:

```bash
GRAPH_ENABLED=true python neo4j/import_staging.py \
  data/prepared/ingestion-preview/graph_staging_relationships.jsonl \
  --execute
```
