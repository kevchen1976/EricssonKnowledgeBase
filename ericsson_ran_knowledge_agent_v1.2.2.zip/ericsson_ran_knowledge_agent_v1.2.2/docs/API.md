# API contract

## Agent API `:8100`

### `POST /query`

Request:

```json
{
  "query": "What does FAJ 121 0488 do?",
  "session_id": "optional",
  "limit": 5,
  "include_evidence": false
}
```

The `session_id` activates Redis-backed conversation history. When omitted, an
authenticated caller uses `session_<email>`; an anonymous API caller is stateless
unless it supplies a session ID. The effective rewritten query is exposed in
`metadata.effective_query`, with `metadata.query_rewritten` indicating whether
the query changed.

Response fields are stable for later supervisor integration:

```text
answer
source
vendor
workflow
feature_ids
package_ids
citations
warnings
evidence
metadata
```

### `GET /capabilities`

Advertises identity formats, workflows, index aliases, graph status, Redis session settings, query-rewrite status, and `retrieval_schema=ericsson-kb-1.2-parent-child`.

## Knowledge Base API `:8102`

- `POST|GET /kb/search`
- `POST|GET /kb/feature/{feature_id}/retrieve`
- `POST|GET /kb/package/{package_id}/retrieve`
- `GET /kb/manifest/feature/{feature_id}`
- `GET /kb/manifest/package/{package_id}`
- `GET /kb/debug/index-info`
- `GET /kb/debug/parent-child-status?sample_size=100`
- `GET /health`
- `GET /ready`

The retrieval response includes both native hit fields (`_id`, `_score`, `_source`) and the Nokia-compatible `content`/`metadata` representation.

## Graph API `:8101`

- `GET /feature/{feature_id}/context`
- `GET /package/{package_id}/context`
- `GET /relations/search?query=...`
- `GET /relations/{entity_id}`
- `GET /health`
- `GET /ready`

The capability response reports the configured logical database (`NEO4J_DATABASE`, default `ericsson`). Entity and relation endpoints return 503 until `GRAPH_ENABLED=true` and Neo4j credentials are configured.

## Parent-context integrity failure

With the default `REQUIRE_PARENT_CONTEXT=true`, a selected child whose stored parent is missing or fails the content-hash check is not returned as a fabricated parent. The KB API responds with HTTP `503`:

```json
{
  "detail": "Stored parent ... was unavailable ...",
  "error_code": "PARENT_CONTEXT_UNAVAILABLE"
}
```

Setting `REQUIRE_PARENT_CONTEXT=false` enables a controlled migration/diagnostic fallback to child content and emits a warning. It is not the recommended production setting.
