# Deployment checklist

## Shared OpenSearch

- Keep all existing Nokia aliases unchanged.
- Configure `ericsson-ran-kb-children`, `ericsson-ran-kb-parents`, and `ericsson-ran-kb-manifests`.
- Keep `OPENSEARCH_INDEX_SAFETY_PREFIX=ericsson-ran-kb-`.
- Use the same embedding model and tokenizer at ingestion and query time.
- Grant the Ericsson service account rights only to `ericsson-ran-kb-*`.

## Prepare and validate

```bash
python -m ericsson_preparation /data/ericsson-pdfs \
  --output-dir data/prepared \
  --overwrite

python scripts/validate_prepared_data.py data/prepared \
  --output logs/prepared_validation.json

python ingest_ericsson.py \
  --prepared-root data/prepared \
  --mode dry-run \
  --test-embedder

python scripts/verify_parent_child_storage.py \
  --preview-dir data/prepared/ingestion-preview \
  --require-embeddings
```

Run the real model tokenizer guard before creating a new index generation:

```bash
python scripts/check_embedding_lengths.py \
  --prepared-root data/prepared \
  --output logs/embedding_length_preflight.json
```

Require `status=passed`, zero over-limit inputs, and a largest input not exceeding the detected model maximum.

Inspect `parents.jsonl` and `children.jsonl`. Confirm deep headings have full paths, parent records contain no vectors, children contain no `parent_content`, every child parent reference resolves, and `embedding_text` equals child `content` in the default mode.

## Rebuild indexes

```bash
python scripts/check_opensearch.py

python ingest_ericsson.py \
  --prepared-root data/prepared \
  --mode rebuild \
  --version 20260902
```

Retain old Ericsson backings for rollback until retrieval is verified. A v1.0 combined chunks index must not be reused as the v1.2 parent index. Rebuild older Ericsson parent/child indexes so v1.2 hashes and roles are present.

## Start and test

```bash
./startup_all_service.sh start
curl http://localhost:8102/ready
curl http://localhost:8100/ready
curl http://localhost:8100/capabilities
```

Confirm readiness reports all three Ericsson aliases, run `scripts/verify_parent_child_storage.py --live`, then test feature, package, general-topic, deep-section, and procedure queries.

## Neo4j later

Leave `GRAPH_ENABLED=false`. Review `graph_staging_relationships.jsonl`, curate the relation model, create/select the Ericsson logical database, apply `neo4j/schema.cypher`, and enable graph integration in a later release.
