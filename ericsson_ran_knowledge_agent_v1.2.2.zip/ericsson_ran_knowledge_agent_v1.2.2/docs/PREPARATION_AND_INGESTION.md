# Preparation and ingestion

## End-to-end command

```bash
python -m ericsson_preparation /data/ericsson-pdfs \
  --output-dir data/prepared \
  --overwrite

python scripts/validate_prepared_data.py data/prepared \
  --output logs/prepared_validation.json

python ingest_ericsson.py \
  --prepared-root data/prepared \
  --mode dry-run \
  --skip-embeddings
```

## Prepared-data contract

```text
prepared-root/
├── markdown/
│   ├── document.md
│   ├── document.md.metadata.json
│   └── document_images/
├── manifests/
├── combined_manifest.jsonl
├── ericsson_feature_catalog.json
├── ericsson_feature_catalog.csv
└── routing-manifest/
```

The extraction layer emits `<!-- page: N -->` markers. Page ranges flow into section records, parents, children, evidence, and citations. Relative image paths remain adjacent to the Markdown document.

## Shared section parser

`ericsson_preparation.sections` and `ingestion.markdown_parser` use the same parser. It:

- reads Ericsson `Contents`/TOC entries as an outline allow-list;
- supports headings from level 1 through level 6;
- accepts deep body headings omitted from a shallow TOC when they remain inside the current chapter;
- builds the full heading path;
- rejects TOC rows as body content;
- rejects `1. Do something` procedure steps as document headings;
- rejects numeric table cells as headings;
- preserves Markdown tables, lists, code blocks, images, and page ranges.

A four-level body heading becomes metadata such as:

```json
{
  "heading": "2.2.3.1 Radio Node",
  "heading_number": "2.2.3.1",
  "heading_level": 4,
  "heading_path": "2 Principles and Guidelines > 2.2 Solution Overview > 2.2.3 Network Elements > 2.2.3.1 Radio Node"
}
```

## Nokia-aligned chunking

Defaults:

```text
parent soft limit           3000 tokens
child maximum                300 tokens
child overlap                 60 tokens
procedure preservation       480 tokens
minimum-child diagnostic      20 tokens
```

The parent soft limit is informational only. One source section always remains one parent, even when it exceeds 3000 tokens. Only children are windowed and embedded.

Procedure-like sections no longer than 480 tokens remain one child, even when they exceed the normal 300-token child size. This preserves complete operational sequences. Other sections use 300-token windows with 60-token overlap. Later windows are prefixed with their heading path.

Production chunk boundaries use the configured embedding-model tokenizer. The offline regex codec exists only so validation can run without downloading model files.

## Embedding input preflight

Long parent sections are valid because parents are never sent to the vector model. Before creating or modifying any OpenSearch index, v1.2.1 tokenizes every final child `embedding_text` with special tokens and compares it with the loaded `SentenceTransformer.max_seq_length`. The run fails before OpenSearch access if any child would be truncated.

```bash
python scripts/check_embedding_lengths.py \
  --prepared-root data/prepared \
  --output logs/embedding_length_preflight.json
```

`EMBEDDING_MAX_INPUT_TOKENS=0` means auto-detect from the model. A positive override may lower the limit but cannot raise it above the detected model ceiling. The normal BGE large model limit is 512.

By default, the text sent to the embedding model is byte-for-byte the stored child `content` after normal string trimming (`EMBEDDING_INPUT_MODE=content`). This mirrors the supplied Nokia implementation. `content_plus_metadata` is available only as an explicit experiment and must not be mixed into an existing child index.

## Separate preview streams

```bash
python ingest_ericsson.py \
  --prepared-root data/prepared \
  --mode dry-run \
  --skip-embeddings
```

Produces:

```text
ingestion-preview/
├── parents.jsonl
├── children.jsonl
├── manifests.jsonl
└── graph_staging_relationships.jsonl
```

The validator checks:

- every child `parent_storage_id` resolves to a preview parent;
- parents have no `embedding` or `embedding_text`;
- children have no `parent_content`;
- all Markdown image links resolve;
- page ranges and Ericsson identities are valid.

The v1.2 storage validator additionally verifies roles, parent and child hashes, exact default embedding input, and optional child-vector presence:

```bash
python scripts/verify_parent_child_storage.py \
  --preview-dir data/prepared/ingestion-preview \
  --require-embeddings \
  --output logs/parent_child_validation.json
```

## Manifest facts

Manifest records are always written to the manifest index. The default `INCLUDE_MANIFEST_FACTS=false` matches the Nokia section-parent strategy and avoids manufacturing one extra parent for every extracted fact. Enabling the flag creates optional fact parents and fact children for deployments that specifically need fact-vector retrieval.

## Rebuild

```bash
python ingest_ericsson.py \
  --prepared-root data/prepared \
  --mode rebuild \
  --version 20260902
```

Rebuild mode:

1. creates parent, child, and manifest backing indexes;
2. indexes parents first;
3. generates embeddings and indexes children;
4. indexes manifests;
5. aborts and removes the new backing indexes if a bulk operation fails;
6. refreshes all three indexes;
7. switches all three aliases in one request;
8. optionally removes old Ericsson backings with `--delete-old`.

## Incremental replacement

```bash
python ingest_ericsson.py \
  --prepared-root data/prepared \
  --mode incremental
```

All three aliases must point to write indexes. Logical `parent_id` values remain stable, while physical parent IDs are run-scoped. Children written in the same run receive the matching physical `parent_storage_id`. New records are written before stale records for the same filenames are removed.

Use rebuild mode when changing embedding models, vector dimensions, `EMBEDDING_INPUT_MODE`, index mappings, or the parent/child storage contract.
