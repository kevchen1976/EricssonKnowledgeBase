# Nokia-to-Ericsson adaptation notes

## Preserved behavior

- Separate Agent, KB and Graph APIs.
- Deterministic feature-ID routing before semantic search.
- Manifest title enrichment and direct-document filename filtering.
- BM25 plus KNN retrieval, Reciprocal Rank Fusion and optional reranking.
- Parent-content de-duplication.
- Separate non-vector parent storage and vectorized child storage.
- Final child ranking before parent `mget` expansion.
- Stored child text is the default embedding input.
- Local image serving and image links in retrieved Markdown.
- Standalone vendor API suitable for a supervisor.
- Local Ollama synthesis with extractive fallback.

## Ericsson-specific changes

- Feature Identity is canonical `FAJ 121 xxxx`; Value Package Identity is `FAJ 801 xxxx`.
- Leading zeroes are preserved.
- Feature and package IDs use separate fields and routing trees.
- Dedicated Feature Descriptions, package documents and general documents have different ownership semantics.
- A package/general record cannot become the direct feature source merely because it contains the ID.
- Feature association is represented as `primary`, `included`, `related`, `mentioned` or `none`.
- OpenSearch index safety rejects any non-`ericsson-ran-kb-` name.
- Neo4j is lazy and disabled instead of being a startup dependency.
- The Agent API ports default to 8100/8101/8102 to coexist with Nokia's 8000/8001/8002.

## Supervisor boundary

The supervisor should consume `/query` from each vendor agent and combine the structured answer/citations. It should not query the vendor indexes directly. This keeps the Nokia and Ericsson retrieval contracts independently testable and preserves each vendor's document semantics.

## Ericsson v1.2 parent storage

Ericsson uses its own three aliases on the shared cluster. Parent sections are stored in `ericsson-ran-kb-parents` without vectors, children are stored and searched in `ericsson-ran-kb-children`, and manifests are stored in `ericsson-ran-kb-manifests`. Parent/child hashes are Ericsson-side integrity metadata and do not require a Nokia index change.
