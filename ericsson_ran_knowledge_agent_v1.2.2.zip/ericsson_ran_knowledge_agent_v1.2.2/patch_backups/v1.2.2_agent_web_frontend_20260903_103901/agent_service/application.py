"""FastAPI assembly for the standalone Ericsson RAN knowledge agent."""
from __future__ import annotations

from fastapi import FastAPI

from agent_core.constants import PACKAGE_VERSION
from fastapi.middleware.cors import CORSMiddleware

from .routes import query, system

app = FastAPI(
    title="Ericsson RAN Knowledge Agent",
    version=PACKAGE_VERSION,
    description="Standalone Ericsson vendor agent with a stable API for a later supervisor.",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)
app.include_router(query.router)
app.include_router(system.router)
