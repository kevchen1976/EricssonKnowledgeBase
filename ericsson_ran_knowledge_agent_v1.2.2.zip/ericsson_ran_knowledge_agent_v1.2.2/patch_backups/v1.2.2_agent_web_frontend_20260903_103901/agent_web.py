#!/usr/bin/env python3
"""Executable and import facade for the Ericsson Agent API."""
from agent_service import app
from agent_core.config import AGENT_WEB_PORT, SERVICE_BIND_HOST

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host=SERVICE_BIND_HOST, port=AGENT_WEB_PORT)
