#!/usr/bin/env python3
"""Create and verify the dedicated Ericsson Ollama client log.

This script does not call Ollama. It resolves the live settings, configures the
same rotating logger used by the Agent API, writes one check record, and prints
a machine-readable summary.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agent_core.logging_utils import configure_rotating_file_logger
from agent_core.settings import get_settings


def main() -> int:
    settings = get_settings(reload=True)
    logger = configure_rotating_file_logger(
        "ericsson_ollama",
        settings.ollama_log_file,
        max_bytes=settings.ollama_log_max_bytes,
        backup_count=settings.ollama_log_backup_count,
    )
    logger.info(
        "[OLLAMA LOG CHECK] file=%s verbose=%s model=%s url=%s",
        settings.ollama_log_file,
        settings.ollama_verbose,
        settings.ollama_model,
        settings.ollama_url,
    )
    path = Path(settings.ollama_log_file)
    result = {
        "ok": path.is_file(),
        "ollama_log_file": str(path),
        "exists": path.is_file(),
        "size_bytes": path.stat().st_size if path.is_file() else 0,
        "ollama_verbose": settings.ollama_verbose,
        "ollama_log_max_bytes": settings.ollama_log_max_bytes,
        "ollama_log_backup_count": settings.ollama_log_backup_count,
        "ollama_model": settings.ollama_model,
        "ollama_url": settings.ollama_url,
        "note": (
            "Request/response summaries are always written. Full bounded payloads "
            "are written only when OLLAMA_VERBOSE=1."
        ),
    }
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
