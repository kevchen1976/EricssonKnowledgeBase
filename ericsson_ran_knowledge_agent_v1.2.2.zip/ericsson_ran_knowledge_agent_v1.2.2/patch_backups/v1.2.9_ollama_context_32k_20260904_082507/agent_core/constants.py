"""Shared Ericsson service/package constants.

Keeping these values in one module prevents the Agent API, KB API, ingestion
reports, capability payloads, and tests from drifting onto different schema
versions during deployment.
"""

PACKAGE_VERSION = "1.2.8"
RETRIEVAL_SCHEMA = "ericsson-kb-1.2-parent-child"
PARENT_CHILD_CONTRACT = "rank-children-then-mget-parents"
PARENT_STORAGE_ROLE = "parent"
CHILD_STORAGE_ROLE = "child"
MANIFEST_STORAGE_ROLE = "manifest"
