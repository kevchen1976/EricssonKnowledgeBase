"""Compatibility configuration facade.

The Nokia service exposes constants from ``agent_core.config``.  The Ericsson
service keeps the same import boundary while sourcing every value from the
shared settings loader.
"""
from __future__ import annotations

from .settings import DEFAULT_SYSTEM_PROMPT, PROJECT_ROOT, SYSTEM_PROMPT_PATH, get_settings

_SETTINGS = get_settings()

VENDOR = _SETTINGS.vendor
CORPUS_ID = _SETTINGS.corpus_id
SERVICE_BIND_HOST = _SETTINGS.bind_host
AGENT_WEB_PORT = _SETTINGS.agent_api_port
AGENT_API_PORT = _SETTINGS.agent_api_port
GRAPH_API_PORT = _SETTINGS.graph_api_port
KB_API_PORT = _SETTINGS.kb_api_port
AGENT_API_URL = _SETTINGS.agent_api_url
GRAPH_API_URL = _SETTINGS.graph_api_url
KB_API_URL = _SETTINGS.kb_api_url
OLLAMA_URL = _SETTINGS.ollama_url
OLLAMA_MODEL = _SETTINGS.ollama_model
OLLAMA_VERBOSE = _SETTINGS.ollama_verbose
OLLAMA_LOG_PROMPT_MAX_CHARS = _SETTINGS.ollama_log_prompt_max_chars
OLLAMA_LOG_RESPONSE_MAX_CHARS = _SETTINGS.ollama_log_response_max_chars
OLLAMA_LOG_FILE = _SETTINGS.ollama_log_file
OLLAMA_LOG_MAX_BYTES = _SETTINGS.ollama_log_max_bytes
OLLAMA_LOG_BACKUP_COUNT = _SETTINGS.ollama_log_backup_count
OPENSEARCH_HOST = _SETTINGS.opensearch_host
OPENSEARCH_PORT = _SETTINGS.opensearch_port
OPENSEARCH_INDEX = _SETTINGS.child_alias
OPENSEARCH_CHILD_INDEX = _SETTINGS.child_alias
OPENSEARCH_PARENT_INDEX = _SETTINGS.parent_alias
OPENSEARCH_MANIFEST_INDEX = _SETTINGS.manifest_alias
PREPARED_ROOT = _SETTINGS.prepared_root
MARKDOWN_ROOT = _SETTINGS.markdown_root
MANIFEST_ROOT = _SETTINGS.feature_manifest_root
PACKAGE_MANIFEST_ROOT = _SETTINGS.package_manifest_root
TOPIC_MANIFEST_ROOT = _SETTINGS.topic_manifest_root
MENTIONED_FEATURE_MANIFEST_ROOT = _SETTINGS.mentioned_feature_manifest_root
KB_ASSET_URL_PREFIX = _SETTINGS.kb_asset_url_prefix
LOG_DIR = _SETTINGS.logs_dir
GRAPH_ENABLED = _SETTINGS.graph_enabled
ENABLE_LLM_QUERY_REWRITE = _SETTINGS.enable_llm_query_rewrite
SESSION_MEMORY_ENABLED = _SETTINGS.session_memory_enabled
SESSION_TTL = _SETTINGS.session_ttl_seconds
MAX_HISTORY = _SETTINGS.max_session_history
REDIS_URL = _SETTINGS.redis_url
REDIS_HOST = _SETTINGS.redis_host
REDIS_PORT = _SETTINGS.redis_port
REDIS_DB = _SETTINGS.redis_db
REDIS_PASSWORD = _SETTINGS.redis_password
REDIS_KEY_PREFIX = _SETTINGS.redis_key_prefix
REDIS_SSL = _SETTINGS.redis_ssl
REDIS_SOCKET_TIMEOUT = _SETTINGS.redis_socket_timeout
REDIS_CONNECT_TIMEOUT = _SETTINGS.redis_connect_timeout
SESSION_HISTORY_ANSWER_CHARS = _SETTINGS.session_history_answer_chars
SESSION_STORED_ANSWER_CHARS = _SETTINGS.session_stored_answer_chars

__all__ = [name for name in globals() if name.isupper()]
