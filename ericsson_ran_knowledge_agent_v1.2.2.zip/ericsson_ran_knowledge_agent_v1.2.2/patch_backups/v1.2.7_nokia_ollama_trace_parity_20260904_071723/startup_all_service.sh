#!/usr/bin/env bash
# Ericsson RAN Knowledge Agent service launcher.
#
# This launcher controls only the Ericsson Python APIs in this repository. It
# deliberately never starts, stops, restarts, or kills the shared OpenSearch
# cluster, Nokia services, Ollama daemon, Redis, or Neo4j. Like the Nokia
# launcher, it may run a local journalctl forwarder that copies the shared
# Ollama systemd journal into this project's logs/ollama.log.

set -euo pipefail

PROJECT_ROOT=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
ENV_FILE=${ERICSSON_SERVICE_ENV_FILE:-"$PROJECT_ROOT/config/services.env"}
# Match the Nokia launcher: source only a real deployment file when present.
# services.env.example is documentation and must never silently override
# settings.json.
if [ -f "$ENV_FILE" ]; then
    # shellcheck disable=SC1090
    set -a
    source "$ENV_FILE"
    set +a
    ERICSSON_ENV_LOADED="$ENV_FILE"
else
    ERICSSON_ENV_LOADED=""
fi

resolve_project_path() {
    local value=$1
    case "$value" in
        /*) printf '%s\n' "$value" ;;
        ~/*) printf '%s/%s\n' "$HOME" "${value#~/}" ;;
        *) printf '%s/%s\n' "$PROJECT_ROOT" "$value" ;;
    esac
}

AGENT_SETTINGS_FILE=$(resolve_project_path "${AGENT_SETTINGS_FILE:-config/settings.json}")
export AGENT_SETTINGS_FILE

if [ -n "${VENV_PATH:-}" ]; then
    VENV_PATH=$(resolve_project_path "$VENV_PATH")
elif [ -x "$PROJECT_ROOT/.venv/bin/python" ]; then
    VENV_PATH="$PROJECT_ROOT/.venv"
fi

choose_python() {
    if [ -n "${VENV_PATH:-}" ] && [ -x "$VENV_PATH/bin/python" ]; then
        printf '%s\n' "$VENV_PATH/bin/python"
        return 0
    fi
    if [ -n "${PYTHON_BIN:-}" ]; then
        if [ -x "$PYTHON_BIN" ]; then
            printf '%s\n' "$PYTHON_BIN"
            return 0
        fi
        if command -v "$PYTHON_BIN" >/dev/null 2>&1; then
            command -v "$PYTHON_BIN"
            return 0
        fi
    fi
    if command -v python3 >/dev/null 2>&1; then
        command -v python3
        return 0
    fi
    if command -v python >/dev/null 2>&1; then
        command -v python
        return 0
    fi
    echo "ERROR: no Python interpreter found; set VENV_PATH or PYTHON_BIN" >&2
    return 1
}

PYTHON_EXEC=$(choose_python)
export PYTHONPATH="$PROJECT_ROOT${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONUNBUFFERED=1

# Resolve service ports and flags through the same settings loader used by the
# applications. Environment values sourced above retain highest precedence.
# shellcheck disable=SC2046
# shellcheck disable=SC2091
eval "$("$PYTHON_EXEC" "$PROJECT_ROOT/scripts/export_service_settings.py")"

LOGS_DIR=${LOGS_DIR:-${RESOLVED_LOGS_DIR:-logs}}
PIDS_DIR=${PIDS_DIR:-run}
LOGS_DIR=$(resolve_project_path "$LOGS_DIR")
PIDS_DIR=$(resolve_project_path "$PIDS_DIR")
SERVICE_START_TIMEOUT=${SERVICE_START_TIMEOUT:-45}
SERVICE_STOP_TIMEOUT=${SERVICE_STOP_TIMEOUT:-30}
mkdir -p "$LOGS_DIR" "$PIDS_DIR"

# Nokia-parity Ollama daemon trace. The Ericsson launcher does NOT own the
# shared Ollama daemon; it only forwards its systemd journal into the local
# ollama.log, matching Nokia scripts/lib/service_components.sh.
OLLAMA_LOG_FORWARDER_ENABLED=${OLLAMA_LOG_FORWARDER_ENABLED:-true}
OLLAMA_SYSTEMD_UNIT=${OLLAMA_SYSTEMD_UNIT:-ollama}
OLLAMA_NATIVE_LOG_FILE=${OLLAMA_NATIVE_LOG_FILE:-"$LOGS_DIR/ollama.log"}
OLLAMA_LOG_FORWARDER_PID_FILE=${OLLAMA_LOG_FORWARDER_PID_FILE:-"$PIDS_DIR/ericsson-ollama-log-forwarder.pid"}

VERBOSE_MODE=false
if [ "${2:-}" = "--verbose" ]; then
    VERBOSE_MODE=true
    export OLLAMA_VERBOSE=1
fi

log() {
    printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*"
}

is_true() {
    case "$(printf '%s' "${1:-}" | tr '[:upper:]' '[:lower:]')" in
        1|true|yes|on) return 0 ;;
        *) return 1 ;;
    esac
}

port_is_open() {
    local port=$1
    "$PYTHON_EXEC" - "$port" <<'PY' >/dev/null 2>&1
import socket
import sys

port = int(sys.argv[1])
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
    sock.settimeout(0.4)
    raise SystemExit(0 if sock.connect_ex(("127.0.0.1", port)) == 0 else 1)
PY
}

http_code() {
    local url=$1
    "$PYTHON_EXEC" - "$url" <<'PY' 2>/dev/null
import sys
import urllib.error
import urllib.request

url = sys.argv[1]
try:
    with urllib.request.urlopen(url, timeout=1.5) as response:
        print(response.status)
except urllib.error.HTTPError as exc:
    print(exc.code)
except Exception:
    raise SystemExit(1)
PY
}

pid_is_running() {
    local pid=$1
    kill -0 "$pid" 2>/dev/null
}

ollama_log_forwarder_is_running() {
    local pid=""
    [ -f "$OLLAMA_LOG_FORWARDER_PID_FILE" ] || return 1
    pid=$(cat "$OLLAMA_LOG_FORWARDER_PID_FILE" 2>/dev/null || true)
    [ -n "$pid" ] && pid_is_running "$pid"
}

start_ollama_log_forwarder() {
    if ! is_true "$OLLAMA_LOG_FORWARDER_ENABLED"; then
        log "Ollama log forwarder disabled (OLLAMA_LOG_FORWARDER_ENABLED=$OLLAMA_LOG_FORWARDER_ENABLED)"
        return 0
    fi

    if ollama_log_forwarder_is_running; then
        log "Ollama log forwarder already running (pid $(cat "$OLLAMA_LOG_FORWARDER_PID_FILE"))"
        return 0
    fi
    rm -f "$OLLAMA_LOG_FORWARDER_PID_FILE"

    if ! command -v journalctl >/dev/null 2>&1; then
        printf '=== Ollama log forwarder unavailable at %s: journalctl not found ===\n' "$(date -Iseconds)" >>"$OLLAMA_NATIVE_LOG_FILE"
        log "WARNING: journalctl not found; cannot mirror Nokia Ollama daemon tracing"
        return 0
    fi

    log "Starting Ollama log forwarder (journal -> $OLLAMA_NATIVE_LOG_FILE)..."
    # This intentionally mirrors Nokia's journal source and output format:
    #   journalctl -u ollama -f --output=short-iso
    # Unlike Nokia's older cleanup code, we never use a global pkill because a
    # shared host may also have Nokia's forwarder running.
    nohup bash -c '
        unit=$1
        logfile=$2
        echo "=== Ollama log forwarder started at $(date -Iseconds) ===" >> "$logfile"
        if journalctl -u "$unit" -n 1 >/dev/null 2>&1; then
            echo "Journal access OK: unit=$unit" >> "$logfile"
            exec journalctl -u "$unit" -f --output=short-iso >> "$logfile" 2>&1
        else
            echo "Cannot access systemd journal for unit=$unit" >> "$logfile"
            exit 0
        fi
    ' _ "$OLLAMA_SYSTEMD_UNIT" "$OLLAMA_NATIVE_LOG_FILE" >/dev/null 2>&1 &

    local pid=$!
    printf '%s\n' "$pid" >"$OLLAMA_LOG_FORWARDER_PID_FILE"
    sleep 1
    if pid_is_running "$pid"; then
        log "Ollama log forwarder started (pid $pid)"
    else
        rm -f "$OLLAMA_LOG_FORWARDER_PID_FILE"
        log "WARNING: Ollama log forwarder exited; check $OLLAMA_NATIVE_LOG_FILE"
    fi
}

stop_ollama_log_forwarder() {
    local pid=""
    if [ -f "$OLLAMA_LOG_FORWARDER_PID_FILE" ]; then
        pid=$(cat "$OLLAMA_LOG_FORWARDER_PID_FILE" 2>/dev/null || true)
    fi
    if [ -n "$pid" ] && pid_is_running "$pid"; then
        log "Stopping Ollama log forwarder (pid $pid)..."
        kill "$pid" 2>/dev/null || true
        local elapsed=0
        while pid_is_running "$pid" && [ "$elapsed" -lt 5 ]; do
            sleep 1
            elapsed=$((elapsed + 1))
        done
        if pid_is_running "$pid"; then
            kill -9 "$pid" 2>/dev/null || true
        fi
    fi
    rm -f "$OLLAMA_LOG_FORWARDER_PID_FILE"
}

show_ollama_log_forwarder_status() {
    if ollama_log_forwarder_is_running; then
        printf 'Ollama Log Forwarder: running (pid %s, unit %s, log %s)\n' \
            "$(cat "$OLLAMA_LOG_FORWARDER_PID_FILE")" "$OLLAMA_SYSTEMD_UNIT" "$OLLAMA_NATIVE_LOG_FILE"
    else
        printf 'Ollama Log Forwarder: stopped (unit %s, log %s)\n' \
            "$OLLAMA_SYSTEMD_UNIT" "$OLLAMA_NATIVE_LOG_FILE"
    fi
}

check_shared_redis() {
    if ! is_true "${SESSION_MEMORY_ENABLED:-false}"; then
        log "Redis session memory is disabled"
        return 0
    fi
    if "$PYTHON_EXEC" "$PROJECT_ROOT/scripts/check_redis.py" >/dev/null 2>&1; then
        log "shared Redis is reachable (${REDIS_HOST:-localhost}:${REDIS_PORT:-6379}, db ${REDIS_DB:-0}, prefix ${REDIS_KEY_PREFIX:-ericsson:session:})"
        return 0
    fi
    log "WARNING: shared Redis is unavailable; session memory and follow-up rewriting will fail until it is reachable"
    return 1
}

pid_matches_script() {
    local pid=$1
    local script_path=$2
    local args
    args=$(ps -p "$pid" -o args= 2>/dev/null || true)
    [ -n "$args" ] && { [[ "$args" == *"$script_path"* ]] || [[ "$args" == *"$(basename "$script_path")"* ]]; }
}

wait_for_health() {
    local name=$1
    local pid=$2
    local port=$3
    local log_file=$4
    local elapsed=0
    local code
    while [ "$elapsed" -lt "$SERVICE_START_TIMEOUT" ]; do
        if ! pid_is_running "$pid"; then
            log "ERROR: $name exited during startup"
            tail -n 40 "$log_file" 2>/dev/null || true
            return 1
        fi
        code=$(http_code "http://127.0.0.1:$port/health" || true)
        if [ "$code" = "200" ]; then
            log "$name health endpoint is ready on port $port"
            return 0
        fi
        sleep 1
        elapsed=$((elapsed + 1))
    done
    log "ERROR: timeout waiting for $name health endpoint on port $port"
    tail -n 40 "$log_file" 2>/dev/null || true
    return 1
}

start_one() {
    local name=$1
    local script=$2
    local port=$3
    local script_path="$PROJECT_ROOT/$script"
    local pid_file="$PIDS_DIR/$name.pid"
    local log_file="$LOGS_DIR/$name.log"
    local pid

    if [ ! -f "$script_path" ]; then
        log "ERROR: missing service entry point: $script_path"
        return 1
    fi

    if [ -f "$pid_file" ]; then
        pid=$(cat "$pid_file" 2>/dev/null || true)
        if [ -n "$pid" ] && pid_is_running "$pid" && pid_matches_script "$pid" "$script_path"; then
            log "$name already running (pid $pid)"
            return 0
        fi
        log "Removing stale or mismatched PID file for $name"
        rm -f "$pid_file"
    fi

    if port_is_open "$port"; then
        log "ERROR: port $port is already in use; refusing to kill or replace an untracked process"
        return 1
    fi

    printf '\n=== %s start %s ===\n' "$name" "$(date -Iseconds)" >>"$log_file"
    (
        cd "$PROJECT_ROOT"
        nohup "$PYTHON_EXEC" -u "$script_path" >>"$log_file" 2>&1 &
        printf '%s\n' "$!"
    ) >"$pid_file"
    pid=$(cat "$pid_file")
    log "started $name (pid $pid, log $log_file)"

    if ! wait_for_health "$name" "$pid" "$port" "$log_file"; then
        if pid_is_running "$pid" && pid_matches_script "$pid" "$script_path"; then
            kill "$pid" 2>/dev/null || true
        fi
        rm -f "$pid_file"
        return 1
    fi
}

stop_one() {
    local name=$1
    local script=$2
    local script_path="$PROJECT_ROOT/$script"
    local pid_file="$PIDS_DIR/$name.pid"
    local pid
    local elapsed=0

    if [ ! -f "$pid_file" ]; then
        log "$name is not tracked as running"
        return 0
    fi
    pid=$(cat "$pid_file" 2>/dev/null || true)
    if [ -z "$pid" ] || ! pid_is_running "$pid"; then
        rm -f "$pid_file"
        log "$name was already stopped"
        return 0
    fi
    if ! pid_matches_script "$pid" "$script_path"; then
        log "WARNING: PID $pid no longer matches $script_path; refusing to signal it"
        rm -f "$pid_file"
        return 0
    fi

    kill "$pid" 2>/dev/null || true
    while pid_is_running "$pid" && [ "$elapsed" -lt "$SERVICE_STOP_TIMEOUT" ]; do
        sleep 1
        elapsed=$((elapsed + 1))
    done
    if pid_is_running "$pid" && pid_matches_script "$pid" "$script_path"; then
        log "forcing $name to stop after ${SERVICE_STOP_TIMEOUT}s"
        kill -9 "$pid" 2>/dev/null || true
    fi
    rm -f "$pid_file"
    log "stopped $name"
}

status_one() {
    local name=$1
    local script=$2
    local port=$3
    local script_path="$PROJECT_ROOT/$script"
    local pid_file="$PIDS_DIR/$name.pid"
    local pid=""
    local health="unavailable"
    local readiness="unavailable"
    local health_code=""
    local ready_code=""

    if [ -f "$pid_file" ]; then
        pid=$(cat "$pid_file" 2>/dev/null || true)
    fi
    if [ -n "$pid" ] && pid_is_running "$pid" && pid_matches_script "$pid" "$script_path"; then
        health_code=$(http_code "http://127.0.0.1:$port/health" || true)
        ready_code=$(http_code "http://127.0.0.1:$port/ready" || true)
        [ -n "$health_code" ] && health="HTTP $health_code"
        [ -n "$ready_code" ] && readiness="HTTP $ready_code"
        printf '%s: running (pid %s, port %s, health %s, ready %s)\n' "$name" "$pid" "$port" "$health" "$readiness"
    elif port_is_open "$port"; then
        printf '%s: not tracked; port %s is occupied by another process\n' "$name" "$port"
    else
        printf '%s: stopped (port %s free)\n' "$name" "$port"
    fi
}

start_all() {
    # Shared infrastructure remains externally managed. Check Redis for clear
    # diagnostics, but never start/stop the Nokia-owned/shared container.
    check_shared_redis || true
    start_ollama_log_forwarder
    start_one ericsson-kb local_kb_api.py "$KB_API_PORT"
    if is_true "$GRAPH_ENABLED"; then
        start_one ericsson-graph local_graph_api.py "$GRAPH_API_PORT"
    else
        log "ericsson-graph skipped (GRAPH_ENABLED=$GRAPH_ENABLED)"
    fi
    start_one ericsson-agent agent_web.py "$AGENT_API_PORT"
}

stop_all() {
    stop_one ericsson-agent agent_web.py
    stop_ollama_log_forwarder
    stop_one ericsson-graph local_graph_api.py
    stop_one ericsson-kb local_kb_api.py
}

show_status() {
    echo "=== Ericsson RAN Knowledge Agent status ==="
    if [ -n "$ERICSSON_ENV_LOADED" ]; then
        echo "deployment env: $ERICSSON_ENV_LOADED"
    else
        echo "deployment env: none (using config/settings.json and exported environment)"
    fi
    status_one ericsson-kb local_kb_api.py "$KB_API_PORT"
    status_one ericsson-graph local_graph_api.py "$GRAPH_API_PORT"
    status_one ericsson-agent agent_web.py "$AGENT_API_PORT"
    show_ollama_log_forwarder_status
    check_shared_redis || true
    echo "Shared OpenSearch, Nokia services, Ollama daemon, Redis, and Neo4j are not managed by this launcher."
}

case "${1:-status}" in
    start) start_all ;;
    stop) stop_all ;;
    restart)
        stop_all
        sleep 1
        start_all
        ;;
    status) show_status ;;
    agent)
        check_shared_redis || true
        start_ollama_log_forwarder
        start_one ericsson-agent agent_web.py "$AGENT_API_PORT"
        ;;
    kb) start_one ericsson-kb local_kb_api.py "$KB_API_PORT" ;;
    graph) start_one ericsson-graph local_graph_api.py "$GRAPH_API_PORT" ;;
    stop-agent)
        stop_one ericsson-agent agent_web.py
        stop_ollama_log_forwarder
        ;;
    stop-kb) stop_one ericsson-kb local_kb_api.py ;;
    stop-graph) stop_one ericsson-graph local_graph_api.py ;;
    redis-check) "$PYTHON_EXEC" "$PROJECT_ROOT/scripts/check_redis.py" ;;
    ollama-log-start) start_ollama_log_forwarder ;;
    ollama-log-stop) stop_ollama_log_forwarder ;;
    ollama-log-status) show_ollama_log_forwarder_status ;;
    cli)
        if ! port_is_open "$AGENT_API_PORT"; then
            log "ERROR: Ericsson Agent API is not listening on port $AGENT_API_PORT"
            exit 1
        fi
        exec "$PYTHON_EXEC" "$PROJECT_ROOT/cli_agent.py"
        ;;
    *)
        echo "usage: $0 {start|stop|restart|status|agent|kb|graph|stop-agent|stop-kb|stop-graph|redis-check|ollama-log-start|ollama-log-stop|ollama-log-status|cli} [--verbose]" >&2
        exit 2
        ;;
esac
