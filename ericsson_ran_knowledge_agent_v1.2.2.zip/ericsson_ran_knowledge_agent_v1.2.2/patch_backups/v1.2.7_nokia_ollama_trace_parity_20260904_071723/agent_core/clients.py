"""HTTP clients used by the Ericsson agent service."""
from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.parse import quote, urljoin

import httpx

from .logging_utils import (
    configure_rotating_file_logger,
    outbound_trace_headers,
)
from .settings import PROJECT_ROOT, Settings


# Keep concise workflow/error summaries in the normal Agent log. Detailed
# Ollama request/response traces are written to ollama-client.log. The native
# Ollama daemon journal is forwarded separately to logs/ollama.log, matching Nokia.
logger = logging.getLogger("ericsson_agent")
ollama_logger = logging.getLogger("ericsson_ollama")


class ServiceClientError(RuntimeError):
    pass


def _bounded_log_text(value: object, max_chars: int) -> tuple[str, int, bool]:
    """Return text bounded only for logs; the outbound Ollama payload is untouched."""
    text = str(value or "")
    original_chars = len(text)
    if max_chars > 0 and original_chars > max_chars:
        return text[:max_chars].rstrip() + "\n...[log truncated]", original_chars, True
    return text, original_chars, False


def _ollama_log_payload(body: Dict[str, Any], *, prompt_limit: int) -> tuple[Dict[str, Any], int, bool, int, bool]:
    logged = dict(body)
    prompt, prompt_chars, prompt_truncated = _bounded_log_text(logged.get("prompt", ""), prompt_limit)
    logged["prompt"] = prompt
    system, system_chars, system_truncated = _bounded_log_text(logged.get("system", ""), prompt_limit)
    if "system" in logged:
        logged["system"] = system
    return logged, prompt_chars, prompt_truncated, system_chars, system_truncated


def _ollama_log_destination(settings: object) -> Path:
    configured = getattr(settings, "ollama_log_file", None)
    if configured:
        return Path(configured).expanduser().resolve()
    logs_dir = getattr(settings, "logs_dir", PROJECT_ROOT / "logs")
    return (Path(logs_dir).expanduser().resolve() / "ollama-client.log").resolve()


def _ensure_ollama_logger(settings: object) -> logging.Logger:
    """Create/configure the dedicated Ollama trace before each call.

    The operation is idempotent. Calling it here, in addition to Agent service
    startup, ensures CLI and test entry points also produce ``ollama-client.log``.
    """
    return configure_rotating_file_logger(
        "ericsson_ollama",
        _ollama_log_destination(settings),
        max_bytes=int(getattr(settings, "ollama_log_max_bytes", 20 * 1024 * 1024)),
        backup_count=int(getattr(settings, "ollama_log_backup_count", 5)),
    )


def _endpoint(base: str, path: str) -> str:
    return urljoin(base.rstrip("/") + "/", path.lstrip("/"))


@dataclass
class KBClient:
    settings: Settings

    def _request(self, method: str, path: str, **kwargs: Any) -> Dict[str, Any]:
        headers = outbound_trace_headers(kwargs.pop("headers", None))
        try:
            with httpx.Client(timeout=self.settings.kb_timeout) as client:
                response = client.request(
                    method,
                    _endpoint(self.settings.kb_api_url, path),
                    headers=headers,
                    **kwargs,
                )
                response.raise_for_status()
                payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise ServiceClientError(f"Ericsson KB API request failed: {exc}") from exc
        if not isinstance(payload, dict):
            raise ServiceClientError("Ericsson KB API returned a non-object response")
        return payload

    def search(self, query: str, *, limit: int, filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self._request(
            "POST",
            "/kb/search",
            json={"query": query, "limit": limit, "filters": filters or {}},
        )

    def retrieve_feature(
        self,
        feature_id: str,
        query: str,
        *,
        limit: int,
        include_related: bool = True,
    ) -> Dict[str, Any]:
        path = f"/kb/feature/{quote(feature_id, safe='')}/retrieve"
        return self._request(
            "POST",
            path,
            json={"query": query, "limit": limit, "include_related": include_related},
        )

    def retrieve_package(self, package_id: str, query: str, *, limit: int) -> Dict[str, Any]:
        path = f"/kb/package/{quote(package_id, safe='')}/retrieve"
        return self._request("POST", path, json={"query": query, "limit": limit})

    def health(self) -> Dict[str, Any]:
        return self._request("GET", "/health")


@dataclass
class GraphClient:
    settings: Settings

    def _request(self, path: str, *, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        headers = outbound_trace_headers()
        try:
            with httpx.Client(timeout=self.settings.graph_timeout) as client:
                response = client.get(
                    _endpoint(self.settings.graph_api_url, path),
                    params=params,
                    headers=headers,
                )
                response.raise_for_status()
                payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise ServiceClientError(f"Ericsson graph API request failed: {exc}") from exc
        if not isinstance(payload, dict):
            raise ServiceClientError("Ericsson graph API returned a non-object response")
        return payload

    def feature_context(self, feature_id: str) -> Dict[str, Any]:
        return self._request(f"/feature/{quote(feature_id, safe='')}/context")

    def package_context(self, package_id: str) -> Dict[str, Any]:
        return self._request(f"/package/{quote(package_id, safe='')}/context")

    def search_context(self, query: str, *, limit: int = 20) -> Dict[str, Any]:
        return self._request("/relations/search", params={"query": query, "limit": limit})


@dataclass
class OllamaClient:
    settings: Settings

    def generate(
        self,
        prompt: str,
        *,
        system: str = "",
        temperature: float = 0.1,
        purpose: str = "general",
    ) -> str:
        trace_logger = _ensure_ollama_logger(self.settings)
        purpose_value = str(purpose or "general").strip() or "general"

        if not self.settings.llm_enabled:
            trace_logger.warning(
                "[OLLAMA SKIPPED] purpose=%s reason=llm-disabled model=%s",
                purpose_value,
                self.settings.ollama_model,
            )
            raise ServiceClientError("LLM generation is disabled")

        body: Dict[str, Any] = {
            "model": self.settings.ollama_model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": temperature},
        }
        if system:
            body["system"] = system

        logged_body, prompt_chars, prompt_truncated, system_chars, system_truncated = _ollama_log_payload(
            body,
            prompt_limit=self.settings.ollama_log_prompt_max_chars,
        )
        trace_logger.info(
            "[OLLAMA REQUEST] purpose=%s url=%s model=%s prompt_chars=%d "
            "system_chars=%d temperature=%s verbose=%s prompt_truncated=%s system_truncated=%s",
            purpose_value,
            self.settings.ollama_url,
            self.settings.ollama_model,
            prompt_chars,
            system_chars,
            temperature,
            self.settings.ollama_verbose,
            prompt_truncated,
            system_truncated,
        )
        if self.settings.ollama_verbose:
            trace_logger.info("=" * 80)
            trace_logger.info(
                "[OLLAMA REQUEST PAYLOAD]\n%s",
                json.dumps(logged_body, indent=2, ensure_ascii=False),
            )
            trace_logger.info("=" * 80)

        started = time.perf_counter()
        status_code: int | None = None
        try:
            with httpx.Client(timeout=self.settings.ollama_timeout) as client:
                response = client.post(self.settings.ollama_url, json=body)
                status_code = response.status_code
                response.raise_for_status()
                payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            latency_ms = (time.perf_counter() - started) * 1000.0
            trace_logger.exception(
                "[OLLAMA ERROR] purpose=%s status=%s latency_ms=%.1f error=%s",
                purpose_value,
                status_code if status_code is not None else "n/a",
                latency_ms,
                exc,
            )
            # Preserve the concise Agent log error used by existing operations.
            logger.error(
                "[OLLAMA ERROR] purpose=%s status=%s latency_ms=%.1f error=%s details_log=%s",
                purpose_value,
                status_code if status_code is not None else "n/a",
                latency_ms,
                exc,
                _ollama_log_destination(self.settings),
            )
            raise ServiceClientError(f"Ollama generation failed: {exc}") from exc

        latency_ms = (time.perf_counter() - started) * 1000.0
        if not isinstance(payload, dict):
            trace_logger.error(
                "[OLLAMA ERROR] purpose=%s status=%s latency_ms=%.1f error=non-object-response",
                purpose_value,
                status_code if status_code is not None else "n/a",
                latency_ms,
            )
            logger.error(
                "[OLLAMA ERROR] purpose=%s status=%s latency_ms=%.1f error=non-object-response details_log=%s",
                purpose_value,
                status_code if status_code is not None else "n/a",
                latency_ms,
                _ollama_log_destination(self.settings),
            )
            raise ServiceClientError("Ollama returned a non-object response")

        text = str(payload.get("response") or payload.get("message", {}).get("content") or "").strip()
        response_text, response_chars, response_truncated = _bounded_log_text(
            text,
            self.settings.ollama_log_response_max_chars,
        )
        trace_logger.info(
            "[OLLAMA RESPONSE] purpose=%s status=%s latency_ms=%.1f response_chars=%d "
            "verbose=%s response_truncated=%s eval_count=%s prompt_eval_count=%s total_duration=%s",
            purpose_value,
            status_code if status_code is not None else "n/a",
            latency_ms,
            response_chars,
            self.settings.ollama_verbose,
            response_truncated,
            payload.get("eval_count"),
            payload.get("prompt_eval_count"),
            payload.get("total_duration"),
        )

        if self.settings.ollama_verbose:
            logged_payload = dict(payload)
            if "response" in logged_payload:
                logged_payload["response"] = response_text
            elif isinstance(logged_payload.get("message"), dict):
                message = dict(logged_payload["message"])
                message["content"] = response_text
                logged_payload["message"] = message
            trace_logger.info("=" * 80)
            trace_logger.info(
                "[OLLAMA RESPONSE PAYLOAD]\n%s",
                json.dumps(logged_payload, indent=2, ensure_ascii=False),
            )
            trace_logger.info("=" * 80)

        # Leave a compact breadcrumb in the normal Agent log while keeping all
        # potentially large payloads in the dedicated file.
        logger.info(
            "[OLLAMA] purpose=%s status=%s latency_ms=%.1f prompt_eval_count=%s eval_count=%s details_log=%s",
            purpose_value,
            status_code if status_code is not None else "n/a",
            latency_ms,
            payload.get("prompt_eval_count"),
            payload.get("eval_count"),
            _ollama_log_destination(self.settings),
        )

        if not text:
            trace_logger.error(
                "[OLLAMA ERROR] purpose=%s status=%s latency_ms=%.1f error=empty-response-text payload_preview=%s",
                purpose_value,
                status_code if status_code is not None else "n/a",
                latency_ms,
                json.dumps(payload, ensure_ascii=False)[:500],
            )
            raise ServiceClientError(f"Ollama returned no response text: {json.dumps(payload)[:500]}")
        return text
