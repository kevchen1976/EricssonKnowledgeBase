from pathlib import Path


def test_launcher_mirrors_nokia_ollama_journal_forwarder():
    root = Path(__file__).resolve().parents[1]
    text = (root / "startup_all_service.sh").read_text(encoding="utf-8")
    assert "start_ollama_log_forwarder()" in text
    assert 'journalctl -u "$unit" -f --output=short-iso' in text
    assert 'OLLAMA_NATIVE_LOG_FILE=${OLLAMA_NATIVE_LOG_FILE:-"$LOGS_DIR/ollama.log"}' in text
    assert "stop_ollama_log_forwarder()" in text
    assert "ollama-log-status" in text


def test_client_log_is_separate_from_native_ollama_log():
    root = Path(__file__).resolve().parents[1]
    text = (root / "agent_core/settings/loader.py").read_text(encoding="utf-8")
    assert '"OLLAMA_CLIENT_LOG_FILE"' in text
    assert 'logs_dir / "ollama-client.log"' in text
