#!/usr/bin/env python3
"""Check Nokia-parity native Ollama trace files without calling Ollama."""
from __future__ import annotations
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
logs = Path(os.getenv("LOGS_DIR", ROOT / "logs"))
if not logs.is_absolute():
    logs = (ROOT / logs).resolve()
native = Path(os.getenv("OLLAMA_NATIVE_LOG_FILE", logs / "ollama.log"))
if not native.is_absolute():
    native = (ROOT / native).resolve()
pid_file = Path(os.getenv("OLLAMA_LOG_FORWARDER_PID_FILE", ROOT / "run" / "ericsson-ollama-log-forwarder.pid"))
if not pid_file.is_absolute():
    pid_file = (ROOT / pid_file).resolve()
pid = pid_file.read_text().strip() if pid_file.is_file() else ""
running = False
if pid.isdigit():
    try:
        os.kill(int(pid), 0)
        running = True
    except OSError:
        pass
print(json.dumps({
    "native_ollama_log": str(native),
    "exists": native.is_file(),
    "forwarder_pid_file": str(pid_file),
    "forwarder_pid": pid or None,
    "forwarder_running": running,
    "systemd_unit": os.getenv("OLLAMA_SYSTEMD_UNIT", "ollama"),
    "source": "journalctl -u ollama -f --output=short-iso",
}, indent=2))
