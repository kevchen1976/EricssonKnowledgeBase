"""Ericsson manifest resolution and Markdown asset URL normalization."""
from __future__ import annotations

import json
import re
from pathlib import Path, PurePosixPath
from typing import Any, Dict, Iterable, List, Optional
from urllib.parse import quote, unquote, urlparse

from agent_core.ids import feature_key, normalize_feature_id, normalize_package_id, package_key

from .state import KBState

_IMAGE_RE = re.compile(r"!\[([^\]]*)\]\(([^)]+)\)")

SAFE_MANIFEST_FIELDS = [
    "record_kind", "record_id", "feature_id", "primary_feature_id", "feature_ids",
    "included_feature_ids", "mentioned_feature_ids", "related_feature_ids",
    "owner_feature_id", "feature_title", "package_id", "primary_package_id",
    "package_ids", "package_names", "filename", "source_markdown", "source_pdf",
    "title", "doc_type", "document_subtype", "doc_role", "manifest_stage",
    "section_type", "section_heading", "heading_path", "page_start", "page_end",
    "access_types", "node_types", "licensing", "prerequisites",
    "restriction_status", "feature_association", "topics", "topic_aliases",
    "content_retrievable", "is_feature_owner", "route_by_feature",
    "route_by_package", "route_by_topic",
]


def _read_jsonl(path: Path) -> List[Dict[str, Any]]:
    records: List[Dict[str, Any]] = []
    if not path.exists():
        return records
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            line = line.strip()
            if not line:
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid manifest JSONL at {path}:{line_number}: {exc}") from exc
            if isinstance(value, dict):
                records.append(value)
    return records


def _document(record: Dict[str, Any]) -> bool:
    return str(record.get("record_kind") or record.get("manifest_stage") or "") == "document"


def _direct_feature(record: Dict[str, Any], feature_id: str) -> bool:
    if not _document(record):
        return False
    owner = normalize_feature_id(str(record.get("owner_feature_id") or record.get("feature_id") or ""))
    return bool(
        owner == feature_id
        and (
            bool(record.get("is_feature_owner"))
            or str(record.get("doc_role") or "") == "feature_document"
            or str(record.get("doc_type") or "") == "feature_description"
        )
    )


def _related_feature(record: Dict[str, Any], feature_id: str) -> bool:
    values: List[str] = []
    for key in ("feature_ids", "included_feature_ids", "mentioned_feature_ids", "related_feature_ids"):
        raw = record.get(key, [])
        if not isinstance(raw, list):
            raw = [raw] if raw else []
        values.extend(normalize_feature_id(str(value)) for value in raw)
    return feature_id in values


def _package_match(record: Dict[str, Any], package_id: str) -> bool:
    values: List[str] = []
    for key in ("package_id", "primary_package_id"):
        value = normalize_package_id(str(record.get(key) or ""))
        if value:
            values.append(value)
    raw = record.get("package_ids", [])
    if not isinstance(raw, list):
        raw = [raw] if raw else []
    values.extend(normalize_package_id(str(value)) for value in raw)
    return package_id in values


def public_manifest_record(record: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not record:
        return None
    return {key: record.get(key) for key in SAFE_MANIFEST_FIELDS if key in record}


class ManifestRepository:
    def __init__(self, state: KBState) -> None:
        self.state = state
        self.settings = state.settings

    def _remote_records(self, clauses: List[Dict[str, Any]], *, size: int = 500) -> List[Dict[str, Any]]:
        try:
            filters = [
                {"term": {"vendor": self.settings.vendor}},
                {"term": {"corpus_id": self.settings.corpus_id}},
            ]
            body = {
                "size": size,
                "query": {
                    "bool": {
                        "filter": filters,
                        "should": clauses,
                        "minimum_should_match": 1,
                    }
                },
            }
            response = self.state.client().search(index=self.settings.manifest_alias, body=body)
            return [hit.get("_source", {}) for hit in (response.get("hits") or {}).get("hits", []) if isinstance(hit.get("_source"), dict)]
        except Exception:
            return []

    def feature_records(self, value: str) -> List[Dict[str, Any]]:
        feature_id = normalize_feature_id(value)
        if not feature_id:
            return []
        key = feature_key(feature_id)
        path = self.settings.feature_manifest_root / "FAJ121" / f"{key}.jsonl"
        mentioned_path = self.settings.mentioned_feature_manifest_root / "FAJ121" / f"{key}.jsonl"
        local_records = _read_jsonl(path) + _read_jsonl(mentioned_path)
        if local_records:
            seen: set[str] = set()
            records: List[Dict[str, Any]] = []
            for record in local_records:
                identity = str(record.get("record_id") or json.dumps(record, sort_keys=True, default=str))
                if identity not in seen:
                    seen.add(identity)
                    records.append(record)
            return records
        return self._remote_records([
            {"term": {"owner_feature_id": feature_id}},
            {"term": {"feature_id": feature_id}},
            {"term": {"primary_feature_id": feature_id}},
            {"term": {"feature_ids": feature_id}},
            {"term": {"included_feature_ids": feature_id}},
            {"term": {"mentioned_feature_ids": feature_id}},
            {"term": {"related_feature_ids": feature_id}},
        ])

    def feature_bundle(self, value: str) -> Dict[str, Any]:
        feature_id = normalize_feature_id(value)
        records = self.feature_records(feature_id)
        direct = [record for record in records if _direct_feature(record, feature_id)]
        related_docs = [record for record in records if _document(record) and not _direct_feature(record, feature_id) and _related_feature(record, feature_id)]
        direct.sort(key=lambda record: (str(record.get("doc_type")) != "feature_description", str(record.get("filename") or "")))
        related_docs.sort(key=lambda record: (
            str(record.get("feature_association") or "") == "mentioned",
            str(record.get("doc_role") or "") == "general_document",
            str(record.get("filename") or ""),
        ))
        title = ""
        for record in direct + related_docs + records:
            candidate = str(record.get("feature_title") or "").strip()
            if candidate:
                title = candidate
                break
        return {
            "feature_id": feature_id,
            "feature_title": title,
            "primary": direct[0] if direct else None,
            "direct_documents": direct,
            "related_documents": related_docs,
            "records": records,
        }

    def package_records(self, value: str) -> List[Dict[str, Any]]:
        package_id = normalize_package_id(value)
        if not package_id:
            return []
        key = package_key(package_id)
        path = self.settings.package_manifest_root / "FAJ801" / f"{key}.jsonl"
        records = _read_jsonl(path)
        if records:
            return records
        return self._remote_records([
            {"term": {"package_id": package_id}},
            {"term": {"primary_package_id": package_id}},
            {"term": {"package_ids": package_id}},
        ])

    def package_bundle(self, value: str) -> Dict[str, Any]:
        package_id = normalize_package_id(value)
        records = self.package_records(package_id)
        documents = [record for record in records if _document(record) and _package_match(record, package_id)]
        documents.sort(key=lambda record: (
            str(record.get("doc_role") or "") != "package_document",
            str(record.get("filename") or ""),
        ))
        return {
            "package_id": package_id,
            "primary": documents[0] if documents else None,
            "documents": documents,
            "records": records,
        }

    def topic_records(self, slug: str) -> List[Dict[str, Any]]:
        safe = re.sub(r"[^a-z0-9-]+", "-", str(slug or "").lower()).strip("-")
        if not safe:
            return []
        return _read_jsonl(self.settings.topic_manifest_root / f"{safe}.jsonl")


def _safe_asset_target(target: str) -> Optional[str]:
    value = target.strip().strip('"\'')
    if " \"" in value:
        value = value.split(" \"", 1)[0]
    parsed = urlparse(value)
    if parsed.scheme or parsed.netloc or value.startswith(("/", "#", "data:")):
        return None
    decoded = unquote(parsed.path).replace("\\", "/")
    pure = PurePosixPath(decoded)
    if not decoded or any(part in {"", ".", ".."} for part in pure.parts):
        return None
    return quote(str(pure), safe="/-_.~")


def rewrite_asset_links(content: str, prefix: str) -> str:
    prefix = "/" + prefix.strip("/") + "/"

    def replace(match: re.Match[str]) -> str:
        alt, target = match.group(1), match.group(2)
        safe = _safe_asset_target(target)
        if safe is None:
            return match.group(0)
        return f"![{alt}]({prefix}{safe})"

    return _IMAGE_RE.sub(replace, content or "")


def extract_image_links(content: str) -> List[Dict[str, str]]:
    seen: set[str] = set()
    links: List[Dict[str, str]] = []
    for alt, target in _IMAGE_RE.findall(content or ""):
        url = target.strip().strip('"\'')
        if not url.startswith(("/", "http://", "https://")) or url in seen:
            continue
        seen.add(url)
        links.append({"label": alt.strip() or Path(unquote(url)).name, "url": url})
    return links
