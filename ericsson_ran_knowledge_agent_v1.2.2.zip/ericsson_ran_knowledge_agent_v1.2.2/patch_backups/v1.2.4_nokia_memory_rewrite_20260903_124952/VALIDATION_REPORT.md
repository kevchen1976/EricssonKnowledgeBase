# Validation report

Validation date: 2026-09-02  
Package version: 1.2.2  
Retrieval schema: `ericsson-kb-1.2-parent-child`  
Retrieval contract: `rank-children-then-mget-parents`

## Scope

The package was checked against the parent/child storage and retrieval strategy in the supplied Nokia `DataChuckingAndEmbedding.zip` package and against four supplied Ericsson documents:

- `16-QAM Uplink.pdf`;
- `IPsec.pdf`;
- `End-to-end MTU Recommendation with IPsec.pdf`;
- `Instantaneous Licensing Solution Guideline.pdf`.

The validation covered PDF preparation, portable Markdown image links, Ericsson manifests, TOC-aware section parsing, four-level headings, procedure-safe parent boundaries, child-only embeddings, separate parent storage, child-to-parent integrity, quiet counting of long non-vector parents, and strict model-input validation for vector children.

Docling and the production BGE model were not installed in this build runtime. PDF preparation therefore exercised the PyMuPDF fallback, and the bundled preview used the deterministic test embedder plus the regex tokenizer fallback. Production deployment must run `scripts/check_embedding_lengths.py` with the actual local model before rebuilding OpenSearch.

## Storage and embedding contract

```text
Ericsson Markdown section
        |
        +--> parent index
        |      complete section content stored once
        |      no embedding / no embedding_text
        |
        `--> child index
               300-token retrieval windows by default
               60-token overlap by default
               procedure preservation ceiling: 480 tokens
               embedding on child only
               parent_id + parent_storage_id
```

Complete parents may exceed the embedding model limit because they are never sent to the transformer. Version 1.2.1 tokenizes those parents with `truncation=False` and `verbose=False`, avoiding the misleading Transformers length advisory while still recording `parent_token_count`.

Every final child `embedding_text` is independently counted with the loaded model tokenizer, including special tokens. A full-corpus preflight runs before an OpenSearch client or backing index is created. Any child over the detected model limit fails the run and writes an `embedding_preflight_failure_<run_id>.json` report with `opensearch_touched: false`. The same assertion runs again immediately before model inference.

The default embedding input remains:

```text
EMBEDDING_INPUT_MODE=content
embedding_text == content
```

## Bundled corpus results

| Check | Result |
|---|---:|
| Documents prepared | 4 |
| Feature documents | 1 |
| Package documents | 1 |
| General/Solution Guideline documents | 2 |
| Manifest records | 580 |
| Document records | 4 |
| Section records | 79 |
| Fact records | 492 |
| Package-feature relationship records | 5 |
| Full section parents | 83 |
| Searchable children after 480-token procedure ceiling | 122 |
| Level-four parents | 10 |
| Markdown image links checked | 30 |
| Broken image links | 0 |
| Maximum parent token count in offline fallback validation | 1,413 |
| Maximum child token count in offline fallback validation | 449 |
| Deterministic test vectors | 122 x 32 dimensions |

The offline token counts above use the regex fallback because the production model files were unavailable in this runtime. They are structural validation values, not substitutes for the deployment-host BGE tokenizer audit.

## Parent/child preview integrity

The deterministic-vector preview reported:

```text
parents containing vectors                    0
children containing parent_content            0
children with unresolved parent reference     0
parent content-hash mismatches                 0
child-to-parent hash mismatches                0
child content-hash mismatches                  0
records missing required hashes                0
storage-contract mismatches                    0
embedding_text/content mismatches              0
embedding-limit violations                     0
records marked embedding_truncated             0
```

## Automated checks

```text
63 automated tests passed
Python compileall passed
Package verification passed
Shell launcher syntax validation passed
Prepared-data validation passed
Parent/child preview validation passed
Patch application test passed against a clean v1.2.0 copy
```

The token-guard tests cover:

- quiet, non-truncating token counting for a parent longer than the transformer limit;
- strict effective model-limit resolution;
- special-token-inclusive rejection of over-limit child input;
- successful full-corpus preflight reporting;
- contextual overflow errors identifying document, heading, child order, and chunk ID.

## RAG logging and SQLite audit checks

The v1.2.2 observability patch was tested without changing the existing retrieval contract. Automated tests verify:

```text
BM25 child recall logging
vector child recall logging
RRF rank and score logging
reranker score logging
final child selection logging
parent mget request/result logging
final parent selection logging
complete Agent query and final-answer SQLite persistence
legacy query_audit migration and compatibility dual-write
request ID propagation from Agent API to KB API
```

The canonical SQLite table is `audit`. Existing v1.2.1 `query_audit` data remains intact. The patch does not alter OpenSearch documents, index mappings, aliases, embeddings, rank calculations, or API response models, so no re-ingestion is required.

## Required deployment check

Run this before the next rebuild:

```bash
python scripts/check_embedding_lengths.py \
  --prepared-root data/prepared \
  --output logs/embedding_length_preflight.json
```

A valid production result must show:

```json
{
  "status": "passed",
  "model_max_tokens": 512,
  "over_limit_inputs": 0,
  "opensearch_touched": false
}
```

The exact largest input count depends on the full corpus and loaded tokenizer, but it must not exceed `model_max_tokens`.

## Deliberately not live-tested in this runtime

- connection and writes to the shared OpenSearch cluster;
- production SentenceTransformer/BGE model loading and semantic-vector quality;
- live BM25/KNN retrieval over populated indexes;
- Ollama answer generation;
- Neo4j connectivity or writes;
- Docker image build and Compose startup;
- native Docling conversion.
