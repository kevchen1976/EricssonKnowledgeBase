# Architecture

## Service boundary

The supplied Nokia agent established this useful boundary:

```text
Agent API -> KB API -> OpenSearch
          -> Graph API -> Neo4j
```

Ericsson keeps the same boundary so both vendor agents remain independently callable and can later be supervised through their APIs.

## Preparation and storage flow

```text
Ericsson PDF
   |
   v
Docling-first extraction
   |-- Markdown page markers
   |-- headings/tables/lists
   `-- adjacent document image folder
   |
   v
Ericsson manifest generation
   |-- document
   |-- section
   |-- fact
   `-- package_feature relation
   |
   v
TOC-aware section parser
   |-- rejects TOC rows as body sections
   |-- rejects numbered procedure steps
   |-- rejects numeric table rows
   `-- supports numeric hierarchy through six levels
   |
   v
one real section = one parent
   |                         \
   |                          `-- 300-token child windows, 60 overlap
   |                               vectors only on children
   v
OpenSearch
   |-- ericsson-ran-kb-parents
   |-- ericsson-ran-kb-children
   `-- ericsson-ran-kb-manifests
```

## Parent/child contract

### Parent index

A parent is one actual document-outline section. It stores complete section context once:

```text
parent_id / parent_storage_id
content
heading / heading_number / heading_level / heading_path
page_start / page_end
image_paths
filename / source_pdf
Ericsson feature/package/document metadata
```

Parents do not contain vectors or `embedding_text`. `parent_max_tokens=3000` is a diagnostic soft limit only; it never divides one source section into several parents.

### Child index

A child stores a bounded retrieval window:

```text
chunk_id
parent_id / parent_storage_id
content / embedding_text / embedding
child_order / token_count
parent page range and section metadata
Ericsson feature/package/document metadata
```

Children do not contain full parent text. Procedure-like sections up to 900 tokens can remain one child so ordered operational steps are not fragmented. Later windows receive the section heading as a prefix.

The default vector input is the stored child `content` itself. Every child also stores `parent_content_sha256`, while the corresponding parent stores `content_sha256`. These fields are checked during parent expansion.

### Manifest index

The manifest index stores document, section, fact, and relationship records. Manifest facts are not duplicated into vector storage by default (`INCLUDE_MANIFEST_FACTS=false`).

## Retrieval

1. Detect explicit `FAJ 121` or `FAJ 801` identities deterministically.
2. Resolve direct feature/package manifests.
3. Search only the child alias with BM25 and KNN under Ericsson vendor/corpus filters.
4. Fuse child rankings with Reciprocal Rank Fusion.
5. Optionally rerank child text.
6. Apply feature-association and manifest-priority boosts.
7. Select the final child hits.
8. Collect unique `parent_storage_id` values and issue one parent-index `mget`.
9. Require each selected child to resolve to a stored parent and verify the expected parent-content hash.
10. Return full parent sections in selected-child order, attaching contributing evidence under `matched_children`.
11. Synthesize and validate the answer.

The result limit therefore applies to selected child evidence. The number of returned parents may be smaller when several selected children belong to the same section.

## Ericsson hierarchy

The parser builds hierarchical paths such as:

```text
2 Principles and Guidelines
  > 2.2 Solution Overview
  > 2.2.3 Network Elements
  > 2.2.3.1 Radio Node
```

The same parser is reused during manifest generation and ingestion, preventing section records from drifting away from parent boundaries.

## Shared-cluster isolation

```text
Shared OpenSearch cluster
├── Nokia aliases and backing indexes
└── Ericsson
    ├── ericsson-ran-kb-children-v...
    ├── ericsson-ran-kb-parents-v...
    ├── ericsson-ran-kb-manifests-v...
    ├── alias ericsson-ran-kb-children
    ├── alias ericsson-ran-kb-parents
    └── alias ericsson-ran-kb-manifests
```

All writes, deletes, alias changes, and searches are constrained to the Ericsson namespace. Rebuild mode switches the three aliases atomically.

## Neo4j boundary

Neo4j is not required for the first release. The package includes a disabled-by-default Graph API, schema, staging records, and dry-run-first importer. Curated Ericsson relations can be loaded later into the logical `ericsson` database without changing the Agent API contract.
