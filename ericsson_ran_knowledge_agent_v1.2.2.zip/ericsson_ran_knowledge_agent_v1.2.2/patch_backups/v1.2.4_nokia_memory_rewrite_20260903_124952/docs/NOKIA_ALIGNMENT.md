# Alignment with the supplied Nokia chunking strategy

Version 1.2 was checked against `DataChuckingAndEmbedding.zip`, especially its TOC-aware chunker, split parent/child mappings, ingestion order, and child-first retrieval.

| Nokia strategy | Ericsson v1.2 |
|---|---|
| One real outline section per parent | Same; parent soft limit is diagnostic only |
| TOC-aware, procedure-safe heading detection | Same, adapted for Ericsson Markdown and deep CPI headings |
| Child windows of 300 tokens | Same default |
| Child overlap of 60 tokens | Same default |
| Preserve procedure-like section up to 900 tokens | Same default |
| Add heading to later windows | Same default, using full Ericsson heading path |
| Embed/search children only | Same |
| Store parent text once in a separate index | Same |
| Index parents before children | Same |
| Rank child hits then `mget` parents | Same |
| No duplicated `parent_content` in children | Same |
| Embed the stored child text | Same default: `embedding_text == content` |
| Parent context fetched only after final child ranking | Same, with strict reference/hash validation |

Ericsson-specific additions are retained:

- `FAJ 121 xxxx` Feature Identities and `FAJ 801 xxxx` Value Package Identities remain separate namespaces;
- four-level and deeper headings carry `heading_number`, `heading_level`, and full `heading_path`;
- Feature Description, package document, and general guideline ownership rules remain distinct;
- `feature_association` differentiates primary, included, related, mentioned, and unrelated evidence;
- manifest and relationship indexes remain separate from vector storage;
- shared-cluster safety requires Ericsson aliases and vendor/corpus filters.

The later supervisor should consume the Nokia and Ericsson `/query` APIs independently. It should not assume the two vendors have identical identity or document-ownership semantics merely because their parent/child retrieval shape is aligned.

## Ericsson v1.2 integrity additions

The Nokia storage shape is preserved, while Ericsson v1.2 adds fail-closed checks that do not alter chunk boundaries: parents and children declare their storage role, parent content is SHA-256 tagged, children carry the expected parent hash, and retrieval rejects missing or mismatched parents by default.
