"""Application state for the standalone Ericsson agent API."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

from agent_core.audit import AuditStore
from agent_core.logging_utils import configure_file_logger
from agent_core.settings import Settings, get_settings
from agent_core.workflow import EricssonAgent

from .sessions import SessionStore


@dataclass
class AgentServiceState:
    settings: Settings
    agent: EricssonAgent
    audit: AuditStore
    sessions: SessionStore
    logger: logging.Logger


_STATE: Optional[AgentServiceState] = None


def get_state(*, reload: bool = False) -> AgentServiceState:
    global _STATE
    if _STATE is None or reload:
        settings = get_settings(reload=reload)
        logger = configure_file_logger(
            "ericsson_agent",
            settings.logs_dir / "ericsson_agent.log",
        )
        _STATE = AgentServiceState(
            settings=settings,
            agent=EricssonAgent(settings),
            audit=AuditStore(settings.audit_db_path, enabled=settings.audit_enabled),
            sessions=SessionStore(enabled=settings.session_memory_enabled),
            logger=logger,
        )
    return _STATE
