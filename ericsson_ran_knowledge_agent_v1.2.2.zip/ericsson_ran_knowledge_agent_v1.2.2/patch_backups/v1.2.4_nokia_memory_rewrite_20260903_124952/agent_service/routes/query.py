"""Standalone Ericsson query endpoint."""
from __future__ import annotations

import time
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException

from agent_core.contracts import QueryRequest, QueryResponse
from agent_core.logging_utils import new_request_id, request_context, single_line

from ..auth import authorize
from ..state import get_state

router = APIRouter()


@router.post("/query", response_model=QueryResponse)
def query_agent(request: QueryRequest, user_email: Optional[str] = Depends(authorize)) -> QueryResponse:
    state = get_state()
    request_id = new_request_id()
    started = time.perf_counter()
    result: QueryResponse | None = None

    with request_context(request_id):
        state.logger.info(
            "[QUERY START] session_id=%s user_email=%s limit=%s include_evidence=%s query=%r",
            request.session_id or "",
            user_email or "",
            request.limit,
            request.include_evidence,
            request.query,
        )
        try:
            result = state.agent.run(
                request.query,
                limit=request.limit,
                include_evidence=request.include_evidence,
            )
            history = state.sessions.get(request.session_id)
            result.metadata["session_id"] = request.session_id
            result.metadata["prior_turn_count"] = len(history)
            state.sessions.add(request.session_id, request.query, result.answer)

            elapsed_ms = int((time.perf_counter() - started) * 1000)
            response_payload = result.model_dump(mode="json")
            citations_payload = [citation.model_dump(mode="json") for citation in result.citations]
            state.audit.record(
                request_id=request_id,
                query=request.query,
                workflow=result.workflow,
                source=result.source,
                latency_ms=elapsed_ms,
                success=True,
                session_id=request.session_id,
                user_email=user_email,
                tool_calls=[
                    {
                        "tool": "ericsson_knowledge_workflow",
                        "workflow": result.workflow,
                        "feature_ids": result.feature_ids,
                        "package_ids": result.package_ids,
                    }
                ],
                tool_outputs=[
                    {
                        "source": result.source,
                        "citations": citations_payload,
                        "warnings": result.warnings,
                        "metadata": result.metadata,
                        "evidence": result.evidence,
                    }
                ],
                final_answer=result.answer,
                validation_ok=True,
                validation_errors=[],
                feature_ids=result.feature_ids,
                package_ids=result.package_ids,
                citation_count=len(result.citations),
                citations=citations_payload,
                warnings=result.warnings,
                response=response_payload,
            )
            state.logger.info(
                "[QUERY COMPLETE] workflow=%s source=%s latency_ms=%d features=%s packages=%s "
                "citations=%d warnings=%d answer_chars=%d answer_preview=%s",
                result.workflow,
                result.source,
                elapsed_ms,
                result.feature_ids,
                result.package_ids,
                len(result.citations),
                len(result.warnings),
                len(result.answer),
                single_line(result.answer, max_chars=320),
            )
            return result
        except Exception as exc:
            elapsed_ms = int((time.perf_counter() - started) * 1000)
            state.audit.record(
                request_id=request_id,
                query=request.query,
                workflow=result.workflow if result else "",
                source="ericsson_agent",
                latency_ms=elapsed_ms,
                success=False,
                session_id=request.session_id,
                user_email=user_email,
                final_answer=result.answer if result else "",
                validation_ok=False,
                validation_errors=[str(exc)],
                feature_ids=result.feature_ids if result else [],
                package_ids=result.package_ids if result else [],
                citation_count=len(result.citations) if result else 0,
                citations=[citation.model_dump(mode="json") for citation in result.citations] if result else [],
                warnings=result.warnings if result else [],
                error=str(exc),
                response=result.model_dump(mode="json") if result else {},
            )
            state.logger.exception(
                "[QUERY ERROR] latency_ms=%d query=%r error=%s",
                elapsed_ms,
                request.query,
                single_line(exc, max_chars=500),
            )
            raise HTTPException(status_code=500, detail=f"Ericsson agent query failed: {exc}") from exc


@router.delete("/session/{session_id}")
def clear_session(session_id: str, _user_email: Optional[str] = Depends(authorize)) -> dict:
    get_state().sessions.clear(session_id)
    return {"cleared": True, "session_id": session_id}
