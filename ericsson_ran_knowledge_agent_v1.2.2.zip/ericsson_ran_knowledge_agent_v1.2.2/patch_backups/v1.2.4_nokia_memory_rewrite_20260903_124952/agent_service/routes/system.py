"""Agent service health and capability endpoints."""
from __future__ import annotations

import httpx
from fastapi import APIRouter, Response, status

from agent_core.constants import PARENT_CHILD_CONTRACT, RETRIEVAL_SCHEMA

from ..state import get_state

router = APIRouter()


@router.get("/health")
def health() -> dict:
    settings = get_state().settings
    return {
        "status": "ok",
        "service": "ericsson-agent-api",
        "vendor": settings.vendor,
        "corpus_id": settings.corpus_id,
        "graph_enabled": settings.graph_enabled,
        "llm_enabled": settings.llm_enabled,
    }


@router.get("/ready")
def ready(response: Response) -> dict:
    settings = get_state().settings
    kb_ready = False
    kb_detail = ""
    try:
        result = httpx.get(settings.kb_api_url.rstrip("/") + "/ready", timeout=min(settings.kb_timeout, 10))
        kb_ready = result.status_code == 200 and bool(result.json().get("ready"))
        kb_detail = result.text[:1000]
    except Exception as exc:
        kb_detail = str(exc)
    if not kb_ready:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    return {"ready": kb_ready, "kb_ready": kb_ready, "kb_detail": kb_detail}


@router.get("/capabilities")
def capabilities() -> dict:
    settings = get_state().settings
    return {
        "vendor": settings.vendor,
        "corpus_id": settings.corpus_id,
        "api_contract": "standalone-vendor-agent-v1",
        "retrieval_schema": RETRIEVAL_SCHEMA,
        "identity_formats": ["FAJ 121 xxxx", "FAJ 801 xxxx"],
        "workflows": ["feature_lookup", "package_lookup", "knowledge_search", "graph_assisted_search"],
        "data_sources": {
            "opensearch": {
                "child_alias": settings.child_alias,
                "parent_alias": settings.parent_alias,
                "manifest_alias": settings.manifest_alias,
                "chunk_alias": settings.child_alias,
                "retrieval_contract": PARENT_CHILD_CONTRACT,
                "require_parent_context": settings.require_parent_context,
                "verify_parent_content_hash": settings.verify_parent_content_hash,
                "embedding_input_mode": settings.embedding_input_mode,
                "embedding_max_input_tokens_override": settings.embedding_max_input_tokens,
                "embedding_token_guard": "strict-preflight-and-pre-encode",
            },
            "neo4j": {"enabled": settings.graph_enabled, "database": settings.neo4j_database},
        },
    }
