"""Small in-process conversation memory for the standalone service.

This is intentionally lightweight.  A future unified supervisor should own the
cross-vendor conversation state; the vendor agent only retains a short local
history when called directly.
"""
from __future__ import annotations

import threading
from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Deque, Dict, List


@dataclass
class Turn:
    query: str
    answer: str
    created_at: str


class SessionStore:
    def __init__(self, *, max_turns: int = 6, enabled: bool = True) -> None:
        self.enabled = bool(enabled)
        self.max_turns = max(1, int(max_turns))
        self._items: Dict[str, Deque[Turn]] = defaultdict(lambda: deque(maxlen=self.max_turns))
        self._lock = threading.RLock()

    def add(self, session_id: str | None, query: str, answer: str) -> None:
        if not self.enabled or not session_id:
            return
        with self._lock:
            self._items[session_id].append(Turn(query, answer, datetime.now(timezone.utc).isoformat()))

    def get(self, session_id: str | None) -> List[Turn]:
        if not self.enabled or not session_id:
            return []
        with self._lock:
            return list(self._items.get(session_id, ()))

    def clear(self, session_id: str) -> None:
        with self._lock:
            self._items.pop(session_id, None)
