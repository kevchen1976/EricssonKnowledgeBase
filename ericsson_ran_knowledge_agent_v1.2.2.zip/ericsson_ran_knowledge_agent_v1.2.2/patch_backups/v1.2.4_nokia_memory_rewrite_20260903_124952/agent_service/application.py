"""FastAPI assembly for the standalone Ericsson RAN knowledge agent."""
from __future__ import annotations

import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from agent_core.constants import PACKAGE_VERSION
from agent_core.settings import PROJECT_ROOT

from .routes import query, system

logger = logging.getLogger("ericsson_agent.web")

app = FastAPI(
    title="Ericsson RAN Knowledge Agent",
    version=PACKAGE_VERSION,
    description="Standalone Ericsson vendor agent with a stable API for a later supervisor.",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

# Register API routes before the catch-all static mount. This preserves /query,
# /health, /ready, /capabilities, /session/*, /docs, and /openapi.json while
# serving the browser application from the same Agent API origin.
app.include_router(query.router)
app.include_router(system.router)

static_root = PROJECT_ROOT / "static"
root_index = PROJECT_ROOT / "index.html"

if (static_root / "index.html").is_file():
    app.mount("/", StaticFiles(directory=str(static_root), html=True), name="static")
    app.state.frontend_root = str(static_root)
    logger.info("[AGENT WEB] Mounted frontend from %s", static_root)
elif root_index.is_file():
    # Nokia-compatible fallback for deployments that keep index.html directly
    # in the project root.
    app.mount("/", StaticFiles(directory=str(PROJECT_ROOT), html=True), name="static")
    app.state.frontend_root = str(PROJECT_ROOT)
    logger.info("[AGENT WEB] Mounted frontend from %s", PROJECT_ROOT)
else:
    app.state.frontend_root = ""
    logger.warning(
        "[AGENT WEB] Frontend not mounted; expected %s or %s",
        static_root / "index.html",
        root_index,
    )
