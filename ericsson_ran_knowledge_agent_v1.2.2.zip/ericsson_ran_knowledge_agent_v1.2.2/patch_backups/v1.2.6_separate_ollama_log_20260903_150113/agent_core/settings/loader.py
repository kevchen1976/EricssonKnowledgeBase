"""Settings loader used by every Ericsson service.

Precedence: process environment > optional config/services.env values > the
JSON selected by AGENT_SETTINGS_FILE > built-in defaults. Paths in JSON and
environment variables are resolved relative to the project root unless they
are already absolute.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Optional

from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_SETTINGS_FILE = PROJECT_ROOT / "config" / "settings.json"


def _load_environment_file() -> None:
    """Load a deployment env file without overriding exported process values."""
    configured = os.getenv("ERICSSON_SERVICE_ENV_FILE", "config/services.env")
    path = Path(os.path.expandvars(os.path.expanduser(configured)))
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    if path.is_file():
        load_dotenv(path, override=False)


def _load_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError(f"Settings file must contain a JSON object: {path}")
    return data


def _deep_get(data: Dict[str, Any], keys: Iterable[str], default: Any = None) -> Any:
    value: Any = data
    for key in keys:
        if not isinstance(value, dict) or key not in value:
            return default
        value = value[key]
    return value


def _env(name: str, fallback: Any) -> Any:
    value = os.getenv(name)
    return fallback if value is None else value


def _env_first(names: Iterable[str], fallback: Any) -> Any:
    """Return the first explicitly configured environment value."""
    for name in names:
        value = os.getenv(name)
        if value is not None:
            return value
    return fallback


def _env_bool(name: str, fallback: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return bool(fallback)
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, fallback: int) -> int:
    value = os.getenv(name)
    return int(value) if value is not None and value.strip() else int(fallback)


def _env_first_int(names: Iterable[str], fallback: int) -> int:
    """Resolve the first non-empty integer environment alias."""
    for name in names:
        value = os.getenv(name)
        if value is not None and value.strip():
            return int(value)
    return int(fallback)


def _env_float(name: str, fallback: float) -> float:
    value = os.getenv(name)
    return float(value) if value is not None and value.strip() else float(fallback)




def _env_choice(name: str, fallback: str, choices: Iterable[str]) -> str:
    value = str(os.getenv(name, fallback)).strip().lower()
    allowed = {str(choice).strip().lower() for choice in choices}
    if value not in allowed:
        raise ValueError(f"{name} must be one of {sorted(allowed)}, got {value!r}")
    return value


def _path(value: str | Path) -> Path:
    p = Path(os.path.expandvars(os.path.expanduser(str(value))))
    if not p.is_absolute():
        p = PROJECT_ROOT / p
    return p.resolve()


def _prepared_child(prepared_root: Path, explicit: str, relative: str) -> Path:
    if explicit:
        return _path(explicit)
    return (prepared_root / relative).resolve()


@dataclass(frozen=True)
class Settings:
    vendor: str
    corpus_id: str

    bind_host: str
    agent_api_port: int
    graph_api_port: int
    kb_api_port: int
    agent_api_url: str
    graph_api_url: str
    kb_api_url: str
    ollama_url: str

    opensearch_host: str
    opensearch_port: int
    opensearch_scheme: str
    opensearch_username: str
    opensearch_password: str
    opensearch_verify_certs: bool
    opensearch_ca_certs: Optional[Path]
    opensearch_timeout: int

    index_safety_prefix: str
    child_alias: str
    child_backing_prefix: str
    parent_alias: str
    parent_backing_prefix: str
    manifest_alias: str
    manifest_backing_prefix: str
    index_shards: int
    index_replicas: int
    vector_engine: str
    vector_space_type: str
    hnsw_m: int
    hnsw_ef_construction: int
    knn_ef_search: int

    prepared_root: Path
    markdown_root: Path
    combined_manifest: Path
    feature_manifest_root: Path
    package_manifest_root: Path
    topic_manifest_root: Path
    mentioned_feature_manifest_root: Path
    embedding_model_path: Path
    reranker_model_path: Path
    logs_dir: Path
    audit_db_path: Path
    kb_asset_url_prefix: str

    embedding_device: str
    embedding_batch_size: int
    embedding_max_input_tokens: int
    embedding_normalize: bool
    reranker_enabled: bool
    reranker_device: str
    llm_enabled: bool
    local_files_only: bool
    ollama_model: str
    ollama_verbose: bool
    ollama_log_prompt_max_chars: int
    ollama_log_response_max_chars: int

    default_limit: int
    maximum_limit: int
    initial_candidate_count: int
    rrf_rank_constant: int
    bm25_content_boost: float
    bm25_heading_boost: float
    bm25_title_boost: float
    feature_association_boost: float
    manifest_priority_boost: float
    allow_bm25_only: bool
    require_parent_context: bool
    verify_parent_content_hash: bool

    parent_max_tokens: int
    child_max_tokens: int
    child_overlap_tokens: int
    minimum_chunk_tokens: int
    keep_procedure_sections: bool
    procedure_max_tokens: int
    add_heading_to_children: bool
    include_manifest_facts: bool
    include_document_preamble: bool
    embedding_input_mode: str

    graph_enabled: bool
    auth_enabled: bool
    session_memory_enabled: bool
    enable_llm_query_rewrite: bool
    audit_enabled: bool
    strict_vendor_filter: bool
    allowed_emails: tuple[str, ...]

    neo4j_uri: str
    neo4j_user: str
    neo4j_password: str
    neo4j_database: str

    redis_url: str
    redis_host: str
    redis_port: int
    redis_db: int
    redis_password: str
    redis_key_prefix: str
    redis_ssl: bool
    redis_socket_timeout: float
    redis_connect_timeout: float
    session_ttl_seconds: int
    max_session_history: int
    session_history_answer_chars: int
    session_stored_answer_chars: int

    kb_timeout: int
    graph_timeout: int
    ollama_timeout: int

    @property
    def chunk_alias(self) -> str:
        """Backward-compatible name for the searchable child alias."""
        return self.child_alias

    @property
    def chunk_backing_prefix(self) -> str:
        """Backward-compatible name for the child backing-index prefix."""
        return self.child_backing_prefix

    @classmethod
    def load(cls) -> "Settings":
        _load_environment_file()
        selected = Path(os.path.expandvars(os.path.expanduser(os.getenv("AGENT_SETTINGS_FILE", str(DEFAULT_SETTINGS_FILE)))))
        # Keep the deployment configuration portable: a relative settings file
        # is resolved from the repository root rather than the caller's current
        # working directory.  This matches the service launcher's behavior and
        # also makes console entry points safe to run from another directory.
        if not selected.is_absolute():
            selected = PROJECT_ROOT / selected
        selected = selected.resolve()
        data = _load_json(selected)
        get = lambda *keys, default=None: _deep_get(data, keys, default)

        prepared_root = _path(_env("ERICSSON_PREPARED_ROOT", get("paths", "prepared_root", default="data/prepared")))
        markdown_root = _prepared_child(
            prepared_root,
            os.getenv("ERICSSON_MARKDOWN_ROOT", ""),
            "markdown",
        )
        combined_manifest = _prepared_child(
            prepared_root,
            os.getenv("ERICSSON_COMBINED_MANIFEST", ""),
            "combined_manifest.jsonl",
        )
        feature_manifest_root = _prepared_child(
            prepared_root,
            os.getenv("ERICSSON_FEATURE_MANIFEST_ROOT", ""),
            "routing-manifest/by-feature-id",
        )
        package_manifest_root = _prepared_child(
            prepared_root,
            os.getenv("ERICSSON_PACKAGE_MANIFEST_ROOT", ""),
            "routing-manifest/by-package-id",
        )
        topic_manifest_root = _prepared_child(
            prepared_root,
            os.getenv("ERICSSON_TOPIC_MANIFEST_ROOT", ""),
            "routing-manifest/by-topic",
        )
        mentioned_feature_manifest_root = _prepared_child(
            prepared_root,
            os.getenv("ERICSSON_MENTIONED_FEATURE_MANIFEST_ROOT", ""),
            "routing-manifest/by-mentioned-feature-id",
        )

        ca_value = str(_env("OPENSEARCH_CA_CERTS", get("services", "opensearch_ca_certs", default=""))).strip()
        allowed = os.getenv("ALLOWED_EMAILS")
        allowed_values = [x.strip() for x in allowed.split(",")] if allowed else get("access", "allowed_emails", default=[])

        return cls(
            vendor=str(_env("VENDOR", get("vendor", default="Ericsson"))),
            corpus_id=str(_env("CORPUS_ID", get("corpus_id", default="ericsson-ran"))),
            bind_host=str(_env("SERVICE_BIND_HOST", get("services", "bind_host", default="0.0.0.0"))),
            agent_api_port=_env_int("AGENT_API_PORT", get("services", "agent_api_port", default=8100)),
            graph_api_port=_env_int("GRAPH_API_PORT", get("services", "graph_api_port", default=8101)),
            kb_api_port=_env_int("KB_API_PORT", get("services", "kb_api_port", default=8102)),
            agent_api_url=str(_env("AGENT_API_URL", get("services", "agent_api_url", default="http://localhost:8100"))),
            graph_api_url=str(_env("GRAPH_API_URL", get("services", "graph_api_url", default="http://localhost:8101"))),
            kb_api_url=str(_env("KB_API_URL", get("services", "kb_api_url", default="http://localhost:8102"))),
            ollama_url=str(_env("OLLAMA_URL", get("services", "ollama_url", default="http://localhost:11434/api/generate"))),
            opensearch_host=str(_env("OPENSEARCH_HOST", get("services", "opensearch_host", default="localhost"))),
            opensearch_port=_env_int("OPENSEARCH_PORT", get("services", "opensearch_port", default=9200)),
            opensearch_scheme=str(_env("OPENSEARCH_SCHEME", get("services", "opensearch_scheme", default="http"))),
            opensearch_username=str(_env("OPENSEARCH_USERNAME", get("services", "opensearch_username", default=""))),
            opensearch_password=str(_env("OPENSEARCH_PASSWORD", get("services", "opensearch_password", default=""))),
            opensearch_verify_certs=_env_bool("OPENSEARCH_VERIFY_CERTS", get("services", "opensearch_verify_certs", default=False)),
            opensearch_ca_certs=_path(ca_value) if ca_value else None,
            opensearch_timeout=_env_int("OPENSEARCH_TIMEOUT", get("timeouts", "opensearch_seconds", default=30)),
            index_safety_prefix=str(_env("OPENSEARCH_INDEX_SAFETY_PREFIX", get("indexes", "safety_prefix", default="ericsson-ran-kb-"))).lower(),
            child_alias=str(_env_first(
                ("OPENSEARCH_CHILD_ALIAS", "OPENSEARCH_CHUNK_ALIAS"),
                get("indexes", "child_alias", default=get("indexes", "chunk_alias", default="ericsson-ran-kb-children")),
            )).lower(),
            child_backing_prefix=str(_env_first(
                ("OPENSEARCH_CHILD_BACKING_PREFIX", "OPENSEARCH_CHUNK_BACKING_PREFIX"),
                get("indexes", "child_backing_prefix", default=get("indexes", "chunk_backing_prefix", default="ericsson-ran-kb-children-v")),
            )).lower(),
            parent_alias=str(_env("OPENSEARCH_PARENT_ALIAS", get("indexes", "parent_alias", default="ericsson-ran-kb-parents"))).lower(),
            parent_backing_prefix=str(_env("OPENSEARCH_PARENT_BACKING_PREFIX", get("indexes", "parent_backing_prefix", default="ericsson-ran-kb-parents-v"))).lower(),
            manifest_alias=str(_env("OPENSEARCH_MANIFEST_ALIAS", get("indexes", "manifest_alias", default="ericsson-ran-kb-manifests"))).lower(),
            manifest_backing_prefix=str(_env("OPENSEARCH_MANIFEST_BACKING_PREFIX", get("indexes", "manifest_backing_prefix", default="ericsson-ran-kb-manifests-v"))).lower(),
            index_shards=_env_int("OPENSEARCH_INDEX_SHARDS", get("indexes", "number_of_shards", default=1)),
            index_replicas=_env_int("OPENSEARCH_INDEX_REPLICAS", get("indexes", "number_of_replicas", default=0)),
            vector_engine=str(_env("OPENSEARCH_VECTOR_ENGINE", get("indexes", "vector_engine", default="lucene"))).lower(),
            vector_space_type=str(_env("OPENSEARCH_VECTOR_SPACE", get("indexes", "vector_space_type", default="cosinesimil"))).lower(),
            hnsw_m=_env_int("OPENSEARCH_HNSW_M", get("indexes", "hnsw_m", default=16)),
            hnsw_ef_construction=_env_int("OPENSEARCH_HNSW_EF_CONSTRUCTION", get("indexes", "hnsw_ef_construction", default=100)),
            knn_ef_search=_env_int("OPENSEARCH_KNN_EF_SEARCH", get("indexes", "knn_ef_search", default=100)),
            prepared_root=prepared_root,
            markdown_root=markdown_root,
            combined_manifest=combined_manifest,
            feature_manifest_root=feature_manifest_root,
            package_manifest_root=package_manifest_root,
            topic_manifest_root=topic_manifest_root,
            mentioned_feature_manifest_root=mentioned_feature_manifest_root,
            embedding_model_path=_path(_env("EMBEDDING_MODEL_PATH", get("paths", "embedding_model_path", default="models/bge-large-en-v1.5"))),
            reranker_model_path=_path(_env("RERANKER_MODEL_PATH", get("paths", "reranker_model_path", default="models/ms-marco-MiniLM-L-12-v2"))),
            logs_dir=_path(_env("LOGS_DIR", get("paths", "logs_dir", default="logs"))),
            audit_db_path=_path(_env("AUDIT_DB_PATH", get("paths", "audit_db_path", default="data/ericsson_agent_audit.db"))),
            kb_asset_url_prefix=str(_env("KB_ASSET_URL_PREFIX", get("services", "kb_asset_url_prefix", default="/kb-assets/"))),
            embedding_device=str(_env("EMBEDDING_DEVICE", get("models", "embedding_device", default="cpu"))),
            embedding_batch_size=_env_int("EMBEDDING_BATCH_SIZE", get("models", "embedding_batch_size", default=32)),
            embedding_max_input_tokens=_env_int(
                "EMBEDDING_MAX_INPUT_TOKENS",
                get("models", "embedding_max_input_tokens", default=0),
            ),
            embedding_normalize=_env_bool("EMBEDDING_NORMALIZE", get("models", "embedding_normalize", default=True)),
            reranker_enabled=_env_bool("USE_RERANKER", get("models", "reranker_enabled", default=False)),
            reranker_device=str(_env("RERANKER_DEVICE", get("models", "reranker_device", default="cpu"))),
            llm_enabled=_env_bool("LLM_ENABLED", get("models", "llm_enabled", default=True)),
            local_files_only=_env_bool("LOCAL_FILES_ONLY", get("models", "local_files_only", default=True)),
            ollama_model=str(_env("OLLAMA_MODEL", get("models", "ollama_model", default="qwen2.5:14b"))),
            ollama_verbose=_env_bool("OLLAMA_VERBOSE", get("logging", "ollama_verbose", default=False)),
            ollama_log_prompt_max_chars=_env_int(
                "OLLAMA_LOG_PROMPT_MAX_CHARS",
                get("logging", "ollama_log_prompt_max_chars", default=12000),
            ),
            ollama_log_response_max_chars=_env_int(
                "OLLAMA_LOG_RESPONSE_MAX_CHARS",
                get("logging", "ollama_log_response_max_chars", default=12000),
            ),
            default_limit=_env_int("DEFAULT_KB_LIMIT", get("retrieval", "default_limit", default=5)),
            maximum_limit=_env_int("MAXIMUM_KB_LIMIT", get("retrieval", "maximum_limit", default=100)),
            initial_candidate_count=_env_int("INITIAL_CANDIDATE_COUNT", get("retrieval", "initial_candidate_count", default=50)),
            rrf_rank_constant=_env_int("RRF_RANK_CONSTANT", get("retrieval", "rrf_rank_constant", default=60)),
            bm25_content_boost=_env_float("BM25_CONTENT_BOOST", get("retrieval", "bm25_content_boost", default=2.0)),
            bm25_heading_boost=_env_float("BM25_HEADING_BOOST", get("retrieval", "bm25_heading_boost", default=3.0)),
            bm25_title_boost=_env_float("BM25_TITLE_BOOST", get("retrieval", "bm25_title_boost", default=2.5)),
            feature_association_boost=_env_float("FEATURE_ASSOCIATION_BOOST", get("retrieval", "feature_association_boost", default=0.08)),
            manifest_priority_boost=_env_float("MANIFEST_PRIORITY_BOOST", get("retrieval", "manifest_priority_boost", default=0.001)),
            allow_bm25_only=_env_bool("ALLOW_BM25_ONLY", get("retrieval", "allow_bm25_only", default=True)),
            require_parent_context=_env_bool("REQUIRE_PARENT_CONTEXT", get("retrieval", "require_parent_context", default=True)),
            verify_parent_content_hash=_env_bool("VERIFY_PARENT_CONTENT_HASH", get("retrieval", "verify_parent_content_hash", default=True)),
            parent_max_tokens=_env_int("PARENT_MAX_TOKENS", get("chunking", "parent_max_tokens", default=3000)),
            child_max_tokens=_env_int("CHILD_MAX_TOKENS", get("chunking", "child_max_tokens", default=300)),
            child_overlap_tokens=_env_int("CHILD_OVERLAP_TOKENS", get("chunking", "child_overlap_tokens", default=60)),
            minimum_chunk_tokens=_env_int("MINIMUM_CHUNK_TOKENS", get("chunking", "minimum_chunk_tokens", default=20)),
            keep_procedure_sections=_env_bool("KEEP_PROCEDURE_SECTIONS", get("chunking", "keep_procedure_sections", default=True)),
            procedure_max_tokens=_env_int("PROCEDURE_MAX_TOKENS", get("chunking", "procedure_max_tokens", default=480)),
            add_heading_to_children=_env_bool("ADD_HEADING_TO_CHILDREN", get("chunking", "add_heading_to_children", default=True)),
            include_manifest_facts=_env_bool("INCLUDE_MANIFEST_FACTS", get("chunking", "include_manifest_facts", default=False)),
            include_document_preamble=_env_bool("INCLUDE_DOCUMENT_PREAMBLE", get("chunking", "include_document_preamble", default=True)),
            embedding_input_mode=_env_choice(
                "EMBEDDING_INPUT_MODE",
                str(get("chunking", "embedding_input_mode", default="content")),
                {"content", "content_plus_metadata"},
            ),
            graph_enabled=_env_bool("GRAPH_ENABLED", get("feature_flags", "graph_enabled", default=False)),
            auth_enabled=_env_bool("AUTH_ENABLED", get("feature_flags", "auth_enabled", default=False)),
            session_memory_enabled=_env_bool("SESSION_MEMORY_ENABLED", get("feature_flags", "session_memory_enabled", default=True)),
            enable_llm_query_rewrite=_env_bool(
                "ENABLE_LLM_QUERY_REWRITE",
                get("feature_flags", "enable_llm_query_rewrite", default=True),
            ),
            audit_enabled=_env_bool("AUDIT_ENABLED", get("feature_flags", "audit_enabled", default=True)),
            strict_vendor_filter=_env_bool("STRICT_VENDOR_FILTER", get("feature_flags", "strict_vendor_filter", default=True)),
            allowed_emails=tuple(x for x in (str(v).strip() for v in allowed_values or []) if x),
            neo4j_uri=str(_env("NEO4J_URI", get("services", "neo4j_uri", default="bolt://localhost:7687"))),
            neo4j_user=str(_env("NEO4J_USER", get("services", "neo4j_user", default="neo4j"))),
            neo4j_password=str(_env("NEO4J_PASSWORD", get("services", "neo4j_password", default=""))),
            neo4j_database=str(_env("NEO4J_DATABASE", get("services", "neo4j_database", default="ericsson"))),
            redis_url=str(_env("REDIS_URL", get("services", "redis_url", default=""))),
            redis_host=str(_env("REDIS_HOST", get("services", "redis_host", default="localhost"))),
            redis_port=_env_int("REDIS_PORT", get("services", "redis_port", default=6379)),
            redis_db=_env_int("REDIS_DB", get("services", "redis_db", default=0)),
            redis_password=str(_env("REDIS_PASSWORD", get("services", "redis_password", default=""))),
            redis_key_prefix=(
                str(_env("REDIS_KEY_PREFIX", get("services", "redis_key_prefix", default="ericsson:session:"))).strip()
                or "ericsson:session:"
            ),
            redis_ssl=_env_bool("REDIS_SSL", get("services", "redis_ssl", default=False)),
            redis_socket_timeout=_env_float(
                "REDIS_SOCKET_TIMEOUT",
                get("timeouts", "redis_seconds", default=5.0),
            ),
            redis_connect_timeout=_env_float(
                "REDIS_CONNECT_TIMEOUT",
                get("timeouts", "redis_connect_seconds", default=3.0),
            ),
            # Prefer the exact Nokia variable names while accepting the earlier
            # Ericsson aliases for a non-breaking upgrade.
            session_ttl_seconds=_env_first_int(
                ("SESSION_TTL", "SESSION_TTL_SECONDS"),
                get("limits", "session_ttl_seconds", default=3600),
            ),
            max_session_history=_env_first_int(
                ("MAX_HISTORY", "MAX_SESSION_HISTORY"),
                get("limits", "max_session_history", default=5),
            ),
            session_history_answer_chars=_env_int(
                "SESSION_HISTORY_ANSWER_CHARS",
                get("limits", "session_history_answer_chars", default=2000),
            ),
            session_stored_answer_chars=_env_int(
                "SESSION_STORED_ANSWER_CHARS",
                get("limits", "session_stored_answer_chars", default=4000),
            ),
            kb_timeout=_env_int("KB_TIMEOUT", get("timeouts", "kb_seconds", default=90)),
            graph_timeout=_env_int("GRAPH_TIMEOUT", get("timeouts", "graph_seconds", default=30)),
            ollama_timeout=_env_int("OLLAMA_TIMEOUT", get("timeouts", "ollama_seconds", default=600)),
        )


_SETTINGS: Optional[Settings] = None


def get_settings(*, reload: bool = False) -> Settings:
    global _SETTINGS
    if _SETTINGS is None or reload:
        _SETTINGS = Settings.load()
    return _SETTINGS
