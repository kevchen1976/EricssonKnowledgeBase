"""HTTP clients used by the Ericsson agent service."""
from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional
from urllib.parse import quote, urljoin

import httpx

from .logging_utils import current_request_id, outbound_trace_headers
from .settings import Settings


logger = logging.getLogger("ericsson_agent")


class ServiceClientError(RuntimeError):
    pass


def _bounded_log_text(value: object, max_chars: int) -> tuple[str, int, bool]:
    """Return text bounded only for logs; the outbound Ollama payload is untouched."""
    text = str(value or "")
    original_chars = len(text)
    if max_chars > 0 and original_chars > max_chars:
        return text[:max_chars].rstrip() + "\n...[log truncated]", original_chars, True
    return text, original_chars, False


def _ollama_log_payload(body: Dict[str, Any], *, prompt_limit: int) -> tuple[Dict[str, Any], int, bool, int, bool]:
    logged = dict(body)
    prompt, prompt_chars, prompt_truncated = _bounded_log_text(logged.get("prompt", ""), prompt_limit)
    logged["prompt"] = prompt
    system, system_chars, system_truncated = _bounded_log_text(logged.get("system", ""), prompt_limit)
    if "system" in logged:
        logged["system"] = system
    return logged, prompt_chars, prompt_truncated, system_chars, system_truncated


def _endpoint(base: str, path: str) -> str:
    return urljoin(base.rstrip("/") + "/", path.lstrip("/"))


@dataclass
class KBClient:
    settings: Settings

    def _request(self, method: str, path: str, **kwargs: Any) -> Dict[str, Any]:
        headers = outbound_trace_headers(kwargs.pop("headers", None))
        try:
            with httpx.Client(timeout=self.settings.kb_timeout) as client:
                response = client.request(
                    method,
                    _endpoint(self.settings.kb_api_url, path),
                    headers=headers,
                    **kwargs,
                )
                response.raise_for_status()
                payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise ServiceClientError(f"Ericsson KB API request failed: {exc}") from exc
        if not isinstance(payload, dict):
            raise ServiceClientError("Ericsson KB API returned a non-object response")
        return payload

    def search(self, query: str, *, limit: int, filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self._request(
            "POST",
            "/kb/search",
            json={"query": query, "limit": limit, "filters": filters or {}},
        )

    def retrieve_feature(
        self,
        feature_id: str,
        query: str,
        *,
        limit: int,
        include_related: bool = True,
    ) -> Dict[str, Any]:
        path = f"/kb/feature/{quote(feature_id, safe='')}/retrieve"
        return self._request(
            "POST",
            path,
            json={"query": query, "limit": limit, "include_related": include_related},
        )

    def retrieve_package(self, package_id: str, query: str, *, limit: int) -> Dict[str, Any]:
        path = f"/kb/package/{quote(package_id, safe='')}/retrieve"
        return self._request("POST", path, json={"query": query, "limit": limit})

    def health(self) -> Dict[str, Any]:
        return self._request("GET", "/health")


@dataclass
class GraphClient:
    settings: Settings

    def _request(self, path: str, *, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        headers = outbound_trace_headers()
        try:
            with httpx.Client(timeout=self.settings.graph_timeout) as client:
                response = client.get(
                    _endpoint(self.settings.graph_api_url, path),
                    params=params,
                    headers=headers,
                )
                response.raise_for_status()
                payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise ServiceClientError(f"Ericsson graph API request failed: {exc}") from exc
        if not isinstance(payload, dict):
            raise ServiceClientError("Ericsson graph API returned a non-object response")
        return payload

    def feature_context(self, feature_id: str) -> Dict[str, Any]:
        return self._request(f"/feature/{quote(feature_id, safe='')}/context")

    def package_context(self, package_id: str) -> Dict[str, Any]:
        return self._request(f"/package/{quote(package_id, safe='')}/context")

    def search_context(self, query: str, *, limit: int = 20) -> Dict[str, Any]:
        return self._request("/relations/search", params={"query": query, "limit": limit})


@dataclass
class OllamaClient:
    settings: Settings

    def generate(
        self,
        prompt: str,
        *,
        system: str = "",
        temperature: float = 0.1,
        purpose: str = "general",
    ) -> str:
        if not self.settings.llm_enabled:
            raise ServiceClientError("LLM generation is disabled")

        body: Dict[str, Any] = {
            "model": self.settings.ollama_model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": temperature},
        }
        if system:
            body["system"] = system

        purpose_value = str(purpose or "general").strip() or "general"
        request_id = current_request_id()
        if self.settings.ollama_verbose:
            logged_body, prompt_chars, prompt_truncated, system_chars, system_truncated = _ollama_log_payload(
                body,
                prompt_limit=self.settings.ollama_log_prompt_max_chars,
            )
            logger.info("=" * 80)
            logger.info(
                "[OLLAMA REQUEST] purpose=%s url=%s model=%s prompt_chars=%d prompt_truncated=%s "
                "system_chars=%d system_truncated=%s",
                purpose_value,
                self.settings.ollama_url,
                self.settings.ollama_model,
                prompt_chars,
                prompt_truncated,
                system_chars,
                system_truncated,
            )
            logger.info("[OLLAMA REQUEST PAYLOAD]\n%s", json.dumps(logged_body, indent=2, ensure_ascii=False))
            logger.info("=" * 80)

        started = time.perf_counter()
        status_code: int | None = None
        try:
            with httpx.Client(timeout=self.settings.ollama_timeout) as client:
                response = client.post(self.settings.ollama_url, json=body)
                status_code = response.status_code
                response.raise_for_status()
                payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            latency_ms = (time.perf_counter() - started) * 1000.0
            logger.error(
                "[OLLAMA ERROR] purpose=%s status=%s latency_ms=%.1f error=%s",
                purpose_value,
                status_code if status_code is not None else "n/a",
                latency_ms,
                exc,
            )
            raise ServiceClientError(f"Ollama generation failed: {exc}") from exc

        latency_ms = (time.perf_counter() - started) * 1000.0
        if not isinstance(payload, dict):
            logger.error(
                "[OLLAMA ERROR] purpose=%s status=%s latency_ms=%.1f error=non-object-response",
                purpose_value,
                status_code if status_code is not None else "n/a",
                latency_ms,
            )
            raise ServiceClientError("Ollama returned a non-object response")

        text = str(payload.get("response") or payload.get("message", {}).get("content") or "").strip()

        if self.settings.ollama_verbose:
            logged_payload = dict(payload)
            response_text, response_chars, response_truncated = _bounded_log_text(
                text,
                self.settings.ollama_log_response_max_chars,
            )
            if "response" in logged_payload:
                logged_payload["response"] = response_text
            elif isinstance(logged_payload.get("message"), dict):
                message = dict(logged_payload["message"])
                message["content"] = response_text
                logged_payload["message"] = message
            logger.info("=" * 80)
            logger.info(
                "[OLLAMA RESPONSE] purpose=%s status=%s latency_ms=%.1f response_chars=%d response_truncated=%s "
                "eval_count=%s prompt_eval_count=%s total_duration=%s",
                purpose_value,
                status_code if status_code is not None else "n/a",
                latency_ms,
                response_chars,
                response_truncated,
                payload.get("eval_count"),
                payload.get("prompt_eval_count"),
                payload.get("total_duration"),
            )
            logger.info("[OLLAMA RESPONSE PAYLOAD]\n%s", json.dumps(logged_payload, indent=2, ensure_ascii=False))
            logger.info("=" * 80)

        if not text:
            raise ServiceClientError(f"Ollama returned no response text: {json.dumps(payload)[:500]}")
        return text
