"""Application state for the standalone Ericsson agent API."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

from agent_core.audit import AuditStore
from agent_core.logging_utils import configure_file_logger
from agent_core.settings import Settings, get_settings
from agent_core.workflow import EricssonAgent

from .sessions import SessionStore


@dataclass
class AgentServiceState:
    settings: Settings
    agent: EricssonAgent
    audit: AuditStore
    sessions: SessionStore
    logger: logging.Logger


_STATE: Optional[AgentServiceState] = None


def get_state(*, reload: bool = False) -> AgentServiceState:
    global _STATE
    if _STATE is None or reload:
        if reload and _STATE is not None:
            _STATE.sessions.close()
        settings = get_settings(reload=reload)
        logger = configure_file_logger(
            "ericsson_agent",
            settings.logs_dir / "ericsson_agent.log",
        )
        sessions = SessionStore(
            enabled=settings.session_memory_enabled,
            max_turns=settings.max_session_history,
            ttl_seconds=settings.session_ttl_seconds,
            redis_url=settings.redis_url,
            redis_host=settings.redis_host,
            redis_port=settings.redis_port,
            redis_db=settings.redis_db,
            redis_password=settings.redis_password,
            redis_ssl=settings.redis_ssl,
            key_prefix=settings.redis_key_prefix,
            socket_timeout=settings.redis_socket_timeout,
            connect_timeout=settings.redis_connect_timeout,
            stored_answer_chars=settings.session_stored_answer_chars,
        )
        _STATE = AgentServiceState(
            settings=settings,
            agent=EricssonAgent(settings),
            audit=AuditStore(settings.audit_db_path, enabled=settings.audit_enabled),
            sessions=sessions,
            logger=logger,
        )
    return _STATE
