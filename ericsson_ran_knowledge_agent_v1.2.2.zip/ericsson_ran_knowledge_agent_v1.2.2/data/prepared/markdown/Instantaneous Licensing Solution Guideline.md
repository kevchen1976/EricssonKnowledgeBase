<!-- page: 1 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Solution Guide         392/22112-IPM10141/100 Uen K

Instantaneous Licensing Solution Guideline

Contents

1
Introduction

2
Principles and Guidelines

2.1
Terminology and Concepts

2.2
Solution Overview

2.3
LCS and BB-HCS Activation Rule

3
Connected Mode IL

3.1
License Refresh

3.2
Software Upgrade

3.3
Node Integration

3.4
Capacity Expansion

3.5
Node Expansion to Support Additional Radio Access Technology

3.6
Hardware Resource Migration to IL

3.7
Hardware Migration from Old to New Radio Node Unit

3.8
Feature Activation

3.9
Return of Licenses

4
Non-Connected Mode

4.1
Common Process from LRF Generation until LKF Installation

4.2
Node Integration

4.3
Capacity Expansion

4.4
Node Expansion to Support Additional Radio Access Technology

4.5
Hardware Resource Migration to IL

4.6
Hardware Migration from Old to New Radio Node Unit

4.7
Feature Activation

4.8
Software Upgrade

4.9
License Refresh

4.10
Return of Licenses

5
Solution Guideline Change History

about:blank
1/41

<!-- page: 2 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

1   Introduction

This document provides an overview of the Instantaneous Licensing (IL) solution with its two deployment options:

– Connected Mode

– Non-Connected Mode.

It outlines the main IL solution use cases and provides links to more detailed information.

The IL solution allows to use licensed features right away without having to install a new License Key File (LKF). Licenses
are given temporarily while the LKF is being generated.

This document is for solution architects and field technicians who work in pre-sales, network design, and solution
deployment.

Section Principle and Guidelines presents a general overview of the IL solution. Section Connected Mode outlines the
Connected Mode IL and section Non-Connected Mode summarizes the Non-Connected Mode IL.

For the Migration to Instantaneous Licensing, see:

– Migrate to Connected Mode Instantaneous Licensing User Guide

– Migrate to Non-Connected Mode Instantaneous Licensing User Guide

about:blank
2/41

<!-- page: 3 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

2   Principles and Guidelines

This section offers an overview of the IL solution, including related concepts and key considerations for deploying the
solution design.

2.1   Terminology and Concepts

Table 1    IL Terminology

Terminology
Description

License
A license is a permit from a licensor to a licensee to use a
software feature or capacity under intellectual property
laws.

Hardware Activation Code
An HWAC provides access to hardware-related
capabilities, that is hardware-related features and
hardware-related capacities. HWACs are represented by
keys in the LKF.

Software Feature
A software feature enables a specific software function in
a specific node.

Software Capacity
A software capacity enables the user to activate resources
to meet the current traffic requirements.

Hardware-Related Feature
A hardware-related feature enhances hardware
functionality.

Hardware-Related Capacity
A hardware-related capacity allows the operator to
enable HW resources.

Instantaneous Licensing
The IL solution allows operators to use licensed features
right away without having to install a new License Key
File (LKF). Licenses are given temporarily while the LKF is
being generated.

Key
A key represents a license or an HWAC in the LKF.
Installed in the node, a key enables a capacity or a
feature. Each key is marked with a start time and a stop
time, and the key is valid only between those times.
Several keys can be contained in one LKF.

Late LKF Binding
Instantaneous Licensing modifies the node integration
process, enabling node integration without LKF. LKF will
be requested, created, and installed after the node
integration.

License Key File (LKF)
The LKF contains the license keys and HWAC keys that
enable functions and capacities for one specific node. The
file is a human-readable text file in XML format. The
latest file installed is the valid one. One node can have
only one LKF at a given time.

License Key Manager (LKM)
The License Key Manager is an application in SSP used to
import node LRFs as input for the generation of an LKF
used for license activation, upgrade, and regeneration for
nodes. The SSP-LKM is used for manual license handling
and non-connected instantaneous licensing.

License Request File (LRF)
A node-generated file that contains the current license
and HWAC demand. This file is used as input in SSP-LKM
to generate License Key File (LKF).

Instantaneous Licensing Perpetual for RAN
The Instantaneous Licensing Perpetual for RAN:
CXC4012700 is a special license, which must be present

about:blank
3/41

<!-- page: 4 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

on the node, which is sending Instantaneous Licensing
requests.

Utility Module
An alternative term for radio node Capacity HWAC. Used
for differentiating HWAC types. Module types are
differentiated by capacity provided (throughput and
spectrum) as well as function (initial module and
expansion module).

Initial Module
A type of utility module. Enables hardware functionality
on the unit that it is installed for. The capacity the module
provides depends on the module type. One hardware unit
can have no more than one initial module installed.

Expansion Module
A type of utility module. Extends the capacity provided by
the initial module. The capacity the module provides
depends on the module type.

Hardware Utilization Package
A Hardware Utilization Package (HUP) is a collection of
utility modules handled as one package. Package types
are differentiated by capacity provided (throughput and
spectrum) as well as function (initial package and
expansion package).

Initial Package
A type of HUP. A collection of initial modules handled as
one package. One hardware unit can have no more than
one initial package installed.

Expansion Package
A type of HUP. A collection of expansion modules handled
as one package. The capacity the package provides
depends on the package type.

Fingerprint
The fingerprint is a logical name that uniquely identifies
the node.

2.2   Solution Overview

The Instantaneous Licensing (IL) solution automates license request and delivery on radio nodes. There are two variants of
IL solution deployment: Connected Mode and Non-Connected Mode.

2.2.1   Connected Mode Instantaneous Licensing

The IL solution in connected mode uses the Customer Access & Security (CAS) to create a secure connection between the
customer network and the Ericsson network for all Ericsson services. The LKF requests can be initiated by the user
from ENM, or directly from radio nodes.

about:blank
4/41

<!-- page: 5 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Figure 1   Connected Mode IL - Simplified View

The figure above provides an overview of the connected mode IL:

– The customer unit defines LCS and BB-HCS in the IL Manager according to contractual agreements.

– An LKF request is either manually triggered or automated, depending on the use case.

– An operator can optionally view information in the IL Manager.

2.2.2   Non-Connected Mode Instantaneous Licensing

about:blank
5/41

![Figure on page 5](Instantaneous_Licensing_Solution_Guideline_images/page_005_image_001.png)

<!-- page: 6 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

The IL solution in non-connected mode automates license calculation and generation of License Request Files through
SSP-LKM and ELIS, to simplify the overall process of obtaining LKF without the need for CAS connections.

Figure 2   Non-Connected Mode IL - Simplified View

The figure above provides an overview of the non-connected mode IL:

– The customer unit defines LCS and BB-HCS in the IL Manager according to contractual agreements.

– Using the designated Python script running on the ENM scripting instance, an operator generates a license demand

calculation in the radio node.

– Based on the calculated license demand, either a customer unit or an operator requests the LKF in SSP-LKM, which

can then be downloaded once generated.

– The operator imports the LKF into ENM and installs the LKF on the radio node.

– An operator can optionally view information in the IL Manager.

The IL solution supports multiple use cases in connected and non-connected modes. For detailed information, see
Instantaneous Licensing and Manage Licenses and Hardware Activation Codes.

For step-by-step guidance on using the IL solution in different use cases, refer to section Connected Mode and section Non-
Connected Mode.

2.2.3   Network Elements

This section provides information regarding the Network Elements involved in the IL solution.

2.2.3.1   Radio Node

The radio node performs various functions like an automatic trigger of an LKF request in connected mode or the LRF
generation in non-connected mode. For detailed information, see Instantaneous Licensing and Manage Licenses and

about:blank
6/41

![Figure on page 6](Instantaneous_Licensing_Solution_Guideline_images/page_006_image_001.png)

<!-- page: 7 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Hardware Activation Codes.

2.2.3.2   ENM

The Ericsson Network Manager (ENM) plays different roles in the two modes of the IL solution:

– In connected mode, ENM mediates the sending of a license requests and license keys between radio nodes and

ELIS.

– In non-connected mode, a designated Python script is provided running on the ENM scripting instance for the

License Request Generation and the Software and Hardware Manager (SHM) for importing the License Keys.

For more specific information on ENM’s support for Instantaneous Licensing solution, see the following ENM documents:

– ENM Configuration System Administrator Guide: Integration of CAS-C and configurable parameters in ENM for IL

solution

– Software Hardware Manager: Create different license key job and import license keys using SHM in ENM for IL

solution

For more information on ENM specific network requirements (including software requirements) for deploying the IL
solution, see Instantaneous Licensing.

2.2.3.3   CAS

Customer Access & Security (CAS) is a part of Instantaneous Licensing in connected mode. CAS creates a standardized and
secure connection between the customer network and the Ericsson network for all Ericsson services.

CAS comprises the following two Network Elements:

– CAS-C: The environment at the operator side for hosting all Ericsson service delivery solutions.

– CAS-E: The Access Network towards customer networks for all Ericsson solutions and service personnel.

In the IL solution, CAS is used to connect the operator’s Ericsson Network Manager (ENM) and the Ericsson License
Information System (ELIS). An IPsec tunnel connects the CAS-C within the customer network and the CAS-E in the
Ericsson network. Proxies on CAS-C and CAS-E are used to handle the LKF requests and responses.

2.2.3.4   ELIS

The Ericsson Electronic Licensing Solution (ELIS) is a web-based entitlement management system for software licenses
and HWACs.

It is used for activating licenses, HWACs, and for managing license pools. ELIS generates the License Authorization Code
(LAC) letter and the requested LKF.

ELIS stores completed purchase orders for each customer based on their respective Software License Targets. ELIS is also
used to handle LKF requests, and to initiate the LKF delivery process.

2.2.3.5   IL Manager

The Instantaneous Licensing (IL) Manager tool is a web based solution used to define LCS and BB-HCS, as part of the
Software Asset Management (SAM) application.

In the IL Manager, Ericsson internal users can create and manage LCS and BB-HCS, connect, and disconnect hardware
resources to LCS, configure the IL settings for an operator, and manage Exemption Request for HW Migration.

IL Manager allows the operator to see information related to the configurations of Instantaneous Licensing, without any
interactions with the Customer Unit personnel. The information in IL Manager can only be read and not modified by the
operator. Information of the following configuration aspects is displayed:

– License Configuration Sets (LCS)

– Baseband Hardware Configuration Sets (BB-HCS)

about:blank
7/41

<!-- page: 8 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

– Exemptions

For more information on how to use IL Manager tool, see the IL Manager online User Guide, which is available inside the IL
Manager tool.

2.2.3.6   SSP-LKM

The License Key Management (LKM) is an application in the Self-Service Portal (SSP) used to import node License Request
File (LRFs) as input for the generation of an LKF ZIP file.

When LRF processing is completed, the respective LKF is generated and becomes available through a secure reference link
to the SSP-License Key File (LKF) Portal.

For more information on how to use the SSP-LKM, see the IL Non-Connected mode Activation online User Guide, which is
available inside the SSP-LKM tool.

2.3   LCS and BB-HCS Activation Rule

The License Configuration Set (LCS) and Baseband HWAC Configuration Set (BB-HCS) Activation Rule applies to
Instantaneous Licensing in connected and Instantaneous Licensing in non-connected mode.

2.3.1   LCS Activation Rule

A License Configuration Set (LCS) is a set of policies and configurations that can be applied to multiple nodes that require a
similar license setup.

The LCSs are stored in ELIS. The IL Manager is used by the customer unit to create LCS definitions. The definition of LCS is
used to select correct License Authorization Codes (LACs) to consume from and generate an LKF. The LCS definition is
independent of the software release version. For detailed information, see Manage Licenses and Hardware Activation
Codes.

Instantaneous Licensing LKFs created for capacity increase, feature activation and license refresh use cases do not
overwrite the existing LKF but add content based on the LCS configuration. Instantaneous Licensing LKFs created for the
software upgrade use case can change depending on the new release features.

2.3.1.1   Recommendation for LCS Setup

When defining the LCS/HCS setup, it is recommended to have one LCS which reflects the contract with the operator. More
LCSs are required to be created when:

– Spectrum and throughput price models are mixed in the network and there is a good commercial reason for this

setup. If there is no good reason, then prior migration to IL, ELIS cleanup is required to align the price model among
all radio nodes in the customer network.

– Payment models are mixed and there is a good commercial reason for this setup. Otherwise, cleanup is required prior

migration to IL, to align payment models at least on EPL level (e.g. buyout for LTE EPL and PAYG for NR

– A few HCSs are required. It is recommended to have a single HCS but if there are more HCSs required, the same

number of LCSs is required to be defined as well.

– There is a necessity to setup fixed license handling either:

• through Quantity, Follow BP Quantity setting in LCS or

• additional license configuration in a way that various fixed values are required for a single license object.

If multiple LCSs are created to manage the customer network the following cases require special attention:

– Migration to IL: the customer unit must provide a LCS_ID for each HWR

– Node Integration: the operator must decide which LCS_ID to pick

about:blank
8/41

<!-- page: 9 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

– Context of the node changes in terms of fixed configurations. Migration between LCSs must be performed which is

partially a manual process.

2.3.1.2   Payment Model

Payment models describe how operators buy capacity, over time, according to a level of functionality determined by the
Base Package (BP) and a choice of Value Packages (VP). Typically, an operator starts with the Base Package, then chooses
which Value Packages to buy, and then determines expected capacity requirements. Ericsson presents a payment model to
the operator, based on one of the available payment models:

– P/ - Pay as You Grow (PAYG)

– B/ - Capacity Buyout

– T/ - Term-based Licensing (TBL)

– S/ - Yearly Fee/Subscription

– N/ - Node Yearly Buyout

Note: During LCS Setup, the following Payment Model rules must be followed:

– Only a single Payment Model variant of a license object can be selected in LCS, e.g. when P/FAJ8014009/5LM is

selected in LCS, then it is not allowed to mix it with B/FAJ8014009/5LM or S/FAJ8014009/5LM

– Within a single market offering the following rules must be followed for all license objects:

• P/ BP can coexist with P/, B/, T/, S/ VPs

• B/ BP can only coexist with B/ VPs

• S/ BP can only coexist with S/ VPs

• T/ BP can only coexist with T/ VPs

• N/ BP can only coexist with N/ VPs

Not following payment rules can cause errors for the LKF Requests.

Such errors can happen if there is an inconsistency between the payment model activated on the radio node and the
payment model specified in the LCS. When a new license object is requested by the radio node, and payment model rules
are not met, LKF generation fails due to Activation Validation Set Rules (AVS) checks. Above rules must be met before
migration to IL.

For further LCS details, see Manage Licenses and Hardware Activation Codes.

2.3.2   BB-HCS Activation Rule

The Baseband HWAC Configuration Set (BB-HCS) provides information on which HWACs are needed to fulfill the radio
node request. It is recommended to manage all HWAC configurations for an EUFT within one BB-HCS. Creating multiple
HCSs requires creating a corresponding number of LCSs. The consequences of using multiple LCSs are described in the
Recommendation for LCS setup.

For more information, see Manage Licenses and Hardware Activation Codes.

about:blank
9/41

<!-- page: 10 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

3   Connected Mode IL

The Instantaneous Licensing solution in connected mode supports the following use cases:

– License Refresh: an existing node is updated with a new LKF.

– Software Upgrade: an existing node is updated with new software.

– Node Integration: new nodes are integrated in the network.

– Capacity Increase: additional capacity is added to the node.

– Node Expansion to support additional Radio Access Technology: an existing node is expanded with an additional

Radio Access Technology, to facilitate Ericsson Spectrum Sharing.

– Hardware Resource Migration to IL: Migration of an existing radio node to the IL solution.

– Hardware Migration from Old to New Radio Node Unit: a radio node unit is replaced with a new one.

– Feature Activation: a feature is activated in the node.

The following prerequisites need to be in place before connection mode IL operations:

– The Customer's network and Ericsson Network are connected by an IPsec secured VPN using CAS solution.

– The radio node is managed by an ENM with SHM capability, and the Instantaneous Licensing feature is enabled on

the radio node.

– Instantaneous Licensing is functional in the radio node, and it has established a secure HTTPS connection to an

HTTP server on ENM.

– On the radio node, the Instantaneous Licensing parameters (administrativeState, euft, swltId) are configured.

– On the radio node, the HTTPS MO configuration is required for the HTTP Secure service.

– All defined LCSs and HCSs are created and activated in SAM IL Manager.

The figure below shows the high level LKF request flow of the IL solution in connected mode.

about:blank
10/41

<!-- page: 11 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Figure 3   Connected Mode IL Operational Flow

Operational Process

1. Initiate LKF Requests: An LKF request is initiated in the ENM Software and Hardware Management (SHM) License

Administrator application. The request can also be triggered from the node, and automatically forwarded to ENM.

2. LKF Request Timer: Depending on the use case, the radio node starts a timer controlling the sending of the LKF

request.

3. ENM Sends LKF Request to ELIS: ENM sends the LKF request to ELIS using the CAS connection. At this step, there

is a timer in ENM that determines how long ENM waits before sending an LKF request to ELIS. There is another
timer in ENM that determines the duration and number of retries for resending the LKF request under abnormal
conditions:

about:blank
11/41

![Figure on page 11](Instantaneous_Licensing_Solution_Guideline_images/page_011_image_001.png)

<!-- page: 12 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

– The timer INSTANTANEOUS_LICENSE_BATCH_REQUEST_INTERVAL_IN_MINUTES in ENM is the timer interval

duration for sending requests to ELIS, and it is configurable.

– The REST/HTTPS LKF Request Retry Timer and number of retries in ENM define the time interval and the number

of times ENM retransmits the LKF Request, and they are not configurable.

For details, see the ENM CPI document: ENM Configuration System Administrator Guide, section Configurable
Parameters for Instantaneous Licensing.

4. Handle LKF Requests in ELIS: ELIS handles requests by translating and producing LKFs in batches (LKF package).

CAS-E initiates a delivery request to download and transfer the files to the CAS-C Dropbox.

5. Fetch LKF from CAS-C Dropbox: ENM monitors the CAS-C Dropbox at configurable intervals and fetches the LKF

when available. At this step, there are two configurable timers in ENM. For details, see the ENM CPI document: ENM
Configuration System Administrator Guide, section Configurable Parameters for Instantaneous Licensing.

– The timer INSTANTANEOUS_LICENSE_SCHEDULER_INTERVAL_IN_MINUTES represents the polling frequency

from ENM to the CAS-C Software Dropbox for the license packages delivered by ELIS.

– The timer INSTANTANEOUS_LICENSE_SCHEDULER_TIMEOUT_IN_MINUTES specifies the period after which

the LKF package scheduler marks a request's package delivery to CAS-C as timed out.

If packages arrive after this period, ENM does not collect them. Packages remain on the CAS-C Dropbox until the
Dropbox housekeeping removes them. If there is a time-out, this is reported with the error message "License delivery
from license generation server has timed out." CAS-C Dropbox housekeeping occurs after a file is untouched for 90
days.

6. Import LKFs in SMRS: SHM enables the import of the LKFs on Software Management Distribution Repository

Services (SMRS).

7. Install LKF on Radio Nodes: Based on the activity specified in each SHM job, LKFs are automatically installed on

the radio nodes.

3.1   License Refresh

The License Refresh use case automatically generates, delivers, and installs the LKF when there is a need to update the
node LKF. Such need can be enabling new optional features, adding new features, or removing existing ones on the radio
node. The update is based on the entitlements in the repository.

Figure 4   LKF Refresh from ENM SHM - Simplified View

Trigger License Key Refresh

The License Key Refresh operation can be triggered from a radio node or from ENM.

Option 1: License Key Refresh from Radio Node

about:blank
12/41

![Figure on page 12](Instantaneous_Licensing_Solution_Guideline_images/page_012_image_001.png)

<!-- page: 13 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Steps

1. Launch Command Line Interface to managed radio node using ENM or MOShell.

2. Trigger LKF refresh from the radio node by performing MO action InstantaneousLicensing.refreshKeyFile.

3. The radio node sends a refresh license key request to ENM. The Instantaneous Licensing process can be monitored

on the radio node by checking the InstantaneousLicensing.progressReport.state.

4. ENM SHM automatically creates a Refresh License Key Job when receiving refresh license key requests from the

radio node. This SHM Job includes Refresh, Request, and Install activities by default. See Software Hardware
Manager User Guide in the Ericsson Network Manager library.

5. Select the Jobs in the Main Jobs Page from ENM SHM UI, check Job Summary > View Job Logs to verify Refresh

activity is completed successfully.

Note: If the LKF request fails because of temporary problems, the auto-recovery mechanism is triggered. For more
information, see Instantaneous Licensing.

Option 2: License Key Refresh from ENM SHM

The License Key Refreshed can be triggered from the ENM SHM.

Steps

1. Log on ENM, open Software and Hardware Manager > License Administration > Refresh License Keys.

2. Follow the Refresh License Keys job wizard, input the necessary information and select specific radio node for

license refresh.

3. This Refresh License Keys job wizard contain three activities:

– Refresh: ENM starts an MO action InstantaneousLicensing.refreshKeyFile on the selected radio node to request

the LKF refresh process.

– Request: ENM sends the License Key Refresh request to ELIS.

– Install: License Installation in the selected nodes.

Note: valid combinations of Refresh License Key Activities for selected radio nodes by SHM job wizard are “Refresh +
Request” or “Refresh+ Request + Install”.

4. Refresh License Key job is displayed in the Main Jobs Page from ENM SHM UI. The job can be run manually,

immediately, or can be scheduled to run at a more suitable time.

5. Refresh License Key job execution begins with Refresh activity. ENM SHM starts an

InstantaneousLicensing.refreshKeyFile action in the selected radio nodes.

6. Radio nodes send a refresh license key request to ENM. The Instantaneous Licensing process can be monitored on

the radio node by checking the InstantaneousLicensing.progressReport.state.

7. Select the Jobs in the Main Jobs Page from ENM SHM UI, check Job Summary > View Job Logs to verify Refresh

activity is completed successfully.

Execution and Supervision of Request Activity in Refresh License Key job

Steps

1. During an Instantaneous License Batch Interval timer, ENM waits for LKF requests from other radio nodes.

Thereafter, ENM SHM formulates the refresh license requests and sends the refresh LKF request to ELIS through
CAS connection. The LKF Request activity can be monitored by checking ENM SHM Job Summary > View Job Logs.

2. ENM begins monitoring and polling the CAS-C Dropbox at configurable intervals for LKF package file delivered by

ELIS.

3. ELIS successfully generates LKFs and delivers LKF package file to CAS-C Dropbox.

4. ENM retrieves the LKF package file from CAS-C Dropbox and imports LKFs in Software Management Distribution

Repository Services (SMRS). The LKF Import process can be monitored by checking ENM SHM Job Summary > View
Job Logs.

about:blank
13/41

<!-- page: 14 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Execution and Supervision of Install Activity in Refresh License Key job

Steps

1. If the refresh license key request is triggered from the radio nodes (see Option 1 above) or the LKF Install activity is

selected during the creation of the Refresh License Key job through ENM SHM (see Option 2 above), ENM performs
the LKF Install activity by default on all radio nodes whose LKF has been successfully imported to SMRS.

2. ENM automatically triggers downloading and installation of the LKF on these radio nodes. The LKF Install activity

can be monitored by checking ENM SHM Job Summary > View Job Logs.

3. ENM SHM sends Refresh License Request Success to node. Check Main Jobs Result on ENM SHM to verify Jobs

Result is Success and Jobs Status is COMPLETED.

4. Optionally, check the MO InstantaneousLicensing.progressReport.state to see if it is FINISHED, and the MO

InstantaneousLicensing.progressReport.result to see if it is SUCCESS to verify the LKF Refresh use case has been
successfully completed in the radio node.

5. Verify that the MO KeyFileInformation.sequenceNumber shows that the new LKF with the next sequence number is

installed in the radio node.

3.2   Software Upgrade

The Software Upgrade use case automates the generation, delivery, and optional installation of the LKF on the radio node
for the software upgrade process.

An Upgrade License Key request using Instantaneous Licensing is initiated from ENM or the radio node and is completed
before proceeding with the software upgrade.

This section describes the following options to trigger a Software Upgrade License Key Request from:

– ENM SHM

– ENM ASU

– Radio Node

The optional usage of the Improved LKF Delivery Time during the Software Upgrade from ENM speeds up the LKF delivery
time.

If the LKF is not required before software upgrade, an upgrade triggered as LKF Refresh or LKF Expansion after the
software upgrade on a node is described.

Note 1: The new software release has to be entitled to the EUFT on ELIS before performing the Software Upgrade use case.
The procedure requires cooperation between the operator and the Customer Unit.

Note 2: If a new feature is available from the target software release and shall be used by the operator, it needs to be
ensured that the new Value Package is part of the LCS. If immediate activation of the Value Package is needed during
upgrade, regardless of the radio node requirement, the quantity setting must be specified in the LCS. The process requires
collaboration between the operator and the Customer Unit.

about:blank
14/41

<!-- page: 15 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Figure 5   License Request for Software Upgrade from ENM - Simplified View

Improved LKF Delivery Time during the Software Upgrade (Optional)

The optional Improved LKF Delivery Time during the Software Upgrade consists of two steps. In step 1, the Instantaneous
Licensing Non-Connected Mode Release Upgrade is used in SSP-LKM to generate the LKF for the new software. In step 2,
during the Upgrade RAN Software in ENM flow an LKF request is triggered to import and install the latest LKF.

Using an optional preparation phase (step 1) from SSP-LKM before software upgrade significantly shortens the LKF
request (step 2) lead time during the software upgrade from ENM and lowers the risk of failure. This functionality is
especially targeted at the operators with large networks. It can be used together with Upgrade License Key Request from
ENM ASU, or with Upgrade License Key Request from ENM SHM.

The figure below shows an example of a software upgrade using ASU visualizing the LKF request lead time gain when
using the preparation phase. The preparation phase uses the Instantaneous Licensing Non-Connected mode Release
Upgrade process in the SSP-LKM.

about:blank
15/41

![Figure on page 15](Instantaneous_Licensing_Solution_Guideline_images/page_015_image_001.png)

![Figure on page 15](Instantaneous_Licensing_Solution_Guideline_images/page_015_image_002.png)

<!-- page: 16 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Figure 6   Standard vs. Improved LKF Delivery Time during the Software Upgrade - ASU Example

For more information, see Considerations for Improved LKF Delivery Time during the Software Upgrade.

Trigger Upgrade License Key Request

The Upgrade License Key Request can be triggered from ENM SHM, ENM ASU, or radio node.

Option 1: Trigger Upgrade License Key Request from ENM SHM

Steps

1. Log on ENM, open Software and Hardware Manager > License Administration > Upgrade License Keys.

2. Follow the Upgrade License Keys wizard, input the necessary information and select specific radio node for upgrade

license keys.

3. This Upgrade License Key job wizard contains two activities:

– Request: ENM sends the Upgrade License Key request to ELIS.

– Install: License Installation in the selected nodes.

Note: Valid combinations of Upgrade License Key Activities for selected radio nodes through SHM job wizard are
“Request” or “Request + Install”.

4. Upgrade License Key job is displayed in the Main Jobs Page from ENM SHM. The job can be run manually,

immediately, or scheduled to run at a more suitable time.

Option 2: Trigger Upgrade License Key Request from ENM ASU

Steps

1. Log on ENM, open Flow Automation > Automated Software Upgrade and click on Start to setup an ASU flow

instance.

– Follow the ASU flow instance setup wizard, select Interactive setup type, input the necessary information include

radio nodes selected for upgrade license keys, Software Packages, and so on.

– At the step Selected Preparation Activities > Perform License Request to request & import licenses and Perform

Post-Install License Installation to install the latest key file imported in ENM for the radio nodes.

2. Review the ASU flow instance and confirm execution. ENM ASU sends the License Request to SHM, and SHM

automatically creates an Upgrade License Key job.

Option 3: Trigger Upgrade License Key Request from the Node

Steps

1. Set the InstantaneousLicensing.licenseSwReleaseTarget attribute on the node to the target software release.

2. Launch Command Line Interface to managed radio node using ENM or MOShell.

3. Trigger LKF refresh from the radio node by performing MO action InstantaneousLicensing.refreshKeyFile.

4. The radio node sends a refresh license key request to ENM. ENM SHM automatically creates a Refresh License Key

Job when receiving refresh license key requests from the radio node.

5. Select the Jobs in the Main Jobs Page from ENM SHM UI, check Job Summary > View Job Logs to verify the Refresh

activity is completed successfully.

Note: If the LKF request fails because of temporary problems, the auto-recovery mechanism is triggered.

For more information, see Instantaneous Licensing.

Execution and Supervision of Request Activity in Upgrade License Key job

Steps

about:blank
16/41

<!-- page: 17 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

1. During an Instantaneous License Batch Interval timer, ENM waits for LKF requests from other radio nodes.

Thereafter, SHM automatically sends the SW Upgrade LKF request towards ELIS through the CAS connection. The
LKF Request activity can be monitored by checking ENM SHM Job Summary > View Job Logs.

2. ENM begins monitoring and polling the CAS-C Dropbox at configurable intervals for LKF package file delivered by

ELIS.

3. ELIS successfully generates LKFs and delivers LKF package file to CAS-C Dropbox.

4. ENM retrieves the LKF package file from CAS-C Dropbox and imports LKFs in Software Management Distribution

Repository Services (SMRS). The LKF Import process can be monitored by checking ENM SHM Job Summary > View
Job Logs.

Execution and Supervision of Install Activity in Upgrade License Key Job

Steps

1. If LKF Install activity is selected during the creation of Upgrade License Key job through ENM SHM (see Option 1

above) or “Perform Post-Install License Installation” is selected during the creation of ASU flow instance (see Option
2 above), ENM performs the LKF Install activity by default on all radio nodes whose LKF has been successfully
imported to SMRS.

2. ENM automatically triggers LKF downloading and installation on these radio nodes. The LKF Install activity can be

monitored by checking ENM SHM Job Summary > View Job Logs.

3. Check Main Jobs Result on ENM SHM to verify Jobs Result is Success and Jobs Status is COMPLETED.

4. Verify that the MO KeyFileInformation.sequenceNumber shows that the new LKF with the next sequence number is

installed in the radio node.

Option 4: LKF Refresh or LKF Capacity Expansion After Software Upgrade on a Node

If the LKF is not required before software upgrade, an LKF Refresh or LKF Capacity Expansion after the software upgrade
on a node provides an updated LKF for the deployed software release.

3.2.1   Software Upgrade Options in Relation to IL

The figure below shows a simplified decision tree for LKF delivery in relation to the software upgrade. If an LKF is not
required before software upgrade, an LKF Refresh request can be triggered after software upgrade. If automatic LKF
request retries are required, a software upgrade from the radio node is needed. If an automated software upgrade is
required, the ASU must be chosen. Otherwise, the manual SHM software upgrade is used. The software upgrade options
from ENM support the Improved LKF Delivery Time during the Software Upgrade if needed.

about:blank
17/41

![Figure on page 17](Instantaneous_Licensing_Solution_Guideline_images/page_017_image_001.png)

<!-- page: 18 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Figure 7   Simplified Decision Tree for Connected Mode IL LKF Delivery During Software Upgrade

The table below provides an overview of the different Software Upgrade options in relation to fetching the LKF. It outlines
the major steps along with providing the advantages and disadvantages of each option.

Figure 8   Overview of Software Upgrade Options in Relation to LKF Fetching

3.2.2   Considerations for Improved LKF Delivery Time during the Software Upgrade

3.2.2.1   Improved LKF Delivery Time during the Software Upgrade and IL Use Case Interaction

Between the preparation phase for the Improved LKF Delivery Time during the Software Upgrade and the real software
upgrade, other Instantaneous Licensing use cases can take place. The figure below shows an example in which between
the preparation phase and the actual software upgrade a Capacity Expansion occurs.

In this example, the LKF Request during software upgrade provides an LKF with the same sequence number already
provided for the LKF triggered by the Capacity Expansion. This is done to optimize and speed up the LKF delivery as no LKF
changes occurred between the Capacity Expansion and the LKF Request for software upgrade. ENM reports the same
sequence number and same LKF content as already imported being an error “File already imported”. This error is no longer
reported since ENM 25.2 release. As the LKF with the appropriate sequence number was already imported, no further
actions are required by ENM to import the LKF with the sequence number X+2. It is recommended to proceed with the
software upgrade and install the LKF on the radio node if not done already. For more information, see Upgrade RAN
Software Manually in ENM and Upgrade RAN Software Using Automation Flow in ENM User Guides. New 24.Q4 features
are entitled in the LKF with sequence number X+1 or above but they can be enabled only after Software Upgrade in the
radio node to 24.Q4.

Figure 9   LKF Preparation - Capacity Expansion Interworking Example

Note: A valid LKF has a sequence number equal to or greater than the sequence number on the latest installed LKF. For
more information, see Manage Licenses and Hardware Activation Codes.

3.2.2.2   Network Case for Improved LKF Delivery Time during the Software Upgrade

about:blank
18/41

![Figure on page 18](Instantaneous_Licensing_Solution_Guideline_images/page_018_image_002.png)

<!-- page: 19 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

If the LKF lead time for Instantaneous Licensing use cases like radio node integration or Capacity Expansion shall be
minimized, coordination between the Improved LKF Delivery Time during the Software Upgrade preparation phase and the
Instantaneous Licensing use cases is required. In this case, it is recommended to avoid executing the Instantaneous
Licensing use cases at the same time as the Improved LKF Delivery Time during the Software Upgrade preparation phase.

The entire customer network or different network portions can be prepared using the Improved LKF Delivery Time during
the Software Upgrade preparation. Depending on the network size, the Improved LKF Delivery Time during the Software
Upgrade preparation phase can be split into several batch groups leaving room for Instantaneous Licensing use cases
between the batch groups execution. The software upgrades are planned during maintenance windows considering the
reduced LKF request time due to using the Improved LKF Delivery Time during the Software Upgrade preparation phase.

3.3   Node Integration

The Node Integration use case automates the generation and delivery of licenses needed for integrating the radio nodes
into the network. This use case ensures that each node is equipped with the required LKF for smooth integration.

Figure 10   Node Integration - Simplified View

This use case offers two suitable approaches for Instantaneous Licensing in connected mode. The recommended approach
is to integrate with Integration Unlock (IU), which is described in this section. An alternative option is to integrate with
Integration LKF.

Note: export-restricted features are not allowed to be used during Integration Unlock.

Generate Configuration Files using Configuration Generator

Before Node Integration, the radio node configuration files need to be generated using the Equipment Configuration Tool
(ECT) or other operator tools.

When generating configuration files, the licensing method is required to be configured. In ECT, select Automatic_with_IU as
the licensing method, the IntegrationUnlock value in the generated configuration files is set to active. For details, see
Manage Equipment Configuration Tool User Guide.

Integrate Radio Node using ENM AP

The radio node configuration files are imported into ENM with Auto Provisioning (AP), and the AP process is executed
successfully.

Steps

1. Log on ENM, open Provisioning > Auto Provisioning > Import, in the import wizard, upload the node configuration

files. These configuration files contain all the parameters such as node type, band, and so on.

about:blank
19/41

![Figure on page 19](Instantaneous_Licensing_Solution_Guideline_images/page_019_image_001.png)

<!-- page: 20 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

2. Once the configuration files are imported, the AP process is executed, and the detailed integration process is

displayed in the status window.

License Request using Integration with IU

The license request using Integration with IU is initiated after the radio node has been successfully integrated using the AP
process.

Steps

1. License Integration Unlock Activated alarm is raised.

2. Unlock the RAT of the radio node and activate the cell.

3. The radio node sends the Capacity Expansion LKF Request to ENM with a list of required licenses. ENM SHM

automatically creates a Capacity Expansion License job.

Note 1: Ifthe cell is not unlocked in Step 2, an empty Capacity Expansion LKF Request is automatically generated and sent
to ENM after one hour as defined by the IU timer.

Note 2: The integration processes varies depending on the operator. There are operators who power off the radio node
shortly after integration. The IU timer does not continue and expires when the radio node is powered off.

Execution and Supervision Capacity Request Job

Steps

1. ENM waits for other radio nodes requests, and after Instantaneous License Batch Interval timer, ENM SHM

formulates the Capacity Expansion LKF Requests and sends the LKF request towards ELIS through CAS connection.
The LKF Request activity can be monitored by checking ENM SHM Job Summary > View Job Logs.

2. ENM begins monitoring and polling the CAS-C Dropbox at configurable intervals for LKF package file delivered by

ELIS.

3. ELIS successfully generates LKFs and delivers LKF package file to CAS-C Dropbox.

4. ENM retrieves the LKF package file from CAS-C Dropbox and imports LKFs in Software Management Distribution

Repository Services (SMRS). The LKF Import process can be monitored by checking ENM SHM Job Summary > View
Job Logs.

Execution and Supervision of Install Activity in Capacity Request Job

Steps

1. ENM automatically triggers LKF downloading and installation on these radio nodes. The LKF Install activity can be

monitored by checking ENM SHM Job Summary > View Job Logs.

2. ENM SHM sends LKF Request Success to node. Check Main Jobs Result on ENM SHM to verify Jobs Result as

Success and Jobs Status as COMPLETED.

3. The License Integration Unlock Activated alarm is ceased after the LKF is installed in the radio node.

4. Optionally, Check the MO InstantaneousLicensing.expansionProgressReport.expansionStatus is set to

KEY_FILE_SUCCESSFUL to verify the Capacity Expansion license request use case is successfully completed in the
radio node

5. Verify that the MO KeyFileInformation.sequenceNumber shows that the LKF with sequence number above 1000 is

installed in the radio node.

3.4   Capacity Expansion

The Capacity Expansion use case automatically generates, delivers, and installs the required LKFs to increase node
capacity.

about:blank
20/41

<!-- page: 21 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Figure 11   Capacity Expansion - Simplified View

For Instantaneous Licensing in connected mode, the necessary license resources are granted immediately when a capacity
increase is needed, for example when additional output power is required. Instantaneous Licensing automatically
calculates the required license demand, submits the LKF request, and delivers the LKF.

Trigger License Key Request for Capacity Expansion

The License Key Request for Capacity Expansion is triggered from the radio node.

Steps

1. Launch Command Line Interface to managed radio node using ENM or MOShell.

2. Configure certain resources that require capacity controlled by license lock or reconfigure existing cells/sectors to

initiate an LKF Request for Capacity Expansion.

3. License System Triggered Unlock Activated alarm is raised. The temporary licenses are granted and enabled on the

radio node.

4. The radio node sends a Capacity Expansion LKF request to ENM. Check the radio node MO

InstantaneousLicensing.expansionProgressReport is set to KEY_FILE_REQUEST_SENT to verify LKF request for
Capacity Expansion is sent to ENM.

5. ENM SHM automatically creates a Capacity Expansion License job.

Execution and Supervision of Request Activity in Capacity Expansion License Key Job

Steps

1. ENM waits for the request from other radio nodes, and after Instantaneous License Batch Interval timer, ENM SHM

formulates the Capacity Expansion LKF Requests and sends the LKF request towards ELIS through CAS connection.

2. The LKF Request activity can be monitored by checking ENM SHM Job Summary > View Job Logs.

3. ENM begins monitoring and polling the CAS-C Dropbox at configurable intervals for LKF package file delivered by

ELIS.

4. ELIS successfully generates LKFs and delivers LKF package file to CAS-C Dropbox.

5. ENM retrieves the LKF package file from CAS-C Dropbox and imports LKFs in Software Management Distribution

Repository Services (SMRS). The LKF Import process can be monitored by checking ENM SHM Job Summary > View
Job Logs.

Execution and Supervision of Install Activity in Capacity Expansion License Key Job

Steps

about:blank
21/41

![Figure on page 21](Instantaneous_Licensing_Solution_Guideline_images/page_021_image_001.png)

<!-- page: 22 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

1. ENM performs the LKF Install activity by default on all radio nodes whose LKF for Capacity Expansion has been

successfully imported to SMRS.

2. ENM automatically triggers downloading and installation of the LKF on these radio nodes. The LKF Install activity

can be monitored by checking ENM SHM Job Summary > View Job Logs.

3. ENM SHM sends Capacity Expansion License Request Success to node. Check Main Job Result on ENM SHM to

verify Jobs Result is Success and Jobs Status is COMPLETED.

4. The STU alarm is ceased after the LKF is installed in the radio node.

5. Check the MO InstantaneousLicensing.expansionProgressReport is set to KEY_FILE_SUCCESSFUL to verify the

Capacity Expansion license request use case is successfully completed in the radio node.

6. Verify that the MO KeyFileInformation.sequenceNumber shows that the new LKF with the next sequence number is

installed in the radio node.

3.5   Node Expansion to Support Additional Radio Access Technology

Instantaneous Licensing automates the request and delivery of licenses necessary for expanding a node to support a New
Radio access type (RAT). When adding support for an additional RAT to an existing radio node, required license resources
are granted immediately. The process involves automatic calculation of the license demand, submission of the request, and
delivery of the LKF.

Figure 12   Node Expansion to Support Additional Radio Access Technology - Simplified View

Trigger License Key Request for Node Expansion to Support Additional RAT

The License Key Request for Capacity Expansion is triggered from a radio node.

Steps

1. Launch Command Line Interface to managed radio node using ENM or MOShell.

2. Configure certain resources that require capacity controlled by license lock to initiate an LKF Request for Capacity

Expansion.

3. The License System Triggered Unlock Activated alarm is raised. The temporary licenses are granted and enabled on

the radio node.

4. The radio node sends a Capacity Expansion LKF request to ENM. Check radio node MO

InstantaneousLicensing.expansionProgressReport is set to KEY_FILE_REQUEST_SENT to verify LKF request for
Capacity Expansion is sent to ENM.

5. ENM SHM automatically creates a Capacity Expansion License job.

about:blank
22/41

<!-- page: 23 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Execution and Supervision of Request Activity in Capacity Expansion License Key Job

Steps

1. ENM waits for the request from other radio nodes, and after Instantaneous License Batch Interval timer, ENM SHM

formulates the Capacity Expansion LKF Requests and sends the LKF request towards ELIS through CAS connection.

2. The LKF Request activity can be monitored by checking ENM SHM Job Summary > View Job Logs.

3. ENM begins monitoring and polling the CAS-C Dropbox at configurable intervals for LKF package file delivered by

ELIS.

4. ELIS successfully generates LKFs and delivers LKF package file to CAS-C Dropbox.

5. ENM retrieves the LKF package file from CAS-C Dropbox and imports LKFs in Software Management Distribution

Repository Services (SMRS). The LKF Import process can be monitored by checking ENM SHM Job Summary > View
Job Logs.

Execution and Supervision of Install Activity in Capacity Expansion License Key Job

Steps

1. ENM performs the LKF Install activity by default on all radio nodes whose LKF for Capacity Expansion has been

successfully imported to SMRS.

2. ENM automatically triggers downloading and installation of the LKF on these radio nodes. The LKF Install activity

can be monitored by checking ENM SHM Job Summary > View Job Logs.

3. ENM SHM sends Capacity Expansion License Request Success to node. Check Main Job Result on ENM SHM to

verify Jobs Result is Success and Jobs Status is COMPLETED.

4. The License System Triggered Unlock Activated alarm is ceased after the LKF is installed in the radio node.

5. Check the MO InstantaneousLicensing.expansionProgressReport is set to KEY_FILE_SUCCESSFUL to verify the

Capacity Expansion license request use case is successfully completed in the radio node.

6. Verify that the MO KeyFileInformation.sequenceNumber shows that the new LKF with the next sequence number is

installed in the radio node.

3.6   Hardware Resource Migration to IL

For details of the Hardware Resource Migration to IL, see Migrate to Connected Mode Instantaneous Licensing User Guide.
Once connectivity is established between ELIS and ENM, and Instantaneous Licensing is enabled in ENM, the operator can
migrate nodes that do not have ‘Instantaneous Licensing Perpetual for RAN’ installed to LCS.

This task involves activities both on the operator side and in the IL Manager performed by the Customer Unit which need to
be coordinated throughout the flow.

about:blank
23/41

![Figure on page 23](Instantaneous_Licensing_Solution_Guideline_images/page_023_image_001.png)

<!-- page: 24 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Figure 13   Hardware Migration to IL - Simplified View

Trigger Hardware Migration in the IL Manager

The Hardware Migration is triggered from IL Manager.

Steps

1. The Customer Unit opens IL Manager > HW Resource to IL to migrate hardware to IL. This operation supports both

Single Migration and Batch Migration methods. The LCS ID has to be selected in the GUI.

2. IL Manager sends initiate requests to ELIS including LCSid and Fingerprint and so on.

3. ELIS processes the requests and provides responses to the IL Manager, indicating success or failure for each

migration request.

4. The Hardware Migration status can be monitored in the IL Manager > HW Resource to IL > Request Status GUI.

Execute LKF Refresh

Steps

1. The operator enables IL on the radio node by setting InstantaneousLicensing.administrativeState to UNLOCKED,

and the License System Trigger Unlock Unavailable alarm is raised.

2. An LKF Refresh is triggered through SHM or directly from the radio node, see section License Refresh for details.

3.6.1   Clean-Up at Migration to Instantaneous Licensing

The problems listed below can be sorted out by using the automated license return on the node to be migrated during
hardware resource migration to Instantaneous Licensing.

– Wrong price model for HWACs

– Multiple or wrong payment models

– Inconsistent base package or value package sets

– Overactivation of HWACs or capacity license objects

– Old licenses or HWACs, for example, DU licenses

– Restricted features.

This is triggered by the cleanup exemption, which allows an operator to perform the return of all licenses and HWACs
activated on the node, activate licenses matching radio node configurations, and follow LCS, HCS, or special activation
rules set in the IL Manager.

Figure 14   Trigger Clean-Up at Migration to Instantaneous Licensing - Simplified View

about:blank
24/41

![Figure on page 24](Instantaneous_Licensing_Solution_Guideline_images/page_024_image_001.png)

<!-- page: 25 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Create Clean-Up Exemption

Prerequisites

– A relevant exemption for LKF Clean-Up is granted.

– Agreement is reached with the customer to perform full license return on selected nodes or in the network.

– The relevant stakeholders managing accounts understand the overall process of Clean-Up flow and its

consequences.

Steps

1. The Customer Unit opens IL Manager > Manage Exemptions, and provides the following information:

– Exemption Type: EUFT or Fingerprint.

– Fingerprint List

Note: This is not applicable for EUFT Exemption. The total number of the nodes that can be stored maximally under
Full LKF Clean-Up Exemption is 2500.

– Return Policy

Trigger Clean-Up Activity

Steps

1. The operator sets the InstantaneousLicensing.administrativeState atttribute to UNLOCKED on the node.

2. Initiate an LKF Refresh with the licenseDemandContent parameter set to FULL_DEMAND. This can be achieved in

one of the following ways:

a. Run the following ENM CLI command: cmedit action SubNetwork=<SubNetwork Name>, MeContext=

<MeContext Name>, ManagedElement=<NetworkElementName>, NodeSupport=1, LicenseSupport=1,
InstantaneousLicensing=1 refreshKeyFile. (licenseDemandContent=FULL_DEMAND)

b. Perform the InstantaneousLicensing.refreshKeyFile MO action with the licenseDemandContent parameter

set to FULL_DEMAND directly on the radio node.

3.7   Hardware Migration from Old to New Radio Node Unit

The Hardware Migration from old to new radio node unit use case describes the procedure during the migration of an old
radio node unit to a new one. This use case is triggered automatically in Instantaneous Licensing connected mode.

Figure 15   Hardware Migration from Old to New Radio Node Unit - Simplified View

Preparation for Hardware Migration

about:blank
25/41

![Figure on page 25](Instantaneous_Licensing_Solution_Guideline_images/page_025_image_001.png)

<!-- page: 26 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Steps

1. The operator informs the Customer Unit about the upcoming HW migration, providing a full list of Fingerprints

affected and the radio node types intended for use with the new Hardware.

IL Manager operation for Hardware Migration

Steps

1. The Customer Unit logs on to IL Manager. Open IL Manager > Manage Exemptions, and follow the Manage

Exemptions wizard. Input necessary information, creating and activating the exemption.

2. Open IL Manager > Manage LCS to update the LCS definitions for the operator. Then open IL Manager > Manage

BB-HCS to update the HWAC for the operator.

These steps are mandatory if the current HCS/LCS settings do not match the required configuration.

The Customer Unit notifies the operator when the IL configuration is ready for the requested Hardware Migration.

Migrate Radio Node Unit

1. Migrate old radio node to new radio node, see Migrate Baseband Unit Using NETCONF-Based Procedure.

Execute LKF Refresh

After unlocking and enabling the cell, initiate LKF Refresh either through ENM SHM or directly from the radio node, see
section License Refresh for details.

3.8   Feature Activation

The Feature Activation use case automates generation, delivery, and installation the of LKF on the radio node when there is
a need for new feature activation.

Figure 16   Feature Activation - Simplified View

Trigger License Key Request for Feature Activation

The License Key Request for Feature Activation is triggered from the radio node.

Steps

1. Launch Command Line Interface to managed radio node using ENM or MOShell.

about:blank
26/41

![Figure on page 26](Instantaneous_Licensing_Solution_Guideline_images/page_026_image_001.png)

<!-- page: 27 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

2. Activate the feature by setting LmFeatureState to ACTIVATED value.

3. Ensure the feature LmLicenseState is ENTITLED or ENABLED, and LmServiceState is INOPERABLE.

4. The radio node sends Capacity Expansion request to ENM, including new feature license keys and capacity demand

for these keys. Verify the progress by checking radio node MO InstantaneousLicensing.expansionProgressReport,
ensuring it shows KEY_FILE_REQUEST_SENT indicating LKF request is sent to ENM.

5. ENM SHM automatically creates a Capacity Expansion License job.

Note: If the LKF request fails because of temporary problems, the auto-recovery mechanism is triggered. For more
information, see Instantaneous Licensing.

Execution and Supervision of Request Activity in Capacity Expansion License Key job

Steps

1. ENM waits for other radio nodes requests, and after Instantaneous License Batch Interval timer, ENM SHM

formulates the Capacity Expansion LKF Requests and sends the LKF request towards ELIS through CAS connection.

2. The LKF Request activity can be monitored by checking ENM SHM Job Summary > View Job Logs.

3. ENM begins monitoring and polling the CAS-C Dropbox at configurable intervals for LKF package file delivered by

ELIS.

4. ELIS successfully generates LKFs and delivers LKF package file to CAS-C Dropbox.

5. ENM retrieves the LKF package file from CAS-C Dropbox and imports LKFs in Software Management Distribution

Repository Services (SMRS). The LKF Import process can be monitored by checking ENM SHM Job Summary > View
Job Logs.

Execution and Supervision of Install Activity in Capacity Expansion License Key job

Steps

1. ENM performs the LKF Install activity by default on all radio nodes whose LKF has been successfully imported to

SMRS.

2. ENM automatically triggers LKF downloading and installation on these radio nodes. The LKF Install activity can be

monitored by checking ENM SHM Job Summary > View Job Logs.

3. ENM SHM sends Capacity Expansion License Request Success to radio nodes. Check Main Jobs Result on ENM SHM

to verify Jobs Result is Success and Jobs Status is COMPLETED.

4. The feature LmLicenseState is ENABLED, and LmServiceState is OPERABLE.

5. Check the MO InstantaneousLicensing.expansionProgressReport is set to KEY_FILE_SUCCESSFUL to verify the

Capacity Expansion license request use case is successfully completed in the radio node.

6. Verify that the MO KeyFileInformation.sequenceNumber shows that the new LKF with the next sequence number is

installed in the radio node.

3.9   Return of Licenses

For return of licenses manual handling is needed by the Customer Unit.

When the license return in ELIS has been completed, the new LKF shall be installed in the radio node. This can be achieved
by an LKF Refresh triggered from the radio node.

Note: The Operator must install the latest LKFs that are manually generated in ELIS on the radio node before triggering
any subsequent Instantaneous Licensing requests. Otherwise, there is a risk that the radio node sends a Capacity
Expansion request for any feature that was manually removed in ELIS.

about:blank
27/41

<!-- page: 28 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

4   Non-Connected Mode

Instantaneous Licensing in non-connected mode supports the following use cases:

– Node Integration: new nodes are integrated in the network.

– Capacity Expansion: additional capacity is added to the node.

– Node Expansion to support additional Radio Access Technology: an existing node is expanded with an additional

Radio Access Technology, to facilitate Ericsson Spectrum Sharing.

– Hardware Migration to IL: Migration of an existing radio node to the IL solution.

– Hardware Migration from Old to New Radio Node Unit: an old radio node unit is migrated to a new one.

– Feature Activation: a feature is activated in the radio node.

– License Refresh: changes in LCS and Fixed Profile configurations are handled through the SSP-LKM Regenerate

Keys option.

– Software Upgrade: an existing node is updated with new software and changes in LCS and Fixed Profile

configurations are handled through the SSP-LKM IL Non-Connected Mode Release Upgrade option.

– Return of Licenses: manual handling for license returns.

Prerequisites

Before the non-connected mode use cases can be used, the following needs to be in place:

– Radio Node License Request flow (Ericsson Software Gateway)

– The operator has a specific ENM User privilege role to run the Generate Radio Node License Request File Flow.

– Operator access to the Self-Service Portal License Key Management (optional).

– The Instantaneous Licensing feature in non-connected mode needs to be enabled,

the InstantaneousLicensing.connectionMode attribute is set to OFFLINE_MODE.

The figure below provides the basic operational process for the IL solution in non-connected mode.

about:blank
28/41

<!-- page: 29 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Figure 17   Non-Connected Mode IL Operational Flow

Operational Process

1. Initiate License Request File (LRF) Generation:

The operator runs the LRF generation process using a designated Python script on the ENM scripting instance.

For detailed information, see Non-Connected Mode: Generate Radio Node License Request File User Guide available
in the Radio Node License Request Flow software package.

2. Trigger License Calculation:

The designated Python script running on the ENM scripting instance triggers the MO action
InstantaneousLicensing.calculateLicenseDemand on the nodes to calculate current license needs. Nodes respond
with their current license demands.

3. Build and Download LRF File:

Based on the collected calculation results from the nodes, the LRF flow creates the LRF file. Once the node selection
for the Generate Radio Node License Request File Flow is validated, the flow transits to the execution phase. As a
result, the LRF file is generated, and can be downloaded. In addition, a report is available providing details
regarding success and error cases of nodes. The operator downloads the LRF file from ENM.

4. Perform License Request, and Activation:

Either the Customer Unit or the operator performs a license request and activation in SSP-LKM. Open SSP-License
Key Mgmt > Activation, input required information such as request name, EUFT ID, LKF Receivers, and so on , and
upload the LRF file. The status can be checked in SSP-License Key Mgmt > Request Status.

5. Submit Activation to ELIS:

about:blank
29/41

![Figure on page 29](Instantaneous_Licensing_Solution_Guideline_images/page_029_image_001.png)

<!-- page: 30 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Once the activation is defined based on LRF content and manual input, the activation is submitted to ELIS.

6. Create LKF Package File:

ELIS creates the LKF package file that contains LKFs generated for successful outcomes. All of these are zipped into
a single file with the name containing the LRF file name. ELIS delivers the LKF ZIP to the SSP-LKM .

7. Fetch Response Data:

SSP-LKM fetches the response data and present it in the Request Status view. The operator is able to consult the
result and error information.

8. Obtain LKF Package File:

Either Customer Unit or operator can obtain the LKF package file by download link in the email or downloads from
SSP/LKM.

9. Upload LKF to ENM/SHM:

The operator uploads the LKF package file to ENM/SHM.

10. Install LKF in Radio Nodes:

LKF is installed in the radio nodes.

4.1   Common Process from LRF Generation until LKF Installation

Figure 18   LRF Generation, LKF Generation, and LKF Installation - Simplified Steps

For most use cases of the non-connected mode, the steps for LRF Generation, LKF Request, and LKF Installation are the
same. The designated Python script running on the ENM scripting instance is used to trigger the calculation of the required
license demand, which is then inserted into the LRF. The LRF is manually uploaded to SSP-LKM. The LKF is automatically
produced, and the operator is notified. The generated LKF is manually installed.

4.1.1   LRF Generation

Steps

1. Run the LRF generation process using the designated Python script on the ENM scripting instance.

For detailed information, see Non-Connected Mode: Generate Radio Node License Request File User Guide available in the
Radio Node License Request Flow software package.

about:blank
30/41

![Figure on page 30](Instantaneous_Licensing_Solution_Guideline_images/page_030_image_001.png)

<!-- page: 31 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

4.1.2   LKF Generation

Steps

1. Log on to SAM (Customer Unit or operator). Open SSP-License Key Mgmt > Activation. Provide required

information such as request name, EUFT ID, LKF Receivers, and so on, and upload the LRF file.

2. Open SSP-License Key Mgmt > Request Status to see the status information.

3. Obtain the LKF package file directly from LKM. A download link is shared by email.

– Option 1: Download LKFs in SSP-LKM

The Customer Unit opens SSP-License Key Mgmt > Request Status > Download LKF, to download the LKF
package file from the SSP-LKM.

– Option 2: Download LKFs and FS in LKM.

Additional Functional Specification of the LKF is available for download.

– Option 3: No LKFs are required.

No LKF is generated with this option.

For detailed information, see the IL Non-Connected Mode Activation User Guide available in the SSP-LKM online menu.

4.1.3   LKF Installation

Steps

1. Log on to ENM. Open Software and Hardware Manager > License Administration > Import Key Files to import the

LKF files. Once the Job Status changes to COMPLETED and the job result is SUCCESS. The LKFs are successfully
installed on the nodes.

2. Open Software and Hardware Manager > License Administration > Create Job > Install Key Files to install the

LKF file in Radio Nodes. The LKF installation status is shown in the Job Details.

4.2   Node Integration

Figure 19   Node Integration with Integration Unlock - Simplified Steps

Radio node integration is performed with the support of Integration Unlock. Required license resources are granted
immediately for 21 days. The designated Python script running on the ENM scripting instance is used to trigger the
calculation of the required license demand which is inserted into the LRF. The LRF is manually uploaded to SSP-LKM. The
LKF is automatically produced, and a notification is sent. The generated LKF is manually installed.

Note: export-restricted features are not allowed to be used during Integration Unlock.

about:blank
31/41

![Figure on page 31](Instantaneous_Licensing_Solution_Guideline_images/page_031_image_001.png)

<!-- page: 32 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Generate Configuration Files

Before node integration, the radio node configuration files need to be generated. This generation process can be done using
ECT (Equipment Configuration Tool) or another configuration tool.

If ECT is used, the licensing method option need to be configured when generating configuration files. in ECT use
Manual_with_Non-Connected_IL as the licensing method.

Integrate Radio Node

The radio node configuration files are imported into ENM with Auto Provisioning.

Steps

1. Log on to ENM. Open Provisioning > Auto Provisioning > Import. Upload the node configuration files in the import

wizard. These configuration files cover all the required parameters such as node type, band, and so on. After the
configuration files are imported into the Auto Provision, the integration is executed, and the detail process is shown
in the status window.

2. Ensure in ENM that the following attributes are configured, and the values are correct.

– InstantaneousLicensing.administrativeState is LOCKED.

– InstantaneousLicensing.connectionMode is OFFLINE_MODE.

– InstantaneousLicensing.euft EUFT is the same as in the LCS definition.

– InstantaneousLicensing.swltId is the same as the LCS ID

3. Unlock the RAT of the radio node, and the cell is activated.

LRF Generation, LKF Generation, and LKF Installation Process

See section Common Process from LRF Generation until LKF Installation for details.

Once the LKF is stored in the radio node, the Integration Unlock alarm is ceased.

4.3   Capacity Expansion

Figure 20   Capacity Expansion - Simplified Steps

The figure above shows simplified steps for a Capacity Expansion. Required license resources are granted immediately for
seven days when there is a need for capacity increase, for example, when additional output power is required. The
designated Python script running on the ENM scripting instance is used to trigger the calculation of the required license
demand which is inserted into the LRF. The LRF is manually uploaded to the SSP-LKM. The LKF is automatically produced,
and the operator is notified. The generated LKF is manually installed.

Trigger Capacity Expansion

The Capacity Expansion is triggered from the radio node.

about:blank
32/41

![Figure on page 32](Instantaneous_Licensing_Solution_Guideline_images/page_032_image_001.png)

<!-- page: 33 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Steps

1. Launch a Command Line Interface to manage the radio node by using ENM or MOShell.

2. Ensure in ENM that the following attribute is configured, and the value is correct:

– InstantaneousLicensing.connectionMode is OFFLINE_MODE

3. Configure a certain resource that requires capacity controlled by license lock, for example, the transmission power of

the sector is modified, or the bandwidth of cells is increased. When the current license consumption is greater than
installed in the LKF, the System Trigger Unlock Activated alarm and the License Additional Resources Required
alarm are raised. The License System grants license resources automatically by STU for seven days.

4. Log on to ENM Monitoring > Alarm Monitor. Click the alarm in the Alarm Monitor to see alarm details.

LRF Generation, LKF Generation, and LKF Installation Process

See section Common Process from LRF Generation until LKF Installation for details.

Once the LKF is stored in the radio node, the System Triggered Unlock alarm and the License Additional Resources
Required alarm are ceased.

4.4   Node Expansion to Support Additional Radio Access Technology

Figure 21   Node Expansion to Support Additional RAT - Simplified Steps

The figure above shows simplified steps for a node expansion to support additional RAT. Required license resources are
granted immediately for seven days when there is a need for an additional RAT. The designated Python script running on
the ENM scripting instance is used to trigger the calculation of the required license demand which is inserted into the LRF.
The LRF is manually uploaded to SSP-LKM. The LKF is automatically produced, and the operator is notified. The generated
LKF is manually installed.

Trigger Node Expansion to Support Additional RAT

The License Key Request for Capacity Expansion is triggered from the radio node.

Steps

1. Launch the Command Line Interface to managed radio node using ENM or MOShell.

2. In ENM ensure that the following attribute are configured, and the values are correct:

– InstantaneousLicensing.connectionMode is OFFLINE_MODE

3. Configure the additional RAT for the radio node. When the current license consumption is greater than installed in

the LKF, the System Trigger Unlock Activated alarm and the License Additional Resources Required alarm are raised
on the radio node. The user is informed about the need for a new LKF.

4. Log on to ENM Monitoring > Alarm Monitor. Click the alarm in the Alarm Monitor to see the alarm details.

about:blank
33/41

![Figure on page 33](Instantaneous_Licensing_Solution_Guideline_images/page_033_image_001.png)

<!-- page: 34 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

LRF Generation, LKFGeneration, and LKF Installation Process

See section Common Process from LRF Generation until LKF Installation for details.

Once the LKF is stored in the radio node, the System Triggered Unlock alarm and the License Additional Resources
Required alarm are ceased.

4.5   Hardware Resource Migration to IL

Figure 22   Hardware Resource Migration to IL - Simplified Steps

For details of the Hardware Resource Migration to IL, see Migrate to Non-Connected Mode Instantaneous Licensing User
Guide. Radio nodes with 'no Instantaneous Licensing Perpetual for RAN' are migrated to LCS.

Radio nodes are migrated to Instantaneous Licensing and associated with a License Configuration Set by IL Manager.
Regeneration is used to generate an LKF which is installed on the radio node.

There are two options in SSP-LKM to regenerate LKFs:

– IL Non-Connected mode Regenerate Keys

– Radio System Regenerate keys flow

As the needed IL updates have been done in the IL Manager, using the Radio System Regenerate keys flow is
recommended as it offers greater efficiency.

This task involves activities both on the operator side and in the IL Manager performed by the Customer Unit which need to
be coordinated throughout the flow.

IL Manager Operation

Steps

1. Customer Unit opens IL Manager > HW Resource to IL to migrate hardware to IL. This operation can be executed

either using Single Migration or Batch Migration. The LCS ID is selected in the GUI.

2. IL Manager sends requests towards ELIS including LCSid and Fingerprint.

3. ELIS processes the requests and formulates the success and failure of each node's LKF request into a response to IL

Manager.

4. The Hardware Migration status can be monitored in the IL Manager > HW Resource to IL > Request Status GUI.

Download LKF

Steps

about:blank
34/41

![Figure on page 34](Instantaneous_Licensing_Solution_Guideline_images/page_034_image_001.png)

<!-- page: 35 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

1. Locate the LKF files by searching for the fingerprints in “Search Keys & FS”. For single migration use “Detailed

search” in the Search criteria, for batch migration use “File based” in the “Search criteria”. As input, the same
Migration File from step 1 of IL Migration Operation can be used.

2. Once the search request has been submitted, the status can be checked under “Request Status LKF”.

3. The License Handler obtains the LKF ZIP through SSP-License Key File Portal > Request Status LKF, under

“Completed”

IL Feature Activation

For detailed information, see Instantaneous Licensing.

LKF Installation Process

See section LKF Installation for details.

4.5.1   Clean-Up at Migration to Instantaneous Licensing

The Instantaneous Licensing in non-connected mode also supports clean-up activity during hardware resource migration
to Instantaneous Licensing.

Figure 23   Clean-Up at Migration to Instantaneous Licensing - Simplified Steps

Create Clean-Up Exemption

Prerequisites

– A relevant exemption for the LKF Clean-Up is granted.

– Agreement is reached with the customer to perform full license return on selected nodes or in the network.

– The relevant stakeholders managing accounts understand the overall process of the Clean-Up flow and its

consequences.

Steps

1. The Customer Unit opens IL Manager > Manage Exemptions, and provides the following information:

– Exemption Type: EUFT or Fingerprint.

– Fingerprint List Note: This is not applicable for EUFT Exemption. The total number of the nodes that can be stored

maximally under Full LKF Clean-Up Exemption is 2500.

– Return Policy

Trigger Full LKF Clean-Up

Steps

about:blank
35/41

![Figure on page 35](Instantaneous_Licensing_Solution_Guideline_images/page_035_image_001.png)

<!-- page: 36 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

1. Generate an LRF with licenseDemandContent set to FULL_DEMAND and submit it to SSP-LKM, then download

LKFs.

Note: the LRF is needed to be provided for each migrated node.

4.6   Hardware Migration from Old to New Radio Node Unit

Figure 24   Hardware Migration from Old to New Radio Node Unit - Simplified Steps

Required HWACs for a new radio node are granted immediately. Instantaneous Licensing calculates the required HWAC
and licenses in the form of a LRF which must be manually uploaded to SSP-LKM. Generated LKF must be manually
installed.

Note: if HW is replaced without changing the node configuration and fingerprint, for example, replacement caused by HW
failure, there is no need to request a new LKF.

This task involves activities both on the operator side and in the IL Manager performed by the Customer Unit which need to
be coordinated throughout the flow.

Preparation for Hardware Migration

Steps

1. The operator informs the Customer Unit that HW Migration takes place along with information containing a full list

of Fingerprints affected and a list of the radio node types used as new Hardware.

2. The Customer Unit requests the exemption for new Hardware by existing flows which are defined for manual

handling if needed.

IL Manager Operation for Hardware Migration

Steps

1. The Customer Unit logs on to IL Manager. Open IL Manager > Manage Exemptions. Follow the Manage

Exemptions wizard. Provide necessary information, create, and activate the exemption.

2. Open IL Manager > Manage LCS to update the LCS definitions for the operator. Then open IL Manager > Manage

BB-HCS to update the HWAC for the operator. These steps are optional, they are performed if the HCS/LCS settings
do not reflect the required configuration.

The operator shall be notified by the Customer Unit when the IL configuration is ready for the requested HW
Migration.

Migrate Radio Node Unit

Steps

1. Migrate the old radio node by replacing it with a new radio node, see Migrate Baseband Unit Using NETCONF-Based

Procedure for details.

about:blank
36/41

![Figure on page 36](Instantaneous_Licensing_Solution_Guideline_images/page_036_image_001.png)

<!-- page: 37 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

2. Choose the Instantaneous Licensing in non-connected mode during the migration process.

3. Ensure in ENM that the following attribute is configured, and the values is correct:

– InstantaneousLicensing.connectionMode is OFFLINE_MODE

LKF Generation, and LKF Installation Process

See sections LKF Generation and LKF Installation for details.

4.7   Feature Activation

Figure 25   Feature Activation - Simplified Steps

The figure above shows simplified steps for a feature activation. The designated Python script running on the ENM
scripting instance is used to trigger the calculation of the required license demand which is inserted into the LRF. The LRF is
manually uploaded to the SSP-LKM. The LKF is automatically produced, and the operator is notified. The generated LKF is
manually installed.

Feature Activation

The License Key Request for Feature Activation is triggered from the radio node.

Steps

1. Launch the Command Line Interface to managed radio node by using ENM or MOShell.

2. Ensure in ENM that the following attribute is configured, and the values is correct:

– InstantaneousLicensing.connectionMode is OFFLINE_MODE

3. Activate the feature where FeatureState.licenseState is ENTITLED, and set the FeatureState.featureState attribute

to ACTIVATED.

4. When the current license consumption is greater than installed in the LKF, the License Additional Resources

Required alarm is raised when the system detects overuse of capacity. The user is informed about the need for a new
LKF.

5. Log on to ENM Monitoring > Alarm Monitor. Click the alarm in the Alarm Monitor to see the alarm details.

LRF Generation, LKF Generation, and LKF Installation Process

See section Common Process from LRF Generation until LKF Installation for details.

Once the LKF is stored in the radio node, the License Additional Resources Required alarm is ceased.

4.8   Software Upgrade

about:blank
37/41

![Figure on page 37](Instantaneous_Licensing_Solution_Guideline_images/page_037_image_001.png)

<!-- page: 38 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

Figure 26   Software Upgrade - Simplified Steps

The LKFs for the upgrade procedure can be obtained with

– the Radio system SSP-LKM upgrade flow (Node License Controlled Market Offerings = Radio system) or

– the Non-Connected IL SSP-LKM Upgrade (Node License Controlled Market Offerings = Radio system Instantaneous

licensing).

The advantage of the IL-based upgrade is the opportunity to apply the IL configuration together with the upgrade. This is
useful if new VPs available in the target Software release shall be directly activated for the upgraded nodes. Using the
‘Radio system’ upgrade, the activation requires an additional step, which is both more complex and requires more action
from the operator. However, the IL-based upgrade leads to a longer upgrade time since the IL processing is added to the
upgrade request handling.

Below the steps for the Non-Connected IL Release Upgrade are shown. The steps for the Radio system SSP-LKM upgrade
flow are similar.

For details, see the Radio system Release Upgrade flow user guide and the License Key Management - Non-Connected IL
Release Upgrade user guide in Software Assets Management (SAM).

SSP-LKM Non-Connected IL Release Upgrade

Steps

1. Open SSP-License Key Mgmt > Upgrade. In the pop-up window for selecting upgrades, choose Node License

Controlled Market Offerings, and select Radio system Instantaneous licensing. Select the EUFT, End User Foreign
Trade, which to be release upgraded.

2. The LKF package file can be obtained directly from SSP-LKM. A download link is shared by email.

3. The release upgrade file is uploaded and automatically validated. The target release is selected.

4. SSP-LKM sends requests towards ELIS including LCSid and Fingerprint and so on.

5. ELIS processes the requests and formulates the success and failure of each node's LKF request into a response to

SSP-LKM.

6. In SSP-License Key Mgmt > Request Status, the upgrade status is shown, and the LKF can be downloaded if

“Download LKFs in LKM” is selected in the previous step.

about:blank
38/41

![Figure on page 38](Instantaneous_Licensing_Solution_Guideline_images/page_038_image_001.png)

<!-- page: 39 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

For details, see the License Key Management - Non-Connected IL Release Upgrade user guide in Software Assets
Management (SAM).

LKF Installation

See section LKF Installation.

4.9   License Refresh

Figure 27   License Refresh - Simplified Steps

A RAN Regenerate Keys request is submitted when there is a need to refresh LKFs for radio nodes migrated to the
Instantaneous Licensing solution. The request is performed based on existing, potentially modified, IL configuration
of LCS and fixed profiles using an Excel input file with fingerprints. The LKF is generated in ELIS and delivered through
SSP-LKM.

SSP-LKM Regenerate Keys

Steps

1. Open SSP-License Key Mgmt >  Regenerate Keys. In the pop-up window of Select Regenerate flow, choose Select

Node License Controlled Market Offering> select Radio System Instantaneous Licensing, and start the
Regenerate flow.

2. Select the EUFT, End User Foreign Trade which wants to be regenerated for.

3. The LKF package file can be obtained directly from SSP-LKM. A download link is shared by email.

4. Two options File based, and Single search based are available to select for regenerate keys.

5. SSP-LKM sends requests towards ELIS including LCSid and Fingerprint and so on.

6. ELIS processes the requests and formulates the success and failure of each node's LKF request into a response to

SSP-LKM.

7. In SSP-License Key Mgmt > Request Status, the regenerate key status is shown, and the LKF can be downloaded if

“Download LKFs in LKM” is selected in the previous step.

about:blank
39/41

![Figure on page 39](Instantaneous_Licensing_Solution_Guideline_images/page_039_image_001.png)

<!-- page: 40 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

For details, see the License Key Management - Non-Connected IL Regenerate Keys user guide in Software Assets
Management (SAM).

LKF Installation

For details, see section LKF Installation.

4.10   Return of Licenses

For return of licenses manual handling is needed by the Customer Unit.

When licenses return in ELIS has been completed, the new LKF shall be installed in the radio node. This can be achieved by
executing the SSP-LKM Regenerate function.

Note: The operator must install the latest LKFs that are manually generated in ELIS on the radio node before triggering any
subsequent LRF Activations. Otherwise, there is a risk that the LRF Activation performs a Capacity Expansion for any
license that was manually removed in ELIS.

about:blank
40/41

<!-- page: 41 -->

9/1/26, 2:03 PM
Instantaneous Licensing Solution Guideline

5   Solution Guideline Change History

This section summarizes the major changes in this document release.

Table 2    Main Solution Guideline Changes per Release

Release
Main Changes

26.Q2
ENM Flow Automation is replaced by a designated Python script running on the ENM scripting
instance.

25.Q2
Improved LKF Delivery Time during Software Upgrade updated, Clean-Up at Migration to
Instantaneous Licensing added and Migration to Non-Connected Mode Instantaneous
Licensing simplified.

25.Q1
Introduction of Node Driven LKF Upgrade Method for Connected Instantaneous Licensing and
Improved LKF Delivery Time during Software Upgrade.

24.Q4
Enhancements of the auto-recovery mechanism when LKF requests initiated from the radio
node fail.

24.Q3
First release of this document.

Legal |  © Ericsson AB 2026

Copyright
© Ericsson AB 2026. All rights reserved. No part of this document may be reproduced in any form without the
written permission of the copyright owner.

Disclaimer
The contents of this document are subject to revision without notice due to continued progress in methodology,
design and manufacturing. Ericsson shall have no liability for any error or damage of any kind resulting from the
use of this document.

about:blank
41/41
