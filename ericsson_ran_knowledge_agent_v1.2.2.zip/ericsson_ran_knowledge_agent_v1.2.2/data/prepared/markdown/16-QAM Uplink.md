<!-- page: 1 -->

9/1/26, 8:49 AM16-QAM Uplink

Feature Description
58/221 04-LZA 701 6014/1 Uen AE38A

16-QAM Uplink

Contents

1 16-QAM Uplink Overview

The 16-QAM Uplink feature enables an increase in uplink peak rates.

Feature Name
16-QAM Uplink

Feature Identity
FAJ 121 0488

Value Package Name
LTE Base Package

Value Package Identity
FAJ 801 0400

Node Type
Baseband Radio Node

Access Type
LTE

Licensing
Non-license-controlled feature. No license is required.

2 Dependencies of 16-QAM Uplink

This feature has no dependencies or limitations.

Feature Dependencies

There are no dependencies to other features.

Hardware

No known limitations.

Limitations

No limitations for this feature.

Network Requirements

No specific network requirements.

3 Feature Operation of 16-QAM Uplink

The higher modulation format enables more information to be transferred in each radio, which results in a higher peak
rate in good radio conditions.

The uplink peak rates are doubled by using 16 QAM modulation compared to QPSK modulation.

4 Parameters for 16-QAM Uplink

The feature has no configuration parameters.

Legal
 | © Ericsson AB 2016–2021

Ericsson CPI1/2

<!-- page: 2 -->

9/1/26, 8:49 AM16-QAM Uplink

Ericsson CPI2/2
