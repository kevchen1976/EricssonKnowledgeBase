<!-- page: 1 -->

9/1/26, 1:10 PMIPsec

Commercial Product Description
9/221 01-LZA 701 6014/1 Uen AL38A

IPsec

Contents

1 IPsec Identity

Value Package Identity FAJ 801 0417

Introduced in
L17.Q4

2 Benefits of IPsec

IPsec protects the OSS and the EPC from malicious or involuntary attacks. It introduces authentication of nodes, integrity
protection, and adds confidentiality through the encryption of all traffic without decreasing performance.

For small cells, IPsec might be mandatory by many operators. The Ericsson solution can secure massive small cell rollout in
an untrusted network. Auto-integration without a laptop ensures the smooth implementation of IPsec.

Protection of the OSS Infrastructure and the EPC Network

IPsec protects the network from potential security breaches, which reduces the risk of network downtime caused by an
attack.

The use of IPsec reduces the risk of interception and injection of data in the LTE system between the Baseband in the RBS
and the SEG. IPsec also has the added benefit of protecting the core infrastructure of the network since only the outer IP
addresses of the IPsec tunnels are visible outside of the SEG. In this case, the inner IP addresses of the RBS and the secure
network (OSS or core network) are not visible to anyone in the untrusted network. In addition, IPsec uses encryption
mechanisms to protect end-user and node traffic sent over a network. It also includes integrity protection and replay
protection.

IPsec is especially important when an operator is liable for ensuring the integrity of their subscribers or when an extra layer of
protection is required for OAM.

Network Characteristics Maintained

IPsec in the eNodeB uses hardware accelerators, which make the IPsec function perform faster than on a normal CPU. This
results in a minor increase in the size of the packets, but otherwise no degradation of throughput. Another benefit of the use
of hardware accelerators is the small increase in packet delay.

Secure Massive Small Cell Rollout

IPsec is included as part of the auto-integration procedure for the deployment of small cells and it is a key mechanism for
secure RBS enrollment. IPsec requires authentication by using digital certificates (ID cards) in every node, which makes sure
that only trusted vendors and operator nodes are allowed to connect to the core network.

3 Included Functions

3.1 IPsec Overview

The IPsec feature uses IPsec ESP to provide security functionality for the IP layer.

Ericsson CPI1/2

<!-- page: 2 -->

9/1/26, 1:10 PMIPsec

Feature
Name
IPsec
IPsec
IPsec
IPsec

Feature
Identity
FAJ 121 0804
FAJ 121 0804
FAJ 121 3586
FAJ 121 0804

NR Base Package
IPsec
IPsec
Baseband IPsec GSM RAN

Value
Package
Name

FAJ 801 4002
FAJ 801 0417
FAJ 801 0516
FAJ 801 0747

Value
Package
Identity

Node Type
Baseband Radio Node
Baseband Radio Node
Baseband Radio Node
Baseband Radio Node

Access Type
NR
LTE
WCDMA
GSM

Licensing

License-controlled
feature. One license is
required for each node.

License-controlled
feature. One license is
required for each node.

License-controlled
feature. One license is
required for each node.

License-controlled
feature. One license is
required for each node.

Summary

The IPsec feature uses IPsec ESP to provide the following functions for the IP layer:

– Anti-replay protection

– Authentication

– Confidentiality

– Integrity protection

The tunnel mode of IPsec also adds the VPN aspect, where IPsec can be used to tunnel network traffic within one network
over a third-party network.

The node supports IPsec using ESP tunnel mode for terminated IP traffic in the node. IKEv2 is used as the control protocol.
ESP processing is in compliance with RFC 4303, and the IKEv2-related processing is in compliance with RFC 7296. The node
also follows the applicable parts of the principles as defined in the RFC 4301 security architecture and the 3GPP security
specifications.

IPsec is used to protect user and control plane traffic and OAM traffic.

Additional Information

For more information on this feature and related topics, see the following documentation:

– 3GPP TS 33.210, Network Domain Security (NDS); IP network layer security

– 3GPP TS 33.310, Network Domain Security (NDS); Authentication Framework (AF)

– 3GPP TS 33.401,, 3GPP System Architecture Evolution (SAE); Security architecture

– Manage IPsec

– System Description

Legal
 | © Ericsson AB 2017–2020, 2025

Ericsson CPI2/2
