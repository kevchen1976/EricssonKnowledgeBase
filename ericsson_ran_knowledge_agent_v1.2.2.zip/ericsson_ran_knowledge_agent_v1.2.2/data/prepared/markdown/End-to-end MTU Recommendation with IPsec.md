<!-- page: 1 -->

9/1/26, 2:02 PM
End-to-end MTU Recommendation with IPsec

Solution Guideline         385/221 12-IPM 101 41/100 Uen F

End-to-end MTU Recommendation with IPsec

Contents

1
Introduction

1.1
Scope

2
Concepts

2.1
Maximum Transmission Unit (MTU)

2.2
Jumbo Frames

2.3
E2E Network with IPsec

2.4
IPsec Overhead

2.5
Fragmentation

3
Performance Impact with Activation of IPsec

3.1
Throughput

3.2
Delay

4
IPsec Deployment Considerations to avoid Fragmentation

4.1
Control Plane

4.2
User Plane

4.3
Example IPsec Deployment Cases with and without Fragmentation

4.4
Inner and Outer Interface MTU Handling in Baseband and SEG

5
Observability

6
Solution Guideline Change History

about:blank
1/16

<!-- page: 2 -->

9/1/26, 2:02 PM
End-to-end MTU Recommendation with IPsec

1   Introduction

The purpose of this document is to support the operators in planning the network with IPsec without any performance
impact. The introduction of IPsec increases the packet sizes that increase the risk for fragmentation and reassembly or
packet loss in the transport layer. The fragmentation and reassembly process requires resources and causes delays that
might affect the network performance. This document describes the IPsec overhead and end-to-end Maximum
Transmission Unit (MTU) settings that are necessary to avoid or handle the fragmentation in the network.

For supplementary information, refer to the following feature descriptions and guidelines:

– Manage Transport Network

– Jumbo Frames

– Characteristic Requirements for NR Backhaul

– Manage IPsec

– IPsec

1.1   Scope

This document provides solution architects with the fundamentals for designing and planning secure RAN transport
networks without any performance impact.

The following products are relevant in the Ericsson RAN security solution:

– Baseband Radio Node

– Juniper® SRX

– Ericsson Network Manager (ENM)

about:blank
2/16

<!-- page: 3 -->

9/1/26, 2:02 PM
End-to-end MTU Recommendation with IPsec

2   Concepts

This section provides an overview of concepts and terminology used in the following chapters.

3GPP mandates the support of IPsec Encapsulating Security Payload (ESP) on radio nodes for protecting the following
interfaces control and user plane traffic in case of untrusted transport network:

– S1

– X2

– NG

– Xn

The use of IPsec can secure the communication over an untrusted medium, but it also introduces additional overhead,
which is a concern for Network Operators. To avoid the performance impact introduced by the IPsec overhead, it is
mandatory to adjust the E2E Maximum Transmission Unit (MTU) based on the supported MTU size by the Transport
Network.

2.1   Maximum Transmission Unit (MTU)

The Maximum Transmission Unit (MTU) is the largest size frame or packet in bytes or octets that can be transmitted across
a network.

2.2   Jumbo Frames

Jumbo frames are packets that are larger than the standard Ethernet frame size of 1518 bytes. The standard frame size is
described in the Institute of Electrical and Electronics Engineers (IEEE) 802.3 standard. The frame size definition for jumbo
frames is vendor-specific because jumbo frames are not part of the IEEE standard.

For example, Baseband supports jumbo frames with a maximum payload length of 9000 bytes. Juniper SRX supports up to
9192 bytes. For more information, see Jumbo Frames.

2.3   E2E Network with IPsec

When using IPsec between Baseband and a Security Gateway (SEG), there are the following levels of IP interfaces:

E2E IP Interface
The interface between the UE and the application server.

Inner IP Interface
The interface in the operator Transport Network between Baseband and S-GW or P-
GW or UPF.

Outer IP Interface
The interface in the untrusted Transport Network between Baseband and SEG.

These 3 interfaces are shown in the following figure.

about:blank
3/16

<!-- page: 4 -->

9/1/26, 2:02 PM
End-to-end MTU Recommendation with IPsec

UEs

Air Interface
Transport

Baseband

Network

Application

Server

S-GW
P-GW/UPF
SEG

Internet

TCP

TCP

E2E MTU

IP

IP

PDCP

PDCP

GTP-U

Eth

GTP-U

Eth

Radio

Radio

UDP

UDP

Operator Transport MTU

IP

IP

IPsec

Eth

IPsec

Eth

Untrusted Transport MTU

IP

IP

Eth

Eth

Figure 1   E2E Network with IPsec

Each IP interface has separate Maximum Transmission Unit (MTU) settings.

When the packets travel through the network, headers for various protocols are added, including the IP header for each IP
interface level. The packets sent over the Transport Network are larger than the original payload sent between the UE and
the application server.

2.4   IPsec Overhead

When using IPsec, the packet size increases due to the overhead from the ESP protocol and the outer IP header. The ESP
overhead depends on which algorithms are used.

The following figure shows an overview of the IPsec overhead.

Figure 2   IPsec Overhead

The following table shows the maximum size of each component in the IPsec protected packet.

Table 1    Maximum ESP Overhead

Overhead Field
Size (bytes)

ESP header
8

Initialization Vector (IV)
16

Padding (max)
15

ESP tail (PAD length, next header)
2

ESP Auth [Integrity Check Value (ICV)]
32

Total
73

In the table above, the total is calculated considering the maximum values of the different parameters. Fields in bold have
fixed size. The rest of the fields have variable sizes depending on the combination used of encryption and integrity
algorithms. Maximum overhead is reached when ENCR_AES_CBC is used for encryption and AUTH_HMAC_SHA2_512_256
for integrity. To get the minimum overhead (34 to 37 bytes depending on padding), ENCR_AES_GCM_16 would need to be

about:blank
4/16

![Figure on page 4](End-to-end_MTU_Recommendation_with_IPsec_images/page_004_image_001.png)

<!-- page: 5 -->

9/1/26, 2:02 PM
End-to-end MTU Recommendation with IPsec

used as combined encryption and integrity algorithm. For more information on the IPsec overhead, see Feature Description
IPsec.

In case of IPv4 in the outer network and the Baseband is behind a NAT device, there is an extra 8 bytes overhead for the
User Datagram Protocol (UDP) encapsulation.

2.5   Fragmentation

Fragmentation is a process that divides packets into fragments so that the resulting fragments can travel across a link with
a smaller maximum transmission unit (MTU) than the original packet size. On the other side of the link, the fragments are
reassembled again to form the original packet.

With the default MTU configuration of 1500 bytes on all IP interface levels, the payload sent by the UE might be too large
for the Transport Network, and fragmentation is needed. In the Baseband, the inner MTU is adjusted based on the outer
MTU and the IPsec overhead, and the inner IP packet is fragmented before IPsec encryption. This is called pre-
fragmentation.

The following figure shows an example of fragmentation and reassembly of a packet sent in the uplink direction, that is for
a packet sent from the UE to the application server.

UEs

Air Interface
Transport

Base-band

Network

Application

Server

S-GW
P-GW/UPF
SEG

Internet

TCP

TCP

E2E MTU = 1500

IP

IP

PDCP

PDCP

GTP-U

Eth

GTP-U

Eth

Radio

Radio

UDP

UDP

Operator Transport MTU=1500

IP

IP

IPsec

Eth

IPsec

Eth

Untrusted Transport MTU=1500

Inner MTU adjusted to 1420 based
on maximum possible IPsec
overhead.

IP

IP

Eth

Eth

ESP

GTP-U/UDP

Payload #1

Payload #1

1364
IP
20

36*

IP
20

8+8

IP
20

Payload

IP
20

1364
GTP-U/UDP

8+8

IP
20

PDCP
Payload

1480
IP
20

1480
IP
20

ESP

Payload #2

Payload #2

116
IP
20

36*

IP
20

IP
20

116

*with ENCR_AES_GCM_16:
SPI=4,SN=4,IV=8, padding=2 (to
align with 4B), tail=2, ICV=16

Figure 3   E2E Network with IPsec, Default MTU of 1500 Bytes on All IP Interfaces

In an IPsec implementation it is also possible to fragment the outer IP packet after IPsec encryption, called post-
fragmentation. Post-fragmentation does not apply to Baseband.

about:blank
5/16

<!-- page: 6 -->

9/1/26, 2:02 PM
End-to-end MTU Recommendation with IPsec

3   Performance Impact with Activation of IPsec

There is no impact on network throughput and latency if fragmentation caused by the IPsec overhead can be avoided.
However, incorrect Maximum Transmission Unit (MTU) setting result in fragmentation. With fragmentation, the network
performance might be impacted.

The following sections cover a performance impact in terms of throughput and delay when IPsec is activated with Ericsson
recommended RAN Security solution components. The recommendation of E2E MTU setting is also covered to avoid
fragmentation in the network.

3.1   Throughput

The Baseband transport interfaces have a higher throughput than the air interface. The increased packet sizes due to the
IPsec overhead do not lead to any throughput impact if fragmentation is avoided.

There is no impact on throughput with IPsec activation in the network if there is no fragmentation due to IPsec overhead.

3.2   Delay

On Baseband, when a packet is subject to IPsec processing, the latency is increased at maximum 150 microseconds in each
direction. IPsec activation introduces only a negligible packet delay if fragmentation is avoided.

about:blank
6/16

<!-- page: 7 -->

9/1/26, 2:02 PM
End-to-end MTU Recommendation with IPsec

4   IPsec Deployment Considerations to avoid Fragmentation

With the introduction of IPsec, because of the increased packet size, there is a higher risk of fragmentation that results in
reassembly of packets or packet loss. The fragmentation and reassembly process requires many resources and causes
delays that might affect the network performance. To avoid fragmentation, the E2E Maximum Transmission Unit (MTU)
must be adjusted based on what the Transport Network can handle.

Most of the network nodes support larger packet sizes than 1500 bytes. These are also known as jumbo frames. However,
jumbo frame sizes are not standardized. It might not be the same size for other network nodes, or some nodes do not
support jumbo frames.

For example, Baseband supports larger packet sizes than 1500 bytes that are up to 9000 bytes, however, Juniper SRX
supports jumbo frames up to 9192 bytes. Typically, end-user applications have a maximum MTU size of 1500 bytes. It is
rare to see MTU sizes greater than 1500 bytes on the Internet side. Large packet sizes do not lead to fragmentation if all
relevant network nodes support jumbo frames. Otherwise, packet fragmentation and reassembly might be required that
can have a negative impact on the network performance.

On the transport side backhaul traffic is mainly user data and to a lesser extent signaling traffic, Operation and
Maintenance (OAM) traffic and may be traffic for Synchronization over IP (SoIP).

The rest of this section describes the MTU setting recommendations and different methods to avoid fragmentation in the
control plane and in the user plane.

4.1   Control Plane

Although the packet size is small in the control plane, still in extreme cases there is a way to limit the control plane IP
packet size by configuring the maximum size of Stream Control Transmission Protocol (SCTP) Protocol Data Units (PDUs).
The following figure shows the control plane protocol stack with IPsec.

about:blank
7/16

<!-- page: 8 -->

9/1/26, 2:02 PM
End-to-end MTU Recommendation with IPsec

Figure 4   Control Plane Protocol Stack with IPsec

Control plane packets usually have a small size, but there are exceptions such as UE Radio Capability information
messages that can be of several kilobytes. Another case is the IPv4 to IPv6 migration where the packet size increases
because of the change of IP type.

These cases can be handled by configuring a maximum SCTP PDU size on Baseband. With this configuration setting,
fragmentation can be avoided in the lower layers in the uplink direction. On Baseband, it is handled through the
SctpProfile.maxSctpPduSize attribute.

In the following examples, the value of the SctpProfile.maxSctpPduSize attribute is calculated when the transport MTU is
1500 bytes and traffic is protected using IPsec:

– For IPv4 (both inner and outer network, and NAT device):

SctpProfile.maxSctpPduSize = Transport MTU - IPsec overhead - Inner IP
header - UDP header for NAT-T

SctpProfile.maxSctpPduSize = 1500 B - 93 B - 20 B - 8 B = 1379 bytes

– For IPv6 (both inner and outer network):

SctpProfile.maxSctpPduSize = Transport MTU - IPsec overhead - Inner IP
header

SctpProfile.maxSctpPduSize = 1500 B - 113 B - 40 B = 1347 bytes

about:blank
8/16

![Figure on page 8](End-to-end_MTU_Recommendation_with_IPsec_images/page_008_image_001.png)

<!-- page: 9 -->

9/1/26, 2:02 PM
End-to-end MTU Recommendation with IPsec

The following table shows the value of the SctpProfile.maxSctpPduSize attribute for each combination of inner and outer
interface IP type. If there is no Network Address Translation (NAT), the maximum IPsec overhead size of 93 bytes for IPv4
and 113 bytes for IPv6 are used for calculation of SCTP MTU in the following table.

Table 2    SCTP MTU Examples (without NAT-T)

SCTP (maxSctpPduSize)
Outer interface MTU size

Inner interface IP Type
Outer interface IP
Type

IPv4
IPv4
1387
1500

IPv6
IPv6
1347
1500

IPv4
IPv6
1367
1500

IPv6
IPv4
1367
1500

4.2   User Plane

The following figure gives the E2E view of the user plane network protocol stack with IPsec for an NR Standalone network.

Figure 5   User Plane Protocol Stack with IPsec (NR SA)

For the LTE and NR Non-Standalone (NSA) cases the user plane protocol stack is similar as in the figure above, except that
the Service Data Adaptation Protocol (SDAP) layer is not relevant for LTE.

Jumbo frames of 9000 bytes are supported on the transport level in Baseband. But the configuration of jumbo frames on
the UE level might cause fragmentation and reassembly in other parts of the network and lower performance.

Maximum Supported E2E MTU Size of 2006 bytes

The maximum supported GTP-U packet size on Baseband is 2048 bytes. Considering the possible RAN overhead in the
worst-case of 28 bytes, and additional consideration for future extensions of 14 bytes (for example, over the F1-U
interface), this 2048 bytes GTP-U packet size in Baseband corresponds to a maximum supported E2E MTU size of 2006 (=
2048-28-14) bytes.

The worst case considers the remote leg in the NR-DC case, where the overhead is the following:

RAN overhead = GTP-U header + GTP-U optional header + DL User Data + PDCP + MAC-I
+ SDAP

RAN overhead = 8 B + 4 B + 8 B + 3 B + 4 B + 1 B = 28 bytes

With a maximum supported E2E MTU size of 2006 bytes, an MTU size of 2209 bytes would be required in the Transport
Network to avoid fragmentation.

about:blank
9/16

![Figure on page 9](End-to-end_MTU_Recommendation_with_IPsec_images/page_009_image_001.png)

<!-- page: 10 -->

9/1/26, 2:02 PM
End-to-end MTU Recommendation with IPsec

This applies if the RAN traffic is protected by IPsec and IPv6 is used in both inner and outer network as follows:

Transport Network MTU = E2E MTU + RAN overhead + Future extension (Reserved bytes
for RAN future extensions, for example, F1-U interface) + UDP header + inner IPv6
header + (maximum IPsec overhead and outer IPv6)

Transport Network MTU = 2006 B + 28 B + 14 B + 8 B + 40 B + 113 B = 2209 bytes

4.3   Example IPsec Deployment Cases with and without Fragmentation

The following figure shows fragmentation and no fragmentation cases in the IPsec deployed network cases, where both
Baseband and SEG support jumbo frames with a payload of 9000 bytes, with different Transport Network (TN) Maximum
Transmission Unit (MTU) settings. The following example cases mentioned below are considering worst case (NR-DC)
overhead and corresponding MTU size requirement on the Transport Network.

IPsec Deployed Network

•
Maximum size of the IP packet (containing IPsec
protected RAN traffic) on Transport = 2209 bytes

•
Both Baseband and SEG support jumbo frames with
payload 9000

Case 2:

Case 1: TN
MTU >= 2209
bytes

TN MTU <
2209 bytes

MTU setting
in Transport
Network (TN)

Fragmentation might

happen

Jumbo frames are supported
by all network nodes in the
mobile network.

No fragmentation

To avoid fragmentation, the
MTU must be aligned E2E to
the given Transport MTU.

Figure 6   Packet Handling in IPsec Deployed Network

4.3.1   Case 1

Jumbo frames are supported by all network nodes in the mobile network, and the MTU in the Transport Network is larger
than or equal to the maximum size of the IP packets 2209 bytes for IPv6.

In this case, the inner and outer interface MTU of both Baseband and SEG can be set to 9000 bytes and no fragmentation
happens.

4.3.2   Case 2

The MTU in the Transport Network is smaller than the maximum size of the IP packets 2209 bytes for IPv6. In this case,
fragmentation might happen.

E2E MTU Settings must be Adjusted to Avoid Fragmentation

To achieve the best performance and prevent fragmentation, the end-to-end (E2E) Maximum Transmission Unit (MTU)
must be adjusted based on what the Baseband and the transport network can handle. The E2E MTU is the MTU over the air
interface and in the packet core.

There are the following methods to avoid fragmentation completely:

about:blank
10/16

<!-- page: 11 -->

9/1/26, 2:02 PM
End-to-end MTU Recommendation with IPsec

– TCP MSS adjustment

– UE Link MTU setting

However, proper MTU settings in the inner and outer interfaces of Baseband or either one of these interfaces and SEG
following Transport Network MTU can be used to prevent post-fragmentation or double fragmentation.

TCP MSS Adjustment

If there is TCP traffic, the TCP Maximum segment Size (MSS) adjustment method can be used to avoid fragmentation in the
lower layers. This method is also known as TCP MSS clamping. With this method the E2E IP packet size can be limited by
configuring the MSS value of the TCP in the core.

The TCP MSS adjustment value is exchanged during the TCP handshake between the UE and the Packet Data Network
(PDN). The configured TCP MSS adjustment value is applicable for both uplink and downlink traffic. For more information,
see "TCP MSS Adjustment" (81/1553-AXB 250 12-V6) in the Packet Core Gateway (PCG) CPI library. The following figure
shows the protocol stack with the MSS and MTU.

Figure 7   Protocol Stack Showing the MSS and MTU

The following example shows the TCP MSS calculation considering the transport network MTU value as 1500 bytes:

TCP MSS value = MTU in the Transport Network – Maximum IPsec overhead for IPv6 –
inner IPv6 header – UDP header – RAN overhead – (Reserved bytes for RAN future
extensions, for example, F1-U interface) – IPv6 header – TCP header

TCP MSS value = 1500 B – 113 B – 40 B – 8 B – 28 B – 14 B – 40 B – 20 B = 1237
bytes

about:blank
11/16

![Figure on page 11](End-to-end_MTU_Recommendation_with_IPsec_images/page_011_image_001.png)

<!-- page: 12 -->

9/1/26, 2:02 PM
End-to-end MTU Recommendation with IPsec

UE Link MTU Setting

To avoid fragmentation on the lower layers, the packet size from the UE needs to be limited by setting the link MTU in the
UE. Ericsson Core supports setting the link MTU in the UE through configuration.

The following example shows a UE link MTU calculation considering the Transport Network MTU value as 1500 bytes:

UE link MTU = MTU in the Transport Network – Maximum IPsec overhead for IPv6 –
inner IPv6 header – UDP header – RAN overhead – (Reserved bytes for RAN future
extensions, for example, F1-U interface)

UE link MTU = 1500 B – 113 B – 40 B – 8 B – 28 B – 14 B = 1297 bytes

The link MTU in the UE is linked to each Packet Data Network (PDN) connection. A UE can have multiple PDN connections
towards APN(s) and get multiple IP addresses.

4.4   Inner and Outer Interface MTU Handling in Baseband and SEG

4.4.1   Baseband

– MTU handling on Outer interface

To prevent fragmentation in an IPv4 based Transport Network (TN), the Maximum Transmission Unit (MTU) in
Baseband must be configured manually according to the MTU in the Transport Network.

If there is an IPv6 Transport Network, the Path MTU Discovery adjusts the MTU of the IPv6 interface in Baseband
that makes the MTU configuration in Baseband less complex. It can be kept on the default value of 1500 bytes if the
MTU in the Transport Network is 1500 bytes or less. If jumbo frames are supported in the Transport Network (MTU
is larger than 1500 bytes), the MTU configuration on the IPv6 interface can be set to the maximum 9000 bytes.

– MTU handling on Inner interface

Regardless of the IP version in the inner and outer network, the MTU for the inner interface is automatically
adjusted, based on the MTU setting on the outer interface and the maximum IPsec overhead for negotiated
algorithms, to avoid post-fragmentation or double fragmentation.

Because of the automatic adjustment, the MTU configuration on the inner interface is as easy as for the outer IPv6
interface. The default value of 1500 bytes is kept if the MTU in the Transport Network is 1500 bytes or less or set to
maximum 9000 bytes if jumbo frames are supported in the Transport Network.

For the MTU adjustment on the inner interface, both the configured MTU on the outer interface, and path MTU in
case of IPv6, are considered.

As an example, in case the default configuration of MTU 1500 bytes is used on both inner and outer interfaces and
ENCR_AES_CBC_256 is the negotiated algorithm, the inner MTU will be adjusted to 1423 bytes in case of an IPv4
Transport Network (or 1415 bytes if there is a NAT device) and 1403 bytes in case of an IPv6 Transport Network.

There is one exception when post-fragmentation or double fragmentation can happen in the Baseband Radio Node.
In case of the IPv6 inner interface, the inner MTU cannot be less than 1280 bytes. If the MTU on the outer interface
is too small, and the inner MTU cannot be fully adjusted, there is a risk of post-fragmentation.

– Maximum Receive Unit in Baseband is 9000 bytes and cannot be configured. It has no relation to any interface MTU.

– For Internet Key Exchange version 2 (IKEv2) traffic, IKEv2 fragmentation can be enabled to avoid large IKEv2

messages fragmented in the IP layer and blocked by a firewall. For more information, see Manage IPsec.

4.4.2   SEG

about:blank
12/16

<!-- page: 13 -->

9/1/26, 2:02 PM
End-to-end MTU Recommendation with IPsec

In this section the Juniper SRX5K is taken as a reference for showing the SEG configuration. The Security Gateway (SEG)
configuration might vary with other vendor-specific implementations.

– Juniper SRX supports jumbo frames up to 9192 bytes.

– Juniper SRX does not support Path MTU Discovery, since it cannot adjust the ESP packet size when receiving ICMP

messages related to Path MTU Discovery.

– In Juniper terminology, the Secure Tunnel (ST) interface and external interface are used for IPsec configuration. The

Secure Tunnel interface can be considered the inner interface, while the external interface can be considered the
outer interface.

– The MTU size for ST and external interfaces can be set independently.

Interface MTU = minimum of (ST MTU, outgoing external interface MTU)

Path or Tunnel MTU = interface MTU - IPsec overhead

– The IPsec overhead varies depending on the configured encryption and hash algorithms.

– Tunnel MTU is the criteria for fragmentation, while the Distribution Frame (DF) bit of the received clear-text inner

packet is the key to decide whether pre-fragmentation happens.

The following figure shows packet fragmentation handling on the Juniper SRX.

Figure 8   Packet Fragmentation Handling on Juniper SRX

– For IPv4 traffic, when the tunnel MTU is less than a clear-text packet size, the following cases exist based on the DF

bit setting of inner packets.

• if the inner packet DF bit is = 0, the packet is pre-fragmented.

• If the inner packet DF bit is = 1, the packet is encrypted and encapsulated. In this phase, the following options

exist depending on the setting of the outer packet DF bit,

– If the outer IP DF bit is = 0; the Packet is post-fragmented.

about:blank
13/16

![Figure on page 13](End-to-end_MTU_Recommendation_with_IPsec_images/page_013_image_001.png)

<!-- page: 14 -->

9/1/26, 2:02 PM
End-to-end MTU Recommendation with IPsec

– If the outer IP DF bit is = 1; the Packet is dropped and the ICMP message sent to the source.

– For IPv6 traffic, fragmentation does not happen on Juniper SRX. Juniper SRX drops an inner packet larger than the

path or tunnel MTU and send an ICMP message back.

– IPsec post fragmentation can be avoided by using the 'set' or 'copy' command to make sure the outer header DF bit

is = 1. When the inner packet is too large and the inner DF bit is = 1, the packet is dropped and an ICMP message is
sent back.

For more information on how to set the DF bit using CLI, see Juniper Junos CLI Reference section "ipsec (Security Group
VPN Member)".

about:blank
14/16

<!-- page: 15 -->

9/1/26, 2:02 PM
End-to-end MTU Recommendation with IPsec

5   Observability

Packet capturing with the Wireshark tool can be used to analyze IP traffic to detect if IP fragmentation is happening in the
network.

Packet capturing can be setup by the following steps:

1. Open Wireshark

2. Connect Wireshark to the network

3. Configure the port mirror on the device or interface where the IP traffic analysis is desired

4. Start the packet capturing

On the captured packets if the Fragment Offset field is larger than 0, it is a packet fragment.

If the Fragment Offset field is = 0 and the More-fragments flag is set, it is a packet fragment.

It is possible to use filters on Wireshark capture, the following example shows for a IPv4 packet filter:

ip.flags.mf == 1 or ip.frag_offset gt 0

On Baseband, it is possible to check if fragmentation is happening on the Baseband traffic towards backhaul using the
following counters:

– InterfaceIPv4.ipIfStatsOutFragCreates

– InterfaceIPv4.ipIfStatsOutFragFails

– InterfaceIPv4.ipIfStatsOutFragOKs

– InterfaceIPv4.ipIfStatsOutFragReqds

– InterfaceIPv6.ipIfStatsOutFragCreates

– InterfaceIPv6.ipIfStatsOutFragFails

– InterfaceIPv6.ipIfStatsOutFragOKs

– InterfaceIPv6.ipIfStatsOutFragReqds

– PeerIpsecTunnel.ipIfStatsOutFragCreates

– Sctp.sctpFragUsrMsgs

The following counters are supported on Baseband to check on the fragments that are received from the backhaul:

– InterfaceIPv4.ipIfStatsReasmFails

– InterfaceIPv4.ipIfStatsReasmOKs

– InterfaceIPv4.ipIfStatsReasmReqds

– InterfaceIPv6.ipIfStatsReasmFails

– InterfaceIPv6.ipIfStatsReasmOKs

– InterfaceIPv6.ipIfStatsReasmReqds

– Sctp.sctpReasmUsrMsgs

about:blank
15/16

<!-- page: 16 -->

9/1/26, 2:02 PM
End-to-end MTU Recommendation with IPsec

6   Solution Guideline Change History

This section summarizes the major changes introduced in each document release.

Table 3    Main Solution Guideline Changes per Release

Release
Main Changes

26.Q1
The maximum supported GTP-U packet size on Baseband is increased from 1930 to 2048 bytes.
The maximum supported E2E MTU size for the User Plane is increased correspondingly.

24.Q2
New integrity algorithm “AUTH_HMAC_SHA2_512_256” is supported on Baseband RAN compute
group 4 and onwards. It adds 16 bytes overhead due to ICV increase compared to other integrity
algorithms. ICV value updated accordingly in the table ‘Maximum ESP Overhead’. Max IPsec
Overhead value updated in calculation examples across the document.

24.Q1
Table 'Maximum IPsec Overhead' replaced with 'Maximum ESP Overhead' and examples of
minimum & maximum overhead with needed algorithms added in Section IPsec Overhead.
Removed round up IPsec overhead value from MTU calculation examples. IPsec feature
description document added as reference.

23.Q3
First version

Legal |  © Ericsson AB 2026

Copyright
© Ericsson AB 2026. All rights reserved. No part of this document may be reproduced in any form without the
written permission of the copyright owner.

Disclaimer
The contents of this document are subject to revision without notice due to continued progress in methodology,
design and manufacturing. Ericsson shall have no liability for any error or damage of any kind resulting from the
use of this document.

about:blank
16/16
