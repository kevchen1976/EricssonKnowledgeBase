# Included prepared sample

`data/prepared` contains the prepared output for the four Ericsson PDFs supplied during development. It is a bootstrap/validation corpus, not a complete Ericsson knowledge base.

It includes Markdown, adjacent image folders, sidecars, the combined manifest, feature/package/topic routing shards, and JSON/CSV feature catalogs. The sample includes a Feature Description, a Commercial Product Description, and two Solution Guidelines, including a document with four-level section headings. It does not contain production embeddings. Replace or extend this directory by running:

```bash
python -m ericsson_preparation /path/to/ericsson-pdfs \
  --output-dir data/prepared \
  --overwrite
```

Then validate and ingest using the commands in the root README.
