"""Deterministic Ericsson query routing.

The standalone Ericsson agent intentionally uses deterministic ID routing before
any LLM decision.  This mirrors the reliable part of the Nokia runtime and
keeps FAJ feature/package lookups inexpensive and explainable.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .ids import find_feature_ids, find_package_ids

_GRAPH_TERMS = {
    "relationship", "relationships", "related", "dependency", "dependencies",
    "depends", "package contains", "contained in", "uses counter", "counter",
    "parameter", "parameters", "kpi", "alarm", "alarms", "impact",
}


@dataclass(frozen=True)
class RouteDecision:
    workflow: str
    query: str
    feature_ids: List[str] = field(default_factory=list)
    package_ids: List[str] = field(default_factory=list)
    use_graph: bool = False
    reason: str = ""


def route_query(query: str, *, graph_enabled: bool = False) -> RouteDecision:
    text = " ".join(str(query or "").split())
    features = find_feature_ids(text)
    packages = find_package_ids(text)
    lower = text.casefold()
    graph_intent = graph_enabled and any(term in lower for term in _GRAPH_TERMS)

    if features:
        return RouteDecision(
            workflow="feature_lookup",
            query=text,
            feature_ids=features,
            package_ids=packages,
            use_graph=graph_intent,
            reason="Ericsson FAJ 121 feature identity detected",
        )
    if packages:
        return RouteDecision(
            workflow="package_lookup",
            query=text,
            package_ids=packages,
            use_graph=graph_intent,
            reason="Ericsson FAJ 801 value-package identity detected",
        )
    if graph_intent:
        return RouteDecision(
            workflow="graph_assisted_search",
            query=text,
            use_graph=True,
            reason="Relationship-oriented query and graph integration is enabled",
        )
    return RouteDecision(
        workflow="knowledge_search",
        query=text,
        reason="No explicit Ericsson identity detected; use corpus retrieval",
    )
