"""Grounded answer synthesis for retrieved Ericsson evidence."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

from .clients import OllamaClient, ServiceClientError
from .contracts import Citation
from .settings import DEFAULT_SYSTEM_PROMPT

_WHITESPACE_RE = re.compile(r"\n{3,}")


def _source(hit: Dict[str, Any]) -> Dict[str, Any]:
    value = hit.get("_source", hit)
    return value if isinstance(value, dict) else {}


def _page_list(source: Dict[str, Any]) -> List[int]:
    start = int(source.get("page_start") or 0)
    end = int(source.get("page_end") or start or 0)
    if start <= 0:
        return []
    if end < start:
        end = start
    if end - start > 20:
        return [start, end]
    return list(range(start, end + 1))


def build_citations(evidence: Sequence[Dict[str, Any]]) -> List[Citation]:
    citations: List[Citation] = []
    for index, hit in enumerate(evidence, 1):
        source = _source(hit)
        citations.append(Citation(
            citation_id=f"E{index}",
            source=str(source.get("source_pdf") or source.get("source_markdown") or source.get("filename") or ""),
            title=str(source.get("title") or ""),
            pages=_page_list(source),
            heading_path=str(source.get("heading_path") or source.get("heading") or ""),
            score=float(hit.get("_score")) if hit.get("_score") is not None else None,
            evidence_tier=str(source.get("feature_association") or source.get("chunk_kind") or ""),
        ))
    return citations


def compact_evidence(evidence: Sequence[Dict[str, Any]], *, max_chars_each: int = 7000) -> str:
    blocks: List[str] = []
    for index, hit in enumerate(evidence, 1):
        source = _source(hit)
        content = str(source.get("content") or "").strip()
        content = _WHITESPACE_RE.sub("\n\n", content)
        if len(content) > max_chars_each:
            content = content[:max_chars_each].rstrip() + "\n[truncated]"
        details = [
            f"[E{index}]",
            f"Title: {source.get('title') or source.get('filename') or 'Unknown'}",
            f"Source: {source.get('source_pdf') or source.get('source_markdown') or source.get('filename') or 'Unknown'}",
            f"Pages: {source.get('page_start') or '?'}-{source.get('page_end') or source.get('page_start') or '?'}",
            f"Section: {source.get('heading_path') or source.get('heading') or 'Unknown'}",
            f"Association: {source.get('feature_association') or 'none'}",
        ]
        if source.get("feature_ids"):
            details.append("Feature identities: " + ", ".join(source["feature_ids"]))
        if source.get("package_ids"):
            details.append("Package identities: " + ", ".join(source["package_ids"]))
        blocks.append("\n".join(details) + "\n\n" + content)
    return "\n\n---\n\n".join(blocks)


def _extractive_answer(query: str, evidence: Sequence[Dict[str, Any]]) -> str:
    if not evidence:
        return "I could not find supporting material in the indexed Ericsson documentation."
    lines = ["The indexed Ericsson documentation provides the following relevant evidence:"]
    for index, hit in enumerate(evidence[:4], 1):
        source = _source(hit)
        content = str(source.get("content") or "").strip()
        # Prefer the first substantive paragraph and keep deterministic citations.
        paragraphs = [p.strip() for p in content.split("\n\n") if p.strip() and not p.lstrip().startswith("#")]
        snippet = paragraphs[0] if paragraphs else content
        if len(snippet) > 900:
            snippet = snippet[:900].rsplit(" ", 1)[0] + "…"
        title = str(source.get("title") or source.get("filename") or "Ericsson document")
        heading = str(source.get("heading_path") or "")
        prefix = f"**{title}**"
        if heading:
            prefix += f" — {heading}"
        lines.append(f"{prefix}: {snippet} [E{index}]")
    return "\n\n".join(lines)


def synthesize_answer(
    query: str,
    evidence: Sequence[Dict[str, Any]],
    *,
    ollama: OllamaClient | None,
    graph_context: Dict[str, Any] | None = None,
    history: str = "",
    effective_query: str = "",
) -> Tuple[str, List[str]]:
    if not evidence and not graph_context:
        return "I could not find supporting material in the indexed Ericsson documentation.", []

    warnings: List[str] = []
    if ollama is None:
        return _extractive_answer(query, evidence), warnings

    evidence_text = compact_evidence(evidence)
    graph_text = ""
    if graph_context:
        graph_text = "\n\nGRAPH CONTEXT (only use facts explicitly present):\n" + str(graph_context)
    system = DEFAULT_SYSTEM_PROMPT
    history_text = str(history or "").strip()
    history_section = ""
    if history_text:
        history_section = (
            "CONVERSATION HISTORY (context only; factual claims still require current evidence):\n"
            f"{history_text}\n\n"
        )
    resolved = str(effective_query or "").strip()
    resolved_section = ""
    if resolved and resolved != str(query).strip():
        resolved_section = (
            "RESOLVED RETRIEVAL QUESTION (from conversation-aware rewrite):\n"
            f"{resolved}\n\n"
        )
    prompt = (
        f"{history_section}"
        f"USER QUESTION:\n{query}\n\n"
        f"{resolved_section}"
        f"ERICSSON DOCUMENT EVIDENCE:\n{evidence_text}{graph_text}\n\n"
        "Write a direct technical answer. Preserve Ericsson terminology. Use only valid evidence markers [E1], [E2], etc."
    )
    try:
        answer = (
            ollama.generate(prompt, system=system, temperature=0.1, purpose="answer_synthesis")
            if isinstance(ollama, OllamaClient)
            else ollama.generate(prompt, system=system, temperature=0.1)
        )
        answer = answer.replace("<answer>", "").replace("</answer>", "").strip()
        return answer, warnings
    except ServiceClientError as exc:
        warnings.append(str(exc) + "; returned an extractive answer instead.")
        return _extractive_answer(query, evidence), warnings
