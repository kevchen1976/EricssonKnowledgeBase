"""Conversation-aware Ericsson query rewriting, aligned with the Nokia agent."""
from __future__ import annotations

import logging
import re

from .clients import OllamaClient
from .ids import find_feature_ids, find_package_ids
from .logging_utils import single_line_words

logger = logging.getLogger("ericsson_agent")


def looks_like_raw_alarm(text: str) -> bool:
    """Avoid rewriting pasted operational alarm rows/log lines."""
    product_tokens = r"Baseband|Radio\s+Node|ENM|NRCell|EUtranCell|GNBCU|GNBDU|NodeB|eNodeB|gNodeB"
    if not re.search(r"\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}", str(text or "")):
        return False
    return bool(re.search(product_tokens, str(text or ""), re.IGNORECASE))


def parse_rewritten_query(raw: str) -> str:
    """Extract only the query when a model adds an unwanted label or markup."""
    text = str(raw or "").strip()
    text = re.sub(r"^```(?:text|markdown)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    prefixes = (
        "the rewritten query is:",
        "rewritten query:",
        "rewritten:",
        "the query is:",
        "query:",
        "the rewritten query is",
        "rewritten query is",
    )
    lowered = text.casefold()
    for prefix in prefixes:
        if lowered.startswith(prefix.casefold()):
            text = text[len(prefix) :].strip()
            break
    text = text.strip('"').strip("'")
    text = re.sub(r"\*\*([^*]+)\*\*", r"\1", text)
    text = re.sub(r"__([^_]+)__", r"\1", text)
    return " ".join(text.split()).strip()


def rewrite_query_with_llm(query: str, history: str, ollama: OllamaClient) -> str:
    """Resolve follow-up references using recent Redis-backed history.

    Like the Nokia implementation, failures are fail-open: the original query
    remains the effective retrieval query when the rewriter is unavailable.
    """
    original = " ".join(str(query or "").split()).strip()
    history_text = str(history or "").strip()
    logger.info("[REWRITE HISTORY] history_chars=%d", len(history_text))
    if history_text:
        logger.info(
            "[REWRITE HISTORY] preview=%s",
            single_line_words(history_text, max_words=50),
        )
    else:
        logger.info("[REWRITE HISTORY] History is empty")

    prompt = f"""
You are a query rewriter for an Ericsson RAN documentation assistant. Given the conversation history and the current user query, rewrite the current query into a fully self-contained query that resolves pronouns, omitted subjects, and references to earlier answers.

IMPORTANT RULES:
- Output ONLY the rewritten query text.
- Do not add explanations, labels, quotation marks, markdown, or an answer.
- Preserve Ericsson identities exactly when they appear: FAJ 121 xxxx is a Feature Identity and FAJ 801 xxxx is a Value Package Identity.
- Do not invent an Ericsson identity that is absent from both the current query and the conversation history.
- Keep a query unchanged when it is already self-contained.

Examples:

History:
User: What is FAJ 121 0488?
Assistant: FAJ 121 0488 is the 16-QAM Uplink feature.
Current query: What are its dependencies?
Rewritten: What are the dependencies of FAJ 121 0488?

History:
User: Which package contains FAJ 121 0488?
Assistant: It is associated with Value Package FAJ 801 0400.
Current query: Does that package require a licence?
Rewritten: Does Value Package FAJ 801 0400 require a licence?

History:
User: Explain the Instantaneous Licensing connected mode.
Assistant: Connected mode uses ENM, CAS, and ELIS for automated licence requests and delivery.
Current query: How does non-connected mode differ?
Rewritten: How does Instantaneous Licensing non-connected mode differ from connected mode?

History:
User: What is the recommended MTU approach with IPsec?
Assistant: The guideline recommends adjusting the end-to-end MTU to the transport-network capability to avoid fragmentation.
Current query: What happens if it is not adjusted?
Rewritten: What happens if the end-to-end MTU is not adjusted for IPsec overhead?

Now rewrite the current query.

Conversation history (previous user/assistant exchanges):
{history_text}

Current user query: {original}

Rewritten query (ONLY the query text):
""".strip()

    try:
        rewritten_raw = (
            ollama.generate(prompt, temperature=0.1, purpose="query_rewrite")
            if isinstance(ollama, OllamaClient)
            else ollama.generate(prompt, temperature=0.1)
        )
        rewritten = parse_rewritten_query(rewritten_raw)
        if not rewritten:
            logger.warning("[REWRITE] Empty response from LLM; using original query")
            return original

        allowed_feature_ids = set(find_feature_ids(original + "\n" + history_text))
        allowed_package_ids = set(find_package_ids(original + "\n" + history_text))
        rewritten_feature_ids = set(find_feature_ids(rewritten))
        rewritten_package_ids = set(find_package_ids(rewritten))
        unexpected_features = sorted(rewritten_feature_ids - allowed_feature_ids)
        unexpected_packages = sorted(rewritten_package_ids - allowed_package_ids)
        if unexpected_features or unexpected_packages:
            logger.warning(
                "[REWRITE] Rejected rewrite containing identities absent from query/history features=%s packages=%s",
                unexpected_features,
                unexpected_packages,
            )
            return original

        logger.info(
            "[REWRITE] original=%r rewritten=%r changed=%s",
            original,
            rewritten,
            rewritten != original,
        )
        return rewritten
    except Exception as exc:
        logger.warning("[REWRITE] LLM rewrite failed: %s. Using original query.", exc)
        return original
