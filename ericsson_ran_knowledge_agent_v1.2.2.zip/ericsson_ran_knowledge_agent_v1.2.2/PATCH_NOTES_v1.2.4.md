# Ericsson RAN Knowledge Agent v1.2.4

This release aligns the standalone Ericsson agent's conversational behavior
with the supplied Nokia agent. It does not change the RAG indexes or scoring.

## Added

- Redis-backed recent conversation history.
- Ericsson-isolated Redis keys: `ericsson:session:<session_id>`.
- Five-turn default memory with one-hour sliding TTL.
- Conversation-aware LLM query rewrite before Ericsson routing/retrieval.
- Bounded history passed to final answer synthesis.
- Original/effective query metadata and audit details.
- Redis startup and readiness checks.
- `scripts/check_redis.py` and launcher `redis-check` command.
- Nokia-style environment names `SESSION_TTL` and `MAX_HISTORY`.

## Preserved

- Existing OpenSearch parent, child, and manifest aliases.
- Existing vectors and embedding dimension.
- Existing chunk boundaries and prepared Markdown.
- BM25, vector recall, RRF, reranker, selection and logging behavior.
- SQLite audit schema and stored records.
- Disabled-by-default Neo4j scaffold.

No OpenSearch re-ingestion is required.

## Deployment

Install the new Python dependency:

```bash
source .venv/bin/activate
python -m pip install -r requirements.txt
```

Use the existing shared Redis instance used by Nokia, normally:

```text
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0
REDIS_KEY_PREFIX=ericsson:session:
SESSION_TTL=3600
MAX_HISTORY=5
```

Check it before restart:

```bash
python scripts/check_redis.py
# or
./startup_all_service.sh redis-check
```

Then restart only the Ericsson services:

```bash
./startup_all_service.sh restart
```

Test a follow-up in one session:

```bash
curl -s -X POST http://localhost:8100/query \
  -H 'Content-Type: application/json' \
  -d '{"query":"What is FAJ 121 0488?","session_id":"memory-test"}'

curl -s -X POST http://localhost:8100/query \
  -H 'Content-Type: application/json' \
  -d '{"query":"What are its dependencies?","session_id":"memory-test"}'
```

The second response should report a rewritten query in
`metadata.effective_query`. Relevant log markers are:

```text
[REDIS]
[MEMORY]
[REWRITE HISTORY]
[REWRITE]
[WORKFLOW EFFECTIVE QUERY]
```
