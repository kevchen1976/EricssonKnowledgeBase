from types import SimpleNamespace

import agent_core.clients as clients


class _Response:
    status_code = 200

    def raise_for_status(self):
        return None

    def json(self):
        return {
            "response": "answer text",
            "eval_count": 7,
            "prompt_eval_count": 11,
            "total_duration": 1234,
        }


class _Client:
    last_json = None

    def __init__(self, *args, **kwargs):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def post(self, url, json):
        self.__class__.last_json = json
        return _Response()


def _settings(verbose=True):
    return SimpleNamespace(
        llm_enabled=True,
        ollama_model="test-model",
        ollama_url="http://localhost:11434/api/generate",
        ollama_timeout=10,
        ollama_verbose=verbose,
        ollama_log_prompt_max_chars=8,
        ollama_log_response_max_chars=6,
    )


def test_verbose_logging_is_bounded_but_outbound_payload_is_not(monkeypatch):
    monkeypatch.setattr(clients.httpx, "Client", _Client)
    messages = []

    def capture(message, *args):
        messages.append(message % args if args else message)

    monkeypatch.setattr(clients.logger, "info", capture)
    result = clients.OllamaClient(_settings()).generate(
        "123456789012345",
        system="abcdefghijklm",
        purpose="query_rewrite",
    )

    assert result == "answer text"
    assert _Client.last_json["prompt"] == "123456789012345"
    assert _Client.last_json["system"] == "abcdefghijklm"
    text = "\n".join(messages)
    assert "[OLLAMA REQUEST]" in text
    assert "purpose=query_rewrite" in text
    assert "prompt_truncated=True" in text
    assert "[OLLAMA RESPONSE]" in text
    assert "response_truncated=True" in text
    assert "...[log truncated]" in text


def test_verbose_logging_can_be_disabled(monkeypatch):
    monkeypatch.setattr(clients.httpx, "Client", _Client)
    messages = []
    monkeypatch.setattr(clients.logger, "info", lambda message, *args: messages.append(message))
    assert clients.OllamaClient(_settings(False)).generate("hello", purpose="answer_synthesis") == "answer text"
    assert messages == []
