"""Read-only Ericsson graph queries with mandatory vendor/corpus scoping."""
from __future__ import annotations

from typing import Any, Dict, List

from agent_core.ids import normalize_feature_id, normalize_package_id

from .state import GraphState


class GraphRepository:
    def __init__(self, state: GraphState) -> None:
        self.state = state
        self.settings = state.settings

    def _run(self, query: str, **parameters: Any) -> List[Dict[str, Any]]:
        parameters.setdefault("vendor", self.settings.vendor)
        parameters.setdefault("corpus_id", self.settings.corpus_id)
        with self.state.driver().session(database=self.settings.neo4j_database or None) as session:
            result = session.run(query, **parameters)
            return [dict(record) for record in result]

    def feature_context(self, value: str) -> Dict[str, Any]:
        feature_id = normalize_feature_id(value)
        if not feature_id:
            raise ValueError("Expected FAJ 121 xxxx feature identity")
        rows = self._run(
            """
            MATCH (f:Feature {id: $feature_id, vendor: $vendor, corpus_id: $corpus_id})
            OPTIONAL MATCH (f)-[:IN_PACKAGE]->(p:Package {vendor: $vendor, corpus_id: $corpus_id})
            OPTIONAL MATCH (d:Document {vendor: $vendor, corpus_id: $corpus_id})-[:DOCUMENTS_FEATURE]->(f)
            OPTIONAL MATCH (f)-[:APPLIES_TO_ACCESS]->(a:AccessType {vendor: $vendor, corpus_id: $corpus_id})
            OPTIONAL MATCH (f)-[:APPLIES_TO_NODE_TYPE]->(n:NodeType {vendor: $vendor, corpus_id: $corpus_id})
            RETURN properties(f) AS feature,
                   collect(DISTINCT properties(p)) AS packages,
                   collect(DISTINCT properties(d)) AS documents,
                   collect(DISTINCT properties(a)) AS access_types,
                   collect(DISTINCT properties(n)) AS node_types
            """,
            feature_id=feature_id,
        )
        if not rows:
            return {"feature_id": feature_id, "found": False}
        return {"feature_id": feature_id, "found": True, **rows[0]}

    def package_context(self, value: str) -> Dict[str, Any]:
        package_id = normalize_package_id(value)
        if not package_id:
            raise ValueError("Expected FAJ 801 xxxx package identity")
        rows = self._run(
            """
            MATCH (p:Package {id: $package_id, vendor: $vendor, corpus_id: $corpus_id})
            OPTIONAL MATCH (f:Feature {vendor: $vendor, corpus_id: $corpus_id})-[:IN_PACKAGE]->(p)
            OPTIONAL MATCH (d:Document {vendor: $vendor, corpus_id: $corpus_id})-[:DOCUMENTS_PACKAGE]->(p)
            OPTIONAL MATCH (p)-[:APPLIES_TO_ACCESS]->(a:AccessType {vendor: $vendor, corpus_id: $corpus_id})
            OPTIONAL MATCH (p)-[:APPLIES_TO_NODE_TYPE]->(n:NodeType {vendor: $vendor, corpus_id: $corpus_id})
            RETURN properties(p) AS package,
                   collect(DISTINCT properties(f)) AS features,
                   collect(DISTINCT properties(d)) AS documents,
                   collect(DISTINCT properties(a)) AS access_types,
                   collect(DISTINCT properties(n)) AS node_types
            """,
            package_id=package_id,
        )
        if not rows:
            return {"package_id": package_id, "found": False}
        return {"package_id": package_id, "found": True, **rows[0]}


    def search_context(self, query_text: str, *, limit: int = 20) -> Dict[str, Any]:
        value = " ".join(str(query_text or "").split()).casefold()
        if not value:
            return {"query": query_text, "matches": []}
        rows = self._run(
            """
            MATCH (n)
            WHERE n.vendor = $vendor AND n.corpus_id = $corpus_id
              AND (toLower(coalesce(n.id, '')) CONTAINS $query_text
                   OR toLower(coalesce(n.title, '')) CONTAINS $query_text
                   OR toLower(coalesce(n.name, '')) CONTAINS $query_text)
            OPTIONAL MATCH (n)-[r]-(m)
            WHERE m.vendor = $vendor AND m.corpus_id = $corpus_id
            RETURN labels(n) AS labels, properties(n) AS entity,
                   collect(DISTINCT {relation: type(r), labels: labels(m), target: properties(m)})[0..10] AS relations
            LIMIT $limit
            """,
            query_text=value,
            limit=limit,
        )
        return {"query": query_text, "matches": rows}

    def relations(self, value: str, *, limit: int = 100) -> Dict[str, Any]:
        feature_id = normalize_feature_id(value)
        package_id = normalize_package_id(value)
        if feature_id:
            rows = self._run(
                """
                MATCH (n:Feature {id: $entity_id, vendor: $vendor, corpus_id: $corpus_id})-[r]-(m)
                WHERE m.vendor = $vendor AND m.corpus_id = $corpus_id
                RETURN type(r) AS relation, labels(m) AS labels, properties(m) AS target
                LIMIT $limit
                """,
                entity_id=feature_id,
                limit=limit,
            )
            return {"entity_id": feature_id, "entity_type": "Feature", "relations": rows}
        if package_id:
            rows = self._run(
                """
                MATCH (n:Package {id: $entity_id, vendor: $vendor, corpus_id: $corpus_id})-[r]-(m)
                WHERE m.vendor = $vendor AND m.corpus_id = $corpus_id
                RETURN type(r) AS relation, labels(m) AS labels, properties(m) AS target
                LIMIT $limit
                """,
                entity_id=package_id,
                limit=limit,
            )
            return {"entity_id": package_id, "entity_type": "Package", "relations": rows}
        raise ValueError("Expected an Ericsson FAJ 121 or FAJ 801 identity")
