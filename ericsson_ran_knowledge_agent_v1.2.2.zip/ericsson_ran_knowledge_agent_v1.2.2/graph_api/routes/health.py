from __future__ import annotations

from fastapi import APIRouter, Response, status

from ..state import get_state

router = APIRouter()


@router.get("/health")
def health() -> dict:
    state = get_state()
    return {
        "status": "ok" if not state.enabled else state.status().get("status", "unknown"),
        "service": "ericsson-graph-api",
        "graph": state.status(),
    }


@router.get("/ready")
def ready(response: Response) -> dict:
    graph = get_state().status()
    ready_value = bool(graph.get("connected"))
    if not ready_value:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    return {"ready": ready_value, "graph": graph}
