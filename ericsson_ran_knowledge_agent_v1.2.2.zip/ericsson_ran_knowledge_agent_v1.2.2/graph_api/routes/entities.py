from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query

from ..repository import GraphRepository
from ..state import GraphDisabledError, get_state

router = APIRouter()


def _repository() -> GraphRepository:
    state = get_state()
    if not state.enabled:
        raise HTTPException(status_code=503, detail="Ericsson Neo4j integration is disabled")
    return GraphRepository(state)


def _translate(call):
    try:
        return call()
    except GraphDisabledError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Ericsson graph query failed: {exc}") from exc


@router.get("/feature/{feature_id}/context")
def feature_context(feature_id: str) -> dict:
    return _translate(lambda: _repository().feature_context(feature_id))


@router.get("/package/{package_id}/context")
def package_context(package_id: str) -> dict:
    return _translate(lambda: _repository().package_context(package_id))



@router.get("/relations/search")
def search_relations(query: str, limit: int = Query(20, ge=1, le=100)) -> dict:
    return _translate(lambda: _repository().search_context(query, limit=limit))

@router.get("/relations/{entity_id}")
def relations(entity_id: str, limit: int = Query(100, ge=1, le=1000)) -> dict:
    return _translate(lambda: _repository().relations(entity_id, limit=limit))
