"""Lazy Neo4j lifecycle for the future Ericsson graph layer."""
from __future__ import annotations

import threading
from typing import Any, Optional

from agent_core.settings import Settings, get_settings


class GraphDisabledError(RuntimeError):
    pass


class GraphState:
    def __init__(self, settings: Optional[Settings] = None) -> None:
        self.settings = settings or get_settings()
        self._driver: Any = None
        self._lock = threading.RLock()

    @property
    def enabled(self) -> bool:
        return self.settings.graph_enabled

    def driver(self):
        if not self.enabled:
            raise GraphDisabledError("Ericsson Neo4j integration is disabled (GRAPH_ENABLED=false)")
        with self._lock:
            if self._driver is None:
                try:
                    from neo4j import GraphDatabase
                except ImportError as exc:
                    raise RuntimeError("neo4j Python package is not installed") from exc
                auth = (self.settings.neo4j_user, self.settings.neo4j_password)
                self._driver = GraphDatabase.driver(self.settings.neo4j_uri, auth=auth)
            return self._driver

    def close(self) -> None:
        with self._lock:
            if self._driver is not None:
                self._driver.close()
                self._driver = None

    def status(self) -> dict[str, Any]:
        if not self.enabled:
            return {"enabled": False, "connected": False, "status": "disabled"}
        try:
            driver = self.driver()
            driver.verify_connectivity()
            return {"enabled": True, "connected": True, "status": "ok", "uri": self.settings.neo4j_uri, "database": self.settings.neo4j_database}
        except Exception as exc:
            return {"enabled": True, "connected": False, "status": "error", "error": str(exc)}


_STATE: Optional[GraphState] = None


def get_state(*, reload: bool = False) -> GraphState:
    global _STATE
    if _STATE is None or reload:
        _STATE = GraphState()
    return _STATE
