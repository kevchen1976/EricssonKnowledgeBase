"""FastAPI assembly for the optional Ericsson Neo4j graph service."""
from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI

from agent_core.constants import PACKAGE_VERSION

from .routes import entities, health
from .state import get_state


@asynccontextmanager
async def lifespan(_app: FastAPI):
    yield
    get_state().close()


app = FastAPI(
    title="Ericsson RAN Knowledge Graph API",
    version=PACKAGE_VERSION,
    description="Scaffolded Neo4j API; disabled until Ericsson relationships are curated and imported.",
    lifespan=lifespan,
)
app.include_router(entities.router)
app.include_router(health.router)
