# Ericsson RAN Knowledge Agent

Version **1.2.4** is an Ericsson-specific sibling of the supplied Nokia RAN knowledge agent. It keeps the standalone Agent, Knowledge Base, and future Graph API boundaries, while using Ericsson identities, document roles, manifests, and OpenSearch namespaces.

The first deployment phase is Markdown/manifest ingestion and OpenSearch retrieval. Neo4j code is included but disabled until Ericsson relations have been curated.

## Runtime architecture

```text
Client or future supervisor
          |
          v
Ericsson Agent API :8100
          |
          +-------------------> Ericsson KB API :8102
          |                            |
          |                            v
          |                  shared OpenSearch cluster
          |                  Ericsson aliases only
          |
          +-------------------> Ericsson Graph API :8101
                                       |
                                       v
                              Neo4j (disabled initially)
```

The Nokia and Ericsson agents remain independently callable. A future supervisor should call their APIs rather than bypassing vendor-specific retrieval and querying their stores directly.

## Nokia-aligned Redis memory and query rewriting (v1.2.4)

The standalone Ericsson Agent API now follows the Nokia conversation flow:

```text
/query
  -> load recent exchanges from Redis
  -> format the last MAX_HISTORY turns
  -> rewrite the current follow-up into a self-contained Ericsson query
  -> route and retrieve with the rewritten query
  -> synthesize using current evidence plus bounded conversation context
  -> audit the query/answer in SQLite
  -> append the completed exchange to Redis with a sliding TTL
```

Ericsson can share the Redis server or Docker container already used by Nokia.
The default key namespace is deliberately separate:

```text
Nokia:     session:<session_id>
Ericsson:  ericsson:session:<session_id>
```

Defaults mirror Nokia where practical:

```text
SESSION_MEMORY_ENABLED=true
ENABLE_LLM_QUERY_REWRITE=true
SESSION_TTL=3600
MAX_HISTORY=5
SESSION_HISTORY_ANSWER_CHARS=2000
SESSION_STORED_ANSWER_CHARS=4000
```

The rewriter runs before Ericsson ID detection, manifest routing, BM25/vector
retrieval, RRF and reranking. It understands `FAJ 121 xxxx` Feature Identities
and `FAJ 801 xxxx` Value Package Identities and fails open to the original query
when Ollama cannot rewrite. Raw alarm-style records are not rewritten.

`config/services.env.example` is now documentation only. Like the Nokia
launcher, `startup_all_service.sh` sources `config/services.env` only when that
real deployment file exists; otherwise `config/settings.json` and exported
environment variables are used.

Install the updated runtime dependency and create a local deployment file when needed:

```bash
source .venv/bin/activate
python -m pip install -r requirements.txt
cp config/services.env.example config/services.env  # only when env overrides are desired
```

Check the shared Redis connection with:

```bash
./startup_all_service.sh redis-check
# or
python scripts/check_redis.py
```

No OpenSearch re-ingestion is required for v1.2.4.

## Nokia-aligned parent/child storage

The Ericsson ingestion path now follows the supplied Nokia section-aware strategy:

```text
real Ericsson document section
             |
             +--> parent index: full section stored once, no vector
             |
             `--> child index: overlapping retrieval windows + vectors
                                      |
                                      v
                           rank child search hits
                                      |
                                      v
                       one mget for unique parent IDs
                                      |
                                      v
                     full parent sections sent to answer layer
```

Important defaults:

```text
one real outline section = one parent
parent soft limit         = 3000 tokens (diagnostic only; it never splits a parent)
child window              = 300 tokens
child overlap             = 60 tokens
procedure preservation    = keep one child when procedure-like section <= 480 tokens
heading prefix            = added to later child windows
```

Production boundaries use the tokenizer belonging to the configured embedding model, normally BGE. A reversible regex tokenizer is used only for offline validation when model files are unavailable.

Version 1.2.1 adds a strict embedding-length guard. Complete parent sections may be longer than the model limit because they are stored, not embedded. Final child `embedding_text` values are tokenized with special tokens and checked against the loaded `SentenceTransformer.max_seq_length` before any OpenSearch index is created. For `bge-large-en-v1.5`, the detected limit is normally 512 tokens. Any overflow stops the run before OpenSearch is touched and writes `logs/embedding_preflight_failure_<run_id>.json`.

The parent section counter uses non-truncating tokenizer calls with advisory warnings disabled. This removes the misleading `740 > 512` message caused by measuring a long non-vector parent while retaining a fail-closed assertion for actual embedding inputs.

The parser is TOC-aware and rejects numbered procedure steps and numeric table rows as section headings. Ericsson section paths are supported through six numeric levels, including four-level headings such as `2.2.3.1 Radio Node` and `3.2.2.1 ...`.

Manifest records remain in the manifest index. `INCLUDE_MANIFEST_FACTS=false` by default so the parent index contains real document sections rather than duplicated fact records. The compatibility option can be enabled when fact-specific vector retrieval is deliberately required.

## Shared OpenSearch, separate Ericsson indexes

The physical cluster may be shared with Nokia. Ericsson uses three aliases and versioned backing indexes:

```text
ericsson-ran-kb-children
  -> ericsson-ran-kb-children-v<version>

ericsson-ran-kb-parents
  -> ericsson-ran-kb-parents-v<version>

ericsson-ran-kb-manifests
  -> ericsson-ran-kb-manifests-v<version>
```

Only child documents contain an `embedding`. Parent documents contain full section `content` once. Child documents reference the parent through `parent_id` and `parent_storage_id`; they do not contain a duplicated `parent_content` field.

Version 1.2.1 makes this contract fail-closed by default:

```text
REQUIRE_PARENT_CONTEXT=true
VERIFY_PARENT_CONTENT_HASH=true
EMBEDDING_INPUT_MODE=content
```

Each parent stores `content_sha256`; every child stores the expected `parent_content_sha256`. Query-time parent expansion rejects a missing or mismatched parent rather than silently answering from a child fragment. The default embedding input is exactly the stored child `content`, matching the supplied Nokia strategy. Metadata-enriched embedding text remains available only as an explicit `content_plus_metadata` experiment that requires a full reindex.

Every managed index name must start with `ericsson-ran-kb-`. Queries and cleanup operations are also scoped by:

```text
vendor    = Ericsson
corpus_id = ericsson-ran
```

A rebuild writes all three new indexes and switches all three aliases in one OpenSearch aliases request. This prevents a new child generation from being served with an old parent or manifest generation.

## Repository map

| Path | Purpose |
|---|---|
| `ericsson_preparation/` | Docling-first PDF extraction, adjacent image folders, Ericsson analysis and manifests |
| `ingestion/` | TOC-aware section parsing, separate parent/child generation, embeddings and OpenSearch deployment |
| `kb_api/` | Manifest resolution, BM25/KNN child search, RRF/reranking and parent `mget` expansion |
| `agent_core/` | Ericsson ID routing, synthesis, validation, audit and workflow |
| `agent_service/` | Standalone `/query`, health, readiness, capabilities and sessions |
| `graph_api/`, `neo4j/` | Disabled-by-default graph scaffold and staging importer |
| `examples/prepared_fixture/` | Synthetic non-product fixture for offline validation |
| `scripts/` | Validation, package verification and deployment diagnostics |

## RAG trace logging and SQLite query audit

Version 1.2.2 adds observability only; it does not change chunking, embeddings, OpenSearch mappings, retrieval scoring, result selection, API response models, or stored vector data. Existing Ericsson indexes remain valid and no re-ingestion is required.

The runtime writes three request-correlated log files under the configured `LOGS_DIR` (default `logs/`):

```text
logs/chunks.log            detailed RAG trace
logs/ericsson_kb.log        KB request/result summaries
logs/ericsson_agent.log     routing, synthesis, validation, and query lifecycle
```

`chunks.log` records the important parent/child RAG stages:

```text
RAG START
BM25_RECALL
VECTOR_RECALL
RRF
RERANKER (or RERANKER_DISABLED / RERANKER_FALLBACK)
FINAL_CHILD_SELECTION
PARENT_MGET_REQUEST / PARENT_MGET_RESULT
FINAL_PARENT_SELECTION
RAG COMPLETE
```

Each line includes `request_id`; each KB search also has a `search_id`, because one Agent request can run more than one feature/package search. Recalled child entries include rank, score, parent ID, document, page, heading path, association, and a bounded content snippet. RRF entries include source ranks/scores, reranker entries include cross-encoder scores, and final entries show the association/manifest boosts used by the existing ranking logic.

The Agent API also records every completed or failed `/query` request in the configured SQLite file:

```text
AUDIT_ENABLED=true
AUDIT_DB_PATH=data/ericsson_agent_audit.db
```

The canonical table is `audit`, compatible with the Nokia audit fields and extended with Ericsson IDs, citations, warnings, success/error status, and the complete response JSON. An existing v1.2.1 `query_audit` table is retained; its old rows are copied into `audit`, and new rows are dual-written for compatibility. Audit failures are logged but do not change the user response.

Example inspection:

```bash
tail -f logs/chunks.log
tail -f logs/ericsson_agent.log

python - <<'PY'
import sqlite3

with sqlite3.connect('data/ericsson_agent_audit.db') as connection:
    row = connection.execute(
        """
        SELECT request_id, created_at, query, workflow, final_answer,
               validation_ok, latency_ms
        FROM audit
        ORDER BY created_at DESC
        LIMIT 1
        """
    ).fetchone()
    print(row)
PY
```

## 1. Install

Use Python 3.10 or newer.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

For PDF extraction and future graph work:

```bash
python -m pip install -r requirements-all.txt
```

Copy the deployment configuration:

```bash
cp config/services.env.example config/services.env
```

Point `EMBEDDING_MODEL_PATH` at the local model used both during ingestion and query-time embedding. Model files may be shared with Nokia, but the OpenSearch indexes remain separate.

## 2. Prepare Ericsson PDFs

```bash
python -m ericsson_preparation /path/to/ericsson-pdfs \
  --output-dir data/prepared \
  --overwrite
```

Expected output:

```text
data/prepared/
├── markdown/
│   ├── 16-QAM Uplink.md
│   └── 16-QAM_Uplink_images/
│       └── page_001_image_001.png
├── manifests/
├── combined_manifest.jsonl
├── ericsson_feature_catalog.json
├── ericsson_feature_catalog.csv
└── routing-manifest/
    ├── by-feature-id/FAJ121/
    ├── by-package-id/FAJ801/
    ├── by-mentioned-feature-id/FAJ121/
    └── by-topic/
```

Relative image links remain portable:

```markdown
![Figure on page 1](16-QAM_Uplink_images/page_001_image_001.png)
```

Already-generated Markdown can be manifested without re-extracting PDFs:

```bash
python generate_manifest_ericsson.py data/prepared/markdown \
  --output-dir data/prepared \
  --overwrite
```

## 3. Validate and preview parent/child documents

```bash
python scripts/validate_prepared_data.py data/prepared \
  --output logs/prepared_validation.json
```

The validator checks identity ownership, page ranges, section hierarchy, image links, parent/child references, absence of vectors in parents, and absence of duplicated parent text in children.

Preview without vectors or a database connection:

```bash
python ingest_ericsson.py \
  --prepared-root data/prepared \
  --mode dry-run \
  --skip-embeddings
```

The preview contains:

```text
data/prepared/ingestion-preview/
├── parents.jsonl
├── children.jsonl
├── manifests.jsonl
└── graph_staging_relationships.jsonl
```

Test the vector document shape with deterministic non-semantic vectors:

```bash
python ingest_ericsson.py \
  --prepared-root examples/prepared_fixture \
  --mode dry-run \
  --test-embedder
```

Never use the deterministic hash embedder for production retrieval.

Validate the actual storage contract in that preview:

```bash
python scripts/verify_parent_child_storage.py \
  --preview-dir examples/prepared_fixture/ingestion-preview \
  --require-embeddings
```

After live ingestion, sample the deployed aliases through either:

```bash
python scripts/verify_parent_child_storage.py --live --sample-size 100
curl 'http://localhost:8102/kb/debug/parent-child-status?sample_size=100'
```

## 4. Ingest into the shared OpenSearch cluster

Run the model-tokenizer preflight first. It generates no vectors and sends no OpenSearch request:

```bash
python scripts/check_embedding_lengths.py \
  --prepared-root data/prepared \
  --output logs/embedding_length_preflight.json
```

Proceed only when the report says `status: passed`, `over_limit_inputs: 0`, and `largest_input_tokens <= model_max_tokens`.

Check connectivity and configured aliases:

```bash
python scripts/check_opensearch.py
```

Initial or release-safe rebuild:

```bash
python ingest_ericsson.py \
  --prepared-root data/prepared \
  --mode rebuild \
  --version 20260902
```

Parents are indexed before children. After parent, child, and manifest bulk writes and refreshes succeed, all three aliases are switched together. Previous Ericsson backing indexes remain available for rollback unless `--delete-old` is supplied.

Incremental replacement is supported after all three aliases have write indexes:

```bash
python ingest_ericsson.py \
  --prepared-root data/prepared \
  --mode incremental
```

Incremental records use run-scoped physical IDs. Children reference the physical parent ID from the same run. Replacement records are written before older records for the affected filenames are removed. Rebuild mode remains preferable for production releases because it provides the cleanest rollback boundary.

### Migration from agent v1.0

Version 1.2 uses separate `children`, `parents`, and `manifests` aliases instead of the v1.0 combined `chunks` alias. Build a fresh v1.2 release with `--mode rebuild`; do not point the parent alias at the old combined index. Existing v1.1 indexes should also be rebuilt so every parent/child pair receives the v1.2 integrity hashes and storage-role metadata.

## 5. Start the standalone services

```bash
./startup_all_service.sh start
./startup_all_service.sh status
```

The launcher controls only Ericsson API processes. It does not start or stop OpenSearch, Nokia services, Ollama, Redis, or Neo4j.

Direct startup:

```bash
python local_kb_api.py       # :8102
python agent_web.py          # :8100
python local_graph_api.py    # :8101; disabled until GRAPH_ENABLED=true
```

KB `/ready` requires the Ericsson child, parent, and manifest aliases.

Docker Compose can run the API services while reusing an external/shared OpenSearch cluster:

```bash
docker compose -f docker-compose.services.yml up --build ericsson-kb ericsson-agent
```

## 6. Query APIs

Generic retrieval:

```bash
curl -X POST http://localhost:8102/kb/search \
  -H 'Content-Type: application/json' \
  -d '{"query":"IPsec MTU fragmentation", "limit":5}'
```

Feature retrieval:

```bash
curl -X POST 'http://localhost:8102/kb/feature/FAJ%20121%200488/retrieve' \
  -H 'Content-Type: application/json' \
  -d '{"query":"What are the dependencies?", "limit":5, "include_related":true}'
```

Standalone agent:

```bash
curl -X POST http://localhost:8100/query \
  -H 'Content-Type: application/json' \
  -d '{"query":"What does FAJ 121 0488 do?", "include_evidence":true}'
```

Search responses contain full parent sections plus `matched_children`, which records the child evidence that caused each parent to be selected.

## 7. Neo4j later

`GRAPH_ENABLED=false` is the default. Preparation and ingestion produce `graph_staging_relationships.jsonl`, and the package includes schema/import/API code. Review the relations before enabling writes:

```bash
python neo4j/import_staging.py \
  data/prepared/ingestion-preview/graph_staging_relationships.jsonl
```

After creating the Ericsson logical database, applying `neo4j/schema.cypher`, and configuring credentials:

```bash
GRAPH_ENABLED=true python neo4j/import_staging.py \
  data/prepared/ingestion-preview/graph_staging_relationships.jsonl \
  --execute
```

## Offline verification

```bash
python -m compileall -q .
pytest -q
python scripts/verify_package.py
```

See `VALIDATION_REPORT.md` and `docs/` for the design and validation details.

## Editable agent instruction and compact RAG logging (v1.2.3)

The Ericsson Agent now follows the Nokia prompt-file pattern. Its system
instruction is stored at the repository root:

```text
agentInstruction.txt
```

The file is loaded when the Agent process starts. Restart the Agent service
after editing it. If the file is missing or empty, the code uses a safe
Ericsson-specific fallback equivalent to the former hard-coded prompt.

Manifest routing is traced in `logs/chunks.log` before feature/package RAG
searches. The trace shows local routing-manifest paths, local record counts,
OpenSearch fallback, candidate records, and the selected direct/related
manifest documents.

To keep logs readable, every result-bearing stage prints no more than five
items and no more than the first 50 words of each item:

```text
MANIFEST RESULT
BM25_RECALL
VECTOR_RECALL
RRF
RERANKER
FINAL_CHILD
FINAL_PARENT
AGENT EVIDENCE
```

Total candidate counts and omitted counts are still written. This update is
logging/prompt configuration only and does not require OpenSearch re-ingestion.
