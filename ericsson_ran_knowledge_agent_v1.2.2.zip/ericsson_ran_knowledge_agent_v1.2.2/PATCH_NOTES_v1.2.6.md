# Patch notes — v1.2.6

## Added

- Dedicated rotating `logs/ollama.log`.
- Request-correlated Ollama request/response summaries for every model call.
- Optional bounded full payload logging with `OLLAMA_VERBOSE=1`.
- `OLLAMA_LOG_FILE`, `OLLAMA_LOG_MAX_BYTES`, and
  `OLLAMA_LOG_BACKUP_COUNT` settings.
- `scripts/check_ollama_log.py` for a no-network log-path verification.
- A concise breadcrumb in the normal Agent log showing the dedicated log path.

## Corrected

The v1.2.5 verbose records used the `ericsson_agent` Python logger. That logger
writes to `logs/ericsson_agent.log`, while the launcher captures process output
in `logs/ericsson-agent.log`. This naming split could make the Ollama records
appear to be missing. v1.2.6 writes them unambiguously to `logs/ollama.log`.

## Unchanged

- Ollama prompts, system instructions, model, options, and responses.
- Query rewrite behavior.
- Redis session memory.
- SQLite audit records.
- Manifest lookup, BM25, vector retrieval, RRF, reranking, and parent expansion.
- OpenSearch mappings, aliases, and indexed content.
- Neo4j behavior.
- Frontend behavior.

No re-ingestion is required.
