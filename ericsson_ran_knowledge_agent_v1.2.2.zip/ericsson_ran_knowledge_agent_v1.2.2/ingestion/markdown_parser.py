"""TOC-aware, page-aware section parsing for Ericsson CPI Markdown.

The parser mirrors the proven Nokia parent strategy:

* real document outline headings define parents;
* a parsed table of contents acts as an allow-list when available;
* numbered procedure steps are not promoted to document headings;
* Ericsson section numbers are supported through six levels, including common
  four-level headings such as ``2.2.3.1 Radio Node``;
* page markers, tables, lists, code blocks, and image references are preserved.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from .models import MarkdownBlock, MarkdownSection

HTML_PAGE_MARKER_RE = re.compile(r"^\s*<!--\s*page\s*:\s*(\d+)\s*-->\s*$", re.IGNORECASE)
TEXT_PAGE_MARKER_RE = re.compile(r"^\s*#{0,3}\s*Page\s+(\d+)\s*$", re.IGNORECASE)
# Public compatibility name used elsewhere in the package.
PAGE_MARKER_RE = HTML_PAGE_MARKER_RE
HEADING_RE = re.compile(r"^\s*(#{1,6})\s+(.+?)\s*$")
IMAGE_RE = re.compile(r"!\[([^\]]*)\]\(([^)]+)\)")
LIST_RE = re.compile(r"^\s*(?:[-+*–—]|\d+[.)])\s+")
TABLE_SEPARATOR_RE = re.compile(r"^\s*\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?\s*$")

# Ericsson documents commonly use 1, 2.2, 2.2.3 and 2.2.3.1.  Six levels
# are accepted so a future CPI document does not silently flatten deeper paths.
NUMBER_ONLY_RE = re.compile(r"^\s*(\d+(?:\.\d+){0,5})\.?\s*$")
NUMBERED_HEADING_RE = re.compile(r"^\s*(\d+(?:\.\d+){0,5})(\.)?\s+(.{2,240}?)\s*$")
TOC_ENTRY_RE = re.compile(r"^\s*(\d+(?:\.\d+){0,5})(?:\.)?\s+(.+?)\s*$")

PROCEDURE_COMMAND_PREFIXES = (
    "set ", "configure ", "go to ", "create ", "add ", "remove ", "check ",
    "verify ", "attach ", "detach ", "start ", "stop ", "run ", "select ",
    "ensure ", "observe ", "decrease ", "increase ", "initiate ", "trigger ",
    "launch ", "log on ", "open ", "follow ", "input ", "download ",
    "install ", "upload ", "perform ", "execute ", "migrate ", "unlock ",
    "activate ", "submit ", "obtain ", "locate ", "choose ",
)
GENERIC_PROCEDURE_LABELS = {
    "steps", "step", "procedure", "operational process", "prerequisites",
    "preconditions", "postconditions",
}


@dataclass(frozen=True)
class _Line:
    index: int
    text: str
    page: int
    page_marker: bool = False


def clean_line(line: str) -> str:
    value = str(line or "").replace("\u00a0", " ").replace("\u2007", " ").replace("\u202f", " ")
    return re.sub(r"\s+", " ", value).strip()


def _page_number(line: str) -> Optional[int]:
    for pattern in (HTML_PAGE_MARKER_RE, TEXT_PAGE_MARKER_RE):
        match = pattern.match(str(line or ""))
        if match:
            return int(match.group(1))
    return None


def _annotate_lines(markdown: str) -> List[_Line]:
    page = 1
    out: List[_Line] = []
    for index, raw in enumerate((markdown or "").splitlines()):
        marker = _page_number(raw)
        if marker is not None:
            page = marker
            out.append(_Line(index=index, text=raw, page=page, page_marker=True))
        else:
            out.append(_Line(index=index, text=raw, page=page, page_marker=False))
    return out


def normalize_number(number: str) -> str:
    return re.sub(r"\.+$", "", str(number or "").strip())


def level_from_number(number: str) -> int:
    value = normalize_number(number)
    return value.count(".") + 1 if value else 0


def normalize_title(title: str) -> str:
    value = re.sub(r"https?://\S+", " ", str(title or ""))
    value = re.sub(r"\.{2,}", " ", value)
    value = re.sub(r"<[^>]+>", " ", value)
    value = re.sub(r"[^0-9A-Za-z]+", " ", value).lower()
    return re.sub(r"\s+", " ", value).strip()


def titles_match(candidate: str, toc_title: str) -> bool:
    candidate_norm = normalize_title(candidate)
    toc_norm = normalize_title(toc_title)
    if not candidate_norm or not toc_norm:
        return False
    if candidate_norm == toc_norm:
        return True
    if candidate_norm.startswith(toc_norm) or toc_norm.startswith(candidate_norm):
        return True
    return SequenceMatcher(None, candidate_norm, toc_norm).ratio() >= 0.78


def _plausible_heading_title(title: str) -> bool:
    value = clean_line(title)
    if not value or len(value) > 240 or value[-1:] in ";!?":
        return False
    if value.startswith(("![", "<!--", "|")):
        return False
    if value.lower().startswith(("table ", "figure ")):
        return False
    if len(value.split()) > 32 or not re.search(r"[A-Za-z]{2}", value):
        return False
    if re.search(r"\b(?:bytes?|kbps|mbps|gbps|mhz|ghz|db|milliseconds?|microseconds?)\b", value, re.I):
        return False
    return bool(re.match(r"[A-Z0-9]", value))


def _looks_like_procedure_step(title: str) -> bool:
    normalized = normalize_title(title)
    return normalized.startswith(tuple(prefix.strip() for prefix in PROCEDURE_COMMAND_PREFIXES))


def _frontmatter_noise(line: str) -> bool:
    value = clean_line(line)
    if not value:
        return True
    if value.lower() in {"about:blank", "ericsson cpi"}:
        return True
    if re.fullmatch(r"\d{1,4}/\d{1,4}", value):
        return True
    if re.search(r"\b\d{1,2}:\d{2}\s*(?:AM|PM)?\b", value, re.I):
        return True
    if re.match(r"^\d{1,2}/\d{1,2}/\d{2,4}", value):
        return True
    return False


def _parse_toc_text(text: str, page: Optional[int] = None) -> Optional[Dict[str, Any]]:
    value = clean_line(re.sub(r"\.{2,}", " ", text or ""))
    if not value:
        return None
    if page is None:
        page_match = re.search(r"\s+(\d{1,4})\s*$", value)
        if page_match:
            page = int(page_match.group(1))
            value = value[:page_match.start()].strip()
    match = TOC_ENTRY_RE.match(value)
    if not match:
        return None
    number = normalize_number(match.group(1))
    heading = clean_line(match.group(2)).strip(" .")
    if not _plausible_heading_title(heading):
        return None
    return {
        "level": level_from_number(number),
        "number": number,
        "heading": heading,
        "page": page,
        "raw": value,
    }


def _toc_entries_from_region(lines: Sequence[_Line], start: int, end: int) -> Tuple[List[Dict[str, Any]], Set[int], int]:
    entries: List[Dict[str, Any]] = []
    consumed: Set[int] = set()
    meaningful = 0
    i = start
    while i < end:
        record = lines[i]
        value = clean_line(record.text)
        if not value or _frontmatter_noise(value):
            i += 1
            continue
        meaningful += 1
        if TABLE_SEPARATOR_RE.match(value):
            consumed.add(record.index)
            i += 1
            continue

        parsed_in_row = False
        if "|" in value:
            cells = [clean_line(cell) for cell in value.strip().strip("|").split("|")]
            cells = [cell for cell in cells if cell and not re.fullmatch(r"-+", cell)]
            pos = 0
            while pos < len(cells):
                cell = cells[pos]
                page: Optional[int] = None
                if pos + 1 < len(cells) and re.fullmatch(r"\d{1,4}", cells[pos + 1]):
                    page = int(cells[pos + 1])
                    pos += 2
                else:
                    pos += 1
                entry = _parse_toc_text(cell, page)
                if entry:
                    entries.append(entry)
                    parsed_in_row = True
            if parsed_in_row:
                consumed.add(record.index)
                i += 1
                continue

        direct = _parse_toc_text(value)
        if direct:
            entries.append(direct)
            consumed.add(record.index)
            i += 1
            continue

        number_match = NUMBER_ONLY_RE.fullmatch(value)
        if number_match:
            j = i + 1
            while j < end and not clean_line(lines[j].text):
                j += 1
            if j < end:
                title = clean_line(lines[j].text)
                if _plausible_heading_title(title):
                    number = normalize_number(number_match.group(1))
                    entries.append({
                        "level": level_from_number(number),
                        "number": number,
                        "heading": title,
                        "page": None,
                        "raw": f"{number} {title}",
                    })
                    consumed.add(record.index)
                    consumed.add(lines[j].index)
                    meaningful += 1
                    i = j + 1
                    continue
        i += 1

    deduped: List[Dict[str, Any]] = []
    seen: Set[Tuple[str, str]] = set()
    for entry in entries:
        key = (entry["number"], normalize_title(entry["heading"]))
        if key in seen:
            continue
        seen.add(key)
        deduped.append(entry)
    return deduped, consumed, meaningful


def _toc_info(markdown: str) -> Tuple[List[Dict[str, Any]], Set[int]]:
    lines = _annotate_lines(markdown)
    all_entries: List[Dict[str, Any]] = []
    skip_indexes: Set[int] = set()

    for marker_pos, record in enumerate(lines):
        marker_text = re.sub(r"^#+\s*", "", clean_line(record.text))
        if not re.fullmatch(r"(?:Table of Contents|Contents)", marker_text, re.I):
            continue

        end = len(lines)
        for pos in range(marker_pos + 1, len(lines)):
            if lines[pos].page_marker:
                end = pos
                break

        entries, consumed, meaningful = _toc_entries_from_region(lines, marker_pos + 1, end)
        ratio = len(consumed) / max(1, meaningful)
        has_page_boundary = end < len(lines)
        confident = len(entries) >= 2 and (
            (has_page_boundary and ratio >= 0.55)
            or (len(entries) >= 4 and ratio >= 0.72)
        )
        if not confident:
            continue

        all_entries.extend(entries)
        # Remove the front-matter TOC from parents.  The page marker that starts
        # the body is deliberately retained.
        skip_indexes.update(lines[pos].index for pos in range(marker_pos, end))

    deduped: List[Dict[str, Any]] = []
    seen: Set[Tuple[str, str]] = set()
    for entry in all_entries:
        key = (entry["number"], normalize_title(entry["heading"]))
        if key in seen:
            continue
        seen.add(key)
        deduped.append(entry)
    return deduped, skip_indexes


def parse_toc(markdown: str) -> List[Dict[str, Any]]:
    """Parse a confident Ericsson table of contents from Markdown."""
    entries, _ = _toc_info(markdown)
    return entries


def _build_toc_lookup(entries: Sequence[Dict[str, Any]]) -> Dict[str, List[str]]:
    lookup: Dict[str, List[str]] = {}
    for entry in entries:
        number = normalize_number(str(entry.get("number") or ""))
        heading = clean_line(str(entry.get("heading") or ""))
        if number and heading:
            lookup.setdefault(number, []).append(heading)
    return lookup


def _extract_numbered_heading(line: str) -> Optional[Tuple[str, str, bool]]:
    value = clean_line(line)
    match = NUMBERED_HEADING_RE.match(value)
    if not match:
        return None
    number = normalize_number(match.group(1))
    trailing_dot = bool(match.group(2))
    title = clean_line(match.group(3)).strip()
    if not _plausible_heading_title(title):
        return None
    return number, title, trailing_dot


def _is_document_heading(
    number: str,
    title: str,
    trailing_dot: bool,
    current_number: str,
    toc_lookup: Dict[str, List[str]],
    seen_real_heading: bool,
) -> bool:
    number = normalize_number(number)
    if not number or not title:
        return False

    if toc_lookup:
        if number in toc_lookup:
            return any(titles_match(title, toc_title) for toc_title in toc_lookup[number])

        # Match the Nokia strategy: when a TOC exists, a top-level number that
        # is not in that TOC is not a document heading. This rejects numeric
        # table cells such as ``73 Total``. Deeper Ericsson headings omitted
        # from the TOC (for example 2.2.3.1) are accepted only inside the
        # currently active top-level chapter.
        current_top = normalize_number(current_number).split(".")[0] if current_number else ""
        candidate_top = number.split(".")[0]
        if current_top and candidate_top != current_top:
            return False
        if level_from_number(number) == 1:
            return False
        return not _looks_like_procedure_step(title)

    current_top = normalize_number(current_number).split(".")[0] if current_number else ""
    candidate_top = number.split(".")[0]
    if current_top and candidate_top != current_top:
        # Without a usable TOC, Ericsson top-level headings normally omit the
        # procedure-step trailing dot, while ordered steps commonly use it.
        if level_from_number(number) == 1 and not trailing_dot and not _looks_like_procedure_step(title):
            return True
        return False

    if level_from_number(number) == 1:
        if trailing_dot:
            return False
        if seen_real_heading and number == normalize_number(current_number):
            return False
        return not _looks_like_procedure_step(title)

    return not _looks_like_procedure_step(title)


def promote_plain_headings(markdown: str) -> str:
    """Return Markdown with only real plain numbered headings promoted.

    This helper is retained for external callers.  Parsing itself does not rely
    on mutating the document and therefore preserves original source text.
    """
    sections = parse_markdown_sections(markdown, include_preamble=True)
    # Reconstructing the complete source would lose exact whitespace, so expose a
    # conservative compatibility behavior: promote direct numbered lines only.
    toc = parse_toc(markdown)
    lookup = _build_toc_lookup(toc)
    out: List[str] = []
    current_number = ""
    seen = False
    for raw in (markdown or "").splitlines():
        if _page_number(raw) is not None or HEADING_RE.match(raw):
            out.append(raw)
            continue
        candidate = _extract_numbered_heading(raw)
        if candidate and _is_document_heading(*candidate, current_number, lookup, seen):
            number, title, _ = candidate
            level = min(6, level_from_number(number))
            out.append(f"{'#' * level} {number} {title}")
            current_number = number
            seen = True
        else:
            out.append(raw)
    # Silence the unused value while keeping parsing validation above explicit.
    del sections
    return "\n".join(out)


def _is_table_line(text: str) -> bool:
    stripped = text.strip()
    return bool(stripped.startswith("|") and stripped.count("|") >= 2) or bool(TABLE_SEPARATOR_RE.match(stripped))


def _block_kind(lines: Sequence[_Line]) -> str:
    text_lines = [line.text for line in lines if line.text.strip()]
    if not text_lines:
        return "paragraph"
    first = text_lines[0].lstrip()
    if first.startswith(("```", "~~~")):
        return "code"
    if all(_is_table_line(line) for line in text_lines):
        return "table"
    if all(LIST_RE.match(line) or line.startswith(("  ", "\t")) for line in text_lines):
        return "list"
    if all(IMAGE_RE.fullmatch(line.strip()) for line in text_lines):
        return "image"
    return "paragraph"


def _to_blocks(lines: Sequence[_Line]) -> List[MarkdownBlock]:
    blocks: List[MarkdownBlock] = []
    current: List[_Line] = []
    in_fence = False
    fence_token = ""

    def flush() -> None:
        nonlocal current
        if not current:
            return
        text = "\n".join(line.text.rstrip() for line in current).strip()
        if text:
            pages = [line.page for line in current]
            blocks.append(MarkdownBlock(text=text, page_start=min(pages), page_end=max(pages), kind=_block_kind(current)))
        current = []

    for line in lines:
        stripped = line.text.strip()
        if in_fence:
            current.append(line)
            if stripped.startswith(fence_token):
                in_fence = False
                flush()
            continue
        if stripped.startswith(("```", "~~~")):
            flush()
            in_fence = True
            fence_token = stripped[:3]
            current.append(line)
            continue
        if not stripped:
            flush()
            continue
        if current:
            current_kind = _block_kind(current)
            line_is_table = _is_table_line(line.text)
            line_is_list = bool(LIST_RE.match(line.text)) or line.text.startswith(("  ", "\t"))
            if current_kind == "table" and not line_is_table:
                flush()
            elif current_kind == "list" and not line_is_list:
                flush()
            elif current_kind not in {"table", "list"} and (line_is_table or LIST_RE.match(line.text)):
                flush()
        current.append(line)
    flush()
    return blocks


def parse_markdown_sections(markdown: str, *, include_preamble: bool = True) -> List[MarkdownSection]:
    """Parse Ericsson Markdown into real outline sections.

    A parent is later created for every returned section.  Numbered headings are
    validated against the TOC when available, which prevents local procedural
    numbering from producing false parents.
    """
    lines = _annotate_lines(markdown)
    toc_entries, toc_skip_indexes = _toc_info(markdown)
    toc_lookup = _build_toc_lookup(toc_entries)

    current_page = 1
    sections: List[MarkdownSection] = []
    stack: List[Tuple[int, str]] = []
    body: List[_Line] = []
    heading = ""
    heading_number = ""
    heading_path = ""
    heading_level = 1
    heading_page = 1
    section_order = 0
    seen_real_heading = False

    def emit() -> None:
        nonlocal body, section_order
        blocks = _to_blocks(body)
        if not blocks and not heading:
            body = []
            return
        if not heading and not include_preamble:
            body = []
            return
        section_order += 1
        pages = [heading_page] + [p for block in blocks for p in (block.page_start, block.page_end)]
        sections.append(MarkdownSection(
            order=section_order,
            heading=heading or "Document Overview",
            heading_path=heading_path or "Document Overview",
            level=heading_level,
            page_start=min(pages) if pages else current_page,
            page_end=max(pages) if pages else current_page,
            blocks=blocks,
            heading_number=heading_number,
        ))
        body = []

    i = 0
    while i < len(lines):
        record = lines[i]
        current_page = record.page
        if record.page_marker:
            i += 1
            continue
        if record.index in toc_skip_indexes:
            i += 1
            continue

        raw_line = record.text
        stripped = clean_line(raw_line)
        is_heading = False
        candidate_heading = ""
        candidate_number = ""
        candidate_level = 0
        consume_through = i

        md_match = HEADING_RE.match(raw_line)
        if md_match:
            md_heading = clean_line(md_match.group(2))
            if not re.fullmatch(r"(?:Table of Contents|Contents|List of Figures|List of Tables)", md_heading, re.I):
                numbered = _extract_numbered_heading(md_heading)
                if numbered:
                    number, title, trailing_dot = numbered
                    if _is_document_heading(
                        number, title, trailing_dot, heading_number, toc_lookup, seen_real_heading
                    ):
                        candidate_heading = f"{number} {title}"
                        candidate_number = number
                        candidate_level = level_from_number(number)
                        is_heading = True
                elif normalize_title(md_heading) not in GENERIC_PROCEDURE_LABELS:
                    candidate_heading = md_heading
                    candidate_level = len(md_match.group(1))
                    is_heading = True

        if not is_heading and stripped:
            numbered = _extract_numbered_heading(stripped)
            if numbered:
                number, title, trailing_dot = numbered
                if _is_document_heading(
                    number, title, trailing_dot, heading_number, toc_lookup, seen_real_heading
                ):
                    candidate_heading = f"{number} {title}"
                    candidate_number = number
                    candidate_level = level_from_number(number)
                    is_heading = True
            else:
                number_only = NUMBER_ONLY_RE.fullmatch(stripped)
                if number_only:
                    j = i + 1
                    while j < len(lines) and not clean_line(lines[j].text):
                        j += 1
                    if j < len(lines) and not lines[j].page_marker and lines[j].index not in toc_skip_indexes:
                        title = clean_line(lines[j].text)
                        number = normalize_number(number_only.group(1))
                        if _plausible_heading_title(title) and _is_document_heading(
                            number, title, False, heading_number, toc_lookup, seen_real_heading
                        ):
                            candidate_heading = f"{number} {title}"
                            candidate_number = number
                            candidate_level = level_from_number(number)
                            consume_through = j
                            is_heading = True

        if is_heading:
            emit()
            heading = candidate_heading
            heading_number = candidate_number
            heading_level = max(1, min(6, candidate_level))
            while stack and stack[-1][0] >= heading_level:
                stack.pop()
            stack.append((heading_level, heading))
            heading_path = " > ".join(value for _, value in stack)
            heading_page = current_page
            seen_real_heading = True
            i = consume_through + 1
            continue

        body.append(_Line(record.index, raw_line, record.page, False))
        i += 1

    emit()
    return sections


def extract_image_paths(text: str) -> List[str]:
    out: List[str] = []
    for _alt, target in IMAGE_RE.findall(text or ""):
        target = target.strip().strip('"\'')
        if ' "' in target:
            target = target.split(' "', 1)[0]
        if " '" in target:
            target = target.split(" '", 1)[0]
        if target and target not in out:
            out.append(target)
    return out
