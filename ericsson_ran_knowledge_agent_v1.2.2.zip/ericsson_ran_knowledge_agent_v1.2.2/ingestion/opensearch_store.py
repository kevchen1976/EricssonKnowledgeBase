"""Safe OpenSearch index creation, alias switching, and bulk writes."""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

from agent_core.settings import Settings


class IndexSafetyError(ValueError):
    pass


def _safety_prefix(settings: Settings) -> str:
    prefix = str(settings.index_safety_prefix or "").strip().lower()
    if not prefix:
        raise IndexSafetyError("OpenSearch index safety prefix cannot be empty")
    if not prefix.startswith("ericsson-"):
        raise IndexSafetyError(
            "Ericsson index safety prefix must itself start with 'ericsson-' so this service cannot be configured "
            "to manage a Nokia or generic shared index namespace."
        )
    if not re.fullmatch(r"[a-z0-9][a-z0-9._-]*", prefix):
        raise IndexSafetyError(f"Invalid OpenSearch index safety prefix: {prefix}")
    return prefix


def make_client(settings: Settings):
    from opensearchpy import OpenSearch

    kwargs: Dict[str, Any] = {
        "hosts": [{
            "host": settings.opensearch_host,
            "port": settings.opensearch_port,
            "scheme": settings.opensearch_scheme,
        }],
        "use_ssl": settings.opensearch_scheme.lower() == "https",
        "verify_certs": settings.opensearch_verify_certs,
        "timeout": settings.opensearch_timeout,
    }
    if settings.opensearch_username:
        kwargs["http_auth"] = (settings.opensearch_username, settings.opensearch_password)
    if settings.opensearch_ca_certs:
        kwargs["ca_certs"] = str(settings.opensearch_ca_certs)
    return OpenSearch(**kwargs)


def validate_index_name(name: str, settings: Settings) -> str:
    value = str(name or "").strip().lower()
    if not value:
        raise IndexSafetyError("Index name cannot be empty")
    if value != name:
        # OpenSearch requires lowercase names; returning the normalized value is safe.
        name = value
    prefix = _safety_prefix(settings)
    if not value.startswith(prefix):
        raise IndexSafetyError(
            f"Refusing to operate on index/alias '{value}'. Ericsson indexes must start with "
            f"'{prefix}' so the shared Nokia indexes cannot be modified."
        )
    if value in {"ran_kb", "nokia", "nokia-ran-kb", "nokia_ran_kb"} or value.startswith("nokia"):
        raise IndexSafetyError(f"Refusing to operate on Nokia index name: {value}")
    if not re.fullmatch(r"[a-z0-9][a-z0-9._-]*", value):
        raise IndexSafetyError(f"Invalid OpenSearch index name: {value}")
    return value


def validate_index_configuration(settings: Settings) -> None:
    """Validate the complete Ericsson alias/backing-prefix configuration.

    This package is intentionally vendor-specific.  The additional vendor and
    corpus checks prevent an environment-variable mistake from making an
    Ericsson service query or manage a generic/Nokia namespace on the shared
    OpenSearch cluster.
    """
    if str(settings.vendor or "").strip().casefold() != "ericsson":
        raise IndexSafetyError(
            f"This service is Ericsson-only; VENDOR must be 'Ericsson', got {settings.vendor!r}"
        )
    corpus_id = str(settings.corpus_id or "").strip().lower()
    if not corpus_id or not corpus_id.startswith("ericsson"):
        raise IndexSafetyError(
            "CORPUS_ID must be Ericsson-scoped (for example 'ericsson-ran')"
        )

    aliases = [
        validate_index_name(settings.child_alias, settings),
        validate_index_name(settings.parent_alias, settings),
        validate_index_name(settings.manifest_alias, settings),
    ]
    prefixes = [
        validate_index_name(settings.child_backing_prefix, settings),
        validate_index_name(settings.parent_backing_prefix, settings),
        validate_index_name(settings.manifest_backing_prefix, settings),
    ]
    if len(set(aliases)) != len(aliases):
        raise IndexSafetyError("Child, parent, and manifest aliases must be different")
    if len(set(prefixes)) != len(prefixes):
        raise IndexSafetyError("Child, parent, and manifest backing-index prefixes must be different")


def sanitize_version(value: str) -> str:
    token = re.sub(r"[^0-9a-z]+", "", str(value or "").lower())
    if not token:
        raise ValueError("Index version cannot be empty")
    return token[:40]


def backing_names(settings: Settings, version: str) -> Tuple[str, str, str]:
    """Return child, parent, and manifest backing indexes for one release."""
    token = sanitize_version(version)
    child = validate_index_name(f"{settings.child_backing_prefix}{token}", settings)
    parent = validate_index_name(f"{settings.parent_backing_prefix}{token}", settings)
    manifest = validate_index_name(f"{settings.manifest_backing_prefix}{token}", settings)
    return child, parent, manifest


def _alias_targets(client: Any, alias: str) -> List[str]:
    try:
        data = client.indices.get_alias(name=alias)
    except Exception as exc:
        status = getattr(exc, "status_code", None)
        if status == 404 or "404" in str(exc):
            return []
        raise
    return sorted(data.keys()) if isinstance(data, dict) else []


def resolve_write_index(client: Any, alias: str) -> Optional[str]:
    try:
        data = client.indices.get_alias(name=alias)
    except Exception as exc:
        status = getattr(exc, "status_code", None)
        if status == 404 or "404" in str(exc):
            return None
        raise
    if not isinstance(data, dict):
        return None
    for index_name, index_data in data.items():
        aliases = index_data.get("aliases", {}) if isinstance(index_data, dict) else {}
        alias_data = aliases.get(alias, {}) if isinstance(aliases, dict) else {}
        if alias_data.get("is_write_index") is True:
            return index_name
    if len(data) == 1:
        return next(iter(data))
    return None


def create_index(client: Any, index_name: str, body: Dict[str, Any], settings: Settings) -> None:
    index_name = validate_index_name(index_name, settings)
    if client.indices.exists(index=index_name):
        raise ValueError(f"Index already exists: {index_name}")
    client.indices.create(index=index_name, body=body)


def switch_alias(client: Any, alias: str, new_index: str, settings: Settings) -> List[str]:
    alias = validate_index_name(alias, settings)
    new_index = validate_index_name(new_index, settings)
    old = _alias_targets(client, alias)
    actions: List[Dict[str, Any]] = [
        {"remove": {"index": index, "alias": alias}} for index in old if index != new_index
    ]
    actions.append({"add": {"index": new_index, "alias": alias, "is_write_index": True}})
    client.indices.update_aliases(body={"actions": actions})
    return old


def bulk_index(
    client: Any,
    index_name: str,
    documents: Iterable[Tuple[str, Dict[str, Any]]],
    settings: Settings,
    *,
    chunk_size: int = 250,
) -> Tuple[int, List[Dict[str, Any]]]:
    from opensearchpy.helpers import streaming_bulk

    index_name = validate_index_name(index_name, settings)

    def actions() -> Iterator[Dict[str, Any]]:
        for doc_id, source in documents:
            yield {
                "_op_type": "index",
                "_index": index_name,
                "_id": str(doc_id)[:512],
                "_source": source,
            }

    succeeded = 0
    failures: List[Dict[str, Any]] = []
    for ok, result in streaming_bulk(
        client,
        actions(),
        chunk_size=chunk_size,
        max_retries=3,
        initial_backoff=1,
        max_backoff=8,
        raise_on_error=False,
        raise_on_exception=False,
    ):
        if ok:
            succeeded += 1
        else:
            failures.append(result)
    return succeeded, failures


def delete_by_filenames(client: Any, index_name: str, filenames: Sequence[str], settings: Settings) -> int:
    index_name = validate_index_name(index_name, settings)
    names = sorted({str(x) for x in filenames if x})
    if not names:
        return 0
    response = client.delete_by_query(
        index=index_name,
        body={
            "query": {
                "bool": {
                    "filter": [
                        {"term": {"vendor": settings.vendor}},
                        {"term": {"corpus_id": settings.corpus_id}},
                        {"terms": {"filename": names}},
                    ]
                }
            }
        },
        conflicts="proceed",
        refresh=True,
    )
    return int(response.get("deleted", 0))


def delete_stale_by_filenames(
    client: Any,
    index_name: str,
    filenames: Sequence[str],
    current_run_id: str,
    settings: Settings,
) -> int:
    """Delete obsolete records after replacement records were indexed.

    Records written in the current run are protected by ``ingestion_run_id``.
    This lets incremental ingestion bulk-write first and remove only stale
    chunks/manifest records afterwards, avoiding an empty-document window when
    embedding or bulk indexing fails.
    """
    index_name = validate_index_name(index_name, settings)
    names = sorted({str(x) for x in filenames if x})
    run_id = str(current_run_id or "").strip()
    if not names:
        return 0
    if not run_id:
        raise ValueError("current_run_id is required when deleting stale records")
    response = client.delete_by_query(
        index=index_name,
        body={
            "query": {
                "bool": {
                    "filter": [
                        {"term": {"vendor": settings.vendor}},
                        {"term": {"corpus_id": settings.corpus_id}},
                        {"terms": {"filename": names}},
                    ],
                    "must_not": [{"term": {"ingestion_run_id": run_id}}],
                }
            }
        },
        conflicts="proceed",
        refresh=True,
    )
    return int(response.get("deleted", 0))


def delete_by_run_id(
    client: Any,
    index_name: str,
    run_id: str,
    settings: Settings,
) -> int:
    """Remove records written by one failed incremental ingestion run.

    The cleanup is always constrained by Ericsson vendor/corpus metadata and is
    only used before stale-record deletion has started.  It therefore restores
    the previous live generation after an embedding or bulk-write failure.
    """
    index_name = validate_index_name(index_name, settings)
    value = str(run_id or "").strip()
    if not value:
        raise ValueError("run_id is required when rolling back an incremental ingestion")
    response = client.delete_by_query(
        index=index_name,
        body={
            "query": {
                "bool": {
                    "filter": [
                        {"term": {"vendor": settings.vendor}},
                        {"term": {"corpus_id": settings.corpus_id}},
                        {"term": {"ingestion_run_id": value}},
                    ]
                }
            }
        },
        conflicts="proceed",
        refresh=True,
    )
    return int(response.get("deleted", 0))


def refresh(client: Any, *indices: str) -> None:
    clean = [index for index in indices if index]
    if clean:
        client.indices.refresh(index=",".join(clean))


def remove_indices(client: Any, indices: Iterable[str], settings: Settings, *, exclude: Iterable[str] = ()) -> List[str]:
    excluded = set(exclude)
    removed: List[str] = []
    for index in indices:
        if index in excluded:
            continue
        validate_index_name(index, settings)
        if client.indices.exists(index=index):
            client.indices.delete(index=index)
            removed.append(index)
    return removed


def switch_aliases_atomic(
    client: Any,
    alias_to_index: Dict[str, str],
    settings: Settings,
) -> Dict[str, List[str]]:
    """Atomically switch multiple Ericsson aliases in one OpenSearch request.

    Keeping the child, parent, and manifest aliases in one action list prevents a query
    service from observing a new child generation with an old parent/manifest
    generation (or the reverse).
    """
    actions: List[Dict[str, Any]] = []
    old_targets: Dict[str, List[str]] = {}
    for alias, new_index in alias_to_index.items():
        alias = validate_index_name(alias, settings)
        new_index = validate_index_name(new_index, settings)
        old = _alias_targets(client, alias)
        old_targets[alias] = old
        actions.extend(
            {"remove": {"index": index, "alias": alias}}
            for index in old
            if index != new_index
        )
        actions.append({"add": {"index": new_index, "alias": alias, "is_write_index": True}})
    client.indices.update_aliases(body={"actions": actions})
    return old_targets


def vector_dimension(client: Any, index_name: str, settings: Settings, *, field: str = "embedding") -> Optional[int]:
    """Return the configured vector dimension for an Ericsson index/alias."""
    index_name = validate_index_name(index_name, settings)
    mapping = client.indices.get_mapping(index=index_name)
    if not isinstance(mapping, dict):
        return None
    dimensions: set[int] = set()
    for value in mapping.values():
        properties = ((value or {}).get("mappings") or {}).get("properties") or {}
        vector = properties.get(field) or {}
        dimension = vector.get("dimension")
        if dimension is not None:
            dimensions.add(int(dimension))
    if len(dimensions) > 1:
        raise RuntimeError(f"Alias {index_name} points to indexes with different {field} dimensions: {sorted(dimensions)}")
    return next(iter(dimensions)) if dimensions else None
