"""Validation of the separate Ericsson parent/child OpenSearch contract.

The child index is the only vector-search index. The parent index stores one
complete document section per parent and is fetched by ``parent_storage_id``
after final child ranking. These checks can be run against an offline ingestion
preview or against the live Ericsson aliases on the shared OpenSearch cluster.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence

from agent_core.constants import (
    CHILD_STORAGE_ROLE,
    PARENT_CHILD_CONTRACT,
    PARENT_STORAGE_ROLE,
    RETRIEVAL_SCHEMA,
)
from agent_core.settings import Settings


def _sha256_text(value: str) -> str:
    return hashlib.sha256(str(value or "").encode("utf-8")).hexdigest()


def _source(record: Mapping[str, Any]) -> Dict[str, Any]:
    source = record.get("_source", record)
    return dict(source) if isinstance(source, Mapping) else {}


def _record_id(record: Mapping[str, Any]) -> str:
    return str(record.get("_id") or _source(record).get("parent_storage_id") or "").strip()


@dataclass
class StorageValidationReport:
    mode: str
    parent_records: int = 0
    child_records: int = 0
    sampled_parent_records: int = 0
    sampled_child_records: int = 0
    level_four_parents: int = 0
    parents_with_embeddings: int = 0
    children_with_parent_content: int = 0
    children_missing_parent_reference: int = 0
    parent_hash_mismatches: int = 0
    child_parent_hash_mismatches: int = 0
    children_without_embeddings: int = 0
    contract_mismatches: int = 0
    records_missing_hashes: int = 0
    child_hash_mismatches: int = 0
    embedding_text_mismatches: int = 0
    embedding_limit_violations: int = 0
    embedding_truncated_records: int = 0
    max_embedding_token_count: int = 0
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    details: Dict[str, Any] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_dict(self) -> Dict[str, Any]:
        value = asdict(self)
        value["ok"] = self.ok
        value["retrieval_schema"] = RETRIEVAL_SCHEMA
        value["retrieval_contract"] = PARENT_CHILD_CONTRACT
        return value


def validate_storage_records(
    parents: Sequence[Mapping[str, Any]],
    children: Sequence[Mapping[str, Any]],
    *,
    mode: str = "records",
    require_embeddings: bool = False,
) -> StorageValidationReport:
    report = StorageValidationReport(
        mode=mode,
        parent_records=len(parents),
        child_records=len(children),
        sampled_parent_records=len(parents),
        sampled_child_records=len(children),
    )
    parent_by_storage_id: Dict[str, Dict[str, Any]] = {}

    for record in parents:
        source = _source(record)
        storage_id = _record_id(record) or str(source.get("parent_storage_id") or source.get("parent_id") or "")
        if not storage_id:
            report.errors.append("A parent record has no OpenSearch _id/parent_storage_id")
            continue
        parent_by_storage_id[storage_id] = source
        if source.get("storage_role") != PARENT_STORAGE_ROLE:
            report.contract_mismatches += 1
            report.errors.append(f"Parent {storage_id} has storage_role={source.get('storage_role')!r}")
        if source.get("retrieval_contract") != PARENT_CHILD_CONTRACT:
            report.contract_mismatches += 1
            report.errors.append(
                f"Parent {storage_id} has retrieval_contract={source.get('retrieval_contract')!r}"
            )
        if "embedding" in source or "embedding_text" in source:
            report.parents_with_embeddings += 1
            report.errors.append(f"Parent {storage_id} contains an embedding field")
        if "parent_content" in source:
            report.errors.append(f"Parent {storage_id} contains legacy parent_content")
        if source.get("parent_storage_id") and str(source["parent_storage_id"]) != storage_id:
            report.errors.append(
                f"Parent {storage_id} has mismatched parent_storage_id={source.get('parent_storage_id')}"
            )
        heading_level = int(source.get("heading_level") or 0)
        if heading_level >= 4:
            report.level_four_parents += 1
        content = str(source.get("content") or "")
        expected = str(source.get("content_sha256") or "").strip()
        if not expected:
            report.records_missing_hashes += 1
            report.errors.append(f"Parent {storage_id} has no content_sha256")
        elif expected != _sha256_text(content):
            report.parent_hash_mismatches += 1
            report.errors.append(f"Parent {storage_id} content_sha256 does not match stored content")

    for record in children:
        source = _source(record)
        child_id = str(record.get("_id") or source.get("chunk_id") or "<unknown-child>")
        if source.get("storage_role") != CHILD_STORAGE_ROLE:
            report.contract_mismatches += 1
            report.errors.append(f"Child {child_id} has storage_role={source.get('storage_role')!r}")
        if source.get("retrieval_contract") != PARENT_CHILD_CONTRACT:
            report.contract_mismatches += 1
            report.errors.append(
                f"Child {child_id} has retrieval_contract={source.get('retrieval_contract')!r}"
            )
        if "parent_content" in source:
            report.children_with_parent_content += 1
            report.errors.append(f"Child {child_id} duplicates parent_content")
        if require_embeddings and not isinstance(source.get("embedding"), list):
            report.children_without_embeddings += 1
            report.errors.append(f"Child {child_id} has no embedding vector")
        content = str(source.get("content") or "")
        child_hash = str(source.get("child_content_sha256") or "").strip()
        if not child_hash:
            report.records_missing_hashes += 1
            report.errors.append(f"Child {child_id} has no child_content_sha256")
        elif child_hash != _sha256_text(content):
            report.child_hash_mismatches += 1
            report.errors.append(f"Child {child_id} child_content_sha256 does not match stored content")
        if str(source.get("embedding_input_mode") or "") == "content":
            embedding_text = str(source.get("embedding_text") or "")
            if embedding_text != content.strip():
                report.embedding_text_mismatches += 1
                report.errors.append(
                    f"Child {child_id} uses embedding_input_mode=content but embedding_text differs from content"
                )
        elif not source.get("embedding_input_mode"):
            report.contract_mismatches += 1
            report.errors.append(f"Child {child_id} has no embedding_input_mode")

        embedding_token_count = int(source.get("embedding_token_count") or 0)
        embedding_model_max_tokens = int(source.get("embedding_model_max_tokens") or 0)
        report.max_embedding_token_count = max(report.max_embedding_token_count, embedding_token_count)
        if source.get("embedding_truncated") is True:
            report.embedding_truncated_records += 1
            report.errors.append(f"Child {child_id} is marked as having a truncated embedding input")
        if (
            embedding_token_count > 0
            and embedding_model_max_tokens > 0
            and embedding_token_count > embedding_model_max_tokens
        ):
            report.embedding_limit_violations += 1
            report.errors.append(
                f"Child {child_id} embedding input has {embedding_token_count} tokens, "
                f"above model limit {embedding_model_max_tokens}"
            )

        storage_id = str(source.get("parent_storage_id") or source.get("parent_id") or "").strip()
        if not storage_id or storage_id not in parent_by_storage_id:
            report.children_missing_parent_reference += 1
            report.errors.append(f"Child {child_id} does not resolve to stored parent {storage_id!r}")
            continue
        parent_source = parent_by_storage_id[storage_id]
        expected_hash = str(source.get("parent_content_sha256") or "").strip()
        actual_hash = str(parent_source.get("content_sha256") or "").strip() or _sha256_text(
            str(parent_source.get("content") or "")
        )
        if not expected_hash:
            report.records_missing_hashes += 1
            report.errors.append(f"Child {child_id} has no parent_content_sha256")
        elif expected_hash != actual_hash:
            report.child_parent_hash_mismatches += 1
            report.errors.append(f"Child {child_id} points to parent {storage_id} with a different content hash")

    return report


def _read_jsonl(path: Path) -> List[Dict[str, Any]]:
    if not path.is_file():
        raise FileNotFoundError(path)
    records: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            line = line.strip()
            if not line:
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSONL at {path}:{line_number}: {exc}") from exc
            if not isinstance(value, dict):
                raise ValueError(f"Expected object at {path}:{line_number}")
            records.append(value)
    return records


def validate_preview_storage(
    preview_dir: Path,
    *,
    require_embeddings: bool = False,
) -> StorageValidationReport:
    preview_dir = Path(preview_dir).expanduser().resolve()
    parents = _read_jsonl(preview_dir / "parents.jsonl")
    children = _read_jsonl(preview_dir / "children.jsonl")
    report = validate_storage_records(
        parents,
        children,
        mode="preview",
        require_embeddings=require_embeddings,
    )
    report.details.update({
        "preview_dir": str(preview_dir),
        "parents_path": str(preview_dir / "parents.jsonl"),
        "children_path": str(preview_dir / "children.jsonl"),
    })
    return report


def _mapping_properties(mapping: Mapping[str, Any]) -> List[Dict[str, Any]]:
    output: List[Dict[str, Any]] = []
    for value in mapping.values():
        if not isinstance(value, Mapping):
            continue
        properties = ((value.get("mappings") or {}).get("properties") or {})
        if isinstance(properties, dict):
            output.append(properties)
    return output


def validate_live_storage(
    client: Any,
    settings: Settings,
    *,
    sample_size: int = 100,
) -> StorageValidationReport:
    sample_size = max(1, min(int(sample_size), 1000))
    report = StorageValidationReport(mode="live")
    report.details.update({
        "child_alias": settings.child_alias,
        "parent_alias": settings.parent_alias,
        "manifest_alias": settings.manifest_alias,
        "sample_size": sample_size,
    })

    try:
        child_mapping = client.indices.get_mapping(index=settings.child_alias)
        parent_mapping = client.indices.get_mapping(index=settings.parent_alias)
    except Exception as exc:
        report.errors.append(f"Could not read Ericsson index mappings: {exc}")
        return report

    child_properties = _mapping_properties(child_mapping)
    parent_properties = _mapping_properties(parent_mapping)
    if not child_properties or any((props.get("embedding") or {}).get("type") != "knn_vector" for props in child_properties):
        report.errors.append("Child alias does not consistently expose embedding as knn_vector")
    if any("embedding" in props or "embedding_text" in props for props in parent_properties):
        report.errors.append("Parent alias mapping contains an embedding/embedding_text field")

    filter_clauses = [
        {"term": {"vendor": settings.vendor}},
        {"term": {"corpus_id": settings.corpus_id}},
    ]
    try:
        report.child_records = int(client.count(
            index=settings.child_alias,
            body={"query": {"bool": {"filter": filter_clauses}}},
        ).get("count", 0))
        report.parent_records = int(client.count(
            index=settings.parent_alias,
            body={"query": {"bool": {"filter": filter_clauses}}},
        ).get("count", 0))
        response = client.search(
            index=settings.child_alias,
            body={
                "size": sample_size,
                "track_total_hits": False,
                "_source": {"excludes": ["embedding"]},
                "query": {"bool": {"filter": filter_clauses}},
                "sort": ["_doc"],
            },
        )
    except Exception as exc:
        report.errors.append(f"Could not sample Ericsson child records: {exc}")
        return report

    child_hits = list((response.get("hits") or {}).get("hits") or [])
    parent_ids: List[str] = []
    seen: set[str] = set()
    for hit in child_hits:
        source = _source(hit)
        parent_id = str(source.get("parent_storage_id") or source.get("parent_id") or "").strip()
        if parent_id and parent_id not in seen:
            seen.add(parent_id)
            parent_ids.append(parent_id)

    try:
        parent_response = client.mget(index=settings.parent_alias, body={"ids": parent_ids}) if parent_ids else {"docs": []}
    except Exception as exc:
        report.errors.append(f"Could not fetch sampled Ericsson parents: {exc}")
        return report

    parent_hits: List[Dict[str, Any]] = []
    for document in parent_response.get("docs", []) if isinstance(parent_response, dict) else []:
        if document.get("found"):
            parent_hits.append({"_id": document.get("_id"), "_source": document.get("_source") or {}})

    sampled = validate_storage_records(
        parent_hits,
        child_hits,
        mode="live-sample",
        require_embeddings=False,
    )
    report.sampled_parent_records = sampled.parent_records
    report.sampled_child_records = sampled.child_records
    report.level_four_parents = sampled.level_four_parents
    report.parents_with_embeddings = sampled.parents_with_embeddings
    report.children_with_parent_content = sampled.children_with_parent_content
    report.children_missing_parent_reference = sampled.children_missing_parent_reference
    report.parent_hash_mismatches = sampled.parent_hash_mismatches
    report.child_parent_hash_mismatches = sampled.child_parent_hash_mismatches
    report.children_without_embeddings = sampled.children_without_embeddings
    report.contract_mismatches = sampled.contract_mismatches
    report.records_missing_hashes = sampled.records_missing_hashes
    report.child_hash_mismatches = sampled.child_hash_mismatches
    report.embedding_text_mismatches = sampled.embedding_text_mismatches
    report.embedding_limit_violations = sampled.embedding_limit_violations
    report.embedding_truncated_records = sampled.embedding_truncated_records
    report.max_embedding_token_count = sampled.max_embedding_token_count
    report.errors.extend(sampled.errors)
    report.warnings.extend(sampled.warnings)
    return report
