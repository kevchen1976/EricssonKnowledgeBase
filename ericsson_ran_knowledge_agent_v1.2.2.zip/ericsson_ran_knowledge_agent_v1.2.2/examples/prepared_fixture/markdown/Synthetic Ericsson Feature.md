<!-- page: 1 -->

# Synthetic Ericsson Feature

This is a generated fixture for validating the Ericsson ingestion pipeline. It is not product documentation.

| Field | Value |
|---|---|
| Feature Name | Synthetic Ericsson Feature |
| Feature Identity | FAJ 121 9999 |
| Value Package Identity | FAJ 801 9999 |
| Access Type | LTE |

## 1 Overview

The synthetic feature demonstrates page-aware Markdown chunking and deterministic Ericsson identity routing.

<!-- page: 2 -->

## 2 Operation

The operation section contains enough text to produce a searchable child chunk while retaining the parent section and source-page range.

![Synthetic test figure](Synthetic_Ericsson_Feature_images/page_002_image_001.png)

## 3 Dependencies

The synthetic fixture has no dependencies.
