#!/usr/bin/env python3
"""Inspect the shared OpenSearch cluster without modifying any index."""
from __future__ import annotations

import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agent_core.settings import get_settings
from ingestion.opensearch_store import make_client, validate_index_configuration


def main() -> int:
    settings = get_settings()
    validate_index_configuration(settings)
    client = make_client(settings)
    info = client.info()
    result = {
        "cluster_name": info.get("cluster_name"),
        "version": (info.get("version") or {}).get("number"),
        "child_alias": settings.child_alias,
        "child_alias_exists": bool(client.indices.exists_alias(name=settings.child_alias)),
        "parent_alias": settings.parent_alias,
        "parent_alias_exists": bool(client.indices.exists_alias(name=settings.parent_alias)),
        "manifest_alias": settings.manifest_alias,
        "manifest_alias_exists": bool(client.indices.exists_alias(name=settings.manifest_alias)),
        "chunk_alias": settings.child_alias,
    }
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
