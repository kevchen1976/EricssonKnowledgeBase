#!/usr/bin/env python3
from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import argparse
import json

import httpx


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--agent-url", default="http://localhost:8100")
    parser.add_argument("--query", default="What does FAJ 121 0488 do?")
    args = parser.parse_args()
    health = httpx.get(args.agent_url.rstrip("/") + "/health", timeout=10)
    answer = httpx.post(
        args.agent_url.rstrip("/") + "/query",
        json={"query": args.query, "include_evidence": True},
        timeout=300,
    )
    print(json.dumps({"health": health.json(), "query": answer.json()}, indent=2, ensure_ascii=False))
    return 0 if health.is_success and answer.is_success else 1


if __name__ == "__main__":
    raise SystemExit(main())
