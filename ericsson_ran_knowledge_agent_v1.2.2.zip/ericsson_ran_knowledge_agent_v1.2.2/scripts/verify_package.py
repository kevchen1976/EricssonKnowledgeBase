#!/usr/bin/env python3
"""Offline package verification requiring no OpenSearch, Neo4j, or ML model."""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agent_core.constants import PACKAGE_VERSION, PARENT_CHILD_CONTRACT, RETRIEVAL_SCHEMA
from agent_core.ids import normalize_feature_id, normalize_package_id
from agent_core.routing import route_query
from agent_core.settings import get_settings
from ingestion.embedding import DeterministicHashEmbedder
from ingestion.opensearch_store import backing_names, validate_index_configuration
from ingestion.pipeline import run_ingestion, settings_for_prepared_root
from ingestion.storage_validation import validate_preview_storage


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    fixture = root / "examples/prepared_fixture"
    preview = root / ".verification-preview"
    shutil.rmtree(preview, ignore_errors=True)
    settings = settings_for_prepared_root(get_settings(), fixture)
    validate_index_configuration(settings)
    child_name, parent_name, manifest_name = backing_names(settings, "verification")
    assert normalize_feature_id("FAJ1210488") == "FAJ 121 0488"
    assert normalize_package_id("FAJ8010400") == "FAJ 801 0400"
    assert route_query("Explain FAJ 121 0488").workflow == "feature_lookup"
    assert PACKAGE_VERSION == "1.2.4"
    assert settings.session_memory_enabled is True
    assert settings.enable_llm_query_rewrite is True
    assert settings.redis_key_prefix.rstrip(":") == "ericsson:session"
    assert settings.session_ttl_seconds == 3600
    assert settings.max_session_history == 5

    from agent_service.application import app as agent_app
    from graph_api.application import app as graph_app
    from kb_api.application import app as kb_app

    report = run_ingestion(
        settings,
        mode="dry-run",
        version="verification",
        embedder=DeterministicHashEmbedder(32),
        preview_dir=preview,
    )
    assert (preview / "parents.jsonl").is_file()
    assert (preview / "children.jsonl").is_file()

    parent_records = [json.loads(line) for line in (preview / "parents.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    child_records = [json.loads(line) for line in (preview / "children.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    assert parent_records and child_records
    assert all("embedding" not in record["_source"] for record in parent_records)
    assert all("embedding_text" not in record["_source"] for record in parent_records)
    assert all(record["_source"].get("storage_role") == "parent" for record in parent_records)
    assert all("parent_content" not in record["_source"] for record in child_records)
    assert all(record["_source"].get("storage_role") == "child" for record in child_records)
    assert all(record["_source"].get("embedding_input_mode") == "content" for record in child_records)
    assert all(record["_source"].get("embedding_text") == record["_source"].get("content") for record in child_records)
    assert all(record["_source"].get("parent_content_sha256") for record in child_records)

    storage_report = validate_preview_storage(preview, require_embeddings=True)
    assert storage_report.ok, storage_report.to_dict()

    result = {
        "ok": True,
        "package_version": PACKAGE_VERSION,
        "conversation": {
            "session_backend": "redis",
            "redis_key_prefix": settings.redis_key_prefix,
            "session_ttl_seconds": settings.session_ttl_seconds,
            "max_session_history": settings.max_session_history,
            "query_rewrite_enabled": settings.enable_llm_query_rewrite,
        },
        "agent_routes": sorted({route.path for route in agent_app.routes}),
        "kb_routes": sorted({route.path for route in kb_app.routes}),
        "graph_routes": sorted({route.path for route in graph_app.routes}),
        "child_alias": settings.child_alias,
        "parent_alias": settings.parent_alias,
        "manifest_alias": settings.manifest_alias,
        "retrieval_schema": RETRIEVAL_SCHEMA,
        "retrieval_contract": PARENT_CHILD_CONTRACT,
        "sample_backing_indexes": [child_name, parent_name, manifest_name],
        "fixture_documents": report.markdown_documents,
        "fixture_parents": report.parents_indexed,
        "fixture_children": report.children_indexed,
        "fixture_manifest_records": report.manifest_records_indexed,
        "storage_validation": storage_report.to_dict(),
        "preview": str(preview),
    }
    print(json.dumps(result, indent=2))
    shutil.rmtree(preview, ignore_errors=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
