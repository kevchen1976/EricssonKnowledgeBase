#!/usr/bin/env python3
"""Validate prepared Ericsson Markdown/manifests before OpenSearch ingestion."""
from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import argparse
import json
import re
from typing import Any, Dict, List

from agent_core.ids import normalize_feature_id, normalize_package_id
from agent_core.settings import get_settings
from ingestion.manifest_loader import ManifestStore
from ingestion.pipeline import settings_for_prepared_root
from ingestion.prepared_loader import build_parent_child_for_document, load_prepared_documents

_IMAGE_RE = re.compile(r"!\[[^\]]*\]\(([^)]+)\)")


def validate(root: Path) -> Dict[str, Any]:
    settings = settings_for_prepared_root(get_settings(), root)
    errors: List[str] = []
    warnings: List[str] = []
    if not settings.combined_manifest.exists():
        errors.append(f"Missing combined manifest: {settings.combined_manifest}")
    if not settings.markdown_root.exists():
        errors.append(f"Missing Markdown directory: {settings.markdown_root}")
    if errors:
        return {"valid": False, "errors": errors, "warnings": warnings}

    store = ManifestStore.load(settings.combined_manifest)
    documents = load_prepared_documents(settings, store)
    record_ids: set[str] = set()
    duplicate_ids: set[str] = set()
    for record in store.records:
        record_id = str(record.get("record_id") or "")
        if record_id:
            if record_id in record_ids:
                duplicate_ids.add(record_id)
            record_ids.add(record_id)
        for key in ("feature_id", "owner_feature_id", "primary_feature_id"):
            value = str(record.get(key) or "")
            if value and normalize_feature_id(value) != value:
                errors.append(f"Non-canonical feature identity in {record_id}: {key}={value!r}")
        for key in ("package_id", "primary_package_id"):
            value = str(record.get(key) or "")
            if value and normalize_package_id(value) != value:
                errors.append(f"Non-canonical package identity in {record_id}: {key}={value!r}")
        start = int(record.get("page_start") or 1)
        end = int(record.get("page_end") or start)
        if end < start or start < 1:
            errors.append(f"Invalid page range in {record_id}: {start}-{end}")
    if duplicate_ids:
        errors.append("Duplicate manifest record IDs: " + ", ".join(sorted(duplicate_ids)[:20]))

    parent_count = 0
    child_count = 0
    image_links = 0
    broken_images: List[str] = []
    invalid_chunk_pages: List[str] = []
    document_roles: Dict[str, int] = {}
    for document in documents:
        record = document.document_record
        role = str(record.get("doc_role") or "general_document")
        document_roles[role] = document_roles.get(role, 0) + 1
        owner = str(record.get("owner_feature_id") or "")
        if role == "feature_document" and not owner:
            errors.append(f"Feature document has no owner_feature_id: {document.filename}")
        if role in {"package_document", "general_document"} and owner:
            errors.append(f"Non-feature document incorrectly owns {owner}: {document.filename}")

        markdown = document.markdown_path.read_text(encoding="utf-8")
        for target in _IMAGE_RE.findall(markdown):
            value = target.strip().strip('"\'').split(" \"", 1)[0]
            if value.startswith(("http://", "https://", "/", "data:")):
                continue
            image_links += 1
            candidate = (document.markdown_path.parent / value).resolve()
            try:
                candidate.relative_to(document.markdown_path.parent.resolve())
            except ValueError:
                broken_images.append(f"unsafe traversal in {document.filename}: {value}")
                continue
            if not candidate.is_file():
                broken_images.append(f"{document.filename}: {value}")

        parents, children = build_parent_child_for_document(document, store, settings)
        parent_count += len(parents)
        child_count += len(children)
        parent_ids = {parent.parent_id for parent in parents}
        for parent in parents:
            source = parent.to_source()
            if "embedding" in source or "parent_content" in source:
                errors.append(f"Invalid stored parent payload: {document.filename}:{parent.parent_id}")
            if parent.page_start < 1 or parent.page_end < parent.page_start:
                invalid_chunk_pages.append(f"{document.filename}:{parent.parent_id}:{parent.page_start}-{parent.page_end}")
        for child in children:
            source = child.to_source(None)
            if child.parent_id not in parent_ids:
                errors.append(f"Child references a missing parent: {document.filename}:{child.chunk_id}")
            if "parent_content" in source:
                errors.append(f"Child duplicates parent content: {document.filename}:{child.chunk_id}")
            if child.page_start < 1 or child.page_end < child.page_start:
                invalid_chunk_pages.append(f"{document.filename}:{child.chunk_id}:{child.page_start}-{child.page_end}")
    if broken_images:
        errors.append("Broken/unsafe Markdown image links: " + "; ".join(broken_images[:20]))
    if invalid_chunk_pages:
        errors.append("Invalid generated chunk page ranges: " + "; ".join(invalid_chunk_pages[:20]))
    if not store.records:
        warnings.append("No manifest records were loaded; ingestion will rely on minimal sidecar metadata")

    relationship_count = sum(len(document.relationship_records) for document in documents)
    return {
        "valid": not errors,
        "prepared_root": str(root.resolve()),
        "documents": len(documents),
        "document_roles": document_roles,
        "manifest_records": len(store.records),
        "generated_parents": parent_count,
        "generated_children": child_count,
        "generated_chunks": child_count,
        "relationship_records": relationship_count,
        "image_links_checked": image_links,
        "errors": errors,
        "warnings": warnings,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("prepared_root", type=Path)
    parser.add_argument("--output", type=Path, default=None)
    args = parser.parse_args()
    report = validate(args.prepared_root.expanduser().resolve())
    rendered = json.dumps(report, indent=2, ensure_ascii=False)
    print(rendered)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    return 0 if report["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
