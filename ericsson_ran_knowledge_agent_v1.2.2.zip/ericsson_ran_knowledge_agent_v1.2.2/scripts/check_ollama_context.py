#!/usr/bin/env python3
"""Print the effective Ericsson Ollama context configuration."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agent_core.constants import PACKAGE_VERSION
from agent_core.settings import get_settings


def main() -> int:
    settings = get_settings(reload=True)
    payload = {
        "ok": settings.ollama_context_tokens > 0,
        "package_version": PACKAGE_VERSION,
        "ollama_url": settings.ollama_url,
        "ollama_model": settings.ollama_model,
        "ollama_context_tokens": settings.ollama_context_tokens,
        "environment_override": os.getenv("OLLAMA_CONTEXT_TOKENS"),
        "request_option": {"num_ctx": settings.ollama_context_tokens},
        "note": "The active value is sent on every Ollama generate request. Stop the already-loaded model before verifying with `ollama ps`.",
    }
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    return 0 if payload["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
