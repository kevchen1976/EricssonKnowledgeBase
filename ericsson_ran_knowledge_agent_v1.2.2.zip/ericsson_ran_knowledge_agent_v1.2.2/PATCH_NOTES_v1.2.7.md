# v1.2.7 - Nokia Ollama trace parity

- Ports Nokia's native Ollama journal-forwarding model into the Ericsson launcher.
- `logs/ollama.log` is now the native Ollama daemon trace source: `journalctl -u ollama -f --output=short-iso`.
- Keeps Ericsson's richer request/response payload trace in `logs/ollama-client.log`.
- Adds isolated PID management so Ericsson never `pkill`s Nokia's forwarder.
- Does not start or stop the shared Ollama daemon.
- Adds `ollama-log-start`, `ollama-log-stop`, and `ollama-log-status` launcher commands.
- Adds `scripts/check_ollama_native_trace.py`.
- No retrieval, RRF, reranking, prompt, Redis, OpenSearch, ingestion, or frontend behavior changes.
