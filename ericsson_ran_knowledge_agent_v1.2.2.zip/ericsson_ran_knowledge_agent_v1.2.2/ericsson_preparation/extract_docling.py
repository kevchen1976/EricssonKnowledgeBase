from __future__ import annotations

import gc
import hashlib
import logging
import re
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .markdown import build_markdown

log = logging.getLogger(__name__)

try:
    import fitz  # PyMuPDF fallback
except Exception:  # pragma: no cover
    fitz = None

try:
    from docling.document_converter import DocumentConverter, PdfFormatOption
    from docling.datamodel.base_models import InputFormat
    from docling.datamodel.pipeline_options import PdfPipelineOptions
    from docling_core.types.doc import PictureItem, TableItem, TextItem
except Exception:  # pragma: no cover
    DocumentConverter = PdfFormatOption = InputFormat = PdfPipelineOptions = None
    PictureItem = TableItem = TextItem = None


@dataclass
class ExtractionResult:
    markdown: str
    page_count: int
    image_files: List[Path]
    engine: str


def _page_bbox(item: Any) -> Tuple[Optional[int], Optional[Tuple[float, float, float, float]]]:
    prov = getattr(item, "prov", None) or getattr(item, "provenance", None)
    if isinstance(prov, list):
        prov = prov[0] if prov else None
    if prov is None:
        return None, None
    page = getattr(prov, "page_no", None) or getattr(prov, "page", None)
    bbox = getattr(prov, "bbox", None) or getattr(prov, "box", None)
    if bbox is None:
        return int(page) if page is not None else None, None
    if isinstance(bbox, (list, tuple)) and len(bbox) == 4:
        return int(page) if page is not None else None, tuple(float(x) for x in bbox)
    for names in (("l", "t", "r", "b"), ("x0", "y0", "x1", "y1"), ("left", "top", "right", "bottom")):
        if all(hasattr(bbox, n) for n in names):
            return int(page) if page is not None else None, tuple(float(getattr(bbox, n)) for n in names)
    return int(page) if page is not None else None, None


def _text_to_markdown(item: Any) -> str:
    text = str(getattr(item, "text", "") or "").strip()
    if not text:
        return ""
    label = str(getattr(item, "label", "") or "").lower()
    if "title" in label:
        return f"# {text}"
    if "section_header" in label or "heading" in label:
        level = getattr(item, "level", None)
        try:
            n = max(2, min(6, int(level) + 1)) if level is not None else 2
        except Exception:
            n = 2
        return f"{'#' * n} {text}"
    if "list_item" in label:
        return f"- {text}"
    return text


def _extract_docling(pdf_path: Path, image_dir: Path, image_link_dir: str, backend: Optional[str] = None) -> ExtractionResult:
    if DocumentConverter is None:
        raise RuntimeError("Docling is not installed")

    opts = PdfPipelineOptions()
    opts.do_ocr = False
    opts.generate_picture_images = True
    opts.generate_page_images = False
    if backend and hasattr(opts, "pdf_backend"):
        opts.pdf_backend = backend

    converter = DocumentConverter(format_options={InputFormat.PDF: PdfFormatOption(pipeline_options=opts)})
    result = converter.convert(pdf_path)
    doc = result.document

    # (sort_key, markdown) per page; bbox top is used when available.
    page_items: Dict[int, List[Tuple[float, int, str]]] = {}
    image_files: List[Path] = []
    image_dir.mkdir(parents=True, exist_ok=True)
    counters: Dict[int, int] = {}
    serial = 0

    for item, _level in doc.iterate_items():
        serial += 1
        page, bbox = _page_bbox(item)
        if page is None:
            continue
        y = bbox[1] if bbox else float(serial)
        rendered = ""
        if TextItem is not None and isinstance(item, TextItem):
            rendered = _text_to_markdown(item)
        elif TableItem is not None and isinstance(item, TableItem):
            try:
                rendered = item.export_to_markdown(doc) if hasattr(item, "export_to_markdown") else item.to_markdown()
            except Exception:
                rendered = "[Table rendering failed]"
        elif PictureItem is not None and isinstance(item, PictureItem):
            try:
                image = item.get_image(doc)
                counters[page] = counters.get(page, 0) + 1
                name = f"page_{page:03d}_image_{counters[page]:03d}.png"
                path = image_dir / name
                image.save(path, format="PNG")
                raw = path.read_bytes()
                if len(raw) >= 6000:
                    image_files.append(path)
                    rendered = f"![Figure on page {page}]({image_link_dir}/{name})"
                else:
                    path.unlink(missing_ok=True)
            except Exception as exc:
                log.debug("Picture extraction failed: %s", exc)
        if rendered.strip():
            page_items.setdefault(page, []).append((y, serial, rendered.strip()))

    pages: Dict[int, str] = {}
    for page in sorted(page_items):
        ordered = sorted(page_items[page], key=lambda x: (x[0], x[1]))
        pages[page] = "\n\n".join(x[2] for x in ordered)

    page_count = max(pages) if pages else len(getattr(doc, "pages", {}) or {})
    del doc, result, converter
    gc.collect()
    return ExtractionResult(build_markdown(pages), page_count, image_files, "docling")


def _extract_fitz(pdf_path: Path, image_dir: Path, image_link_dir: str) -> ExtractionResult:
    if fitz is None:
        raise RuntimeError("Neither Docling nor PyMuPDF is installed")
    doc = fitz.open(pdf_path)
    pages: Dict[int, str] = {}
    image_files: List[Path] = []
    image_dir.mkdir(parents=True, exist_ok=True)
    seen = set()

    for pno, page in enumerate(doc, 1):
        blocks = page.get_text("blocks", sort=True)
        chunks = []
        for block in blocks:
            txt = (block[4] or "").strip()
            if txt:
                chunks.append(txt)
        pages[pno] = "\n\n".join(chunks)

        for idx, info in enumerate(page.get_images(full=True), 1):
            xref = info[0]
            try:
                data = doc.extract_image(xref)
                raw = data["image"]
                if len(raw) < 6000:
                    continue
                digest = hashlib.sha256(raw).hexdigest()
                if digest in seen:
                    continue
                seen.add(digest)
                ext = data.get("ext", "png")
                path = image_dir / f"page_{pno:03d}_image_{idx:03d}.{ext}"
                path.write_bytes(raw)
                image_files.append(path)
                pages[pno] += f"\n\n![Figure on page {pno}]({image_link_dir}/{path.name})"
            except Exception:
                pass
    count = len(doc)
    doc.close()
    return ExtractionResult(build_markdown(pages), count, image_files, "pymupdf-fallback")


def _safe_document_stem(stem: str) -> str:
    """Return a stable filesystem-safe stem used for per-document asset folders."""
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", stem).strip("._-")
    return cleaned or "document"


def extract_pdf(pdf_path: Path, output_dir: Path, backend: Optional[str] = None, allow_fallback: bool = True) -> ExtractionResult:
    """Extract a PDF to Markdown and an adjacent per-document image folder.

    Markdown is written by the caller under ``output_dir/markdown``.  Images are
    therefore stored under ``output_dir/markdown/<safe_stem>_images`` and image
    references embedded in the returned Markdown are relative to that Markdown
    file, e.g. ``16-QAM_Uplink_images/page_001_image_001.png``.
    """
    markdown_dir = output_dir / "markdown"
    markdown_dir.mkdir(parents=True, exist_ok=True)
    image_link_dir = f"{_safe_document_stem(pdf_path.stem)}_images"
    image_dir = markdown_dir / image_link_dir

    # A fresh extraction must not leave orphaned figures from an older version
    # of the same PDF.  This is especially important when --overwrite is used.
    if image_dir.exists():
        shutil.rmtree(image_dir)

    try:
        return _extract_docling(pdf_path, image_dir, image_link_dir, backend=backend)
    except Exception as exc:
        if not allow_fallback:
            raise
        log.warning("Docling extraction failed for %s; using PyMuPDF fallback: %s", pdf_path.name, exc)
        if image_dir.exists():
            shutil.rmtree(image_dir)
        return _extract_fitz(pdf_path, image_dir, image_link_dir)
