"""Ericsson manifest sections aligned with ingestion parent boundaries."""
from __future__ import annotations

from typing import List

from ingestion.markdown_parser import parse_markdown_sections

from .ids import find_feature_ids, find_package_ids
from .models import Section


def infer_section_type(heading: str, text: str) -> str:
    sample = f"{heading} {text[:700]}".lower()
    heading_lower = heading.lower()
    if "deactivat" in sample or "disable" in heading_lower:
        return "deactivation"
    if "activat" in sample or "enable" in heading_lower:
        return "activation"
    if any(key in sample for key in ("dependenc", "prerequisite", "requirement")):
        return "prerequisite"
    if any(key in sample for key in ("parameter", "configuration attribute", "setting")):
        return "parameter"
    if any(key in sample for key in ("counter", "kpi", "measurement", "observability", "monitor")):
        return "monitoring"
    if any(key in sample for key in ("limitation", "restriction", "incompatib")):
        return "restriction"
    if any(key in sample for key in ("impact", "performance")):
        return "impact"
    if any(key in sample for key in ("operation", "function", "behavior", "behaviour", "process", "flow")):
        return "operation"
    if any(key in sample for key in ("identity", "overview", "introduction", "benefit", "concept")):
        return "overview"
    if "change history" in sample or "revision" in sample:
        return "change_log"
    return "general"


def parse_sections(markdown: str) -> List[Section]:
    """Return the exact section outline later used for parent chunking.

    The shared parser is TOC-aware and supports Ericsson headings through six
    numeric levels, including four-part paths such as ``2.2.3.1 Radio Node``.
    Using it in both preparation and ingestion prevents manifest headings from
    drifting away from parent boundaries.
    """
    parsed = parse_markdown_sections(markdown, include_preamble=False)
    sections: List[Section] = []
    for item in parsed:
        body = "\n\n".join(block.text for block in item.blocks if block.text.strip()).strip()
        full = item.text
        sections.append(Section(
            order=item.order,
            heading=item.heading,
            text=body,
            page_start=item.page_start,
            page_end=item.page_end,
            section_type=infer_section_type(item.heading, body),
            heading_path=item.heading_path,
            feature_ids=find_feature_ids(full),
            package_ids=find_package_ids(full),
            heading_number=item.heading_number,
            heading_level=item.level,
        ))
    if sections:
        return sections

    # A heading-less general document remains retrievable as one section.
    page_end = 1
    for marker in parse_markdown_sections(markdown, include_preamble=True):
        page_end = max(page_end, marker.page_end)
    return [Section(
        order=1,
        heading="Document Overview",
        text=(markdown or "").strip(),
        page_start=1,
        page_end=page_end,
        section_type="general",
        heading_path="Document Overview",
        feature_ids=find_feature_ids(markdown),
        package_ids=find_package_ids(markdown),
        heading_number="",
        heading_level=1,
    )]
