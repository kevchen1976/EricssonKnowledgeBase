from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Dict, Iterable, List

from .ids import feature_key, package_key
from .models import DocumentAnalysis, Section


def _questions_for_document(r: DocumentAnalysis) -> List[str]:
    if r.owner_feature_id:
        fid = r.owner_feature_id
        return [
            f"What does {fid} do?",
            f"What are the dependencies of {fid}?",
            f"What parameters are used by {fid}?",
            f"Which package contains {fid}?",
        ]
    return [f"What does {r.title} describe?", f"What are the key recommendations in {r.title}?"]


def _questions_for_section(s: Section, feature_id: str, title: str) -> List[str]:
    subject = feature_id or title
    mapping = {
        "activation": [f"How do I activate {subject}?"],
        "deactivation": [f"How do I deactivate {subject}?"],
        "prerequisite": [f"What are the dependencies or requirements for {subject}?"],
        "parameter": [f"What parameters or settings apply to {subject}?"],
        "monitoring": [f"How can I monitor {subject}?"],
        "restriction": [f"What limitations or restrictions apply to {subject}?"],
        "impact": [f"What is the performance or system impact of {subject}?"],
    }
    return mapping.get(s.section_type, [f"What does {s.heading} say about {subject}?"])


def _extract_facts(text: str, limit: int = 20) -> List[str]:
    facts: List[str] = []
    for line in (text or "").splitlines():
        s = re.sub(r"^\s*(?:[-*•]|\d+[.)])\s*", "", line).strip()
        if len(s) < 25 or s.startswith("|") or s.startswith("!["):
            continue
        # Prefer complete statements and concrete identity/configuration lines.
        if re.search(r"[.!?]$", s) or any(k in s.lower() for k in ("feature identity", "value package", "maximum", "minimum", "required", "supports", "no ")):
            if s not in facts:
                facts.append(s[:1000])
        if len(facts) >= limit:
            break
    return facts


def document_record(r: DocumentAnalysis) -> Dict[str, object]:
    return {
        "record_kind": "document",
        "manifest_stage": "document",
        "record_id": f"{r.markdown_path.name}#document",
        "vendor": "Ericsson",
        "filename": r.markdown_path.name,
        "source_markdown": r.markdown_path.name,
        "source_pdf": r.source_pdf.name,
        "title": r.title,
        "doc_type": r.doc_type,
        "doc_role": r.doc_role,
        "manifest_only": False,
        "content_retrievable": True,
        "is_feature_owner": bool(r.owner_feature_id),
        "route_by_feature": bool(r.owner_feature_id or r.included_feature_ids),
        "route_by_package": bool(r.package_ids),
        "route_by_topic": True,
        "primary_feature_id": r.primary_feature_id,
        "owner_feature_id": r.owner_feature_id,
        "feature_id": r.owner_feature_id,
        "feature_key": feature_key(r.owner_feature_id),
        "feature_ids": r.feature_ids,
        "included_feature_ids": r.included_feature_ids,
        "mentioned_feature_ids": r.mentioned_feature_ids,
        "feature_title": r.feature_title,
        "primary_package_id": r.primary_package_id,
        "package_id": r.primary_package_id,
        "package_key": package_key(r.primary_package_id),
        "package_ids": r.package_ids,
        "package_names": r.package_names,
        "access_types": r.access_types,
        "node_types": r.node_types,
        "licensing": r.licensing,
        "topics": r.topics,
        "topic_aliases": r.topic_aliases,
        "section_type": "document",
        "section_heading": r.title,
        "heading_path": r.title,
        "page_start": 1,
        "page_end": r.page_count,
        "prerequisites": [],
        "restriction_status": "",
        "question_templates": _questions_for_document(r),
        "doc_stats": {"page_count": r.page_count, "section_count": len(r.sections)},
    }


def section_records(r: DocumentAnalysis) -> List[Dict[str, object]]:
    out: List[Dict[str, object]] = []
    for s in r.sections:
        # Section route target: owner first, then explicitly included/mentioned IDs in the section.
        section_fids = s.feature_ids or ([r.owner_feature_id] if r.owner_feature_id else [])
        route_fid = r.owner_feature_id or (section_fids[0] if section_fids else "")
        out.append({
            "record_kind": "section",
            "manifest_stage": "section",
            "record_id": f"{r.markdown_path.name}#section#{s.order}",
            "vendor": "Ericsson",
            "filename": r.markdown_path.name,
            "source_markdown": r.markdown_path.name,
            "title": r.title,
            "doc_type": r.doc_type,
            "doc_role": r.doc_role,
            "manifest_only": False,
            "content_retrievable": True,
            "primary_feature_id": r.primary_feature_id,
            "owner_feature_id": r.owner_feature_id,
            "feature_id": route_fid,
            "feature_ids": section_fids,
            "included_feature_ids": r.included_feature_ids,
            "mentioned_feature_ids": r.mentioned_feature_ids,
            "feature_title": r.feature_title,
            "package_ids": s.package_ids or r.package_ids,
            "section_order": s.order,
            "section_heading": s.heading,
            "heading_path": s.heading_path or s.heading,
            "heading_number": s.heading_number,
            "heading_level": s.heading_level,
            "section_type": s.section_type,
            "feature_association": s.feature_association,
            "page_start": s.page_start,
            "page_end": s.page_end,
            "topics": r.topics,
            "topic_aliases": [],
            "prerequisites": [],
            "restriction_status": "" if s.section_type != "restriction" else "see_section",
            "question_templates": _questions_for_section(s, route_fid, r.title),
            "priority": {"activation":100,"deactivation":95,"prerequisite":90,"parameter":85,"monitoring":80,"restriction":75,"impact":70,"operation":65,"overview":60}.get(s.section_type, 50),
            "evidence": {"page_start": s.page_start, "page_end": s.page_end},
        })
    return out


def fact_records(r: DocumentAnalysis) -> List[Dict[str, object]]:
    out: List[Dict[str, object]] = []
    for s in r.sections:
        route_fid = r.owner_feature_id or (s.feature_ids[0] if s.feature_ids else "")
        for idx, fact in enumerate(_extract_facts(s.text), 1):
            out.append({
                "record_kind": "fact",
                "manifest_stage": "fact",
                "record_id": f"{r.markdown_path.name}#fact#{s.order}.{idx}",
                "vendor": "Ericsson",
                "filename": r.markdown_path.name,
                "source_markdown": r.markdown_path.name,
                "title": r.title,
                "doc_type": r.doc_type,
                "doc_role": r.doc_role,
                "manifest_only": False,
                "feature_id": route_fid,
                "feature_ids": s.feature_ids or ([r.owner_feature_id] if r.owner_feature_id else []),
                "feature_title": r.feature_title,
                "section_heading": s.heading,
                "heading_path": s.heading_path or s.heading,
                "heading_number": s.heading_number,
                "heading_level": s.heading_level,
                "section_type": s.section_type,
                "feature_association": s.feature_association,
                "page_start": s.page_start,
                "page_end": s.page_end,
                "fact": fact,
                "answer_summary": fact,
                "question_templates": _questions_for_section(s, route_fid, r.title),
                "priority": 10 + {"activation":100,"deactivation":95,"prerequisite":90,"parameter":85,"monitoring":80,"restriction":75,"impact":70,"operation":65,"overview":60}.get(s.section_type, 50),
                "evidence": {"page_start": s.page_start, "page_end": s.page_end},
            })
    return out


def relationship_records(r: DocumentAnalysis) -> List[Dict[str, object]]:
    out = []
    for idx, v in enumerate(r.feature_variants, 1):
        out.append({
            "record_kind": "package_feature",
            "manifest_stage": "relationship",
            "record_id": f"{r.markdown_path.name}#package-feature#{idx}",
            "vendor": "Ericsson",
            "filename": r.markdown_path.name,
            "source_markdown": r.markdown_path.name,
            "title": r.title,
            "doc_type": r.doc_type,
            "doc_role": r.doc_role,
            "feature_id": v.feature_id,
            "feature_ids": [v.feature_id],
            "feature_title": v.feature_name or (r.title if r.doc_role in {"feature_document", "package_document"} else ""),
            "feature_association": "included" if r.doc_role == "package_document" else "primary",
            "package_id": v.package_id,
            "package_ids": [v.package_id] if v.package_id else [],
            "package_name": v.package_name,
            "access_type": v.access_type,
            "node_type": v.node_type,
            "licensing": v.licensing,
            "section_type": "identity",
            "page_start": 1,
            "page_end": r.page_count,
        })
    return out


def manifest_records(r: DocumentAnalysis) -> List[Dict[str, object]]:
    return [document_record(r), *section_records(r), *fact_records(r), *relationship_records(r)]


def write_jsonl(path: Path, records: Iterable[Dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")


def write_sidecar(r: DocumentAnalysis) -> Path:
    doc = document_record(r)
    attrs = {k: v for k, v in doc.items() if k not in {"record_kind", "manifest_stage", "record_id"}}
    payload = {"metadataAttributes": attrs}
    path = Path(str(r.markdown_path) + ".metadata.json")
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return path
