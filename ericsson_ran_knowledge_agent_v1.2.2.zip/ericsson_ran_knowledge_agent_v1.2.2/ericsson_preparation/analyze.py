from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, Iterable, List

from .classify import classify_document, document_role
from .ids import find_feature_ids, find_package_ids, normalize_feature_id, normalize_package_id
from .markdown import first_nonempty_heading, markdown_tables, slugify
from .models import DocumentAnalysis, FeatureVariant
from .sections import parse_sections

STOPWORDS = {
    "the", "and", "for", "with", "from", "this", "that", "feature", "description",
    "commercial", "product", "solution", "guideline", "contents", "overview", "general",
    "ericsson", "baseband", "radio", "node", "document", "information",
}


def _clean(value: str) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


def _first_match(text: str, label: str, value_re: str = r"([^\n|]{1,160})") -> str:
    m = re.search(rf"\b{label}\b\s*[:|]?\s*{value_re}", text or "", re.I)
    return _clean(m.group(1)) if m else ""


def _extract_title(markdown: str, source: Path) -> str:
    h = first_nonempty_heading(markdown)
    if h and not re.search(r"^(feature description|commercial product description|solution guideline)$", h, re.I):
        if not re.match(r"^\d{1,2}/\d{1,2}/\d{2,4}", h):
            return h

    # Filenames exported from CPI are normally the document title. Remove only
    # common browser/download copy suffixes such as "(1)". This is more robust
    # than using browser timestamp headers that may be present in the PDF.
    stem = re.sub(r"\s*\(\d+\)\s*$", "", source.stem).strip()
    if stem and not re.fullmatch(r"[A-F0-9_-]{12,}", stem, re.I):
        return stem

    lines = [_clean(x.lstrip("#").strip()) for x in markdown.splitlines() if _clean(x.lstrip("#").strip())]
    family_words = ("feature description", "commercial product description", "solution guideline")
    for line in lines[:30]:
        if line.lower() in family_words or line.lower() == "contents" or line.startswith("<!--"):
            continue
        if re.match(r"^\d{1,2}/\d{1,2}/\d{2,4}", line):
            continue
        if len(line) < 160:
            return line
    return source.stem


def _topics(title: str, markdown: str) -> str:
    tokens = re.findall(r"[A-Za-z][A-Za-z0-9+-]{2,}", f"{title} {markdown[:5000]}")
    counts: Dict[str, int] = {}
    for t in tokens:
        key = t.lower()
        if key in STOPWORDS or key.isdigit():
            continue
        counts[key] = counts.get(key, 0) + 1
    ranked = sorted(counts, key=lambda k: (-counts[k], k))[:14]
    return " ".join(ranked)


def _aliases(title: str, topics: str) -> List[str]:
    out: List[str] = []
    for candidate in (title, " ".join(topics.split()[:4])):
        s = slugify(candidate)
        if s and s not in out and s not in {"contents", "overview"}:
            out.append(s)
    return out[:3]


def _rowmap(table: List[List[str]]) -> Dict[str, List[str]]:
    result: Dict[str, List[str]] = {}
    for row in table:
        if not row:
            continue
        key = re.sub(r"\s+", " ", row[0]).strip().lower()
        result[key] = row[1:]
    return result


def _clean_table_lines(value: str) -> List[str]:
    """Return useful logical rows from a flattened Ericsson identity table.

    PyMuPDF and some PDF exports preserve the visual column order but flatten
    table cells into separate lines.  Page markers, browser headers, and empty
    lines are removed while cell text remains intact.
    """
    out: List[str] = []
    for raw in (value or "").splitlines():
        line = _clean(raw)
        if not line or line.startswith("<!--"):
            continue
        if re.match(r"^\d{1,2}/\d{1,2}/\d{2,4},", line):
            continue
        if re.fullmatch(r"Ericsson\s+CPI\d+/\d+", line, re.I):
            continue
        out.append(line)
    return out


def _between(text: str, start: str, end: str) -> str:
    match = re.search(rf"{start}\s*(?P<body>.*?)(?={end})", text or "", re.I | re.S)
    return match.group("body") if match else ""


def _flattened_identity_columns(markdown: str) -> Dict[str, List[str]]:
    """Recover transposed identity-table columns from flattened PDF text.

    Ericsson CPI tables are commonly transposed: each row is an attribute and
    each visual column is an access/package variant.  In flattened extraction,
    the package-name cells can appear immediately after the Feature Identity
    values and before the ``Value Package Name`` label.  This routine handles
    that layout without promoting unrelated IDs elsewhere in the document.
    """
    feature_names = _clean_table_lines(_between(
        markdown,
        r"Feature\s*\n\s*Name(?:\s*\n|\s+)",
        r"Feature\s*\n\s*Identity",
    ))

    identity_to_package_label = _between(
        markdown,
        r"Feature\s*\n\s*Identity(?:\s*\n|\s+)",
        r"Value\s*\n\s*Package\s*\n\s*Name",
    )
    mixed_lines = _clean_table_lines(identity_to_package_label)
    feature_ids: List[str] = []
    package_names: List[str] = []
    last_feature_index = -1
    for index, line in enumerate(mixed_lines):
        values = find_feature_ids(line)
        if values:
            feature_ids.extend(values)
            last_feature_index = index
    if last_feature_index >= 0:
        package_names = [
            line for line in mixed_lines[last_feature_index + 1 :]
            if not find_feature_ids(line) and not find_package_ids(line)
        ]

    package_region = _between(
        markdown,
        r"Value\s*\n\s*Package\s*\n\s*Name(?:\s*\n|\s+)",
        r"Value\s*\n\s*Package\s*\n\s*Identity",
    )
    package_ids: List[str] = []
    for line in _clean_table_lines(package_region):
        package_ids.extend(find_package_ids(line))

    node_types = _clean_table_lines(_between(
        markdown,
        r"Node\s+Type(?:\s*\n|\s+)",
        r"Access\s+Type",
    ))
    access_types = [
        value.upper()
        for value in _clean_table_lines(_between(
            markdown,
            r"Access\s+Type(?:\s*\n|\s+)",
            r"Licensing",
        ))
        if re.fullmatch(r"NR|LTE|WCDMA|GSM", value, re.I)
    ]

    licensing_region = _between(markdown, r"Licensing(?:\s*\n|\s+)", r"Summary")
    licensing_matches = [
        _clean(match)
        for match in re.findall(
            r"License-controlled\s+feature\.\s+One\s+license\s+is\s+required\s+for\s+each\s+node\.",
            licensing_region,
            re.I,
        )
    ]

    return {
        "feature_names": feature_names,
        "feature_ids": feature_ids,
        "package_names": package_names,
        "package_ids": package_ids,
        "node_types": node_types,
        "access_types": access_types,
        "licensing": licensing_matches,
    }


def extract_feature_variants(markdown: str) -> List[FeatureVariant]:
    variants: List[FeatureVariant] = []
    for table in markdown_tables(markdown):
        rows = _rowmap(table)
        id_key = next((k for k in rows if k == "feature identity"), None)
        if not id_key:
            continue
        feature_ids = rows.get(id_key, [])
        names = rows.get("feature name", [])
        package_ids = rows.get("value package identity", [])
        package_names = rows.get("value package name", [])
        access = rows.get("access type", [])
        nodes = rows.get("node type", [])
        licensing = rows.get("licensing", [])
        width = max(len(feature_ids), len(names), len(package_ids), len(package_names), len(access), 0)
        for i in range(width):
            fid_candidates = find_feature_ids(feature_ids[i] if i < len(feature_ids) else "")
            if not fid_candidates:
                continue
            pid_candidates = find_package_ids(package_ids[i] if i < len(package_ids) else "")
            variants.append(FeatureVariant(
                feature_id=fid_candidates[0],
                feature_name=_clean(names[i]) if i < len(names) else "",
                package_id=pid_candidates[0] if pid_candidates else "",
                package_name=_clean(package_names[i]) if i < len(package_names) else "",
                access_type=_clean(access[i]) if i < len(access) else "",
                node_type=_clean(nodes[i]) if i < len(nodes) else "",
                licensing=_clean(licensing[i]) if i < len(licensing) else "",
            ))
    # Fallback for text extractors that flatten Ericsson's transposed identity
    # table. Recover column values from the bounded identity-table region so
    # IDs in references/change history do not become package relationships.
    if not variants:
        columns = _flattened_identity_columns(markdown)
        raw_fids = columns["feature_ids"]
        raw_pids = columns["package_ids"]
        if len(raw_fids) >= 1:
            width = len(raw_fids)
            # Some extractors leave a cover-level package ID inside the bounded
            # region. The visual table has one package per feature column, so
            # retain the final N package identities in that case.
            if len(raw_pids) > width:
                raw_pids = raw_pids[-width:]
            for i, fid in enumerate(raw_fids):
                variants.append(FeatureVariant(
                    feature_id=fid,
                    feature_name=columns["feature_names"][i] if i < len(columns["feature_names"]) else "",
                    package_id=raw_pids[i] if i < len(raw_pids) else "",
                    package_name=columns["package_names"][i] if i < len(columns["package_names"]) else "",
                    access_type=columns["access_types"][i] if i < len(columns["access_types"]) else "",
                    node_type=columns["node_types"][i] if i < len(columns["node_types"]) else "",
                    licensing=columns["licensing"][i] if i < len(columns["licensing"]) else "",
                ))

    # Last-resort pairing for legacy flattened Markdown that lacks recognizable
    # labels but still contains repeated feature and package identities.
    if not variants:
        raw_fids = [f"FAJ 121 {x}" for x in re.findall(r"FAJ\s*121\s*(\d{4})", markdown, re.I)]
        raw_pids = [f"FAJ 801 {x}" for x in re.findall(r"FAJ\s*801\s*(\d{4})", markdown, re.I)]
        if len(raw_fids) >= 2 and len(raw_pids) >= len(raw_fids):
            raw_pids = raw_pids[-len(raw_fids):]
            for i, fid in enumerate(raw_fids):
                variants.append(FeatureVariant(feature_id=fid, package_id=raw_pids[i]))

    # deterministic dedupe
    seen = set(); out = []
    for v in variants:
        key = (v.feature_id, v.package_id, v.access_type)
        if key not in seen:
            seen.add(key); out.append(v)
    return out


def analyze_markdown(markdown_path: Path, source_pdf: Path | None = None, page_count: int = 0) -> DocumentAnalysis:
    markdown = markdown_path.read_text(encoding="utf-8")
    source_pdf = source_pdf or markdown_path.with_suffix(".pdf")
    title = _extract_title(markdown, source_pdf)
    all_fids = find_feature_ids(markdown)
    all_pids = find_package_ids(markdown)
    doc_type = classify_document(markdown, source_pdf.name)
    role = document_role(doc_type, all_fids)
    variants = extract_feature_variants(markdown)

    # Ownership is intentionally conservative: only a dedicated Feature Description owns a feature.
    owner = all_fids[0] if role == "feature_document" and len(all_fids) == 1 else ""
    included = []
    if role == "package_document":
        included = list(dict.fromkeys([v.feature_id for v in variants] or all_fids))
    mentioned = [f for f in all_fids if f != owner and f not in included]

    # Dedicated identity table fields.
    feature_title = _first_match(markdown, r"Feature\s+Name") if owner else ""
    if owner and (not feature_title or find_feature_ids(feature_title)):
        feature_title = title
    primary_package = ""
    if owner:
        # Prefer the first package identity in the dedicated feature document.
        primary_package = all_pids[0] if all_pids else ""

    sections = parse_sections(markdown)
    for section in sections:
        if owner:
            section.feature_association = "primary"
        elif any(fid in included for fid in section.feature_ids):
            section.feature_association = "included"
        elif section.feature_ids:
            section.feature_association = "mentioned"
        else:
            section.feature_association = "none"

    access_types = list(dict.fromkeys(v.access_type for v in variants if v.access_type))
    node_types = list(dict.fromkeys(v.node_type for v in variants if v.node_type))
    package_names = list(dict.fromkeys(v.package_name for v in variants if v.package_name))
    if owner and not access_types:
        access = _first_match(markdown, r"Access\s+Type")
        if access:
            access_types.append(access)
    if owner and not node_types:
        node = _first_match(markdown, r"Node\s+Type")
        if node:
            node_types.append(node)
    if owner and not package_names:
        package_name = _first_match(markdown, r"Value\s+Package\s+Name")
        if package_name and not find_package_ids(package_name):
            package_names.append(package_name)
    licensing = _first_match(markdown, r"Licensing")

    # Dedicated Feature Descriptions often use a compact identity list rather
    # than the multi-column table found in package documents.  Materialize that
    # owner/package pair as a relationship too so the future graph staging is
    # complete and the feature catalog retains the package title.
    if owner and primary_package and not variants:
        variants = [FeatureVariant(
            feature_id=owner,
            feature_name=feature_title or title,
            package_id=primary_package,
            package_name=package_names[0] if package_names else "",
            access_type=access_types[0] if access_types else "",
            node_type=node_types[0] if node_types else "",
            licensing=licensing,
        )]

    topics = _topics(title, markdown)
    return DocumentAnalysis(
        source_pdf=source_pdf,
        markdown_path=markdown_path,
        title=title,
        doc_type=doc_type,
        doc_role=role,
        primary_feature_id=owner,
        owner_feature_id=owner,
        feature_ids=all_fids,
        included_feature_ids=included,
        mentioned_feature_ids=mentioned,
        primary_package_id=primary_package,
        package_ids=all_pids,
        feature_title=feature_title,
        package_names=package_names,
        access_types=access_types,
        node_types=node_types,
        licensing=licensing,
        topics=topics,
        topic_aliases=_aliases(title, topics),
        sections=sections,
        feature_variants=variants,
        page_count=page_count or max([s.page_end for s in sections] or [1]),
    )
