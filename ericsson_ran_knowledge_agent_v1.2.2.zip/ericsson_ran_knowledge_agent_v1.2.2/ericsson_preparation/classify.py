from __future__ import annotations

import re
from pathlib import Path
from typing import List, Tuple

from .ids import find_feature_ids, find_package_ids

_DOC_PATTERNS: List[Tuple[str, re.Pattern[str]]] = [
    ("feature_description", re.compile(r"\bFeature\s+Description\b", re.I)),
    ("commercial_product_description", re.compile(r"\bCommercial\s+Product\s+Description\b", re.I)),
    ("solution_guideline", re.compile(r"\bSolution\s+Guideline\b", re.I)),
    ("system_description", re.compile(r"\bSystem\s+Description\b", re.I)),
    ("operation_instruction", re.compile(r"\b(?:Operation|Operating)\s+(?:Instruction|Guide)\b", re.I)),
    ("configuration_instruction", re.compile(r"\b(?:Configuration|Configuring)\s+(?:Instruction|Guide)\b", re.I)),
    ("user_guide", re.compile(r"\bUser\s+Guide\b", re.I)),
]


def classify_document(text: str, filename: str = "") -> str:
    # Document-family banners appear at the very top of Ericsson CPI pages.
    # Keep this window deliberately short so cross-references such as
    # "see Feature Description IPsec" do not reclassify a Solution Guideline.
    head = (text or "")[:1800]
    # Choose the earliest document-family banner instead of the first pattern in
    # code order.  This prevents a later cross-reference such as
    # "Feature Description IPsec" from overriding an earlier
    # "Solution Guideline" banner.
    banner_matches = []
    for order, (name, pattern) in enumerate(_DOC_PATTERNS):
        match = pattern.search(head)
        if match:
            banner_matches.append((match.start(), order, name))
    if banner_matches:
        return min(banner_matches)[2]

    # Ericsson identity-table signatures are strong fallback signals.
    has_feature_identity = bool(re.search(r"\bFeature\s+Identity\b", head, re.I))
    has_package_identity = bool(re.search(r"\bValue\s+Package\s+Identity\b", head, re.I))
    fids = find_feature_ids(head)
    pids = find_package_ids(head)
    if has_feature_identity and len(fids) == 1:
        return "feature_description"
    if has_package_identity and (len(fids) > 1 or len(pids) > 1):
        return "commercial_product_description"

    lower_name = Path(filename).stem.lower()
    if "solution guideline" in lower_name:
        return "solution_guideline"
    return "general_document"


def document_role(doc_type: str, feature_ids: List[str]) -> str:
    if doc_type == "feature_description" and len(feature_ids) == 1:
        return "feature_document"
    if doc_type == "commercial_product_description":
        return "package_document"
    return "general_document"
