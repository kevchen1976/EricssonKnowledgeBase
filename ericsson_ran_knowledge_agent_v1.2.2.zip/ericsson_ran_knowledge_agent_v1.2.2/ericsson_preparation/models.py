from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional


@dataclass
class Section:
    order: int
    heading: str
    text: str
    page_start: int
    page_end: int
    section_type: str = "overview"
    heading_path: str = ""
    feature_ids: List[str] = field(default_factory=list)
    package_ids: List[str] = field(default_factory=list)
    feature_association: str = "none"
    heading_number: str = ""
    heading_level: int = 1


@dataclass
class FeatureVariant:
    feature_id: str
    feature_name: str = ""
    package_id: str = ""
    package_name: str = ""
    access_type: str = ""
    node_type: str = ""
    licensing: str = ""


@dataclass
class DocumentAnalysis:
    source_pdf: Path
    markdown_path: Path
    title: str
    doc_type: str
    doc_role: str
    primary_feature_id: str = ""
    owner_feature_id: str = ""
    feature_ids: List[str] = field(default_factory=list)
    included_feature_ids: List[str] = field(default_factory=list)
    mentioned_feature_ids: List[str] = field(default_factory=list)
    primary_package_id: str = ""
    package_ids: List[str] = field(default_factory=list)
    feature_title: str = ""
    package_names: List[str] = field(default_factory=list)
    access_types: List[str] = field(default_factory=list)
    node_types: List[str] = field(default_factory=list)
    licensing: str = ""
    topics: str = ""
    topic_aliases: List[str] = field(default_factory=list)
    sections: List[Section] = field(default_factory=list)
    feature_variants: List[FeatureVariant] = field(default_factory=list)
    page_count: int = 0
    extra: Dict[str, object] = field(default_factory=dict)
