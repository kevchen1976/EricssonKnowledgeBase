# Changelog

## 1.2.4 — 2026-09-03

- Replaced the Ericsson in-process deque session store with Nokia-aligned Redis-backed conversation history.
- Added the exact Nokia request order: load history before workflow, rewrite the follow-up, retrieve with the effective query, synthesize with bounded history, audit the answer, then append the exchange with a sliding TTL.
- Added Ericsson-aware LLM query rewriting before routing, with `FAJ 121`/`FAJ 801` preservation, raw-alarm bypass, fail-open fallback, and rewrite logging.
- Added an Ericsson-specific Redis key namespace (`ericsson:session:`) so Nokia and Ericsson can share one Redis deployment without sharing sessions.
- Added Nokia-compatible `SESSION_TTL` and `MAX_HISTORY` settings, while retaining the older Ericsson environment aliases.
- Added Redis startup/readiness diagnostics and `scripts/check_redis.py`.
- Changed the launcher to source only a real `config/services.env`; `services.env.example` is no longer silently used as runtime configuration.
- Added effective/original query metadata to the API response and SQLite audit tool call.
- Kept OpenSearch indexes, chunking, embeddings, manifests, BM25/KNN, RRF, reranking, and Neo4j behavior unchanged; no re-ingestion is required.

## 1.2.2 — 2026-09-02

- Added Nokia-style, request-correlated RAG trace logging to `logs/chunks.log` without changing retrieval scores, ranking, filters, result limits, or response contracts.
- Added detailed trace stages for BM25 child recall, vector child recall, Reciprocal Rank Fusion, optional reranker scores, final child selection, parent `mget`, and final parent selection.
- Added Agent workflow logs to `logs/ericsson_agent.log` and retained the existing KB summary log in `logs/ericsson_kb.log`.
- Propagated one request ID from the Agent API to the KB API so Agent, RAG, and SQLite records can be correlated.
- Added a Nokia-compatible SQLite `audit` table that records each Agent API query, workflow/tool details, final answer, validation result, citations, warnings, latency, and complete response JSON.
- Preserved existing v1.2.1 `query_audit` history by migrating rows into `audit` and dual-writing compatibility rows when the legacy table exists.
- Added automated coverage for every RAG trace stage and complete query/answer audit persistence.

## 1.2.1 — 2026-09-02

- Fixed the misleading Transformers `sequence length ... 740 > 512` warning emitted while counting long, non-vector parent sections. Deliberate count/split tokenization now uses `verbose=False` without truncation.
- Added a strict production embedding guard that counts each final child input including model special tokens and rejects any input above `SentenceTransformer.max_seq_length`.
- Added a full-corpus embedding preflight before any OpenSearch client/index operation, so an over-limit child cannot leave a partial rebuild generation.
- Added `scripts/check_embedding_lengths.py` for a standalone no-OpenSearch token audit.
- Changed the default procedure-preservation ceiling from 900 to 480 tokens; the normal child window remains 300 with 60-token overlap.
- Added actual `embedding_token_count`, `embedding_model_max_tokens`, and `embedding_truncated=false` metadata to newly indexed children.
- Switched to `get_embedding_dimension()` where available, removing the Sentence Transformers deprecation warning while retaining compatibility with older releases.
- Added cleanup on `KeyboardInterrupt`/`SystemExit` for rebuild indexes and a safe `scripts/cleanup_rebuild_version.py` helper for an already-incomplete generation.

## 1.2.0 — 2026-09-02

- Completed the Nokia-aligned split-storage contract: full semantic parents are stored once in `ericsson-ran-kb-parents`, while only retrieval children are embedded in `ericsson-ran-kb-children`.
- Kept the established section-aware boundaries: one actual Ericsson outline section is one parent, including four-level headings such as `2.2.3.1`; numbered operational steps remain section body content.
- Made the default embedding input exactly the stored child `content`, matching the supplied Nokia ingestion behavior. Added an explicit `content_plus_metadata` opt-in mode that requires a rebuild.
- Added `storage_role`, `retrieval_contract`, `content_sha256`, `child_content_sha256`, and `parent_content_sha256` metadata to make the physical parent/child relationship auditable.
- Made parent expansion fail closed by default when a selected child has no stored parent or the parent content hash does not match. Controlled child-only fallback remains available only when `REQUIRE_PARENT_CONTEXT=false`.
- Added offline and live parent/child storage validation in `scripts/verify_parent_child_storage.py` and `GET /kb/debug/parent-child-status`.
- Added HTTP 503 `PARENT_CONTEXT_UNAVAILABLE` handling for parent-storage integrity failures.
- Extended automated coverage for exact child embedding input, non-vector parents, strict parent retrieval, content-hash checks, and preview storage validation.
- Refreshed the bundled prepared corpus with four supplied Ericsson examples, including the deep Instantaneous Licensing hierarchy.

## 1.1.0 — 2026-09-02

- Reworked Ericsson ingestion to follow the supplied Nokia section-aware parent/child strategy.
- Added TOC-aware, procedure-safe section parsing shared by preparation and ingestion.
- Added numeric heading support through six levels, including Ericsson four-level headings such as `2.2.3.1` and `3.2.2.1`.
- Defined one real document-outline section as one parent record; the 3000-token parent setting is diagnostic only and does not split a source section.
- Changed child defaults to 300 tokens with 60-token overlap.
- Added procedure preservation so a procedure-like section up to 900 tokens remains one child.
- Added the full heading path as a prefix to later child windows.
- Split OpenSearch storage into three Ericsson aliases:
  - `ericsson-ran-kb-children` for BM25 text and vectors;
  - `ericsson-ran-kb-parents` for full section context stored once;
  - `ericsson-ran-kb-manifests` for document, section, fact, and relationship records.
- Removed duplicated full-parent text from child documents and removed vectors from parent documents.
- Changed retrieval to rank child hits first and then fetch unique full parents with one parent-index `mget`.
- Added `parent_storage_id` for safe same-run parent resolution during incremental replacement.
- Changed rebuild mode to create and switch child, parent, and manifest aliases together in one atomic alias request.
- Kept logical `parent_id` stable while using run-scoped physical IDs during incremental ingestion.
- Disabled manifest-fact vector duplication by default with `INCLUDE_MANIFEST_FACTS=false`; fact records remain available in the manifest index.
- Added parent/child referential-integrity, mapping, deep-heading, procedure-preservation, and retrieval-expansion tests.
- Added migration guidance: v1.0's combined `ericsson-ran-kb-chunks` alias must be replaced by a v1.1 rebuild.

## 1.0.0 — 2026-09-02

- Added Ericsson Docling-first PDF preparation with adjacent image folders and portable Markdown links.
- Added Ericsson document, section, fact and package-feature manifests.
- Added deterministic `FAJ 121` feature and `FAJ 801` package routing.
- Added initial hierarchical Markdown chunking and manifest-fact chunks.
- Added role-aware identity handling so feature IDs cited in general documents are indexed as mentions, while package IDs remain included relationships.
- Added shared-cluster OpenSearch ingestion with Ericsson-only aliases, versioned backing indexes and mandatory namespace filters.
- Added fail-closed validation for Ericsson vendor/corpus configuration and the `ericsson-ran-kb-` shared-cluster safety prefix.
- Added hybrid BM25/KNN retrieval, Reciprocal Rank Fusion, optional reranking and parent de-duplication.
- Added standalone Ericsson Agent and Knowledge Base APIs on ports 8100 and 8102.
- Added a disabled-by-default Neo4j/Graph API scaffold on port 8101.
- Added rebuild, incremental and offline dry-run ingestion modes.
- Added run-scoped physical OpenSearch IDs for safe incremental replacement.
- Added a process-safe Ericsson-only launcher and a shared environment/settings configuration path.

## 1.2.3

- Added Nokia-style root `agentInstruction.txt` loading with a safe fallback.
- Added correlated manifest file/OpenSearch lookup tracing before RAG search.
- Limited result-bearing RAG, manifest, and final-evidence log entries to five.
- Limited every logged result content preview to the first 50 words.
- Kept retrieval, scores, reranking, embeddings, indexes, APIs, and SQLite audit unchanged.
