#!/usr/bin/env python3
"""Rebuild Ericsson feature/package/topic routing shards from combined_manifest.jsonl."""
from __future__ import annotations

import argparse
from pathlib import Path
from ericsson_preparation.routing import build_routing


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--overwrite", action="store_true")
    args = p.parse_args()
    index = build_routing(Path(args.input).expanduser().resolve(), Path(args.output_dir).expanduser().resolve(), overwrite=args.overwrite)
    print(f"feature shards={len(index['feature_shards'])}, package shards={len(index['package_shards'])}, topic shards={len(index['topic_shards'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
