# v1.2.1 embedding token-guard patch

## Why the 740 > 512 warning remained

`PROCEDURE_MAX_TOKENS=480` was not the source of the repeated warning. During parent generation, v1.2.0 called the Hugging Face tokenizer on each complete parent section to record `parent_token_count`. A 740-token parent is valid because parents are stored in `ericsson-ran-kb-parents` and are never embedded. The tokenizer nevertheless emitted its model-length advisory before the first parent bulk write.

v1.2.1 separates the two cases:

- complete parent count/split tokenization is non-truncating and quiet;
- every final child `embedding_text` is counted with model special tokens and must fit the loaded SentenceTransformer limit;
- a full-corpus preflight runs before OpenSearch is contacted;
- model inference repeats the assertion as defense in depth.

For BGE large v1.5, the detected model limit should be 512 and the vector dimension should be 1024.

## Stop the currently running `20260902b` attempt

Press `Ctrl+C` in the ingestion terminal. v1.2.1 also cleans new rebuild indexes on future interrupts, but v1.2.0 did not catch `KeyboardInterrupt`.

After applying this patch, inspect the incomplete generation:

```bash
python scripts/cleanup_rebuild_version.py --version 20260902b
```

The command is dry-run by default and shows current alias targets. It refuses to delete a live alias target. When it shows no live conflict, remove the incomplete indexes with:

```bash
python scripts/cleanup_rebuild_version.py --version 20260902b --execute
```

## Preflight before rebuilding

```bash
python scripts/check_embedding_lengths.py \
  --prepared-root data/prepared \
  --output logs/embedding_length_preflight.json
```

Required result:

```json
{
  "status": "passed",
  "model_max_tokens": 512,
  "over_limit_inputs": 0,
  "opensearch_touched": false
}
```

The exact largest child count depends on the corpus, but it must be no greater than `model_max_tokens`.

## Rebuild under a new version

Do not reuse the partially created `20260902b` name. Use a new generation:

```bash
python ingest_ericsson.py \
  --prepared-root data/prepared \
  --mode rebuild \
  --version 20260902c
```

Before any `PUT ...-v20260902c`, the log should contain:

```text
Embedding preflight passed: inputs=... largest=... model_max=512 ...
```

The final report additionally contains:

```text
embedding_model_max_tokens
embedding_inputs_checked
largest_embedding_input_tokens
largest_embedding_input_label
embedding_inputs_over_limit
```

A successful run must have `embedding_inputs_over_limit: 0`, `failures: 0`, and `largest_embedding_input_tokens <= embedding_model_max_tokens`.
