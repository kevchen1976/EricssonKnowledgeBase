# Configuration

All services use `agent_core/settings/loader.py`. Effective precedence:

```text
process environment
    > optional config/services.env
    > JSON selected by AGENT_SETTINGS_FILE
    > built-in defaults
```

Relative paths are resolved from the repository root.

## Shared OpenSearch

Ericsson and Nokia may share the physical cluster, but not aliases or backing indexes. Ericsson defaults:

```text
ericsson-ran-kb-children  -> ericsson-ran-kb-children-v<release>
ericsson-ran-kb-parents   -> ericsson-ran-kb-parents-v<release>
ericsson-ran-kb-manifests -> ericsson-ran-kb-manifests-v<release>
```

The three aliases and backing prefixes must be distinct. KB readiness requires all three.

Legacy `OPENSEARCH_CHUNK_ALIAS` and `OPENSEARCH_CHUNK_BACKING_PREFIX` are accepted only as child-index compatibility fallbacks. New deployments should use `OPENSEARCH_CHILD_*` and must configure `OPENSEARCH_PARENT_*`.

## Chunking

```text
PARENT_MAX_TOKENS=3000       diagnostic only
CHILD_MAX_TOKENS=300
CHILD_OVERLAP_TOKENS=60
KEEP_PROCEDURE_SECTIONS=true
PROCEDURE_MAX_TOKENS=480
ADD_HEADING_TO_CHILDREN=true
INCLUDE_MANIFEST_FACTS=false
EMBEDDING_INPUT_MODE=content
REQUIRE_PARENT_CONTEXT=true
VERIFY_PARENT_CONTENT_HASH=true
```

The tokenizer is loaded from `EMBEDDING_MODEL_PATH`. Use the same model family and vector dimension during ingestion and query-time retrieval. The default embedding input is exactly the stored child `content`. Parent context is authoritative; missing or hash-mismatched parents fail closed by default.

## Ports

```text
Agent API  8100
Graph API  8101
KB API     8102
```

## Neo4j

`GRAPH_ENABLED=false` is intentional. When relations are ready, use a separate logical database such as `ericsson`.

## Launcher boundary

`startup_all_service.sh` controls only the Ericsson APIs. It never starts, stops, or kills OpenSearch, Nokia services, Ollama, Redis, or Neo4j, and it refuses to replace an untracked process on an Ericsson port.

## Embedding token guard

`EMBEDDING_MAX_INPUT_TOKENS=0` derives the hard input limit from the loaded SentenceTransformer model. The ingestion preflight validates every final child embedding input before any OpenSearch index is created. For `bge-large-en-v1.5`, the detected limit is 512 tokens.

## Redis conversation memory and query rewriting

The Ericsson agent mirrors the Nokia request order: Redis history is loaded
before workflow execution, the last five exchanges are formatted for the LLM
rewriter, the rewritten self-contained query is used for routing/retrieval, and
the completed exchange is written back with a sliding TTL.

```text
SESSION_MEMORY_ENABLED=true
ENABLE_LLM_QUERY_REWRITE=true
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0
REDIS_KEY_PREFIX=ericsson:session:
SESSION_TTL=3600
MAX_HISTORY=5
```

`SESSION_TTL_SECONDS` and `MAX_SESSION_HISTORY` are retained as compatibility
aliases, but new deployments should use the Nokia-compatible names above.
`REDIS_URL` can replace the host/port/db/password fields. Use
`SESSION_HISTORY_ANSWER_CHARS=2000` for the text passed back into the rewrite and
synthesis prompts, and `SESSION_STORED_ANSWER_CHARS=4000` for each answer kept in
Redis.

The Ericsson and Nokia agents may use the same Redis server. Their keys remain
isolated by prefix. The Ericsson launcher does not start or stop the shared
Redis container.

`services.env.example` is never sourced automatically. Copy it to
`config/services.env` when environment overrides are required. Otherwise the
service uses `config/settings.json`.

```bash
cp config/services.env.example config/services.env
./startup_all_service.sh redis-check
```
