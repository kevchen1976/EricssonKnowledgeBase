"""KB service health, readiness, and index diagnostics."""
from __future__ import annotations

from fastapi import APIRouter, Query, Response, status

from agent_core.constants import PARENT_CHILD_CONTRACT, RETRIEVAL_SCHEMA
from ingestion.storage_validation import validate_live_storage

from ..state import get_state

router = APIRouter()


@router.get("/health")
def health() -> dict:
    settings = get_state().settings
    return {
        "status": "ok",
        "service": "ericsson-kb-api",
        "vendor": settings.vendor,
        "corpus_id": settings.corpus_id,
        "child_alias": settings.child_alias,
        "parent_alias": settings.parent_alias,
        "manifest_alias": settings.manifest_alias,
        "chunk_alias": settings.child_alias,
        "retrieval_schema": RETRIEVAL_SCHEMA,
    }


@router.get("/ready")
def ready(response: Response) -> dict:
    state = get_state()
    search = state.opensearch_status()
    ready_value = bool(
        search.get("connected")
        and search.get("child_alias_exists")
        and search.get("parent_alias_exists")
        and search.get("manifest_alias_exists")
    )
    if not ready_value:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    return {
        "ready": ready_value,
        "opensearch": search,
        "markdown_root_exists": state.settings.markdown_root.exists(),
        "combined_manifest_exists": state.settings.combined_manifest.exists(),
    }


@router.get("/kb/debug/index-info")
def index_info() -> dict:
    state = get_state()
    return {
        "opensearch": state.opensearch_status(),
        "configured": {
            "child_alias": state.settings.child_alias,
            "parent_alias": state.settings.parent_alias,
            "manifest_alias": state.settings.manifest_alias,
            "chunk_alias": state.settings.child_alias,
            "index_safety_prefix": state.settings.index_safety_prefix,
            "vendor_filter": state.settings.vendor,
            "corpus_filter": state.settings.corpus_id,
            "retrieval_schema": RETRIEVAL_SCHEMA,
            "embedding_max_input_tokens_override": state.settings.embedding_max_input_tokens,
            "embedding_token_guard": "strict-preflight-and-pre-encode",
        },
    }


@router.get("/kb/debug/parent-child-status")
def parent_child_status(
    response: Response,
    sample_size: int = Query(25, ge=1, le=1000),
) -> dict:
    """Sample the live child -> stored-parent integrity contract."""
    state = get_state()
    report = validate_live_storage(state.client(), state.settings, sample_size=sample_size)
    if not report.ok:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    payload = report.to_dict()
    payload["retrieval_contract"] = PARENT_CHILD_CONTRACT
    return payload
