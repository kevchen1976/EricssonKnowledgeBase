"""Knowledge Base retrieval, manifest, and diagnostics endpoints."""
from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional

from fastapi import APIRouter, Body, HTTPException, Query

from agent_core.ids import normalize_feature_id, normalize_package_id
from agent_core.logging_utils import single_line

from ..manifest import ManifestRepository, extract_image_links, public_manifest_record, rewrite_asset_links
from ..models import FeatureRetrieveRequest, PackageRetrieveRequest, SearchRequest
from ..search import HybridSearchEngine, SearchOutcome
from ..state import get_state

router = APIRouter()


def _public_hit(hit: Dict[str, Any]) -> Dict[str, Any]:
    state = get_state()
    source = dict(hit.get("_source") or {})
    source.pop("embedding", None)
    source.pop("embedding_text", None)
    source["content"] = rewrite_asset_links(str(source.get("content") or ""), state.settings.kb_asset_url_prefix)
    matched_children = source.get("matched_children", [])
    if isinstance(matched_children, list):
        for child in matched_children:
            if isinstance(child, dict) and child.get("content"):
                child["content"] = rewrite_asset_links(str(child["content"]), state.settings.kb_asset_url_prefix)
    paths = source.get("image_paths", []) if isinstance(source.get("image_paths"), list) else []
    asset_prefix = "/" + state.settings.kb_asset_url_prefix.strip("/") + "/"
    source["image_urls"] = [asset_prefix + str(path).lstrip("/") for path in paths]
    links = extract_image_links(source["content"])
    return {
        "_id": hit.get("_id"),
        "_score": hit.get("_score"),
        "_rrf_score": hit.get("_rrf_score"),
        "_rerank_score": hit.get("_rerank_score"),
        "_source": source,
        "content": source["content"],
        "metadata": {
            "filename": source.get("filename"),
            "source_pdf": source.get("source_pdf"),
            "title": source.get("title"),
            "feature_id": source.get("feature_id"),
            "feature_ids": source.get("feature_ids", []),
            "package_ids": source.get("package_ids", []),
            "heading_path": source.get("heading_path"),
            "section_type": source.get("section_type"),
            "feature_association": source.get("feature_association"),
            "page_start": source.get("page_start"),
            "page_end": source.get("page_end"),
            "score": hit.get("_score"),
            "image_links": links,
        },
    }


def _response(query: str, outcome: SearchOutcome) -> Dict[str, Any]:
    hits = [_public_hit(hit) for hit in outcome.hits]
    feature_ids: set[str] = set()
    package_ids: set[str] = set()
    documents: Dict[str, Dict[str, Any]] = {}
    image_links: Dict[str, Dict[str, str]] = {}
    for hit in hits:
        source = hit["_source"]
        for value in source.get("feature_ids", []) or []:
            if value:
                feature_ids.add(str(value))
        if source.get("feature_id"):
            feature_ids.add(str(source["feature_id"]))
        for value in source.get("package_ids", []) or []:
            if value:
                package_ids.add(str(value))
        filename = str(source.get("filename") or "")
        if filename and (filename not in documents or float(hit.get("_score") or 0) > float(documents[filename].get("score") or 0)):
            documents[filename] = {
                "filename": filename,
                "title": source.get("title"),
                "feature_id": source.get("feature_id"),
                "score": hit.get("_score"),
            }
        for link in extract_image_links(str(source.get("content") or "")):
            image_links[link["url"]] = link
    return {
        "query": query,
        "retrievalResults": hits,
        "results": hits,
        "aggregated_feature_ids": sorted(feature_ids),
        "aggregated_package_ids": sorted(package_ids),
        "matched_documents": list(documents.values()),
        "image_links": list(image_links.values()),
        "fallback_type": outcome.mode,
        "warnings": outcome.warnings,
    }


def _search(query: str, limit: int, filters: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
    state = get_state()
    state.rag_logger.info(
        "[KB REQUEST] operation=search query=%r limit=%d filters=%s",
        query,
        limit,
        dict(filters or {}),
    )
    outcome = HybridSearchEngine(state).search(query, limit=limit, filters=filters)
    response = _response(query, outcome)
    state.rag_logger.info(
        "[KB RESPONSE] operation=search parents=%d mode=%s warnings=%d",
        len(outcome.hits),
        outcome.mode,
        len(outcome.warnings),
    )
    return response


@router.post("/kb/search")
def search_post(request: SearchRequest) -> Dict[str, Any]:
    return _search(request.query, request.limit, request.filters.model_dump(exclude_none=True))


@router.get("/kb/search")
def search_get(
    query: str,
    topic: Optional[str] = None,
    limit: int = Query(5, ge=1, le=100),
) -> Dict[str, Any]:
    # ``topic`` is retained for compatibility with the Nokia KB API contract.
    return _search(query if not topic else f"{query} {topic}", limit)


def _feature_retrieve(feature_value: str, request: FeatureRetrieveRequest) -> Dict[str, Any]:
    feature_id = normalize_feature_id(feature_value)
    if not feature_id:
        raise HTTPException(status_code=400, detail="Expected an Ericsson Feature Identity in the form FAJ 121 xxxx")
    state = get_state()
    repository = ManifestRepository(state)
    bundle = repository.feature_bundle(feature_id)
    primary = bundle.get("primary")
    query = request.query or f"Feature {feature_id}"
    title = str(bundle.get("feature_title") or "").strip()
    enriched = f"{query} {title}".strip() if title else query
    warnings: List[str] = []
    outcomes: List[SearchOutcome] = []
    state.rag_logger.info(
        "[KB FEATURE_ROUTE] feature_id=%s title=%s direct_document=%s include_related=%s "
        "query=%r enriched_query=%r limit=%d",
        feature_id,
        single_line(title, max_chars=160),
        (primary or {}).get("filename") if isinstance(primary, dict) else "",
        request.include_related,
        query,
        enriched,
        request.limit,
    )

    if isinstance(primary, dict) and primary.get("filename"):
        outcomes.append(HybridSearchEngine(state).search(
            enriched,
            limit=request.limit,
            filters={"filename": primary["filename"]},
        ))
    else:
        warnings.append(
            f"No dedicated Ericsson Feature Description was resolved for {feature_id}; related package/general documents may be used."
        )

    if request.include_related and (not outcomes or len(outcomes[0].hits) < request.limit):
        related = HybridSearchEngine(state).search(
            enriched,
            limit=request.limit,
            filters={"feature_id": feature_id},
        )
        outcomes.append(related)

    merged: Dict[str, Dict[str, Any]] = {}
    ordered: List[str] = []
    for outcome_index, outcome in enumerate(outcomes):
        warnings.extend(outcome.warnings)
        for hit in outcome.hits:
            source = hit.get("_source") or {}
            key = str(source.get("parent_id") or hit.get("_id") or "")
            if not key:
                continue
            adjusted = dict(hit)
            if outcome_index == 0 and primary:
                adjusted["_score"] = float(adjusted.get("_score") or 0.0) + 1.0
            if key not in merged:
                ordered.append(key)
                merged[key] = adjusted
            elif float(adjusted.get("_score") or 0.0) > float(merged[key].get("_score") or 0.0):
                merged[key] = adjusted
    hits = sorted((merged[key] for key in ordered), key=lambda h: float(h.get("_score") or 0.0), reverse=True)[:request.limit]
    outcome = SearchOutcome(hits=hits, mode="feature_manifest_hybrid", warnings=list(dict.fromkeys(warnings)))
    response = _response(query, outcome)
    related_used = any(str((hit.get("_source") or {}).get("filename") or "") != str((primary or {}).get("filename") or "") for hit in hits)
    state.rag_logger.info(
        "[KB FEATURE_FINAL] feature_id=%s outcome_count=%d merged_parents=%d direct_available=%s "
        "related_used=%s warnings=%d",
        feature_id,
        len(outcomes),
        len(hits),
        bool(primary),
        related_used,
        len(outcome.warnings),
    )
    response.update({
        "feature_id": feature_id,
        "feature_title": title,
        "direct_feature_pdf_available": bool(primary),
        "related_source_used": related_used,
        "citation_only": not bool(hits),
        "blocked_follow_up": False,
        "manifest": public_manifest_record(primary),
        "manifest_record": public_manifest_record(primary),
        "related_manifests": [public_manifest_record(record) for record in bundle.get("related_documents", [])],
        "resolved_source_filename": (primary or {}).get("filename"),
    })
    return response


@router.post("/kb/feature/{feature_id}/retrieve")
def retrieve_feature_post(feature_id: str, request: FeatureRetrieveRequest) -> Dict[str, Any]:
    return _feature_retrieve(feature_id, request)


@router.get("/kb/feature/{feature_id}/retrieve")
def retrieve_feature_get(
    feature_id: str,
    query: Optional[str] = None,
    topic: Optional[str] = None,
    limit: int = Query(10, ge=1, le=100),
    include_related: bool = True,
) -> Dict[str, Any]:
    effective = query if not topic else f"{query or ''} {topic}".strip()
    return _feature_retrieve(feature_id, FeatureRetrieveRequest(query=effective or None, limit=limit, include_related=include_related))


@router.get("/kb/manifest/feature/{feature_id}")
def feature_manifest(feature_id: str) -> Dict[str, Any]:
    bundle = ManifestRepository(get_state()).feature_bundle(feature_id)
    if not bundle.get("records"):
        raise HTTPException(status_code=404, detail="Ericsson feature manifest not found")
    return {
        "feature_id": bundle["feature_id"],
        "feature_title": bundle["feature_title"],
        "primary": public_manifest_record(bundle.get("primary")),
        "direct_documents": [public_manifest_record(record) for record in bundle.get("direct_documents", [])],
        "related_documents": [public_manifest_record(record) for record in bundle.get("related_documents", [])],
        "record_count": len(bundle.get("records", [])),
    }


def _package_retrieve(package_value: str, request: PackageRetrieveRequest) -> Dict[str, Any]:
    package_id = normalize_package_id(package_value)
    if not package_id:
        raise HTTPException(status_code=400, detail="Expected an Ericsson Value Package Identity in the form FAJ 801 xxxx")
    state = get_state()
    bundle = ManifestRepository(state).package_bundle(package_id)
    primary = bundle.get("primary")
    query = request.query or f"Value Package {package_id}"
    filters: Dict[str, Any] = {"package_id": package_id}
    state.rag_logger.info(
        "[KB PACKAGE_ROUTE] package_id=%s direct_document=%s query=%r limit=%d",
        package_id,
        (primary or {}).get("filename") if isinstance(primary, dict) else "",
        query,
        request.limit,
    )
    outcome = HybridSearchEngine(state).search(query, limit=request.limit, filters=filters)
    response = _response(query, outcome)
    state.rag_logger.info(
        "[KB PACKAGE_FINAL] package_id=%s parents=%d warnings=%d",
        package_id,
        len(outcome.hits),
        len(outcome.warnings),
    )
    response.update({
        "package_id": package_id,
        "manifest": public_manifest_record(primary),
        "manifest_record": public_manifest_record(primary),
        "related_manifests": [public_manifest_record(record) for record in bundle.get("documents", [])],
        "resolved_source_filename": (primary or {}).get("filename"),
    })
    return response


@router.post("/kb/package/{package_id}/retrieve")
def retrieve_package_post(package_id: str, request: PackageRetrieveRequest) -> Dict[str, Any]:
    return _package_retrieve(package_id, request)


@router.get("/kb/package/{package_id}/retrieve")
def retrieve_package_get(
    package_id: str,
    query: Optional[str] = None,
    limit: int = Query(10, ge=1, le=100),
) -> Dict[str, Any]:
    return _package_retrieve(package_id, PackageRetrieveRequest(query=query, limit=limit))


@router.get("/kb/manifest/package/{package_id}")
def package_manifest(package_id: str) -> Dict[str, Any]:
    bundle = ManifestRepository(get_state()).package_bundle(package_id)
    if not bundle.get("records"):
        raise HTTPException(status_code=404, detail="Ericsson package manifest not found")
    return {
        "package_id": bundle["package_id"],
        "primary": public_manifest_record(bundle.get("primary")),
        "documents": [public_manifest_record(record) for record in bundle.get("documents", [])],
        "record_count": len(bundle.get("records", [])),
    }


@router.get("/kb/debug/raw-search")
def debug_raw_search(text: str, limit: int = Query(3, ge=1, le=20)) -> Dict[str, Any]:
    return _search(text, limit)
